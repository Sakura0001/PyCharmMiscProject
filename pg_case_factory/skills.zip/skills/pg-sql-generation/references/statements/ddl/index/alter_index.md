# 技能：ALTER INDEX

## 官方语法范围补充

```sql
ALTER INDEX [ IF EXISTS ] name RENAME TO new_name
ALTER INDEX [ IF EXISTS ] name SET TABLESPACE tablespace_name
ALTER INDEX name ATTACH PARTITION index_name
ALTER INDEX name [ NO ] DEPENDS ON EXTENSION extension_name
ALTER INDEX [ IF EXISTS ] name SET ( storage_parameter [= value] [, ... ] )
ALTER INDEX [ IF EXISTS ] name RESET ( storage_parameter [, ... ] )
ALTER INDEX [ IF EXISTS ] name ALTER [ COLUMN ] column_number
    SET STATISTICS integer
ALTER INDEX ALL IN TABLESPACE name [ OWNED BY role_name [, ... ] ]
    SET TABLESPACE new_tablespace [ NOWAIT ]
```

## 语句作用

用于描述 PostgreSQL ALTER INDEX 生成规则。该语句用于修改已有索引的定义，可覆盖索引重命名、迁移表空间、挂接分区索引、声明扩展依赖、调整存储参数、设置统计信息，以及对指定 tablespace 下全部索引做批量迁移。

这个 skill 承担如下职责：

- 定义测试因子与覆盖策略
- 定义 ALTER INDEX 的 SQL 生成范围
- 标识各语法分支的前置依赖与失败路径边界

## 语法范围

ALTER INDEX [ IF EXISTS ] name RENAME TO new_name
ALTER INDEX [ IF EXISTS ] name SET TABLESPACE tablespace_name
ALTER INDEX name ATTACH PARTITION index_name
ALTER INDEX name [ NO ] DEPENDS ON EXTENSION extension_name
ALTER INDEX [ IF EXISTS ] name SET ( storage_parameter [= value] [, ... ] )
ALTER INDEX [ IF EXISTS ] name RESET ( storage_parameter [, ... ] )
ALTER INDEX [ IF EXISTS ] name ALTER [ COLUMN ] column_number
    SET STATISTICS integer
ALTER INDEX ALL IN TABLESPACE name [ OWNED BY role_name [, ... ] ]
    SET TABLESPACE new_tablespace [ NOWAIT ]

## 测试因子分级

### T1：核心语义因子
- IF EXISTS 是否指定
- NO 是否指定
- SET STATISTICS 是否显式携带 COLUMN
- ALL IN TABLESPACE 是否显式携带 OWNED BY
- ALL IN TABLESPACE 是否显式携带 NOWAIT

### T2：重要行为因子
- 语句分支类型：
  - RENAME
  - SET TABLESPACE
  - ATTACH PARTITION
  - DEPENDS ON EXTENSION / NO DEPENDS ON EXTENSION
  - SET STORAGE
  - RESET STORAGE
  - SET STATISTICS
  - ALL IN TABLESPACE SET TABLESPACE

### T3：对象名与标识符因子
- `name / new_name / tablespace_name / index_name / extension_name / source_tablespace / new_tablespace / role_name` 的输入形态
- 代表性取值：
  - 合法标识符
  - 带引号标识符
  - 保留字
  - 空字符串
  - 特殊字符
  - 已存在对象名
  - 不存在对象名

### T4：storage_parameter 因子
- 单个参数
- 多个参数
- 显式 value
- 不显式 value

### T5：数值输入因子
- `column_number / statistics_value` 的输入形态
- 代表性取值：
  - 负整数
  - 0
  - 正整数
  - 小数
  - 负小数

### T6：OWNED BY 角色列表因子
- 单个 role
- 多个 role

## 覆盖策略
- 需要覆盖所有 ALTER INDEX 语法分支。
- 需要覆盖所有基表。
- 需要覆盖每张基表中所有的列类型。
- T1 和 T2 作为主覆盖因子。
- T1 因子做笛卡尔积覆盖。
- T2 因子按规模控制策略参与组合：
  - 当组合规模可控时，与 T1 一起参与笛卡尔积覆盖。
  - 当组合规模过大时，优先保留 T1 的完整覆盖，对 T2 做裁剪、抽样或轮转覆盖。
- `IF EXISTS` 仅挂到支持 `IF EXISTS` 的分支。
- `NO` 仅挂到 `DEPENDS ON EXTENSION` 分支。
- `COLUMN` 仅挂到 `SET STATISTICS` 分支。
- `OWNED BY / NOWAIT` 仅挂到 `ALL IN TABLESPACE` 分支。
- T3、T4、T5、T6 不进入全局主笛卡尔积，仅作为附属因子挂靠到代表性主样本上。
- 必须同时保留成功路径与失败路径。
- 如果生成规模超过 100 万，优先裁剪 T3-T6，再裁剪局部语法开关，最后才允许压缩语句分支数量。
## 生成约束

- 必须覆盖所有基表列类型。
- 必须覆盖已有索引成功修改的路径。
- 必须覆盖目标索引不存在、但 `IF EXISTS` 缺失时的失败路径。
- 必须覆盖目标索引不存在、但 `IF EXISTS` 存在时的代表性 no-op 路径。
- `ATTACH PARTITION` 仅能挂到已准备好父分区索引与子分区索引的生命周期样本。
- `SET TABLESPACE` 与 `ALL IN TABLESPACE ... SET TABLESPACE` 的成功路径依赖预创建 tablespace。
- `DEPENDS ON EXTENSION` 的成功路径依赖扩展存在。
- `OWNED BY` 的成功路径依赖角色存在；角色数量变化应保留代表性覆盖。
- `SET ( storage_parameter = value )` 与 `RESET ( storage_parameter )` 既要覆盖合法组合，也要覆盖语法或语义非法组合。
- `column_number / statistics_value` 的非法数值形态应作为失败路径保留，不得误判为成功样本。

## 挂靠规则

- T3 因子挂靠到 `RENAME`、`SET TABLESPACE`、`ATTACH PARTITION`、`DEPENDS ON EXTENSION`、`ALL IN TABLESPACE` 等代表性分支上轮转注入。
- T4 因子仅挂靠到 `SET STORAGE` 与 `RESET STORAGE` 分支。
- T5 因子仅挂靠到 `SET STATISTICS` 分支。
- T6 因子仅挂靠到包含 `OWNED BY` 的 `ALL IN TABLESPACE` 分支。
- 单条样本允许同时挂靠多个低优先级因子，但不得破坏语句分支与成功/失败归因的可识别性。

## 规模控制规则

- 优先保证：
  - 各语句分支全覆盖
  - 语法开关代表性覆盖
  - 已存在 / 不存在 / 非法标识符输入全覆盖
  - 成功 / 失败路径全覆盖
- 次优先保证：
  - storage_parameter 写法全覆盖
  - 数值输入形态全覆盖
  - `OWNED BY` 角色数量全覆盖
- 低优先级因子仅保证冒烟覆盖与代表性覆盖。

## 输出要求

- 生成结果应为可执行的 PostgreSQL ALTER INDEX 测试样本集合。
- 输出样本应具备明确因子归因能力。
- 对于依赖分区索引、tablespace、extension、role 的分支，应在生命周期计划里显式准备前置对象。
- 当采用裁剪策略时，应优先保留语句分支、成功/失败路径和标识符输入形态的覆盖。