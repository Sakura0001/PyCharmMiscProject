# 技能：CREATE INDEX

## 官方语法范围补充

```sql
CREATE [ UNIQUE ] INDEX [ CONCURRENTLY ] [ [ IF NOT EXISTS ] name ] ON [ ONLY ] table_name [ USING method ]
    ( { column_name | ( expression ) } [ COLLATE collation ] [ opclass [ ( opclass_parameter = value [, ... ] ) ] ] [ ASC | DESC ] [ NULLS { FIRST | LAST } ] [, ...] )
    [ INCLUDE ( column_name [, ...] ) ]
    [ NULLS [ NOT ] DISTINCT ]
    [ WITH ( storage_parameter [= value] [, ... ] ) ]
    [ TABLESPACE tablespace_name ]
    [ WHERE predicate ]
```

## 语句作用

用于描述普通表上的 PostgreSQL CREATE INDEX 生成规则。该语句用于在指定表上创建索引，以提升查询访问效率；可生成普通索引、唯一索引、部分索引、覆盖索引，并支持不同索引方法与并发构建模式。

这个 skill 承担如下职责：

- 定义测试因子与覆盖策略
- 定义 CREATE INDEX 的 SQL 生成范围

## 语法范围

CREATE [ UNIQUE ] INDEX [ CONCURRENTLY ] [ [ IF NOT EXISTS ] name ]
ON table_name USING method
(
  column_name [ ASC | DESC ] [ NULLS { FIRST | LAST } ]
)
[ INCLUDE ( column_name [, ...] ) ]
[ WITH ( storage_parameter [= value] [, ... ] ) ]
[ TABLESPACE tablespace_name ]
[ WHERE predicate ]

## 测试因子分级

### T1：核心语义因子
- method
- column_name 对应的列类型
- UNIQUE
- WHERE predicate
- INCLUDE
- CONCURRENTLY

### T2：重要行为因子
- ASC | DESC
- NULLS FIRST | LAST
- IF NOT EXISTS

### T3：附属实现因子
- WITH ( storage_parameter = value )
- TABLESPACE tablespace_name

### T4：低优先级补点因子
- name 是否显式指定
- 命名风格
- predicate 写法风格差异
- WITH 参数的大量边缘枚举值

## 覆盖策略
- 需要覆盖所有基表。
- 需要覆盖每张基表中所有的列类型。
- T1 和 T2 作为主覆盖因子。
- T1 因子做笛卡尔积覆盖。
- T2 因子按规模控制策略参与组合：
  - 当组合规模可控时，与 T1 一起参与笛卡尔积覆盖。
  - 当组合规模过大时，优先保留 T1 的完整覆盖，对 T2 做裁剪、抽样或轮转覆盖。
- T3 和 T4 不进入主笛卡尔积，仅作为挂靠因子附着到已生成的主样本上。
- 非重要因子做轮转挂靠，保证每个因子及其主要取值至少被覆盖一次。
- 如果生成用例规模超过 100 万，优先优化 T2 级别因子，尽量保持 T1 完整覆盖，同时保留 T2 的代表性覆盖。
- 如果优化后规模仍超过阈值，允许保留生成程序到 `artifacts/generated_programs/`，由程序继续负责裁剪和展开。
## 生成约束

- 必须覆盖所有基表列类型。
- 必须同时覆盖成功路径与失败路径。
- 必须覆盖不同 method 下的合法与非法组合。
- T1 因子不得因规模问题被整体省略。
- T2 因子允许降级为代表性覆盖。
- T3、T4 因子仅允许挂靠，不单独扩展为主维度。

## 挂靠规则

- T3 因子挂靠到 T1/T2 已生成样本上轮转注入。
- T4 因子挂靠到包含代表性 method、列类型、唯一性、部分索引、覆盖索引等主样本上轮转注入。
- 单条样本允许同时挂靠多个低优先级因子，但不得破坏主覆盖因子的可识别性与可归因性。

## 规模控制规则

- 优先保证：
  - method 全覆盖
  - 列类型全覆盖
  - UNIQUE 全覆盖
  - WHERE predicate 全覆盖
  - INCLUDE 全覆盖
  - CONCURRENTLY 代表性覆盖
- 次优先保证：
  - ASC | DESC 全覆盖
  - NULLS FIRST | LAST 全覆盖
  - IF NOT EXISTS 全覆盖
- 低优先级因子仅保证冒烟覆盖与代表性覆盖。

## 输出要求

- 生成结果应为可执行的 PostgreSQL CREATE INDEX 测试样本集合。
- 输出样本应具备明确因子归因能力。
- 输出样本应避免无意义重复。
- 当采用裁剪策略时，应优先保留核心语义覆盖样本。

## 结构化配置

```yaml
structured_config:
  kind: statement
  domain: index
  skill_name: create_index
  statement:
    key: create_index
    name: CREATE INDEX
    aliases:
      - create index
      - 创建索引
      - 索引创建
    purpose: 在指定表上创建 PostgreSQL 索引，覆盖 method、列类型、唯一性、部分索引、覆盖索引和并发构建等因子。
  syntax_templates:
    - CREATE [ UNIQUE ] INDEX [ CONCURRENTLY ] [ [ IF NOT EXISTS ] name ] ON [ ONLY ] table_name [ USING method ] ( column_name [ ASC | DESC ] [ NULLS { FIRST | LAST } ] ) [ INCLUDE ( column_name [, ...] ) ] [ WITH ( storage_parameter [= value] [, ... ] ) ] [ TABLESPACE tablespace_name ] [ WHERE predicate ]
  factor_layers:
    - tier: T1
      name: 核心语义因子
      factors: [method, column_source, unique, predicate, include, concurrently]
    - tier: T2
      name: 重要行为因子
      factors: [order, nulls, if_not_exists]
    - tier: T3
      name: 附属实现因子
      factors: [with_storage, tablespace]
    - tier: T4
      name: 低优先级补点因子
      factors: [name_style, predicate_style]
  factors:
    method:
      label: index method
      importance: important
      values: [btree, hash, gist, spgist, gin, brin]
    column_source:
      label: column_name 对应的列类型
      importance: important
      values:
        - all_template_columns
    unique:
      label: UNIQUE
      importance: important
      values: ["false", "true"]
    predicate:
      label: WHERE predicate
      importance: important
      values: ["false", "true"]
    include:
      label: INCLUDE
      importance: important
      values: ["false", "true"]
    concurrently:
      label: CONCURRENTLY
      importance: important
      values: ["false", "true"]
    order:
      label: ASC | DESC
      importance: non_important
      values: [none, asc, desc]
    nulls:
      label: NULLS FIRST | LAST
      importance: non_important
      values: [none, first, last]
    if_not_exists:
      label: IF NOT EXISTS
      importance: non_important
      values: ["false", "true"]
    with_storage:
      label: WITH storage_parameter
      importance: non_important
      values: [none, method_storage]
    tablespace:
      label: TABLESPACE
      importance: non_important
      values: [none, pg_default]
    name_style:
      label: name 是否显式指定
      importance: non_important
      values: [explicit_compact, explicit_semantic, implicit]
    predicate_style:
      label: predicate 写法风格
      importance: non_important
      values: [is_not_null, range_guard, parenthesized]
  defaults:
    order: none
    nulls: none
    if_not_exists: "false"
    with_storage: none
    tablespace: none
    name_style: explicit_compact
    predicate_style: is_not_null
  coverage_policy:
    main_combination_axes: [method, column_source, unique, predicate, include, concurrently]
    non_main_factors: [order, nulls, if_not_exists, with_storage, tablespace, name_style, predicate_style]
    dynamic_factor_sources:
      column_source: base_object_columns
    python_expand_threshold: 200
    max_generated_sql: 1000000
    preserve_axes_first: [method, column_source, unique, predicate, include]
  rendering:
    statement_template: CREATE {unique_clause}INDEX {concurrently_clause}{if_not_exists_clause}{index_name_clause}ON {table_name} USING {method} ({column_name}{order_clause}{nulls_clause}){include_clause}{with_clause}{tablespace_clause}{predicate_clause};
    verification_query_template: SELECT c.relname AS index_name, i.indisvalid AS is_valid FROM pg_class c JOIN pg_index i ON i.indexrelid = c.oid WHERE c.relname = '{index_name}' ORDER BY c.relname;
    factor_value_bindings:
      method:
        factor: method
        values:
          btree: btree
          hash: hash
          gist: gist
          spgist: spgist
          gin: gin
          brin: brin
      unique_clause:
        factor: unique
        values:
          "false": ""
          "true": "UNIQUE "
      concurrently_clause:
        factor: concurrently
        values:
          "false": ""
          "true": "CONCURRENTLY "
      if_not_exists_clause:
        factor: if_not_exists
        values:
          "false": ""
          "true": "IF NOT EXISTS "
      order_clause:
        factor: order
        values:
          none: ""
          asc: " ASC"
          desc: " DESC"
      nulls_clause:
        factor: nulls
        values:
          none: ""
          first: " NULLS FIRST"
          last: " NULLS LAST"
```
