# 技能：ALTER COLLATION

## 官方语法范围补充

```sql
ALTER COLLATION name REFRESH VERSION

ALTER COLLATION name RENAME TO new_name
ALTER COLLATION name OWNER TO { new_owner | CURRENT_ROLE | CURRENT_USER | SESSION_USER }
ALTER COLLATION name SET SCHEMA new_schema
```

## 语句作用

用于描述 PostgreSQL `ALTER COLLATION` 生成规则。该语句用于更改已有校对规则的定义，可覆盖刷新版本信息、重命名、修改属主、迁移 schema，以及对象不存在、权限不足、目标对象冲突、目标 schema 或 owner 不存在、被其他对象引用等成功与失败路径。

这个 skill 承担如下职责：

- 定义测试因子与覆盖策略
- 定义 `ALTER COLLATION` 的 SQL 生成范围
- 标识各语法分支的前置依赖、权限边界与失败路径归因

## 语法范围

ALTER COLLATION name REFRESH VERSION
ALTER COLLATION name RENAME TO new_name
ALTER COLLATION name OWNER TO { new_owner | CURRENT_ROLE | CURRENT_USER | SESSION_USER }
ALTER COLLATION name SET SCHEMA new_schema

## 测试因子分级

### T1：核心语义因子

- 语句分支类型：
  - REFRESH VERSION
  - RENAME TO
  - OWNER TO
  - SET SCHEMA
- 执行用户与权限：
  - super 用户
  - collation owner
  - 普通用户
  - 无权限用户
- `new_owner` 目标形式，仅适用于 `OWNER TO`：
  - 普通用户
  - super 用户
  - 当前 owner
  - CURRENT_ROLE
  - CURRENT_USER
  - SESSION_USER

### T2：重要行为因子

- collation 状态：
  - collation 存在
  - collation 不存在
  - collation 被其他对象引用
- `RENAME TO` 目标状态：
  - `new_name` 为新名称
  - `new_name` 已存在
- `SET SCHEMA` 目标状态：
  - 目标 schema 存在
  - 目标 schema 中已存在同名 collation

### T3：异常场景因子

- `new_owner` 不存在
- `new_schema` 不存在
- 执行用户无对象所有权或无目标 schema CREATE 权限
- 非法或边界标识符：
  - 空字符串
  - 保留字
  - 特殊字符
  - 带引号标识符

### T4：标识符与依赖补点因子

- `name / new_name / new_schema / new_owner` 的输入形态
- schema 限定名与非限定名
- 依赖对象类型：
  - 无依赖对象
  - 表字段显式使用该 collation
  - 索引或表达式依赖该 collation

## 覆盖策略
- 需要覆盖所有 `ALTER COLLATION` 语法分支。
- 不需要覆盖所有基表。
- 不需要覆盖每张基表中所有的列类型。
- `ALTER COLLATION` 是对象级 DDL，不要求覆盖普通表中的所有列类型；仅在“被其他对象引用”场景中准备最小依赖对象。
- T1 和 T2 作为主覆盖因子。
- T1 因子做笛卡尔积覆盖，但 `new_owner` 仅挂到 `OWNER TO` 分支。
- T2 因子按分支适用性参与组合：
  - `collation 存在 / 不存在 / 被引用` 适用于所有分支。
  - `new_name 新名称 / 已存在` 仅适用于 `RENAME TO`。
  - `目标 schema 存在 / 目标 schema 同名冲突` 仅适用于 `SET SCHEMA`。
- T3、T4 不进入全局主笛卡尔积，仅作为附属因子挂靠到代表性主样本上。
- 必须同时保留成功路径、失败路径和权限路径。
- 如果生成规模超过 100 万，优先裁剪 T4，再裁剪 T3，最后才允许压缩 T1/T2 的分支组合。
## 生成约束

- 成功路径必须先创建测试 schema、测试 collation 和必要角色。
- 测试 collation 优先使用 `CREATE COLLATION <name> FROM "C"` 构造，避免依赖环境特定 locale。
- 所有对象名必须带任务唯一前缀，结束清理必须使用 `CASCADE` 覆盖依赖对象。
- `REFRESH VERSION` 必须覆盖 collation 存在、collation 不存在、权限不足、被依赖对象引用的路径；验证可读取 `pg_collation.collversion` 与 `pg_collation_actual_version(oid)`。
- `RENAME TO` 必须覆盖新名称成功、`new_name` 已存在失败、collation 不存在失败、权限不足失败、被引用后重命名仍能通过依赖关系解析的路径。
- `OWNER TO` 必须覆盖 owner、普通用户、super 用户、CURRENT_ROLE、CURRENT_USER、SESSION_USER，以及 `new_owner` 不存在失败路径；成功样本需保证目标 owner 对所在 schema 具备必要权限。
- `SET SCHEMA` 必须覆盖目标 schema 存在成功、`new_schema` 不存在失败、目标 schema 同名 collation 冲突失败、权限不足失败、被引用对象随依赖关系保持一致的路径。
- 普通用户与无权限用户场景必须明确区分：普通用户可以作为目标 owner 或对象 owner；无权限用户用于验证非 owner 执行 `ALTER COLLATION` 的失败路径。
- 被其他对象引用的场景应至少创建一张表字段使用该 collation，例如 `text COLLATE <collation>`，并在变更后查询 catalog 或执行稳定排序查询验证依赖仍可解析。
- 失败路径必须使用预期失败包装，不得让单个失败样本中断整批 SQL 执行。

## 挂靠规则

- T3 异常场景挂靠到对应语法分支的代表性样本：
  - `new_owner` 不存在仅挂到 `OWNER TO`。
  - `new_schema` 不存在仅挂到 `SET SCHEMA`。
  - `new_name` 已存在仅挂到 `RENAME TO`。
  - 无权限用户覆盖所有分支各至少一个样本。
- T4 标识符因子在四个分支上轮转挂靠，必须包含合法标识符、带引号标识符、保留字、特殊字符和空字符串失败样本。
- 被引用对象因子在 `REFRESH VERSION`、`RENAME TO`、`OWNER TO`、`SET SCHEMA` 各至少保留一个成功或预期失败样本，确保依赖对象生命周期闭环。
- 单条样本允许同时挂靠多个低优先级因子，但不得破坏语句分支、权限路径和成功/失败归因的可识别性。

## 规模控制规则

- 优先保证：
  - 四个语法分支全覆盖
  - super 用户、owner、普通用户、无权限用户路径全覆盖
  - collation 存在、不存在、被引用状态全覆盖
  - `new_name` 已存在、`new_owner` 不存在、`new_schema` 不存在、目标 schema 冲突全覆盖
  - 成功、失败、权限失败路径全覆盖
- 次优先保证：
  - CURRENT_ROLE、CURRENT_USER、SESSION_USER 目标 owner 形式全覆盖
  - schema 限定名与非限定名全覆盖
  - 合法、带引号、保留字、特殊字符标识符形态全覆盖
- 低优先级因子仅保证冒烟覆盖与代表性覆盖。

## 输出要求

- 生成结果应为可执行的 PostgreSQL `ALTER COLLATION` 测试样本集合。
- 输出样本应具备明确因子归因能力。
- 对于依赖 role、schema、table、index 的分支，应在生命周期计划里显式准备前置对象。
- 对需要 super 用户的 setup 和 cleanup，SQL 文件中必须明确隔离该阶段，避免把权限失败误归因为环境缺失。
- 当采用裁剪策略时，应优先保留语句分支、权限路径、对象状态和异常场景覆盖。