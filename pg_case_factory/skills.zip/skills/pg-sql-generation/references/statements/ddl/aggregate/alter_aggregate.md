# 技能：ALTER AGGREGATE

## 官方语法范围补充

```sql
ALTER AGGREGATE name ( aggregate_signature ) RENAME TO new_name
ALTER AGGREGATE name ( aggregate_signature )
                OWNER TO { new_owner | CURRENT_ROLE | CURRENT_USER | SESSION_USER }
ALTER AGGREGATE name ( aggregate_signature ) SET SCHEMA new_schema

where aggregate_signature is:

* |
[ argmode ] [ argname ] argtype [ , ... ] |
[ [ argmode ] [ argname ] argtype [ , ... ] ] ORDER BY [ argmode ] [ argname ] argtype [ , ... ]
```

## 语句作用

用于描述 PostgreSQL ALTER AGGREGATE 生成规则。该语句用于修改已有聚合函数的元数据，可覆盖聚合函数重命名、所有者变更，以及迁移到其他 schema。

这个 skill 承担如下职责：

- 定义测试因子与覆盖策略
- 定义 ALTER AGGREGATE 的 SQL 生成范围
- 标识聚合函数签名、权限、schema 迁移、依赖对象与失败路径边界

## 语法范围

ALTER AGGREGATE name ( aggregate_signature ) RENAME TO new_name
ALTER AGGREGATE name ( aggregate_signature )
    OWNER TO { new_owner | CURRENT_ROLE | CURRENT_USER | SESSION_USER }
ALTER AGGREGATE name ( aggregate_signature ) SET SCHEMA new_schema

where aggregate_signature is:

*
[ argmode ] [ argname ] argtype [ , ... ]
[ [ argmode ] [ argname ] argtype [ , ... ] ] ORDER BY
    [ argmode ] [ argname ] argtype [ , ... ]

## 测试因子分级

### T1：aggregate_signature 因子
- `*` 零参数聚合签名
- 单参数签名
- 多参数签名
- 带参数模式的签名，例如 `IN arg integer`
- 带参数名称的签名
- ordered-set 聚合签名，包含 direct argument 与 `ORDER BY` argument
- 多 `ORDER BY` 字段签名
- 参数类型为自定义类型
- 参数名为关键字或需要双引号引用

### T2：聚合函数形态因子
- 单参数聚合函数
- 多参数聚合函数
- 零参数聚合函数
- ordered-set 聚合函数
- 参数类型为自定义类型的聚合函数
- 名称与 `avg / min / max` 等常见聚合语义相似的用户自定义聚合函数

### T3：new_name / new_owner / new_schema 因子
- 合法新名称
- 已存在同名聚合函数
- 特殊字符与双引号标识符
- 存在用户
- 不存在用户
- `CURRENT_ROLE`
- `CURRENT_USER`
- `SESSION_USER`
- 存在且具备 `CREATE` 权限的目标 schema
- 存在但无 `CREATE` 权限的目标 schema
- 不存在的 schema
- 目标 schema 中已存在同名同签名聚合函数

### T4：权限与角色因子
- 当前用户是聚合函数所有者
- 当前用户不是聚合函数所有者
- 当前用户是新所有者的成员
- 当前用户不是新所有者的成员
- admin / superuser 用户执行任意操作
- 用户具备目标 schema 的 `CREATE` 权限
- 用户不具备目标 schema 的 `CREATE` 权限

### T5：异常与边界因子
- 聚合函数类型错误
- 聚合参数多参数或少参数
- 聚合参数类型不匹配
- ordered-set 聚合的 direct argument 与 `ORDER BY` argument 不匹配
- 聚合函数不存在
- 新名称非法或引用后仍冲突
- 目标 owner 不存在
- 目标 schema 不存在
- `*` 被错误用于非零参数聚合

### T6：依赖和影响因子
- 聚合函数被视图引用
- 聚合函数被其他函数调用
- `SET SCHEMA` 后原 schema 中消失，目标 schema 中出现
- `RENAME TO` 后依赖视图或函数仍可执行
- `OWNER TO` 后 `pg_proc.proowner` 变化
- `pg_aggregate` 与 `pg_proc` 系统表中聚合函数身份保持一致
- OWNER 变更后权限继承与成员关系生效

## 覆盖策略
- 需要覆盖所有 ALTER AGGREGATE 语法分支：
  - `RENAME TO`
  - `OWNER TO new_owner`
  - `OWNER TO CURRENT_ROLE`
  - `OWNER TO CURRENT_USER`
  - `OWNER TO SESSION_USER`
  - `SET SCHEMA`
- 不需要覆盖所有基表。
- 不需要覆盖每张基表中所有的列类型。
- T1 和 T2 强相关，应使用“聚合函数形态 + 合法签名”的绑定组合做主覆盖，不做无约束笛卡尔积。
- T1/T2 绑定组合需要覆盖单参数、多参数、零参数、ordered-set、自定义类型、参数模式、参数名称、关键字参数名和多 `ORDER BY` 字段。
- `RENAME TO / OWNER TO / SET SCHEMA` 语法分支与 T1/T2 绑定组合作为主覆盖因子。
- T3、T4、T5、T6 不进入全局主笛卡尔积，仅作为附属因子挂靠到代表性主样本上。
- 对 T1/T2 不匹配的组合应作为 T5 失败路径单独保留，例如签名参数个数或类型错误。
- 必须同时保留成功路径与失败路径。
- 成功路径不得修改 PostgreSQL 内置 `pg_catalog` 聚合函数；涉及 `avg / min / max` 语义时，应创建用户自定义聚合函数承载测试。
- 如果生成规模超过 100 万，优先裁剪 T3-T6，再裁剪 `OWNER TO` 的角色别名分支，最后才允许压缩 T1/T2 绑定组合。
## 生成约束

- 必须预创建用于成功路径的用户自定义聚合函数，不能直接改写内置聚合函数。
- 必须为每种聚合函数形态准备匹配的 `CREATE AGGREGATE` 前置对象。
- 单参数、多参数、零参数、ordered-set 和自定义类型聚合函数都必须有成功修改路径。
- `ALTER AGGREGATE name ( aggregate_signature )` 中的签名必须与目标聚合函数身份一致；参数名不参与 PostgreSQL 聚合函数身份判断，但应覆盖可解析的命名写法。
- `RENAME TO` 的失败路径必须覆盖目标名称已存在同签名聚合函数。
- `OWNER TO new_owner` 的成功路径依赖目标 role 存在，且执行用户能够成为该 role；失败路径必须覆盖 role 不存在或无成员关系。
- `OWNER TO CURRENT_ROLE / CURRENT_USER / SESSION_USER` 必须作为独立代表性分支覆盖。
- `SET SCHEMA` 的成功路径依赖目标 schema 存在并具备 `CREATE` 权限；失败路径必须覆盖目标 schema 不存在、无 `CREATE` 权限、目标 schema 已有同名同签名聚合函数。
- 当前用户不是聚合函数所有者时，非 admin 用户执行 `RENAME TO / OWNER TO / SET SCHEMA` 应作为失败路径保留。
- admin / superuser 执行路径应覆盖权限绕过能力，但仍不得破坏系统内置对象。
- 聚合函数被视图或其他函数引用时，`RENAME TO / SET SCHEMA / OWNER TO` 后应验证依赖对象行为和系统目录状态。
- `SET SCHEMA` 后必须验证原 schema 中查不到该聚合函数，目标 schema 中可以通过 `pg_proc` 与 `pg_aggregate` 查询到该聚合函数。
- OWNER 变更后必须验证 `pg_proc.proowner` 与目标 role 一致，并验证后续权限继承路径。

## 挂靠规则

- T3 因子按分支挂靠：
  - `new_name` 仅挂靠到 `RENAME TO`
  - `new_owner / CURRENT_ROLE / CURRENT_USER / SESSION_USER` 仅挂靠到 `OWNER TO`
  - `new_schema` 仅挂靠到 `SET SCHEMA`
- T4 权限因子挂靠到所有语法分支的代表性成功和失败样本上。
- T5 异常与边界因子挂靠到对应可归因分支：
  - 签名类型错误、参数过多或过少挂靠到所有语法分支的代表性样本
  - ordered-set 参数不匹配挂靠到 ordered-set 聚合样本
  - 已存在同名聚合函数挂靠到 `RENAME TO` 与 `SET SCHEMA`
  - role 不存在挂靠到 `OWNER TO new_owner`
  - schema 不存在挂靠到 `SET SCHEMA`
- T6 依赖和影响因子挂靠到稳定成功路径上，优先选择单参数聚合、多参数聚合和 ordered-set 聚合各至少一个样本。
- 单条样本允许同时挂靠多个低优先级因子，但不得破坏语句分支、聚合签名、权限预期和成功/失败归因的可识别性。

## 规模控制规则

- 优先保证：
  - 所有 ALTER AGGREGATE 语法分支全覆盖
  - T1/T2 合法绑定组合全覆盖
  - 单参数、多参数、零参数、ordered-set、自定义类型聚合全覆盖
  - 成功 / 失败路径全覆盖
  - 权限核心路径全覆盖：owner、非 owner、新 owner 成员、无成员关系、admin
- 次优先保证：
  - `new_name / new_owner / new_schema` 的合法、冲突、不存在、无权限取值全覆盖
  - quoted identifier、关键字参数名、特殊字符名称代表性覆盖
  - 依赖视图、依赖函数、系统表验证代表性覆盖
- 低优先级因子仅保证冒烟覆盖与代表性覆盖。

## 输出要求

- 生成结果应为可执行的 PostgreSQL ALTER AGGREGATE 测试样本集合。
- 输出样本应具备明确因子归因能力。
- 每个成功路径都应包含前置聚合函数创建、目标 ALTER AGGREGATE、系统目录或行为验证、结束清理。
- 每个失败路径都应包含明确的失败原因，不应与其他失败因子混杂。
- 对 role、schema、type、support function、aggregate、view、dependent function 等前置对象，应在生命周期计划里显式准备和清理。
- 当采用裁剪策略时，应优先保留语句分支、T1/T2 绑定组合、权限路径和成功/失败路径的覆盖。