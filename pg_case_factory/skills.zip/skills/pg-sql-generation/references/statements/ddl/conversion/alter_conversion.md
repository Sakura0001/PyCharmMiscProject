# 技能：ALTER CONVERSION

## 官方语法范围补充

```sql
ALTER CONVERSION name RENAME TO new_name
ALTER CONVERSION name OWNER TO { new_owner | CURRENT_ROLE | CURRENT_USER | SESSION_USER }
ALTER CONVERSION name SET SCHEMA new_schema
```

## 语句作用

用于描述 PostgreSQL `ALTER CONVERSION` 生成规则。该语句用于更改已有字符集转换对象的元数据，可覆盖转换重命名、修改属主、迁移 schema，以及 conversion 不存在、权限不足、目标对象冲突、目标 schema 或 owner 不存在、依赖关系保持等成功与失败路径。

这个 skill 承担如下职责：

- 定义测试因子与覆盖策略
- 定义 `ALTER CONVERSION` 的 SQL 生成范围
- 标识各语法分支的前置依赖、权限边界、依赖关系与失败路径归因

## 语法范围

ALTER CONVERSION name RENAME TO new_name
ALTER CONVERSION name OWNER TO { new_owner | CURRENT_ROLE | CURRENT_USER | SESSION_USER }
ALTER CONVERSION name SET SCHEMA new_schema

## 测试因子分级

### T1：核心语义因子

- 语句分支类型：
  - RENAME TO
  - OWNER TO
  - SET SCHEMA
- 执行用户与权限：
  - super 用户
  - conversion owner
  - 普通用户
  - 无权限用户
- `new_owner` 目标形式，仅适用于 `OWNER TO`：
  - 普通用户
  - super 用户
  - 当前 owner
  - CURRENT_ROLE
  - CURRENT_USER
  - SESSION_USER

### T2：conversion 状态因子

- conversion 存在
- conversion 不存在
- conversion 为指定编码对的 DEFAULT conversion
- conversion 保留对转换函数的依赖关系
- schema 限定名与非限定名

### T3：异常场景因子

- `RENAME TO` 目标状态：
  - `new_name` 为新名称
  - `new_name` 已存在
- `OWNER TO` 目标状态：
  - `new_owner` 存在
  - `new_owner` 不存在
  - 执行用户不是目标 owner 的成员
- `SET SCHEMA` 目标状态：
  - 目标 schema 存在
  - `new_schema` 不存在
  - 目标 schema 中已存在同名 conversion
  - 执行用户无目标 schema `CREATE` 权限

### T4：标识符与边界补点因子

- `name / new_name / new_schema / new_owner` 的输入形态
- 合法标识符、带引号标识符、保留字、特殊字符、空字符串失败样本
- 源编码与目标编码组合：
  - `UTF8` 到 `LATIN1`
  - `LATIN1` 到 `UTF8`
  - 非法编码名称失败样本
- 转换函数状态：
  - 转换函数存在且签名合法
  - 转换函数不存在
  - 转换函数签名不满足 conversion 要求

## 覆盖策略
- 需要覆盖所有 `ALTER CONVERSION` 语法分支。
- 不需要覆盖所有基表。
- 不需要覆盖每张基表中所有的列类型。
- `ALTER CONVERSION` 是对象级 DDL，不要求覆盖普通表中的所有列类型或所有表类型。
- T1 和 T2 作为主覆盖因子。
- T1 因子做笛卡尔积覆盖，但 `new_owner` 仅挂到 `OWNER TO` 分支。
- T2 因子按分支适用性参与组合：
  - `conversion 存在 / 不存在` 适用于所有分支。
  - `DEFAULT conversion` 与转换函数依赖关系适用于所有成功变更分支的代表性样本。
  - schema 限定名与非限定名在三个分支上轮转覆盖。
- T3、T4 不进入全局主笛卡尔积，仅作为附属因子挂靠到代表性主样本上。
- 必须同时保留成功路径、失败路径和权限路径。
- 如果生成规模超过 100 万，优先裁剪 T4，再裁剪 T3，最后才允许压缩 T1/T2 的分支组合。
## 生成约束

- 成功路径必须先创建测试 schema、测试 role、转换函数和测试 conversion。
- 测试 conversion 应使用任务唯一前缀命名，避免与系统内置 conversion 或其他用例冲突。
- 测试 conversion 不得直接修改 PostgreSQL 内置 `pg_catalog` conversion；内置 conversion 只能作为只读查询或冲突参照，不作为 ALTER 成功目标。
- 自定义 conversion 的前置函数必须满足 `CREATE CONVERSION` 对转换函数的签名要求，且应放在受控测试 schema 中。
- 结束清理必须按依赖顺序删除 conversion、转换函数、schema 和 role；必要时使用 `CASCADE` 清理依赖对象。
- `RENAME TO` 必须覆盖新名称成功、`new_name` 已存在失败、conversion 不存在失败、权限不足失败、DEFAULT conversion 重命名后 catalog 状态仍一致的路径。
- `OWNER TO` 必须覆盖 owner、普通用户、super 用户、CURRENT_ROLE、CURRENT_USER、SESSION_USER，以及 `new_owner` 不存在失败路径；成功样本需保证目标 owner 对所在 schema 具备必要权限。
- `SET SCHEMA` 必须覆盖目标 schema 存在成功、`new_schema` 不存在失败、目标 schema 同名 conversion 冲突失败、权限不足失败、迁移后原 schema 消失且目标 schema 可查询到目标 conversion 的路径。
- 普通用户与无权限用户场景必须明确区分：普通用户可以作为目标 owner 或 conversion owner；无权限用户用于验证非 owner 执行 `ALTER CONVERSION` 的失败路径。
- conversion 的依赖关系应通过 `pg_conversion`、`pg_depend`、`pg_namespace` 和 `pg_roles` 等系统目录验证，不应误用 collation 相关 catalog 作为验证依据。
- DEFAULT conversion 场景应验证 `pg_conversion.condefault`、`conforencoding`、`contoencoding` 在 `RENAME TO / OWNER TO / SET SCHEMA` 后保持预期。
- 失败路径必须使用预期失败包装，不得让单个失败样本中断整批 SQL 执行。

## 挂靠规则

- T3 异常场景挂靠到对应语法分支的代表性样本：
  - `new_name` 已存在仅挂到 `RENAME TO`。
  - `new_owner` 不存在、目标 owner 成员关系不足仅挂到 `OWNER TO`。
  - `new_schema` 不存在、目标 schema 同名冲突、目标 schema 权限不足仅挂到 `SET SCHEMA`。
  - 无权限用户覆盖所有分支各至少一个样本。
- T4 标识符因子在三个分支上轮转挂靠，必须包含合法标识符、带引号标识符、保留字、特殊字符和空字符串失败样本。
- 编码组合与转换函数状态主要挂靠到前置 `CREATE CONVERSION` 生命周期样本；不应把转换函数创建失败误归因为 `ALTER CONVERSION` 失败。
- DEFAULT conversion 与转换函数依赖关系至少在 `RENAME TO`、`OWNER TO`、`SET SCHEMA` 各保留一个成功样本，确保依赖对象生命周期闭环。
- 单条样本允许同时挂靠多个低优先级因子，但不得破坏语句分支、权限路径和成功/失败归因的可识别性。

## 规模控制规则

- 优先保证：
  - 三个语法分支全覆盖
  - super 用户、owner、普通用户、无权限用户路径全覆盖
  - conversion 存在、不存在、DEFAULT 状态和转换函数依赖关系全覆盖
  - `new_name` 已存在、`new_owner` 不存在、`new_schema` 不存在、目标 schema 冲突全覆盖
  - 成功、失败、权限失败路径全覆盖
- 次优先保证：
  - CURRENT_ROLE、CURRENT_USER、SESSION_USER 目标 owner 形式全覆盖
  - schema 限定名与非限定名全覆盖
  - 合法、带引号、保留字、特殊字符标识符形态全覆盖
  - 代表性编码组合和转换函数状态覆盖
- 低优先级因子仅保证冒烟覆盖与代表性覆盖。

## 输出要求

- 生成结果应为可执行的 PostgreSQL `ALTER CONVERSION` 测试样本集合。
- 输出样本应具备明确因子归因能力。
- 对于依赖 role、schema、conversion function 的分支，应在生命周期计划里显式准备前置对象。
- 对需要 super 用户的 setup 和 cleanup，SQL 文件中必须明确隔离该阶段，避免把权限失败误归因为环境缺失。
- 当采用裁剪策略时，应优先保留语句分支、权限路径、对象状态和异常场景覆盖。
