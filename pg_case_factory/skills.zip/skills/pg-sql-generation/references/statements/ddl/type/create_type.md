# 技能：CREATE TYPE

## 语句作用

用于描述 PostgreSQL CREATE TYPE 生成规则。官方说明：define a new data type。

这个 skill 承担如下职责：

- 定义测试因子与覆盖策略
- 定义 CREATE TYPE 的 SQL 生成范围
- 标识语法分支、前置依赖、权限边界、成功路径与失败路径

## 语法范围

```sql
CREATE TYPE name AS
    ( [ attribute_name data_type [ COLLATE collation ] [, ... ] ] )

CREATE TYPE name AS ENUM
    ( [ 'label' [, ... ] ] )

CREATE TYPE name AS RANGE (
    SUBTYPE = subtype
    [ , SUBTYPE_OPCLASS = subtype_operator_class ]
    [ , COLLATION = collation ]
    [ , CANONICAL = canonical_function ]
    [ , SUBTYPE_DIFF = subtype_diff_function ]
    [ , MULTIRANGE_TYPE_NAME = multirange_type_name ]
)

CREATE TYPE name (
    INPUT = input_function,
    OUTPUT = output_function
    [ , RECEIVE = receive_function ]
    [ , SEND = send_function ]
    [ , TYPMOD_IN = type_modifier_input_function ]
    [ , TYPMOD_OUT = type_modifier_output_function ]
    [ , ANALYZE = analyze_function ]
    [ , SUBSCRIPT = subscript_function ]
    [ , INTERNALLENGTH = { internallength | VARIABLE } ]
    [ , PASSEDBYVALUE ]
    [ , ALIGNMENT = alignment ]
    [ , STORAGE = storage ]
    [ , LIKE = like_type ]
    [ , CATEGORY = category ]
    [ , PREFERRED = preferred ]
    [ , DEFAULT = default ]
    [ , ELEMENT = element ]
    [ , DELIMITER = delimiter ]
    [ , COLLATABLE = collatable ]
)

CREATE TYPE name
```

## 测试因子分级

### T1：核心语义因子
- 语句分支：CREATE TYPE name AS
- 语句分支：CREATE TYPE name AS ENUM
- 语句分支：CREATE TYPE name AS RANGE (
- 语句分支：CREATE TYPE name (
- 语句分支：CREATE TYPE name
- 目标 type 对象身份：已存在、不存在、重名、schema 限定名、双引号标识符、保留字标识符
- 核心对象状态：创建前、执行后、依赖对象存在、依赖对象缺失

### T2：重要行为因子
- 语法开关或子句：`DEFAULT`
- 语法开关或子句：`COLLATE`
- 成功路径与失败路径
- 权限与 owner 差异

### T3：对象名与输入形态因子
- 合法普通标识符
- schema 限定标识符
- 双引号标识符
- 关键字或大小写敏感标识符
- 已存在对象名
- 不存在对象名
- 非法名称或非法参数值

### T4：依赖对象与环境因子
- 涉及表、列、表达式、索引、约束或类型的分支，需要覆盖仓库基表的代表性表类型与核心列类型。
- 权限因子至少覆盖 owner、非 owner 与权限不足失败路径。
- 命名空间相关因子按对象是否支持 schema 限定名进行挂靠覆盖。
- 依赖对象被其他对象引用、存在循环依赖或需要清理顺序时，应作为独立失败/成功边界。

### T5：异常与边界因子
- 语法合法但语义非法的组合
- 语法非法的组合
- 权限不足
- 对象类型不匹配
- 依赖对象不存在或仍被依赖
- 事务限制、锁冲突或环境限制

### T6：验证与清理因子
- 系统目录验证
- 元命令或查询验证
- 对象可用性验证
- 失败路径错误原因归因
- 清理顺序与幂等清理

## 覆盖策略
- 需要覆盖所有 CREATE TYPE 语法分支。
- 不需要覆盖所有基表。
- 不需要覆盖每张基表中所有的列类型。
- T1 和 T2 作为主覆盖因子。
- T1 因子做笛卡尔积覆盖；如分支之间存在互斥前置条件，应先按语法分支拆分再做局部笛卡尔积。
- T2 因子按规模控制策略参与组合：
  - 当组合规模可控时，与 T1 一起参与笛卡尔积覆盖。
  - 当组合规模过大时，优先保留 T1 的完整覆盖，对 T2 做裁剪、抽样或轮转覆盖。
- T3、T4、T5、T6 不进入全局主笛卡尔积，仅作为附属因子挂靠到代表性主样本上。
- 必须同时保留成功路径与失败路径。
- 如果生成规模超过 100 万，优先裁剪 T3-T6，再裁剪局部语法开关，最后才允许压缩语句分支数量。
## 生成约束

- 必须覆盖对象成功创建、重名冲突、非法定义与依赖对象缺失路径。
- 支持 `IF NOT EXISTS` 或 `OR REPLACE` 时，需要分别覆盖正常创建、no-op/替换语义与冲突边界。
- 成功路径必须包含可验证的对象存在性检查，并在生命周期末尾清理对象。
- 对官方语法中出现的每一种顶层形式，都必须至少生成一个成功或失败可归因样本。
- 每个样本必须包含明确的前置对象准备、目标 CREATE TYPE 语句、验证语句与清理语句。
- 不得把多个独立失败原因混在同一条失败样本中。
- 对需要 superuser、文件系统、复制连接、tablespace 目录、扩展、外部服务或非事务环境的分支，必须在生命周期计划中显式标注环境依赖。

## 挂靠规则

- T3 因子挂靠到各语法分支的代表性成功样本和失败样本上轮转注入。
- T4 因子仅挂靠到需要依赖对象、权限、schema、tablespace、server、extension、role 或表对象的分支。
- T5 因子按失败原因单独挂靠，不得破坏主覆盖因子的可识别性与可归因性。
- T6 因子挂靠到稳定成功路径和关键失败路径上，确保每个分支都有验证与清理策略。
- 单条样本允许同时挂靠多个低优先级因子，但不得让语句分支、对象状态、权限预期和成功/失败归因变得不可识别。

## 规模控制规则

- 优先保证：
  - 所有语法分支全覆盖
  - 目标对象存在 / 不存在 / 冲突 / 非法输入全覆盖
  - 成功 / 失败路径全覆盖
  - 权限核心路径全覆盖
- 次优先保证：
  - 官方 Synopsis 中的可选关键字和子句代表性覆盖
  - schema、owner、tablespace、extension、server、role 等依赖对象代表性覆盖
  - 引用、依赖、锁、事务限制和环境限制代表性覆盖
- 低优先级因子仅保证冒烟覆盖与代表性覆盖。

## 输出要求

- 生成结果应为可执行的 PostgreSQL CREATE TYPE 测试样本集合。
- 输出样本应具备明确因子归因能力。
- 每个样本应标注所属语法分支、预期成功/失败、前置依赖和清理策略。
- 当采用裁剪策略时，应优先保留语句分支、成功/失败路径和对象状态覆盖。
