# 技能：ALTER USER

## 语句作用

用于描述 PostgreSQL ALTER USER 生成规则。官方说明：change a database role。

这个 skill 承担如下职责：

- 定义测试因子与覆盖策略
- 定义 ALTER USER 的 SQL 生成范围
- 标识语法分支、前置依赖、权限边界、成功路径与失败路径

## 语法范围

```sql
ALTER USER role_specification [ WITH ] option [ ... ]

where option can be:

      SUPERUSER | NOSUPERUSER
    | CREATEDB | NOCREATEDB
    | CREATEROLE | NOCREATEROLE
    | INHERIT | NOINHERIT
    | LOGIN | NOLOGIN
    | REPLICATION | NOREPLICATION
    | BYPASSRLS | NOBYPASSRLS
    | CONNECTION LIMIT connlimit
    | [ ENCRYPTED ] PASSWORD 'password' | PASSWORD NULL
    | VALID UNTIL 'timestamp'

ALTER USER name RENAME TO new_name

ALTER USER { role_specification | ALL } [ IN DATABASE database_name ] SET configuration_parameter { TO | = } { value | DEFAULT }
ALTER USER { role_specification | ALL } [ IN DATABASE database_name ] SET configuration_parameter FROM CURRENT
ALTER USER { role_specification | ALL } [ IN DATABASE database_name ] RESET configuration_parameter
ALTER USER { role_specification | ALL } [ IN DATABASE database_name ] RESET ALL

where role_specification can be:

    role_name
  | CURRENT_ROLE
  | CURRENT_USER
  | SESSION_USER
```

## 测试因子分级

### T1：核心语义因子
- 语句分支：ALTER USER role_specification [ WITH ] option [ ... ]
- 语句分支：ALTER USER name RENAME TO new_name
- 语句分支：ALTER USER { role_specification | ALL } [ IN DATABASE database_name ] SET configuration_parameter { TO | = } { value | D
- 语句分支：ALTER USER { role_specification | ALL } [ IN DATABASE database_name ] SET configuration_parameter FROM CURRENT
- 语句分支：ALTER USER { role_specification | ALL } [ IN DATABASE database_name ] RESET configuration_parameter
- 语句分支：ALTER USER { role_specification | ALL } [ IN DATABASE database_name ] RESET ALL
- 目标 user 对象身份：已存在、不存在、重名、schema 限定名、双引号标识符、保留字标识符
- 核心对象状态：创建前、执行后、依赖对象存在、依赖对象缺失

### T2：重要行为因子
- 语法开关或子句：`RENAME TO`
- 语法开关或子句：`WITH`
- 语法开关或子句：`DEFAULT`
- 语法开关或子句：`NULL`
- 语法开关或子句：`RESET`
- 成功路径与失败路径
- 权限与 owner 差异

### T3：对象名与输入形态因子
- 合法普通标识符
- schema 限定标识符
- 双引号标识符
- 关键字或大小写敏感标识符
- 已存在对象名
- 不存在对象名
- 非法名称或非法参数值

### T4：依赖对象与环境因子
- 该语句不默认扩展为所有基表列类型；只有语法显式引用列、类型或依赖表对象时才挂靠代表性列类型。
- 角色、owner、权限、成员关系与当前执行用户差异必须进入成功路径和失败路径。
- schema、database、tablespace、extension 或 server 等命名空间/环境依赖必须显式准备与清理。
- 依赖对象被其他对象引用、存在循环依赖或需要清理顺序时，应作为独立失败/成功边界。

### T5：异常与边界因子
- 语法合法但语义非法的组合
- 语法非法的组合
- 权限不足
- 对象类型不匹配
- 依赖对象不存在或仍被依赖
- 事务限制、锁冲突或环境限制

### T6：验证与清理因子
- 系统目录验证
- 元命令或查询验证
- 对象可用性验证
- 失败路径错误原因归因
- 清理顺序与幂等清理

## 覆盖策略
- 需要覆盖所有 ALTER USER 语法分支。
- 不需要覆盖所有基表。
- 不需要覆盖每张基表中所有的列类型。
- T1 和 T2 作为主覆盖因子。
- T1 因子做笛卡尔积覆盖；如分支之间存在互斥前置条件，应先按语法分支拆分再做局部笛卡尔积。
- T2 因子按规模控制策略参与组合：
  - 当组合规模可控时，与 T1 一起参与笛卡尔积覆盖。
  - 当组合规模过大时，优先保留 T1 的完整覆盖，对 T2 做裁剪、抽样或轮转覆盖。
- T3、T4、T5、T6 不进入全局主笛卡尔积，仅作为附属因子挂靠到代表性主样本上。
- 必须同时保留成功路径与失败路径。
- 如果生成规模超过 100 万，优先裁剪 T3-T6，再裁剪局部语法开关，最后才允许压缩语句分支数量。
## 生成约束

- 必须预创建可被修改的目标对象，并为每个 ALTER 分支准备最小合法前置状态。
- 必须覆盖目标对象存在时的成功修改路径、目标对象不存在时的失败路径，以及支持 `IF EXISTS` 分支的代表性 no-op 路径。
- RENAME / OWNER / SET SCHEMA / SET / RESET / ADD / DROP 等分支需要保持独立归因。
- 对官方语法中出现的每一种顶层形式，都必须至少生成一个成功或失败可归因样本。
- 每个样本必须包含明确的前置对象准备、目标 ALTER USER 语句、验证语句与清理语句。
- 不得把多个独立失败原因混在同一条失败样本中。
- 对需要 superuser、文件系统、复制连接、tablespace 目录、扩展、外部服务或非事务环境的分支，必须在生命周期计划中显式标注环境依赖。

## 挂靠规则

- T3 因子挂靠到各语法分支的代表性成功样本和失败样本上轮转注入。
- T4 因子仅挂靠到需要依赖对象、权限、schema、tablespace、server、extension、role 或表对象的分支。
- T5 因子按失败原因单独挂靠，不得破坏主覆盖因子的可识别性与可归因性。
- T6 因子挂靠到稳定成功路径和关键失败路径上，确保每个分支都有验证与清理策略。
- 单条样本允许同时挂靠多个低优先级因子，但不得让语句分支、对象状态、权限预期和成功/失败归因变得不可识别。

## 规模控制规则

- 优先保证：
  - 所有语法分支全覆盖
  - 目标对象存在 / 不存在 / 冲突 / 非法输入全覆盖
  - 成功 / 失败路径全覆盖
  - 权限核心路径全覆盖
- 次优先保证：
  - 官方 Synopsis 中的可选关键字和子句代表性覆盖
  - schema、owner、tablespace、extension、server、role 等依赖对象代表性覆盖
  - 引用、依赖、锁、事务限制和环境限制代表性覆盖
- 低优先级因子仅保证冒烟覆盖与代表性覆盖。

## 输出要求

- 生成结果应为可执行的 PostgreSQL ALTER USER 测试样本集合。
- 输出样本应具备明确因子归因能力。
- 每个样本应标注所属语法分支、预期成功/失败、前置依赖和清理策略。
- 当采用裁剪策略时，应优先保留语句分支、成功/失败路径和对象状态覆盖。
