-- ============================================================
-- RDS MySQL DDL 秒级/在线修改列类型 测试套件 — 阿里云环境
-- 环境说明: 所有功能开关默认开启
-- 覆盖类型: 整数(SIGNED/UNSIGNED) + CHAR + VARCHAR
-- 覆盖算法: INSTANT + INPLACE
-- ============================================================
-- 本文件由 generate_test_sql.py 自动生成, 请勿手动修改
-- Suite-Revision: 505d13b7cf36   (生成器源码哈希; 时间戳见 results/generation_manifest.json)
-- 用例 ID 规则: TC-<文件号>-<作用域>-<序号>-<IT|IP>  —— 全局唯一
--   作用域 REG=普通表 OFAT/二元组, ATR=列属性保持, SPE=特殊模式,
--          FK=外键, PTK=分区(目标列是分区键), PNK=分区(目标列非分区键)
-- ============================================================

SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
SET SESSION innodb_lock_wait_timeout = 50;

-- File 05: CHAR INSTANT

-- Test Case: TC-05-REG-0001-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=8857300739ad=167|1264|1265|1406 neg_probe=778a3e0a1e27=167|1264|1265|1406 neg_probe=8ab475cab74c=167|1264|1265|1406 neg_probe=fad9aba513e7=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0001_it, t2_tc_05_reg_0001_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0001_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0001_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0001_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0001_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0001_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0001_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0001_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0001_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0001_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0001_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0001_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0001_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0001_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0001_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0001_it (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0001_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0001_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0001_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0001_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0001_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0001_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0001_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0001_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0001_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0001_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0001_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0001_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0001_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0001_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0001_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0001_it);
-- probe 1/2 -> t1_tc_05_reg_0001_it
INSERT INTO t1_tc_05_reg_0001_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0001_it
INSERT INTO t2_tc_05_reg_0001_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0001_it
INSERT INTO t1_tc_05_reg_0001_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0001_it
INSERT INTO t2_tc_05_reg_0001_it (target) VALUES ('test');
SELECT 'TC-05-REG-0001-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0001_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0001_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0001_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0001_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0001-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0001_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0001_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0001_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0001_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0001_it a JOIN t2_tc_05_reg_0001_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0002-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=834ef26cb6ef=167|1264|1265|1406 neg_probe=2dfc8353d46c=167|1264|1265|1406 neg_probe=e10d39648e2f=167|1264|1265|1406 neg_probe=6bef2ba947d8=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0002_it, t2_tc_05_reg_0002_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0002_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0002_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0002_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0002_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0002_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0002_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0002_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0002_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0002_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0002_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0002_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0002_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0002_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0002_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0002_it (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0002_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0002_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0002_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0002_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0002_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0002_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0002_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0002_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0002_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0002_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0002_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0002_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0002_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0002_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0002_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0002_it);
-- probe 1/2 -> t1_tc_05_reg_0002_it
INSERT INTO t1_tc_05_reg_0002_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0002_it
INSERT INTO t2_tc_05_reg_0002_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0002_it
INSERT INTO t1_tc_05_reg_0002_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0002_it
INSERT INTO t2_tc_05_reg_0002_it (target) VALUES ('test');
SELECT 'TC-05-REG-0002-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0002_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0002_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0002_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0002_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0002-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0002_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0002_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0002_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0002_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0002_it a JOIN t2_tc_05_reg_0002_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0003-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=99111b53e48f=167|1264|1265|1406 neg_probe=29abf9b37d7b=167|1264|1265|1406 neg_probe=1ebb498bce34=167|1264|1265|1406 neg_probe=ab91a3487d2e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0003_it, t2_tc_05_reg_0003_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0003_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0003_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0003_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0003_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0003_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0003_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0003_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0003_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0003_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0003_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0003_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0003_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0003_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0003_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0003_it (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0003_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0003_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0003_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0003_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0003_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0003_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0003_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0003_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0003_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0003_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0003_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0003_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0003_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0003_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0003_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0003_it);
-- probe 1/2 -> t1_tc_05_reg_0003_it
INSERT INTO t1_tc_05_reg_0003_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0003_it
INSERT INTO t2_tc_05_reg_0003_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0003_it
INSERT INTO t1_tc_05_reg_0003_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0003_it
INSERT INTO t2_tc_05_reg_0003_it (target) VALUES ('test');
SELECT 'TC-05-REG-0003-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0003_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0003_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0003_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0003_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0003-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0003_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0003_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0003_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0003_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0003_it a JOIN t2_tc_05_reg_0003_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0004-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: FAIL
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=FAIL build=SUCCESS assertions=2 neg_probes=2 neg_probe=3fd6a04ec14a=167|1264|1265|1406 neg_probe=92cc30010842=167|1264|1265|1406 neg_probe=696a4bc76f2d=167|1264|1265|1406 neg_probe=63b3108139a5=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0004_it, t2_tc_05_reg_0004_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0004_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0004_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0004_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0004_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0004_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0004_it (target) VALUES ('a');
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_05_reg_0004_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0004_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0004_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0004_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0004_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0004_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0004_it (target) VALUES ('x');
-- Oracle table: CHAR(1)
CREATE TABLE t2_tc_05_reg_0004_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0004_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0004_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0004_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0004_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0004_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0004_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0004_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0004_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0004_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0004_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0004_it (target) VALUES ('x');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0004_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0004_it);
-- probe 1/2 -> t1_tc_05_reg_0004_it
INSERT INTO t1_tc_05_reg_0004_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0004_it
INSERT INTO t2_tc_05_reg_0004_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0004_it
INSERT INTO t1_tc_05_reg_0004_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0004_it
INSERT INTO t2_tc_05_reg_0004_it (target) VALUES ('test');
SELECT 'TC-05-REG-0004-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0004_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0004_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0004_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0004_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0004-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0004_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0004_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0004_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0004_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0004_it a JOIN t2_tc_05_reg_0004_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0005-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=a5cdb9f18ad4=167|1264|1265|1406 neg_probe=61e7158bc163=167|1264|1265|1406 neg_probe=d5706c313e91=167|1264|1265|1406 neg_probe=fa16014264f0=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0005_it, t2_tc_05_reg_0005_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0005_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0005_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0005_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0005_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0005_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0005_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0005_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0005_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0005_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0005_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0005_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0005_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0005_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0005_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0005_it (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0005_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0005_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0005_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0005_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0005_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0005_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0005_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0005_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0005_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0005_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0005_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0005_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0005_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0005_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0005_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0005_it);
-- probe 1/2 -> t1_tc_05_reg_0005_it
INSERT INTO t1_tc_05_reg_0005_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0005_it
INSERT INTO t2_tc_05_reg_0005_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0005_it
INSERT INTO t1_tc_05_reg_0005_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0005_it
INSERT INTO t2_tc_05_reg_0005_it (target) VALUES ('test');
SELECT 'TC-05-REG-0005-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0005_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0005_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0005_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0005_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0005-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0005_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0005_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0005_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0005_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0005_it a JOIN t2_tc_05_reg_0005_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0006-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=8ec27b6d1c23=167|1264|1265|1406 neg_probe=ff5264ebd182=167|1264|1265|1406 neg_probe=d90ebaffb07b=167|1264|1265|1406 neg_probe=60748bc195ed=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0006_it, t2_tc_05_reg_0006_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0006_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0006_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0006_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0006_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0006_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0006_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0006_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0006_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0006_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0006_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0006_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0006_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0006_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0006_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0006_it (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0006_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0006_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0006_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0006_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0006_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0006_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0006_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0006_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0006_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0006_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0006_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0006_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0006_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0006_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0006_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0006_it);
-- probe 1/2 -> t1_tc_05_reg_0006_it
INSERT INTO t1_tc_05_reg_0006_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0006_it
INSERT INTO t2_tc_05_reg_0006_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0006_it
INSERT INTO t1_tc_05_reg_0006_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0006_it
INSERT INTO t2_tc_05_reg_0006_it (target) VALUES ('test');
SELECT 'TC-05-REG-0006-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0006_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0006_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0006_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0006_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0006-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0006_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0006_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0006_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0006_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0006_it a JOIN t2_tc_05_reg_0006_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0007-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=989feb88666c=167|1264|1265|1406 neg_probe=07dd5c0719f3=167|1264|1265|1406 neg_probe=60a48084eddf=167|1264|1265|1406 neg_probe=bb2b886f96c0=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0007_it, t2_tc_05_reg_0007_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0007_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0007_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0007_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0007_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0007_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0007_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0007_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0007_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0007_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0007_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0007_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0007_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0007_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0007_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0007_it (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0007_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0007_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0007_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0007_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0007_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0007_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0007_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0007_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0007_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0007_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0007_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0007_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0007_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0007_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0007_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0007_it);
-- probe 1/2 -> t1_tc_05_reg_0007_it
INSERT INTO t1_tc_05_reg_0007_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0007_it
INSERT INTO t2_tc_05_reg_0007_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0007_it
INSERT INTO t1_tc_05_reg_0007_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0007_it
INSERT INTO t2_tc_05_reg_0007_it (target) VALUES ('test');
SELECT 'TC-05-REG-0007-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0007_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0007_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0007_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0007_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0007-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0007_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0007_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0007_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0007_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0007_it a JOIN t2_tc_05_reg_0007_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0008-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=f185be1ee767=167|1264|1265|1406 neg_probe=2f6a5eb76f04=167|1264|1265|1406 neg_probe=81f3b0ebcb81=167|1264|1265|1406 neg_probe=d479ea0082c2=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0008_it, t2_tc_05_reg_0008_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0008_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0008_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0008_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0008_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0008_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0008_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0008_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0008_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0008_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0008_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0008_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0008_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0008_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0008_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0008_it (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0008_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0008_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0008_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0008_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0008_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0008_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0008_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0008_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0008_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0008_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0008_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0008_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0008_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0008_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0008_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0008_it);
-- probe 1/2 -> t1_tc_05_reg_0008_it
INSERT INTO t1_tc_05_reg_0008_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0008_it
INSERT INTO t2_tc_05_reg_0008_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0008_it
INSERT INTO t1_tc_05_reg_0008_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0008_it
INSERT INTO t2_tc_05_reg_0008_it (target) VALUES ('test');
SELECT 'TC-05-REG-0008-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0008_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0008_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0008_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0008_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0008-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0008_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0008_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0008_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0008_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0008_it a JOIN t2_tc_05_reg_0008_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0009-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=2f6edb688d9c=167|1264|1265|1406 neg_probe=ea50c99330f0=167|1264|1265|1406 neg_probe=be719a65ce6e=167|1264|1265|1406 neg_probe=b96440d75cbe=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0009_it, t2_tc_05_reg_0009_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0009_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0009_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0009_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0009_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0009_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0009_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0009_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0009_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0009_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0009_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0009_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0009_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0009_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0009_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0009_it (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0009_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0009_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0009_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0009_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0009_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0009_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0009_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0009_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0009_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0009_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0009_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0009_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0009_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0009_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0009_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0009_it);
-- probe 1/2 -> t1_tc_05_reg_0009_it
INSERT INTO t1_tc_05_reg_0009_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0009_it
INSERT INTO t2_tc_05_reg_0009_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0009_it
INSERT INTO t1_tc_05_reg_0009_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0009_it
INSERT INTO t2_tc_05_reg_0009_it (target) VALUES ('test');
SELECT 'TC-05-REG-0009-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0009_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0009_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0009_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0009_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0009-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0009_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0009_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0009_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0009_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0009_it a JOIN t2_tc_05_reg_0009_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0010-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=f25a44d71ffe=167|1264|1265|1406 neg_probe=4cf196ea7074=167|1264|1265|1406 neg_probe=7f8981e93b54=167|1264|1265|1406 neg_probe=8e0fbcd8af9a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0010_it, t2_tc_05_reg_0010_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0010_it (
  target CHAR(1) CHARACTER SET latin1,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0010_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0010_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0010_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0010_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0010_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0010_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0010_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0010_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0010_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0010_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0010_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0010_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0010_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0010_it (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0010_it (
  target CHAR(2) CHARACTER SET latin1,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0010_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0010_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0010_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0010_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0010_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0010_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0010_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0010_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0010_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0010_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0010_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0010_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0010_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0010_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0010_it);
-- probe 1/2 -> t1_tc_05_reg_0010_it
INSERT INTO t1_tc_05_reg_0010_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0010_it
INSERT INTO t2_tc_05_reg_0010_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0010_it
INSERT INTO t1_tc_05_reg_0010_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0010_it
INSERT INTO t2_tc_05_reg_0010_it (target) VALUES ('test');
SELECT 'TC-05-REG-0010-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0010_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0010_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0010_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0010_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0010-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0010_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0010_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0010_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0010_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0010_it a JOIN t2_tc_05_reg_0010_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0011-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=b86f3bba5e36=167|1264|1265|1406 neg_probe=259deb797ad7=167|1264|1265|1406 neg_probe=47a652ee2731=167|1264|1265|1406 neg_probe=f5ce250db90a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0011_it, t2_tc_05_reg_0011_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0011_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target CHAR(1) CHARACTER SET latin1, PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0011_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0011_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0011_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0011_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0011_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0011_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0011_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0011_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0011_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0011_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0011_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0011_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0011_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0011_it (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0011_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target CHAR(2) CHARACTER SET latin1, PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0011_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0011_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0011_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0011_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0011_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0011_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0011_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0011_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0011_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0011_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0011_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0011_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0011_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0011_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0011_it);
-- probe 1/2 -> t1_tc_05_reg_0011_it
INSERT INTO t1_tc_05_reg_0011_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0011_it
INSERT INTO t2_tc_05_reg_0011_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0011_it
INSERT INTO t1_tc_05_reg_0011_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0011_it
INSERT INTO t2_tc_05_reg_0011_it (target) VALUES ('test');
SELECT 'TC-05-REG-0011-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0011_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0011_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0011_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0011_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0011-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0011_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0011_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0011_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0011_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0011_it a JOIN t2_tc_05_reg_0011_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0012-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=b191e1f000cc=167|1264|1265|1406 neg_probe=876eced374e2=167|1264|1265|1406 neg_probe=7f2b9772ef09=167|1264|1265|1406 neg_probe=988617bb76aa=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0012_it, t2_tc_05_reg_0012_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0012_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0012_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0012_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0012_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0012_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0012_it (target) VALUES ('a');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0012_it MODIFY target CHAR(2) CHARACTER SET latin1 NOT NULL, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0012_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0012_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0012_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0012_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0012_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0012_it (target) VALUES ('x');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0012_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0012_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0012_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0012_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0012_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0012_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0012_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0012_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0012_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0012_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0012_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0012_it (target) VALUES ('x');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0012_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0012_it);
-- probe 1/2 -> t1_tc_05_reg_0012_it
INSERT INTO t1_tc_05_reg_0012_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0012_it
INSERT INTO t2_tc_05_reg_0012_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0012_it
INSERT INTO t1_tc_05_reg_0012_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0012_it
INSERT INTO t2_tc_05_reg_0012_it (target) VALUES ('test');
SELECT 'TC-05-REG-0012-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0012_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0012_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0012_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0012_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0012-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0012_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0012_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0012_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0012_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0012_it a JOIN t2_tc_05_reg_0012_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0013-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=7d06103d4301=167|1264|1265|1406 neg_probe=99c66dfd7df6=167|1264|1265|1406 neg_probe=54f575de7eac=167|1264|1265|1406 neg_probe=6b0608dbf08e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0013_it, t2_tc_05_reg_0013_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0013_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0013_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0013_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0013_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0013_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0013_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0013_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0013_it MODIFY target CHAR(2) CHARACTER SET latin1 DEFAULT '', ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0013_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0013_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0013_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0013_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0013_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0013_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0013_it (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0013_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0013_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0013_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0013_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0013_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0013_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0013_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0013_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0013_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0013_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0013_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0013_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0013_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0013_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0013_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0013_it);
-- probe 1/2 -> t1_tc_05_reg_0013_it
INSERT INTO t1_tc_05_reg_0013_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0013_it
INSERT INTO t2_tc_05_reg_0013_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0013_it
INSERT INTO t1_tc_05_reg_0013_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0013_it
INSERT INTO t2_tc_05_reg_0013_it (target) VALUES ('test');
SELECT 'TC-05-REG-0013-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0013_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0013_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0013_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0013_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0013-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0013_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0013_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0013_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0013_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0013_it a JOIN t2_tc_05_reg_0013_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0014-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=6c67e9023db2=167|1264|1265|1406 neg_probe=03f360bf2551=167|1264|1265|1406 neg_probe=02138ce84c70=167|1264|1265|1406 neg_probe=36bb5278cf6a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0014_it, t2_tc_05_reg_0014_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0014_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0014_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0014_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0014_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0014_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0014_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0014_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0014_it MODIFY target CHAR(2) CHARACTER SET latin1 DEFAULT NULL, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0014_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0014_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0014_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0014_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0014_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0014_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0014_it (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0014_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0014_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0014_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0014_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0014_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0014_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0014_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0014_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0014_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0014_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0014_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0014_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0014_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0014_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0014_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0014_it);
-- probe 1/2 -> t1_tc_05_reg_0014_it
INSERT INTO t1_tc_05_reg_0014_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0014_it
INSERT INTO t2_tc_05_reg_0014_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0014_it
INSERT INTO t1_tc_05_reg_0014_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0014_it
INSERT INTO t2_tc_05_reg_0014_it (target) VALUES ('test');
SELECT 'TC-05-REG-0014-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0014_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0014_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0014_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0014_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0014-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0014_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0014_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0014_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0014_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0014_it a JOIN t2_tc_05_reg_0014_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0015-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=6c06e8ba110b=167|1264|1265|1406 neg_probe=36408a5edde2=167|1264|1265|1406 neg_probe=f2161f630589=167|1264|1265|1406 neg_probe=6d56db37a606=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0015_it, t2_tc_05_reg_0015_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0015_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0015_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0015_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0015_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0015_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0015_it (target) VALUES ('a');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0015_it MODIFY target CHAR(2) CHARACTER SET latin1 NOT NULL DEFAULT '', ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0015_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0015_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0015_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0015_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0015_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0015_it (target) VALUES ('x');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0015_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0015_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0015_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0015_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0015_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0015_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0015_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0015_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0015_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0015_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0015_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0015_it (target) VALUES ('x');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0015_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0015_it);
-- probe 1/2 -> t1_tc_05_reg_0015_it
INSERT INTO t1_tc_05_reg_0015_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0015_it
INSERT INTO t2_tc_05_reg_0015_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0015_it
INSERT INTO t1_tc_05_reg_0015_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0015_it
INSERT INTO t2_tc_05_reg_0015_it (target) VALUES ('test');
SELECT 'TC-05-REG-0015-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0015_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0015_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0015_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0015_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0015-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0015_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0015_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0015_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0015_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0015_it a JOIN t2_tc_05_reg_0015_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0016-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=ee21698c4118=167|1264|1265|1406 neg_probe=32dbf7eb22e5=167|1264|1265|1406 neg_probe=67414dd295bb=167|1264|1265|1406 neg_probe=89088ecdfc76=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0016_it, t2_tc_05_reg_0016_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0016_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0016_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0016_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0016_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0016_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0016_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0016_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0016_it MODIFY target CHAR(2) CHARACTER SET latin1 INVISIBLE, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0016_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0016_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0016_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0016_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0016_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0016_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0016_it (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0016_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0016_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0016_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0016_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0016_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0016_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0016_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0016_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0016_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0016_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0016_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0016_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0016_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0016_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0016_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0016_it);
-- probe 1/2 -> t1_tc_05_reg_0016_it
INSERT INTO t1_tc_05_reg_0016_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0016_it
INSERT INTO t2_tc_05_reg_0016_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0016_it
INSERT INTO t1_tc_05_reg_0016_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0016_it
INSERT INTO t2_tc_05_reg_0016_it (target) VALUES ('test');
SELECT 'TC-05-REG-0016-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0016_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0016_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0016_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0016_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0016-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0016_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0016_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0016_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0016_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0016_it a JOIN t2_tc_05_reg_0016_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0017-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=0d79c023b8dd=167|1264|1265|1406 neg_probe=aa4e794037ea=167|1264|1265|1406 neg_probe=32ecf0da7907=167|1264|1265|1406 neg_probe=d9620d43ae52=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0017_it, t2_tc_05_reg_0017_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0017_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0017_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0017_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0017_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0017_it);
-- probe 1/2 -> t1_tc_05_reg_0017_it
INSERT INTO t1_tc_05_reg_0017_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0017_it
INSERT INTO t2_tc_05_reg_0017_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0017_it
INSERT INTO t1_tc_05_reg_0017_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0017_it
INSERT INTO t2_tc_05_reg_0017_it (target) VALUES ('test');
SELECT 'TC-05-REG-0017-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0017_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0017_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0017_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0017_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0017-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0017_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0017_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0017_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0017_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0017_it a JOIN t2_tc_05_reg_0017_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0018-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=d5a1e52f1bb0=167|1264|1265|1406 neg_probe=fa215ff348e7=167|1264|1265|1406 neg_probe=138542244e9d=167|1264|1265|1406 neg_probe=59c294fc6b2c=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0018_it, t2_tc_05_reg_0018_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0018_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0018_it (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0018_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0018_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0018_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0018_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0018_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0018_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0018_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0018_it (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0018_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0018_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0018_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0018_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0018_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0018_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0018_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0018_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0018_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0018_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0018_it);
-- probe 1/2 -> t1_tc_05_reg_0018_it
INSERT INTO t1_tc_05_reg_0018_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0018_it
INSERT INTO t2_tc_05_reg_0018_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0018_it
INSERT INTO t1_tc_05_reg_0018_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0018_it
INSERT INTO t2_tc_05_reg_0018_it (target) VALUES ('test');
SELECT 'TC-05-REG-0018-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0018_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0018_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0018_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0018_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0018-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0018_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0018_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0018_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0018_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0018_it a JOIN t2_tc_05_reg_0018_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0019-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: CHAR-01
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=f8a7eea7d669=167|1264|1265|1406 neg_probe=e2c21c117cf2=167|1264|1265|1406 neg_probe=5bfc4f8f697d=167|1264|1265|1406 neg_probe=40cf48fb32c5=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0019_it, t2_tc_05_reg_0019_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0019_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0019_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0019_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0019_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0019_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0019_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0019_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0019_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0019_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0019_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0019_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0019_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0019_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0019_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0019_it (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0019_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0019_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0019_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0019_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0019_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0019_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0019_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0019_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0019_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0019_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0019_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0019_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0019_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0019_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0019_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0019_it);
-- probe 1/2 -> t1_tc_05_reg_0019_it
INSERT INTO t1_tc_05_reg_0019_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0019_it
INSERT INTO t2_tc_05_reg_0019_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0019_it
INSERT INTO t1_tc_05_reg_0019_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0019_it
INSERT INTO t2_tc_05_reg_0019_it (target) VALUES ('test');
SELECT 'TC-05-REG-0019-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0019_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0019_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0019_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0019_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0019-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0019_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0019_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0019_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0019_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0019_it a JOIN t2_tc_05_reg_0019_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0020-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: CHAR-01
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=fe5d0bc529c9=167|1264|1265|1406 neg_probe=9439aeebdf3b=167|1264|1265|1406 neg_probe=7fe8250abee1=167|1264|1265|1406 neg_probe=775ef82770a1=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0020_it, t2_tc_05_reg_0020_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0020_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0020_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0020_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0020_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0020_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0020_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0020_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0020_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0020_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0020_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0020_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0020_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0020_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0020_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0020_it (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0020_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0020_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0020_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0020_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0020_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0020_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0020_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0020_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0020_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0020_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0020_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0020_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0020_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0020_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0020_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0020_it);
-- probe 1/2 -> t1_tc_05_reg_0020_it
INSERT INTO t1_tc_05_reg_0020_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0020_it
INSERT INTO t2_tc_05_reg_0020_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0020_it
INSERT INTO t1_tc_05_reg_0020_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0020_it
INSERT INTO t2_tc_05_reg_0020_it (target) VALUES ('test');
SELECT 'TC-05-REG-0020-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0020_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0020_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0020_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0020_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0020-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0020_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0020_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0020_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0020_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0020_it a JOIN t2_tc_05_reg_0020_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0021-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=9883ce69cf7e=167|1264|1265|1406 neg_probe=2dcff7a8ec10=167|1264|1265|1406 neg_probe=b9d05fcd2c1e=167|1264|1265|1406 neg_probe=cdb0c343836d=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0021_it, t2_tc_05_reg_0021_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0021_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0021_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0021_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0021_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0021_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0021_it (target) VALUES ('a');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0021_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0021_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0021_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0021_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0021_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0021_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0021_it (target) VALUES ('x');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0021_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0021_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0021_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0021_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0021_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0021_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0021_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0021_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0021_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0021_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0021_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0021_it (target) VALUES ('x');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0021_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0021_it);
-- probe 1/2 -> t1_tc_05_reg_0021_it
INSERT INTO t1_tc_05_reg_0021_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0021_it
INSERT INTO t2_tc_05_reg_0021_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0021_it
INSERT INTO t1_tc_05_reg_0021_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0021_it
INSERT INTO t2_tc_05_reg_0021_it (target) VALUES ('test');
SELECT 'TC-05-REG-0021-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0021_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0021_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0021_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0021_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0021-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0021_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0021_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0021_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0021_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0021_it a JOIN t2_tc_05_reg_0021_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0022-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=83672167be4f=167|1264|1265|1406 neg_probe=209f5e06687d=167|1264|1265|1406 neg_probe=102b3ac02a55=167|1264|1265|1406 neg_probe=15921ff81b4e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0022_it, t2_tc_05_reg_0022_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0022_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0022_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0022_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0022_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0022_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0022_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0022_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0022_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0022_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0022_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0022_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0022_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0022_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0022_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0022_it (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0022_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0022_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0022_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0022_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0022_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0022_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0022_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0022_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0022_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0022_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0022_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0022_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0022_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0022_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0022_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0022_it);
-- probe 1/2 -> t1_tc_05_reg_0022_it
INSERT INTO t1_tc_05_reg_0022_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0022_it
INSERT INTO t2_tc_05_reg_0022_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0022_it
INSERT INTO t1_tc_05_reg_0022_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0022_it
INSERT INTO t2_tc_05_reg_0022_it (target) VALUES ('test');
SELECT 'TC-05-REG-0022-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0022_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0022_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0022_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0022_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0022-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0022_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0022_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0022_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0022_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0022_it a JOIN t2_tc_05_reg_0022_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0023-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=ab57ed3244c6=167|1264|1265|1406 neg_probe=038913a28bc0=167|1264|1265|1406 neg_probe=fc4eed6dd855=167|1264|1265|1406 neg_probe=f0831ff37bf7=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0023_it, t2_tc_05_reg_0023_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0023_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0023_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0023_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0023_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0023_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0023_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0023_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0023_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0023_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0023_it (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0023_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0023_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0023_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0023_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0023_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0023_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0023_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0023_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0023_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0023_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0023_it);
-- probe 1/2 -> t1_tc_05_reg_0023_it
INSERT INTO t1_tc_05_reg_0023_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0023_it
INSERT INTO t2_tc_05_reg_0023_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0023_it
INSERT INTO t1_tc_05_reg_0023_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0023_it
INSERT INTO t2_tc_05_reg_0023_it (target) VALUES ('test');
SELECT 'TC-05-REG-0023-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0023_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0023_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0023_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0023_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0023-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0023_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0023_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0023_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0023_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0023_it a JOIN t2_tc_05_reg_0023_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0024-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=2d29e0b4931f=ACCEPTED neg_probe=4eeab2586062=ACCEPTED neg_probe=716ccbcb789f=ACCEPTED neg_probe=c2a2cd1cd1f5=ACCEPTED
DROP TABLE IF EXISTS t1_tc_05_reg_0024_it, t2_tc_05_reg_0024_it;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_05_reg_0024_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0024_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0024_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0024_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0024_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0024_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0024_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0024_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0024_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0024_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0024_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0024_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0024_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0024_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0024_it (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0024_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0024_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0024_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0024_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0024_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0024_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0024_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0024_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0024_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0024_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0024_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0024_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0024_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0024_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0024_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0024_it);
-- probe 1/2 -> t1_tc_05_reg_0024_it
INSERT INTO t1_tc_05_reg_0024_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0024_it
INSERT INTO t2_tc_05_reg_0024_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0024_it
INSERT INTO t1_tc_05_reg_0024_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0024_it
INSERT INTO t2_tc_05_reg_0024_it (target) VALUES ('test');
SELECT 'TC-05-REG-0024-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0024_it) - @neg_before_t1 = (SELECT COUNT(*) FROM t2_tc_05_reg_0024_it) - @neg_before_t2,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0024_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0024_it) - @neg_before_t2,' expect=t1_added = t2_added (非 STRICT: 截断行为必须与对照表一致) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0024-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0024_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0024_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0024_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0024_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0024_it a JOIN t2_tc_05_reg_0024_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0025-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=28a008961d9b=167|1264|1265|1406 neg_probe=146cd59f731d=167|1264|1265|1406 neg_probe=3baadcc16ce9=167|1264|1265|1406 neg_probe=3580b592f492=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0025_it, t2_tc_05_reg_0025_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0025_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0025_it MODIFY target CHAR(2) CHARACTER SET latin1 NOT NULL, ALGORITHM=instant;
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0025_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0025_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0025_it);
-- probe 1/2 -> t1_tc_05_reg_0025_it
INSERT INTO t1_tc_05_reg_0025_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0025_it
INSERT INTO t2_tc_05_reg_0025_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0025_it
INSERT INTO t1_tc_05_reg_0025_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0025_it
INSERT INTO t2_tc_05_reg_0025_it (target) VALUES ('test');
SELECT 'TC-05-REG-0025-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0025_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0025_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0025_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0025_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0025-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0025_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0025_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0025_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0025_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0025_it a JOIN t2_tc_05_reg_0025_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0026-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: CHAR-01
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=b405f2603bb3=167|1264|1265|1406 neg_probe=e63f68efa7bf=167|1264|1265|1406 neg_probe=c51e9c949eb0=167|1264|1265|1406 neg_probe=00b68c213af0=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0026_it, t2_tc_05_reg_0026_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0026_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0026_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0026_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0026_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0026_it);
-- probe 1/2 -> t1_tc_05_reg_0026_it
INSERT INTO t1_tc_05_reg_0026_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0026_it
INSERT INTO t2_tc_05_reg_0026_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0026_it
INSERT INTO t1_tc_05_reg_0026_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0026_it
INSERT INTO t2_tc_05_reg_0026_it (target) VALUES ('test');
SELECT 'TC-05-REG-0026-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0026_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0026_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0026_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0026_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0026-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0026_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0026_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0026_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0026_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0026_it a JOIN t2_tc_05_reg_0026_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0027-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=2 neg_probe=f2ecdadd3e8e=167|1264|1265|1406 neg_probe=b0d20f2f34f3=167|1264|1265|1406 neg_probe=a36913998d3d=167|1264|1265|1406 neg_probe=428d2d8c7362=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0027_it, t2_tc_05_reg_0027_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0027_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0027_it MODIFY target CHAR(2) CHARACTER SET latin1 NOT NULL DEFAULT '', ALGORITHM=instant;
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_05_reg_0027_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0027_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0027_it);
-- probe 1/2 -> t1_tc_05_reg_0027_it
INSERT INTO t1_tc_05_reg_0027_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0027_it
INSERT INTO t2_tc_05_reg_0027_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0027_it
INSERT INTO t1_tc_05_reg_0027_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0027_it
INSERT INTO t2_tc_05_reg_0027_it (target) VALUES ('test');
SELECT 'TC-05-REG-0027-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0027_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0027_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0027_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0027_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0027-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0027_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0027_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0027_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0027_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0027_it a JOIN t2_tc_05_reg_0027_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0028-IT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: FAIL
-- Varied factor: KP-05
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=FAIL build=SUCCESS assertions=2 neg_probes=2 neg_probe=c507bb4e47cf=167|1264|1265|1406 neg_probe=feae8e25a8cb=167|1264|1265|1406 neg_probe=d7a278fa64a3=167|1264|1265|1406 neg_probe=edd321222f9c=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0028_it, t2_tc_05_reg_0028_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0028_it (
  target CHAR(1) CHARACTER SET latin1,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_reg_0028_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0028_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0028_it (target) VALUES ('x');
INSERT INTO t1_tc_05_reg_0028_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0028_it (target) VALUES ('a');
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_05_reg_0028_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0028_it (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0028_it (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0028_it (target) VALUES ('ww');
INSERT INTO t1_tc_05_reg_0028_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0028_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0028_it (target) VALUES ('x');
-- Oracle table: CHAR(1)
CREATE TABLE t2_tc_05_reg_0028_it (
  target CHAR(1) CHARACTER SET latin1,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_05_reg_0028_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0028_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0028_it (target) VALUES ('x');
INSERT INTO t2_tc_05_reg_0028_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0028_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0028_it (target) VALUES ('zz');
INSERT INTO t2_tc_05_reg_0028_it (target) VALUES ('z');
INSERT INTO t2_tc_05_reg_0028_it (target) VALUES ('ww');
INSERT INTO t2_tc_05_reg_0028_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0028_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0028_it (target) VALUES ('x');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0028_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0028_it);
-- probe 1/2 -> t1_tc_05_reg_0028_it
INSERT INTO t1_tc_05_reg_0028_it (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_05_reg_0028_it
INSERT INTO t2_tc_05_reg_0028_it (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_05_reg_0028_it
INSERT INTO t1_tc_05_reg_0028_it (target) VALUES ('test');
-- probe 2/2 -> t2_tc_05_reg_0028_it
INSERT INTO t2_tc_05_reg_0028_it (target) VALUES ('test');
SELECT 'TC-05-REG-0028-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0028_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0028_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0028_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0028_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0028-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0028_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0028_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0028_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0028_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0028_it a JOIN t2_tc_05_reg_0028_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-ATR-0001-IT
-- Column attribute preservation: COMMENT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant
DROP TABLE IF EXISTS t1_tc_05_atr_0001_it, t2_tc_05_atr_0001_it;
CREATE TABLE t1_tc_05_atr_0001_it (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(1) CHARACTER SET latin1 COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_atr_0001_it (target) VALUES ('');
INSERT INTO t1_tc_05_atr_0001_it (target) VALUES ('a');
INSERT INTO t1_tc_05_atr_0001_it (target) VALUES ('x');
INSERT INTO t1_tc_05_atr_0001_it (target) VALUES ('');
INSERT INTO t1_tc_05_atr_0001_it (target) VALUES ('a');
ALTER TABLE t1_tc_05_atr_0001_it MODIFY target CHAR(2) CHARACTER SET latin1 COMMENT 'test_comment', ALGORITHM=instant;
INSERT INTO t1_tc_05_atr_0001_it (target) VALUES ('zz');
INSERT INTO t1_tc_05_atr_0001_it (target) VALUES ('z');
INSERT INTO t1_tc_05_atr_0001_it (target) VALUES ('ww');
SELECT 'TC-05-ATR-0001-IT' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_05_atr_0001_it' AND column_name='target' AND column_comment='test_comment';

-- Test Case: TC-05-ATR-0002-IT
-- Column attribute preservation: CHARSET
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant
DROP TABLE IF EXISTS t1_tc_05_atr_0002_it, t2_tc_05_atr_0002_it;
CREATE TABLE t1_tc_05_atr_0002_it (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_atr_0002_it (target) VALUES ('');
INSERT INTO t1_tc_05_atr_0002_it (target) VALUES ('a');
INSERT INTO t1_tc_05_atr_0002_it (target) VALUES ('x');
INSERT INTO t1_tc_05_atr_0002_it (target) VALUES ('');
INSERT INTO t1_tc_05_atr_0002_it (target) VALUES ('a');
ALTER TABLE t1_tc_05_atr_0002_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=instant;
INSERT INTO t1_tc_05_atr_0002_it (target) VALUES ('zz');
INSERT INTO t1_tc_05_atr_0002_it (target) VALUES ('z');
INSERT INTO t1_tc_05_atr_0002_it (target) VALUES ('ww');
SELECT 'TC-05-ATR-0002-IT' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_05_atr_0002_it' AND column_name='target' AND character_set_name='latin1';

-- Test Case: TC-05-ATR-0003-IT
-- Column attribute preservation: COLLATE
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant
DROP TABLE IF EXISTS t1_tc_05_atr_0003_it, t2_tc_05_atr_0003_it;
CREATE TABLE t1_tc_05_atr_0003_it (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(1) CHARACTER SET latin1 COLLATE latin1_bin,
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_05_atr_0003_it (target) VALUES ('');
INSERT INTO t1_tc_05_atr_0003_it (target) VALUES ('a');
INSERT INTO t1_tc_05_atr_0003_it (target) VALUES ('x');
INSERT INTO t1_tc_05_atr_0003_it (target) VALUES ('');
INSERT INTO t1_tc_05_atr_0003_it (target) VALUES ('a');
ALTER TABLE t1_tc_05_atr_0003_it MODIFY target CHAR(2) CHARACTER SET latin1 COLLATE latin1_bin, ALGORITHM=instant;
INSERT INTO t1_tc_05_atr_0003_it (target) VALUES ('zz');
INSERT INTO t1_tc_05_atr_0003_it (target) VALUES ('z');
INSERT INTO t1_tc_05_atr_0003_it (target) VALUES ('ww');
SELECT 'TC-05-ATR-0003-IT' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_05_atr_0003_it' AND column_name='target' AND collation_name='latin1_bin';

-- Test Case: TC-05-REG-0029-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=fe5ba2acb660=167|1264|1265|1406 neg_probe=7b32bc3d889e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0029_it, t2_tc_05_reg_0029_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0029_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0029_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0029_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0029_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0029_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0029_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0029_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0029_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0029_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0029_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0029_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0029_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0029_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0029_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0029_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0029_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0029_it (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0029_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0029_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0029_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0029_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0029_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0029_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0029_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0029_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0029_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0029_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0029_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0029_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0029_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0029_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0029_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0029_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0029_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0029_it);
-- probe 1/1 -> t1_tc_05_reg_0029_it
INSERT INTO t1_tc_05_reg_0029_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0029_it
INSERT INTO t2_tc_05_reg_0029_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0029-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0029_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0029_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0029_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0029_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0029-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0029_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0029_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0029_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0029_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0029_it a JOIN t2_tc_05_reg_0029_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0030-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=7bc8e745e452=167|1264|1265|1406 neg_probe=d4204a4cd54d=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0030_it, t2_tc_05_reg_0030_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0030_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0030_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0030_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0030_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0030_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0030_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0030_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0030_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0030_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0030_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0030_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0030_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0030_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0030_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0030_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0030_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0030_it (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0030_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0030_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0030_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0030_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0030_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0030_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0030_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0030_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0030_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0030_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0030_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0030_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0030_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0030_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0030_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0030_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0030_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0030_it);
-- probe 1/1 -> t1_tc_05_reg_0030_it
INSERT INTO t1_tc_05_reg_0030_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0030_it
INSERT INTO t2_tc_05_reg_0030_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0030-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0030_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0030_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0030_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0030_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0030-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0030_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0030_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0030_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0030_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0030_it a JOIN t2_tc_05_reg_0030_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0031-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=6b17ad630def=167|1264|1265|1406 neg_probe=905d75af8391=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0031_it, t2_tc_05_reg_0031_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0031_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0031_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0031_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0031_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0031_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0031_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0031_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0031_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0031_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0031_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0031_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0031_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0031_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0031_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0031_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0031_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0031_it (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0031_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0031_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0031_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0031_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0031_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0031_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0031_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0031_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0031_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0031_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0031_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0031_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0031_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0031_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0031_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0031_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0031_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0031_it);
-- probe 1/1 -> t1_tc_05_reg_0031_it
INSERT INTO t1_tc_05_reg_0031_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0031_it
INSERT INTO t2_tc_05_reg_0031_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0031-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0031_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0031_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0031_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0031_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0031-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0031_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0031_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0031_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0031_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0031_it a JOIN t2_tc_05_reg_0031_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0032-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: FAIL
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=FAIL build=SUCCESS assertions=2 neg_probes=1 neg_probe=26ff5b5b5524=167|1264|1265|1406 neg_probe=40bf118a6a0b=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0032_it, t2_tc_05_reg_0032_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0032_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0032_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0032_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0032_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0032_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0032_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0032_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0032_it (target) VALUES ('🎉');
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_05_reg_0032_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0032_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0032_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0032_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0032_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0032_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0032_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Oracle table: CHAR(63)
CREATE TABLE t2_tc_05_reg_0032_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0032_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0032_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0032_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0032_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0032_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0032_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0032_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0032_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0032_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0032_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0032_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0032_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0032_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0032_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0032_it);
-- probe 1/1 -> t1_tc_05_reg_0032_it
INSERT INTO t1_tc_05_reg_0032_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0032_it
INSERT INTO t2_tc_05_reg_0032_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0032-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0032_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0032_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0032_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0032_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0032-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0032_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0032_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0032_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0032_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0032_it a JOIN t2_tc_05_reg_0032_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0033-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=4c524e38a31f=167|1264|1265|1406 neg_probe=52143a80e241=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0033_it, t2_tc_05_reg_0033_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0033_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0033_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0033_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0033_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0033_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0033_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0033_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0033_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0033_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0033_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0033_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0033_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0033_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0033_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0033_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0033_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0033_it (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0033_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0033_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0033_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0033_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0033_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0033_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0033_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0033_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0033_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0033_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0033_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0033_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0033_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0033_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0033_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0033_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0033_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0033_it);
-- probe 1/1 -> t1_tc_05_reg_0033_it
INSERT INTO t1_tc_05_reg_0033_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0033_it
INSERT INTO t2_tc_05_reg_0033_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0033-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0033_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0033_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0033_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0033_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0033-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0033_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0033_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0033_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0033_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0033_it a JOIN t2_tc_05_reg_0033_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0034-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=54af280c4e37=167|1264|1265|1406 neg_probe=02fe79c86670=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0034_it, t2_tc_05_reg_0034_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0034_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0034_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0034_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0034_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0034_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0034_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0034_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0034_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0034_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0034_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0034_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0034_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0034_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0034_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0034_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0034_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0034_it (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0034_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0034_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0034_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0034_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0034_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0034_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0034_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0034_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0034_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0034_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0034_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0034_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0034_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0034_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0034_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0034_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0034_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0034_it);
-- probe 1/1 -> t1_tc_05_reg_0034_it
INSERT INTO t1_tc_05_reg_0034_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0034_it
INSERT INTO t2_tc_05_reg_0034_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0034-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0034_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0034_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0034_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0034_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0034-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0034_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0034_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0034_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0034_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0034_it a JOIN t2_tc_05_reg_0034_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0035-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=0e2cf13f23ab=167|1264|1265|1406 neg_probe=f02d50066d69=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0035_it, t2_tc_05_reg_0035_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0035_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0035_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0035_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0035_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0035_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0035_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0035_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0035_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0035_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0035_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0035_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0035_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0035_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0035_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0035_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0035_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0035_it (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0035_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0035_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0035_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0035_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0035_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0035_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0035_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0035_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0035_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0035_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0035_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0035_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0035_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0035_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0035_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0035_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0035_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0035_it);
-- probe 1/1 -> t1_tc_05_reg_0035_it
INSERT INTO t1_tc_05_reg_0035_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0035_it
INSERT INTO t2_tc_05_reg_0035_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0035-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0035_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0035_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0035_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0035_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0035-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0035_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0035_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0035_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0035_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0035_it a JOIN t2_tc_05_reg_0035_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0036-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=9473c34bc974=167|1264|1265|1406 neg_probe=56281358dfea=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0036_it, t2_tc_05_reg_0036_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0036_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0036_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0036_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0036_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0036_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0036_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0036_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0036_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0036_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0036_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0036_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0036_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0036_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0036_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0036_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0036_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0036_it (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0036_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0036_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0036_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0036_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0036_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0036_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0036_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0036_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0036_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0036_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0036_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0036_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0036_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0036_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0036_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0036_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0036_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0036_it);
-- probe 1/1 -> t1_tc_05_reg_0036_it
INSERT INTO t1_tc_05_reg_0036_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0036_it
INSERT INTO t2_tc_05_reg_0036_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0036-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0036_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0036_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0036_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0036_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0036-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0036_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0036_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0036_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0036_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0036_it a JOIN t2_tc_05_reg_0036_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0037-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=bb7dc5a4ed46=167|1264|1265|1406 neg_probe=1d48fa88d1b0=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0037_it, t2_tc_05_reg_0037_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0037_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0037_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0037_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0037_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0037_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0037_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0037_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0037_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0037_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0037_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0037_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0037_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0037_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0037_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0037_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0037_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0037_it (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0037_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0037_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0037_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0037_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0037_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0037_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0037_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0037_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0037_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0037_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0037_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0037_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0037_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0037_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0037_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0037_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0037_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0037_it);
-- probe 1/1 -> t1_tc_05_reg_0037_it
INSERT INTO t1_tc_05_reg_0037_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0037_it
INSERT INTO t2_tc_05_reg_0037_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0037-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0037_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0037_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0037_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0037_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0037-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0037_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0037_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0037_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0037_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0037_it a JOIN t2_tc_05_reg_0037_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0038-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=43e0d3db38f0=167|1264|1265|1406 neg_probe=42c8c09edb8e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0038_it, t2_tc_05_reg_0038_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0038_it (
  target CHAR(63) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0038_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0038_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0038_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0038_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0038_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0038_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0038_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0038_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0038_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0038_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0038_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0038_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0038_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0038_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0038_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0038_it (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0038_it (
  target CHAR(64) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0038_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0038_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0038_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0038_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0038_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0038_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0038_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0038_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0038_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0038_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0038_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0038_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0038_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0038_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0038_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0038_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0038_it);
-- probe 1/1 -> t1_tc_05_reg_0038_it
INSERT INTO t1_tc_05_reg_0038_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0038_it
INSERT INTO t2_tc_05_reg_0038_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0038-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0038_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0038_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0038_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0038_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0038-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0038_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0038_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0038_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0038_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0038_it a JOIN t2_tc_05_reg_0038_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0039-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=f50729e2c8c4=167|1264|1265|1406 neg_probe=87a6b4886101=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0039_it, t2_tc_05_reg_0039_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0039_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target CHAR(63) CHARACTER SET utf8mb4, PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0039_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0039_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0039_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0039_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0039_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0039_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0039_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0039_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0039_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0039_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0039_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0039_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0039_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0039_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0039_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0039_it (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0039_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target CHAR(64) CHARACTER SET utf8mb4, PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0039_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0039_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0039_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0039_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0039_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0039_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0039_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0039_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0039_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0039_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0039_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0039_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0039_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0039_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0039_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0039_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0039_it);
-- probe 1/1 -> t1_tc_05_reg_0039_it
INSERT INTO t1_tc_05_reg_0039_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0039_it
INSERT INTO t2_tc_05_reg_0039_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0039-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0039_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0039_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0039_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0039_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0039-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0039_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0039_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0039_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0039_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0039_it a JOIN t2_tc_05_reg_0039_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0040-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=70ea0e91212f=167|1264|1265|1406 neg_probe=1372cbbe44fb=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0040_it, t2_tc_05_reg_0040_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0040_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0040_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0040_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0040_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0040_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0040_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0040_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0040_it (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0040_it MODIFY target CHAR(64) CHARACTER SET utf8mb4 NOT NULL, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0040_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0040_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0040_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0040_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0040_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0040_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0040_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0040_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0040_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0040_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0040_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0040_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0040_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0040_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0040_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0040_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0040_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0040_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0040_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0040_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0040_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0040_it);
-- probe 1/1 -> t1_tc_05_reg_0040_it
INSERT INTO t1_tc_05_reg_0040_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0040_it
INSERT INTO t2_tc_05_reg_0040_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0040-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0040_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0040_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0040_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0040_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0040-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0040_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0040_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0040_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0040_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0040_it a JOIN t2_tc_05_reg_0040_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0041-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=682d2ad5af63=167|1264|1265|1406 neg_probe=938ae582b19c=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0041_it, t2_tc_05_reg_0041_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0041_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0041_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0041_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0041_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0041_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0041_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0041_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0041_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0041_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0041_it MODIFY target CHAR(64) CHARACTER SET utf8mb4 DEFAULT '', ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0041_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0041_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0041_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0041_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0041_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0041_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0041_it (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0041_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0041_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0041_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0041_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0041_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0041_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0041_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0041_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0041_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0041_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0041_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0041_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0041_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0041_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0041_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0041_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0041_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0041_it);
-- probe 1/1 -> t1_tc_05_reg_0041_it
INSERT INTO t1_tc_05_reg_0041_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0041_it
INSERT INTO t2_tc_05_reg_0041_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0041-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0041_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0041_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0041_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0041_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0041-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0041_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0041_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0041_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0041_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0041_it a JOIN t2_tc_05_reg_0041_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0042-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=e16bb8f0e95b=167|1264|1265|1406 neg_probe=3a8c35aeb623=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0042_it, t2_tc_05_reg_0042_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0042_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0042_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0042_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0042_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0042_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0042_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0042_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0042_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0042_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0042_it MODIFY target CHAR(64) CHARACTER SET utf8mb4 DEFAULT NULL, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0042_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0042_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0042_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0042_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0042_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0042_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0042_it (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0042_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0042_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0042_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0042_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0042_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0042_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0042_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0042_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0042_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0042_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0042_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0042_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0042_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0042_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0042_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0042_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0042_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0042_it);
-- probe 1/1 -> t1_tc_05_reg_0042_it
INSERT INTO t1_tc_05_reg_0042_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0042_it
INSERT INTO t2_tc_05_reg_0042_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0042-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0042_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0042_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0042_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0042_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0042-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0042_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0042_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0042_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0042_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0042_it a JOIN t2_tc_05_reg_0042_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0043-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=79043c9f8b34=167|1264|1265|1406 neg_probe=eef7b82204b3=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0043_it, t2_tc_05_reg_0043_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0043_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0043_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0043_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0043_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0043_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0043_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0043_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0043_it (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0043_it MODIFY target CHAR(64) CHARACTER SET utf8mb4 NOT NULL DEFAULT '', ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0043_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0043_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0043_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0043_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0043_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0043_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0043_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0043_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0043_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0043_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0043_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0043_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0043_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0043_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0043_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0043_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0043_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0043_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0043_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0043_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0043_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0043_it);
-- probe 1/1 -> t1_tc_05_reg_0043_it
INSERT INTO t1_tc_05_reg_0043_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0043_it
INSERT INTO t2_tc_05_reg_0043_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0043-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0043_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0043_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0043_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0043_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0043-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0043_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0043_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0043_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0043_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0043_it a JOIN t2_tc_05_reg_0043_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0044-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=dd0382d52d25=167|1264|1265|1406 neg_probe=b97a6958fb5c=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0044_it, t2_tc_05_reg_0044_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0044_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0044_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0044_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0044_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0044_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0044_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0044_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0044_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0044_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0044_it MODIFY target CHAR(64) CHARACTER SET utf8mb4 INVISIBLE, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0044_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0044_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0044_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0044_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0044_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0044_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0044_it (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0044_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0044_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0044_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0044_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0044_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0044_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0044_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0044_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0044_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0044_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0044_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0044_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0044_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0044_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0044_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0044_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0044_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0044_it);
-- probe 1/1 -> t1_tc_05_reg_0044_it
INSERT INTO t1_tc_05_reg_0044_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0044_it
INSERT INTO t2_tc_05_reg_0044_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0044-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0044_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0044_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0044_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0044_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0044-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0044_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0044_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0044_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0044_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0044_it a JOIN t2_tc_05_reg_0044_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0045-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=f85b4687f964=167|1264|1265|1406 neg_probe=57f8b874922f=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0045_it, t2_tc_05_reg_0045_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0045_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0045_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0045_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0045_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0045_it);
-- probe 1/1 -> t1_tc_05_reg_0045_it
INSERT INTO t1_tc_05_reg_0045_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0045_it
INSERT INTO t2_tc_05_reg_0045_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0045-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0045_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0045_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0045_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0045_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0045-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0045_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0045_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0045_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0045_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0045_it a JOIN t2_tc_05_reg_0045_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0046-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=f510a49c459f=167|1264|1265|1406 neg_probe=ba209e1407de=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0046_it, t2_tc_05_reg_0046_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0046_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0046_it (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0046_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0046_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0046_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0046_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0046_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0046_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0046_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0046_it (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0046_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0046_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0046_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0046_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0046_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0046_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0046_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0046_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0046_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0046_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0046_it);
-- probe 1/1 -> t1_tc_05_reg_0046_it
INSERT INTO t1_tc_05_reg_0046_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0046_it
INSERT INTO t2_tc_05_reg_0046_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0046-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0046_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0046_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0046_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0046_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0046-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0046_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0046_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0046_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0046_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0046_it a JOIN t2_tc_05_reg_0046_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0047-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: CHAR-02
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=4e1d5b84d7b7=167|1264|1265|1406 neg_probe=211876d45bb8=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0047_it, t2_tc_05_reg_0047_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0047_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0047_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0047_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0047_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0047_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0047_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0047_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0047_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0047_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0047_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0047_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0047_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0047_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0047_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0047_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0047_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0047_it (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0047_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0047_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0047_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0047_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0047_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0047_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0047_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0047_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0047_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0047_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0047_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0047_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0047_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0047_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0047_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0047_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0047_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0047_it);
-- probe 1/1 -> t1_tc_05_reg_0047_it
INSERT INTO t1_tc_05_reg_0047_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0047_it
INSERT INTO t2_tc_05_reg_0047_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0047-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0047_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0047_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0047_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0047_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0047-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0047_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0047_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0047_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0047_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0047_it a JOIN t2_tc_05_reg_0047_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0048-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: CHAR-02
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=095e62ded73d=167|1264|1265|1406 neg_probe=b3bbb39200d6=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0048_it, t2_tc_05_reg_0048_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0048_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0048_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0048_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0048_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0048_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0048_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0048_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0048_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0048_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0048_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0048_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0048_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0048_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0048_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0048_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0048_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0048_it (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0048_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0048_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0048_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0048_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0048_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0048_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0048_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0048_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0048_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0048_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0048_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0048_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0048_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0048_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0048_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0048_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0048_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0048_it);
-- probe 1/1 -> t1_tc_05_reg_0048_it
INSERT INTO t1_tc_05_reg_0048_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0048_it
INSERT INTO t2_tc_05_reg_0048_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0048-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0048_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0048_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0048_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0048_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0048-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0048_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0048_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0048_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0048_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0048_it a JOIN t2_tc_05_reg_0048_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0049-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=8ce262711985=167|1264|1265|1406 neg_probe=8f71e86700de=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0049_it, t2_tc_05_reg_0049_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0049_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0049_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0049_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0049_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0049_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0049_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0049_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0049_it (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0049_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0049_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0049_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0049_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0049_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0049_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0049_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0049_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0049_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0049_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0049_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0049_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0049_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0049_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0049_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0049_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0049_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0049_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0049_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0049_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0049_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0049_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0049_it);
-- probe 1/1 -> t1_tc_05_reg_0049_it
INSERT INTO t1_tc_05_reg_0049_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0049_it
INSERT INTO t2_tc_05_reg_0049_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0049-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0049_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0049_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0049_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0049_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0049-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0049_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0049_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0049_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0049_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0049_it a JOIN t2_tc_05_reg_0049_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0050-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=df52cb7b2d1b=167|1264|1265|1406 neg_probe=57745782e67f=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0050_it, t2_tc_05_reg_0050_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0050_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0050_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0050_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0050_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0050_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0050_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0050_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0050_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0050_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0050_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0050_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0050_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0050_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0050_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0050_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0050_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0050_it (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0050_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0050_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0050_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0050_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0050_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0050_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0050_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0050_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0050_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0050_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0050_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0050_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0050_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0050_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0050_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0050_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0050_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0050_it);
-- probe 1/1 -> t1_tc_05_reg_0050_it
INSERT INTO t1_tc_05_reg_0050_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0050_it
INSERT INTO t2_tc_05_reg_0050_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0050-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0050_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0050_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0050_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0050_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0050-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0050_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0050_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0050_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0050_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0050_it a JOIN t2_tc_05_reg_0050_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0051-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=bbf6f8c1d5b3=167|1264|1265|1406 neg_probe=9db122499e66=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0051_it, t2_tc_05_reg_0051_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0051_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0051_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0051_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0051_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0051_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0051_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0051_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0051_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0051_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0051_it (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0051_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0051_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0051_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0051_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0051_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0051_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0051_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0051_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0051_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0051_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0051_it);
-- probe 1/1 -> t1_tc_05_reg_0051_it
INSERT INTO t1_tc_05_reg_0051_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0051_it
INSERT INTO t2_tc_05_reg_0051_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0051-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0051_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0051_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0051_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0051_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0051-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0051_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0051_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0051_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0051_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0051_it a JOIN t2_tc_05_reg_0051_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0052-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=4520544816df=ACCEPTED neg_probe=8d90eb00f685=ACCEPTED
DROP TABLE IF EXISTS t1_tc_05_reg_0052_it, t2_tc_05_reg_0052_it;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_05_reg_0052_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0052_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0052_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0052_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0052_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0052_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0052_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0052_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0052_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0052_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0052_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0052_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0052_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0052_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0052_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0052_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0052_it (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0052_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0052_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0052_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0052_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0052_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0052_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0052_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0052_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0052_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0052_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0052_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0052_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0052_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0052_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0052_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0052_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0052_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0052_it);
-- probe 1/1 -> t1_tc_05_reg_0052_it
INSERT INTO t1_tc_05_reg_0052_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0052_it
INSERT INTO t2_tc_05_reg_0052_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0052-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0052_it) - @neg_before_t1 = (SELECT COUNT(*) FROM t2_tc_05_reg_0052_it) - @neg_before_t2,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0052_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0052_it) - @neg_before_t2,' expect=t1_added = t2_added (非 STRICT: 截断行为必须与对照表一致) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0052-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0052_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0052_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0052_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0052_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0052_it a JOIN t2_tc_05_reg_0052_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0053-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=e9de1c6b2382=167|1264|1265|1406 neg_probe=486f1eae29e4=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0053_it, t2_tc_05_reg_0053_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0053_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0053_it MODIFY target CHAR(64) CHARACTER SET utf8mb4 NOT NULL, ALGORITHM=instant;
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0053_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0053_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0053_it);
-- probe 1/1 -> t1_tc_05_reg_0053_it
INSERT INTO t1_tc_05_reg_0053_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0053_it
INSERT INTO t2_tc_05_reg_0053_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0053-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0053_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0053_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0053_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0053_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0053-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0053_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0053_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0053_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0053_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0053_it a JOIN t2_tc_05_reg_0053_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0054-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: CHAR-02
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=34f0792e1e2d=167|1264|1265|1406 neg_probe=91b7082ea7fc=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0054_it, t2_tc_05_reg_0054_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0054_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0054_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0054_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0054_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0054_it);
-- probe 1/1 -> t1_tc_05_reg_0054_it
INSERT INTO t1_tc_05_reg_0054_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0054_it
INSERT INTO t2_tc_05_reg_0054_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0054-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0054_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0054_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0054_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0054_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0054-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0054_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0054_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0054_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0054_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0054_it a JOIN t2_tc_05_reg_0054_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0055-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=a99e530bc15b=167|1264|1265|1406 neg_probe=72fe2201c514=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0055_it, t2_tc_05_reg_0055_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0055_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0055_it MODIFY target CHAR(64) CHARACTER SET utf8mb4 NOT NULL DEFAULT '', ALGORITHM=instant;
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_05_reg_0055_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0055_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0055_it);
-- probe 1/1 -> t1_tc_05_reg_0055_it
INSERT INTO t1_tc_05_reg_0055_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0055_it
INSERT INTO t2_tc_05_reg_0055_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0055-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0055_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0055_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0055_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0055_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0055-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0055_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0055_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0055_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0055_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0055_it a JOIN t2_tc_05_reg_0055_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0056-IT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant, Expected: FAIL
-- Varied factor: KP-05
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=FAIL build=SUCCESS assertions=2 neg_probes=1 neg_probe=f5d4e7fb9ac7=167|1264|1265|1406 neg_probe=804ac0bcc769=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0056_it, t2_tc_05_reg_0056_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0056_it (
  target CHAR(63) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0056_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0056_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0056_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0056_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0056_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0056_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0056_it (target) VALUES ('🎉');
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_05_reg_0056_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0056_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0056_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0056_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0056_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0056_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0056_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Oracle table: CHAR(63)
CREATE TABLE t2_tc_05_reg_0056_it (
  target CHAR(63) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0056_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0056_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0056_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0056_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0056_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0056_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0056_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0056_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0056_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0056_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0056_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0056_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0056_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0056_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0056_it);
-- probe 1/1 -> t1_tc_05_reg_0056_it
INSERT INTO t1_tc_05_reg_0056_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0056_it
INSERT INTO t2_tc_05_reg_0056_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0056-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0056_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0056_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0056_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0056_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0056-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0056_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0056_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0056_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0056_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0056_it a JOIN t2_tc_05_reg_0056_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-ATR-0004-IT
-- Column attribute preservation: COMMENT
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant
DROP TABLE IF EXISTS t1_tc_05_atr_0004_it, t2_tc_05_atr_0004_it;
CREATE TABLE t1_tc_05_atr_0004_it (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(63) CHARACTER SET utf8mb4 COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_atr_0004_it (target) VALUES ('');
INSERT INTO t1_tc_05_atr_0004_it (target) VALUES ('a');
INSERT INTO t1_tc_05_atr_0004_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_atr_0004_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_atr_0004_it (target) VALUES ('Hello');
ALTER TABLE t1_tc_05_atr_0004_it MODIFY target CHAR(64) CHARACTER SET utf8mb4 COMMENT 'test_comment', ALGORITHM=instant;
INSERT INTO t1_tc_05_atr_0004_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_05_atr_0004_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_05_atr_0004_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
SELECT 'TC-05-ATR-0004-IT' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_05_atr_0004_it' AND column_name='target' AND column_comment='test_comment';

-- Test Case: TC-05-ATR-0005-IT
-- Column attribute preservation: CHARSET
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant
DROP TABLE IF EXISTS t1_tc_05_atr_0005_it, t2_tc_05_atr_0005_it;
CREATE TABLE t1_tc_05_atr_0005_it (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(63) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_atr_0005_it (target) VALUES ('');
INSERT INTO t1_tc_05_atr_0005_it (target) VALUES ('a');
INSERT INTO t1_tc_05_atr_0005_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_atr_0005_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_atr_0005_it (target) VALUES ('Hello');
ALTER TABLE t1_tc_05_atr_0005_it MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=instant;
INSERT INTO t1_tc_05_atr_0005_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_05_atr_0005_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_05_atr_0005_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
SELECT 'TC-05-ATR-0005-IT' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_05_atr_0005_it' AND column_name='target' AND character_set_name='utf8mb4';

-- Test Case: TC-05-ATR-0006-IT
-- Column attribute preservation: COLLATE
-- Type: CHAR(63) -> CHAR(64), Algorithm: instant
DROP TABLE IF EXISTS t1_tc_05_atr_0006_it, t2_tc_05_atr_0006_it;
CREATE TABLE t1_tc_05_atr_0006_it (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(63) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_atr_0006_it (target) VALUES ('');
INSERT INTO t1_tc_05_atr_0006_it (target) VALUES ('a');
INSERT INTO t1_tc_05_atr_0006_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_atr_0006_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_atr_0006_it (target) VALUES ('Hello');
ALTER TABLE t1_tc_05_atr_0006_it MODIFY target CHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, ALGORITHM=instant;
INSERT INTO t1_tc_05_atr_0006_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_05_atr_0006_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_05_atr_0006_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
SELECT 'TC-05-ATR-0006-IT' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_05_atr_0006_it' AND column_name='target' AND collation_name='utf8mb4_bin';

-- Test Case: TC-05-REG-0057-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=829d2a4a25d1=167|1264|1265|1406 neg_probe=9692e41b6783=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0057_it, t2_tc_05_reg_0057_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0057_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0057_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0057_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0057_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0057_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0057_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0057_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0057_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0057_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0057_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0057_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0057_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0057_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0057_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0057_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0057_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0057_it (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0057_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0057_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0057_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0057_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0057_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0057_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0057_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0057_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0057_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0057_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0057_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0057_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0057_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0057_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0057_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0057_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0057_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0057_it);
-- probe 1/1 -> t1_tc_05_reg_0057_it
INSERT INTO t1_tc_05_reg_0057_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0057_it
INSERT INTO t2_tc_05_reg_0057_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0057-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0057_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0057_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0057_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0057_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0057-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0057_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0057_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0057_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0057_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0057_it a JOIN t2_tc_05_reg_0057_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0058-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=11bb79be6821=167|1264|1265|1406 neg_probe=ca363dbfe688=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0058_it, t2_tc_05_reg_0058_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0058_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0058_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0058_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0058_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0058_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0058_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0058_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0058_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0058_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0058_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0058_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0058_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0058_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0058_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0058_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0058_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0058_it (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0058_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0058_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0058_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0058_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0058_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0058_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0058_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0058_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0058_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0058_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0058_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0058_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0058_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0058_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0058_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0058_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0058_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0058_it);
-- probe 1/1 -> t1_tc_05_reg_0058_it
INSERT INTO t1_tc_05_reg_0058_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0058_it
INSERT INTO t2_tc_05_reg_0058_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0058-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0058_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0058_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0058_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0058_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0058-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0058_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0058_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0058_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0058_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0058_it a JOIN t2_tc_05_reg_0058_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0059-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=4ae41a95eb67=167|1264|1265|1406 neg_probe=5e5e5f92c62d=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0059_it, t2_tc_05_reg_0059_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0059_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0059_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0059_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0059_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0059_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0059_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0059_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0059_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0059_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0059_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0059_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0059_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0059_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0059_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0059_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0059_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0059_it (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0059_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0059_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0059_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0059_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0059_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0059_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0059_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0059_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0059_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0059_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0059_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0059_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0059_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0059_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0059_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0059_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0059_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0059_it);
-- probe 1/1 -> t1_tc_05_reg_0059_it
INSERT INTO t1_tc_05_reg_0059_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0059_it
INSERT INTO t2_tc_05_reg_0059_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0059-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0059_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0059_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0059_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0059_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0059-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0059_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0059_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0059_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0059_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0059_it a JOIN t2_tc_05_reg_0059_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0060-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: FAIL
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=FAIL build=SUCCESS assertions=2 neg_probes=1 neg_probe=00748792569e=167|1264|1265|1406 neg_probe=bceffd3e3fc7=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0060_it, t2_tc_05_reg_0060_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0060_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0060_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0060_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0060_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0060_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0060_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0060_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0060_it (target) VALUES ('🎉');
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_05_reg_0060_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0060_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0060_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0060_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0060_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0060_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0060_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Oracle table: CHAR(254)
CREATE TABLE t2_tc_05_reg_0060_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0060_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0060_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0060_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0060_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0060_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0060_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0060_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0060_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0060_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0060_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0060_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0060_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0060_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0060_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0060_it);
-- probe 1/1 -> t1_tc_05_reg_0060_it
INSERT INTO t1_tc_05_reg_0060_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0060_it
INSERT INTO t2_tc_05_reg_0060_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0060-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0060_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0060_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0060_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0060_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0060-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0060_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0060_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0060_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0060_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0060_it a JOIN t2_tc_05_reg_0060_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0061-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=d15d91c00968=167|1264|1265|1406 neg_probe=f1de56ab9cde=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0061_it, t2_tc_05_reg_0061_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0061_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0061_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0061_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0061_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0061_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0061_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0061_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0061_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0061_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0061_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0061_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0061_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0061_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0061_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0061_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0061_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0061_it (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0061_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0061_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0061_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0061_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0061_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0061_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0061_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0061_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0061_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0061_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0061_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0061_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0061_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0061_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0061_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0061_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0061_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0061_it);
-- probe 1/1 -> t1_tc_05_reg_0061_it
INSERT INTO t1_tc_05_reg_0061_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0061_it
INSERT INTO t2_tc_05_reg_0061_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0061-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0061_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0061_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0061_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0061_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0061-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0061_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0061_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0061_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0061_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0061_it a JOIN t2_tc_05_reg_0061_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0062-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=c175ab3a315a=167|1264|1265|1406 neg_probe=9696949373d5=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0062_it, t2_tc_05_reg_0062_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0062_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0062_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0062_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0062_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0062_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0062_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0062_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0062_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0062_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0062_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0062_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0062_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0062_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0062_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0062_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0062_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0062_it (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0062_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0062_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0062_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0062_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0062_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0062_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0062_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0062_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0062_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0062_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0062_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0062_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0062_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0062_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0062_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0062_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0062_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0062_it);
-- probe 1/1 -> t1_tc_05_reg_0062_it
INSERT INTO t1_tc_05_reg_0062_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0062_it
INSERT INTO t2_tc_05_reg_0062_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0062-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0062_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0062_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0062_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0062_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0062-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0062_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0062_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0062_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0062_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0062_it a JOIN t2_tc_05_reg_0062_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0063-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=a919714ba08a=167|1264|1265|1406 neg_probe=623f909cca7f=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0063_it, t2_tc_05_reg_0063_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0063_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0063_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0063_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0063_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0063_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0063_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0063_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0063_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0063_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0063_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0063_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0063_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0063_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0063_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0063_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0063_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0063_it (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0063_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0063_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0063_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0063_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0063_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0063_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0063_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0063_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0063_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0063_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0063_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0063_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0063_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0063_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0063_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0063_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0063_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0063_it);
-- probe 1/1 -> t1_tc_05_reg_0063_it
INSERT INTO t1_tc_05_reg_0063_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0063_it
INSERT INTO t2_tc_05_reg_0063_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0063-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0063_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0063_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0063_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0063_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0063-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0063_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0063_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0063_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0063_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0063_it a JOIN t2_tc_05_reg_0063_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0064-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=960cbc2f34f2=167|1264|1265|1406 neg_probe=90990638086d=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0064_it, t2_tc_05_reg_0064_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0064_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0064_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0064_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0064_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0064_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0064_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0064_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0064_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0064_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0064_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0064_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0064_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0064_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0064_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0064_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0064_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0064_it (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0064_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0064_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0064_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0064_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0064_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0064_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0064_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0064_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0064_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0064_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0064_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0064_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0064_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0064_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0064_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0064_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0064_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0064_it);
-- probe 1/1 -> t1_tc_05_reg_0064_it
INSERT INTO t1_tc_05_reg_0064_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0064_it
INSERT INTO t2_tc_05_reg_0064_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0064-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0064_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0064_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0064_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0064_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0064-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0064_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0064_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0064_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0064_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0064_it a JOIN t2_tc_05_reg_0064_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0065-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=962928f6620a=167|1264|1265|1406 neg_probe=94755be6f35e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0065_it, t2_tc_05_reg_0065_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0065_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0065_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0065_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0065_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0065_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0065_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0065_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0065_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0065_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0065_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0065_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0065_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0065_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0065_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0065_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0065_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0065_it (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0065_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0065_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0065_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0065_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0065_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0065_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0065_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0065_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0065_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0065_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0065_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0065_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0065_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0065_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0065_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0065_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0065_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0065_it);
-- probe 1/1 -> t1_tc_05_reg_0065_it
INSERT INTO t1_tc_05_reg_0065_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0065_it
INSERT INTO t2_tc_05_reg_0065_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0065-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0065_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0065_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0065_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0065_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0065-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0065_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0065_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0065_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0065_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0065_it a JOIN t2_tc_05_reg_0065_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0066-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=5d218b3de9cc=167|1264|1265|1406 neg_probe=168589bfba56=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0066_it, t2_tc_05_reg_0066_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0066_it (
  target CHAR(254) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0066_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0066_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0066_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0066_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0066_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0066_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0066_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0066_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0066_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0066_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0066_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0066_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0066_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0066_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0066_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0066_it (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0066_it (
  target CHAR(255) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0066_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0066_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0066_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0066_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0066_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0066_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0066_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0066_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0066_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0066_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0066_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0066_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0066_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0066_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0066_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0066_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0066_it);
-- probe 1/1 -> t1_tc_05_reg_0066_it
INSERT INTO t1_tc_05_reg_0066_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0066_it
INSERT INTO t2_tc_05_reg_0066_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0066-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0066_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0066_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0066_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0066_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0066-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0066_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0066_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0066_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0066_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0066_it a JOIN t2_tc_05_reg_0066_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0067-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=2ce00622eeb1=167|1264|1265|1406 neg_probe=964d85d2a02d=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0067_it, t2_tc_05_reg_0067_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0067_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target CHAR(254) CHARACTER SET utf8mb4, PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0067_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0067_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0067_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0067_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0067_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0067_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0067_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0067_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0067_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0067_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0067_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0067_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0067_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0067_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0067_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0067_it (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0067_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target CHAR(255) CHARACTER SET utf8mb4, PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0067_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0067_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0067_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0067_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0067_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0067_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0067_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0067_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0067_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0067_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0067_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0067_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0067_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0067_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0067_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0067_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0067_it);
-- probe 1/1 -> t1_tc_05_reg_0067_it
INSERT INTO t1_tc_05_reg_0067_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0067_it
INSERT INTO t2_tc_05_reg_0067_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0067-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0067_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0067_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0067_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0067_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0067-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0067_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0067_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0067_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0067_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0067_it a JOIN t2_tc_05_reg_0067_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0068-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=06922170d643=167|1264|1265|1406 neg_probe=49da064e6887=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0068_it, t2_tc_05_reg_0068_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0068_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0068_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0068_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0068_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0068_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0068_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0068_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0068_it (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0068_it MODIFY target CHAR(255) CHARACTER SET utf8mb4 NOT NULL, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0068_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0068_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0068_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0068_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0068_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0068_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0068_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0068_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0068_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0068_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0068_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0068_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0068_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0068_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0068_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0068_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0068_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0068_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0068_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0068_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0068_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0068_it);
-- probe 1/1 -> t1_tc_05_reg_0068_it
INSERT INTO t1_tc_05_reg_0068_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0068_it
INSERT INTO t2_tc_05_reg_0068_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0068-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0068_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0068_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0068_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0068_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0068-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0068_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0068_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0068_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0068_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0068_it a JOIN t2_tc_05_reg_0068_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0069-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=3f7e26816f72=167|1264|1265|1406 neg_probe=946a8e5d3717=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0069_it, t2_tc_05_reg_0069_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0069_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0069_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0069_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0069_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0069_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0069_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0069_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0069_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0069_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0069_it MODIFY target CHAR(255) CHARACTER SET utf8mb4 DEFAULT '', ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0069_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0069_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0069_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0069_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0069_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0069_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0069_it (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0069_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0069_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0069_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0069_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0069_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0069_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0069_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0069_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0069_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0069_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0069_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0069_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0069_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0069_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0069_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0069_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0069_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0069_it);
-- probe 1/1 -> t1_tc_05_reg_0069_it
INSERT INTO t1_tc_05_reg_0069_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0069_it
INSERT INTO t2_tc_05_reg_0069_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0069-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0069_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0069_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0069_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0069_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0069-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0069_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0069_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0069_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0069_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0069_it a JOIN t2_tc_05_reg_0069_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0070-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=ebf1c03f3632=167|1264|1265|1406 neg_probe=6c704c4bc4b8=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0070_it, t2_tc_05_reg_0070_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0070_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0070_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0070_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0070_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0070_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0070_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0070_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0070_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0070_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0070_it MODIFY target CHAR(255) CHARACTER SET utf8mb4 DEFAULT NULL, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0070_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0070_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0070_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0070_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0070_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0070_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0070_it (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0070_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0070_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0070_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0070_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0070_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0070_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0070_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0070_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0070_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0070_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0070_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0070_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0070_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0070_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0070_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0070_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0070_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0070_it);
-- probe 1/1 -> t1_tc_05_reg_0070_it
INSERT INTO t1_tc_05_reg_0070_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0070_it
INSERT INTO t2_tc_05_reg_0070_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0070-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0070_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0070_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0070_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0070_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0070-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0070_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0070_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0070_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0070_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0070_it a JOIN t2_tc_05_reg_0070_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0071-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=3fb2b7c76481=167|1264|1265|1406 neg_probe=e966848f7013=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0071_it, t2_tc_05_reg_0071_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0071_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0071_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0071_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0071_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0071_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0071_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0071_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0071_it (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0071_it MODIFY target CHAR(255) CHARACTER SET utf8mb4 NOT NULL DEFAULT '', ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0071_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0071_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0071_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0071_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0071_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0071_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0071_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0071_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0071_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0071_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0071_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0071_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0071_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0071_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0071_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0071_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0071_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0071_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0071_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0071_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0071_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0071_it);
-- probe 1/1 -> t1_tc_05_reg_0071_it
INSERT INTO t1_tc_05_reg_0071_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0071_it
INSERT INTO t2_tc_05_reg_0071_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0071-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0071_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0071_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0071_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0071_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0071-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0071_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0071_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0071_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0071_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0071_it a JOIN t2_tc_05_reg_0071_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0072-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=457e6f86d489=167|1264|1265|1406 neg_probe=a5b83e1a84c2=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0072_it, t2_tc_05_reg_0072_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0072_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0072_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0072_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0072_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0072_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0072_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0072_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0072_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0072_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0072_it MODIFY target CHAR(255) CHARACTER SET utf8mb4 INVISIBLE, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0072_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0072_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0072_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0072_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0072_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0072_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0072_it (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0072_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0072_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0072_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0072_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0072_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0072_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0072_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0072_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0072_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0072_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0072_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0072_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0072_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0072_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0072_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0072_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0072_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0072_it);
-- probe 1/1 -> t1_tc_05_reg_0072_it
INSERT INTO t1_tc_05_reg_0072_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0072_it
INSERT INTO t2_tc_05_reg_0072_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0072-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0072_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0072_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0072_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0072_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0072-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0072_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0072_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0072_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0072_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0072_it a JOIN t2_tc_05_reg_0072_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0073-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=cbcbcad3eae6=167|1264|1265|1406 neg_probe=42fc759a9f2c=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0073_it, t2_tc_05_reg_0073_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0073_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0073_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0073_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0073_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0073_it);
-- probe 1/1 -> t1_tc_05_reg_0073_it
INSERT INTO t1_tc_05_reg_0073_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0073_it
INSERT INTO t2_tc_05_reg_0073_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0073-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0073_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0073_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0073_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0073_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0073-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0073_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0073_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0073_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0073_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0073_it a JOIN t2_tc_05_reg_0073_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0074-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=23d4302e79d8=167|1264|1265|1406 neg_probe=7d546c8299ce=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0074_it, t2_tc_05_reg_0074_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0074_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0074_it (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0074_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0074_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0074_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0074_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0074_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0074_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0074_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0074_it (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0074_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0074_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0074_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0074_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0074_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0074_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0074_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0074_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0074_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0074_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0074_it);
-- probe 1/1 -> t1_tc_05_reg_0074_it
INSERT INTO t1_tc_05_reg_0074_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0074_it
INSERT INTO t2_tc_05_reg_0074_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0074-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0074_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0074_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0074_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0074_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0074-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0074_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0074_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0074_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0074_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0074_it a JOIN t2_tc_05_reg_0074_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0075-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: CHAR-03
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=971fca0c43f4=167|1264|1265|1406 neg_probe=234acc8bbc36=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0075_it, t2_tc_05_reg_0075_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0075_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0075_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0075_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0075_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0075_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0075_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0075_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0075_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0075_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0075_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0075_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0075_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0075_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0075_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0075_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0075_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0075_it (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0075_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0075_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0075_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0075_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0075_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0075_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0075_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0075_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0075_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0075_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0075_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0075_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0075_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0075_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0075_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0075_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0075_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0075_it);
-- probe 1/1 -> t1_tc_05_reg_0075_it
INSERT INTO t1_tc_05_reg_0075_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0075_it
INSERT INTO t2_tc_05_reg_0075_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0075-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0075_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0075_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0075_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0075_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0075-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0075_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0075_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0075_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0075_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0075_it a JOIN t2_tc_05_reg_0075_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0076-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: CHAR-03
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=bdf325ded966=167|1264|1265|1406 neg_probe=497a95e515e7=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0076_it, t2_tc_05_reg_0076_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0076_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0076_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0076_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0076_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0076_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0076_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0076_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0076_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0076_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0076_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0076_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0076_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0076_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0076_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0076_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0076_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0076_it (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0076_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0076_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0076_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0076_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0076_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0076_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0076_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0076_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0076_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0076_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0076_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0076_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0076_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0076_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0076_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0076_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0076_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0076_it);
-- probe 1/1 -> t1_tc_05_reg_0076_it
INSERT INTO t1_tc_05_reg_0076_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0076_it
INSERT INTO t2_tc_05_reg_0076_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0076-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0076_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0076_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0076_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0076_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0076-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0076_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0076_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0076_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0076_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0076_it a JOIN t2_tc_05_reg_0076_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0077-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=b3a008739c4b=167|1264|1265|1406 neg_probe=f5a76a2656ab=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0077_it, t2_tc_05_reg_0077_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0077_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0077_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0077_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0077_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0077_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0077_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0077_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0077_it (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0077_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0077_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0077_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0077_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0077_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0077_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0077_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0077_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0077_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0077_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0077_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0077_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0077_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0077_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0077_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0077_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0077_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0077_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0077_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0077_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0077_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0077_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0077_it);
-- probe 1/1 -> t1_tc_05_reg_0077_it
INSERT INTO t1_tc_05_reg_0077_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0077_it
INSERT INTO t2_tc_05_reg_0077_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0077-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0077_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0077_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0077_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0077_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0077-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0077_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0077_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0077_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0077_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0077_it a JOIN t2_tc_05_reg_0077_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0078-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=ed029662f7a9=167|1264|1265|1406 neg_probe=ec9d5463bd3d=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0078_it, t2_tc_05_reg_0078_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0078_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0078_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0078_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0078_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0078_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0078_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0078_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0078_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0078_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0078_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0078_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0078_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0078_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0078_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0078_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0078_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0078_it (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0078_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0078_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0078_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0078_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0078_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0078_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0078_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0078_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0078_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0078_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0078_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0078_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0078_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0078_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0078_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0078_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0078_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0078_it);
-- probe 1/1 -> t1_tc_05_reg_0078_it
INSERT INTO t1_tc_05_reg_0078_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0078_it
INSERT INTO t2_tc_05_reg_0078_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0078-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0078_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0078_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0078_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0078_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0078-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0078_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0078_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0078_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0078_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0078_it a JOIN t2_tc_05_reg_0078_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0079-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=682f17dc4459=167|1264|1265|1406 neg_probe=6cf8556cb17e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0079_it, t2_tc_05_reg_0079_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0079_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0079_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0079_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0079_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0079_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0079_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0079_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0079_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0079_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0079_it (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0079_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0079_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0079_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0079_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0079_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0079_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0079_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0079_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0079_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0079_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0079_it);
-- probe 1/1 -> t1_tc_05_reg_0079_it
INSERT INTO t1_tc_05_reg_0079_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0079_it
INSERT INTO t2_tc_05_reg_0079_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0079-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0079_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0079_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0079_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0079_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0079-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0079_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0079_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0079_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0079_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0079_it a JOIN t2_tc_05_reg_0079_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0080-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=c0f99873da49=ACCEPTED neg_probe=556316876dd3=ACCEPTED
DROP TABLE IF EXISTS t1_tc_05_reg_0080_it, t2_tc_05_reg_0080_it;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_05_reg_0080_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0080_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0080_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0080_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0080_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0080_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0080_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0080_it (target) VALUES ('🎉');
INSERT INTO t1_tc_05_reg_0080_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0080_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0080_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0080_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0080_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0080_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0080_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0080_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0080_it (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0080_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0080_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0080_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0080_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0080_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0080_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0080_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0080_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0080_it (target) VALUES (NULL);
INSERT INTO t2_tc_05_reg_0080_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0080_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0080_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0080_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0080_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0080_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0080_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0080_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0080_it);
-- probe 1/1 -> t1_tc_05_reg_0080_it
INSERT INTO t1_tc_05_reg_0080_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0080_it
INSERT INTO t2_tc_05_reg_0080_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0080-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0080_it) - @neg_before_t1 = (SELECT COUNT(*) FROM t2_tc_05_reg_0080_it) - @neg_before_t2,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0080_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0080_it) - @neg_before_t2,' expect=t1_added = t2_added (非 STRICT: 截断行为必须与对照表一致) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0080-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0080_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0080_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0080_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0080_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0080_it a JOIN t2_tc_05_reg_0080_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0081-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=35d6e4a2be2a=167|1264|1265|1406 neg_probe=32a935e5de09=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0081_it, t2_tc_05_reg_0081_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0081_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0081_it MODIFY target CHAR(255) CHARACTER SET utf8mb4 NOT NULL, ALGORITHM=instant;
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0081_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0081_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0081_it);
-- probe 1/1 -> t1_tc_05_reg_0081_it
INSERT INTO t1_tc_05_reg_0081_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0081_it
INSERT INTO t2_tc_05_reg_0081_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0081-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0081_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0081_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0081_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0081_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0081-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0081_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0081_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0081_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0081_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0081_it a JOIN t2_tc_05_reg_0081_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0082-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: CHAR-03
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=685259d8a52d=167|1264|1265|1406 neg_probe=3abf1f480885=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0082_it, t2_tc_05_reg_0082_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0082_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0082_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0082_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0082_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0082_it);
-- probe 1/1 -> t1_tc_05_reg_0082_it
INSERT INTO t1_tc_05_reg_0082_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0082_it
INSERT INTO t2_tc_05_reg_0082_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0082-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0082_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0082_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0082_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0082_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0082-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0082_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0082_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0082_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0082_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0082_it a JOIN t2_tc_05_reg_0082_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0083-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=1 neg_probe=bdff0180cf74=167|1264|1265|1406 neg_probe=db63e53ae810=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0083_it, t2_tc_05_reg_0083_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0083_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_05_reg_0083_it MODIFY target CHAR(255) CHARACTER SET utf8mb4 NOT NULL DEFAULT '', ALGORITHM=instant;
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_05_reg_0083_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0083_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0083_it);
-- probe 1/1 -> t1_tc_05_reg_0083_it
INSERT INTO t1_tc_05_reg_0083_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0083_it
INSERT INTO t2_tc_05_reg_0083_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0083-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0083_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0083_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0083_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0083_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0083-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0083_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0083_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0083_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0083_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0083_it a JOIN t2_tc_05_reg_0083_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-REG-0084-IT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant, Expected: FAIL
-- Varied factor: KP-05
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=FAIL build=SUCCESS assertions=2 neg_probes=1 neg_probe=62ecce50aee4=167|1264|1265|1406 neg_probe=73693766742c=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_05_reg_0084_it, t2_tc_05_reg_0084_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_05_reg_0084_it (
  target CHAR(254) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_reg_0084_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0084_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0084_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0084_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_reg_0084_it (target) VALUES ('Hello');
INSERT INTO t1_tc_05_reg_0084_it (target) VALUES ('你好');
INSERT INTO t1_tc_05_reg_0084_it (target) VALUES ('🎉');
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_05_reg_0084_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0084_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0084_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_05_reg_0084_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_05_reg_0084_it (target) VALUES ('');
INSERT INTO t1_tc_05_reg_0084_it (target) VALUES ('a');
INSERT INTO t1_tc_05_reg_0084_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Oracle table: CHAR(254)
CREATE TABLE t2_tc_05_reg_0084_it (
  target CHAR(254) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_05_reg_0084_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0084_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0084_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0084_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_05_reg_0084_it (target) VALUES ('Hello');
INSERT INTO t2_tc_05_reg_0084_it (target) VALUES ('你好');
INSERT INTO t2_tc_05_reg_0084_it (target) VALUES ('🎉');
INSERT INTO t2_tc_05_reg_0084_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0084_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_05_reg_0084_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_05_reg_0084_it (target) VALUES ('');
INSERT INTO t2_tc_05_reg_0084_it (target) VALUES ('a');
INSERT INTO t2_tc_05_reg_0084_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_05_reg_0084_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_05_reg_0084_it);
-- probe 1/1 -> t1_tc_05_reg_0084_it
INSERT INTO t1_tc_05_reg_0084_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_05_reg_0084_it
INSERT INTO t2_tc_05_reg_0084_it (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-05-REG-0084-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_05_reg_0084_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_05_reg_0084_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_05_reg_0084_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_05_reg_0084_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-05-REG-0084-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_05_reg_0084_it
   WHERE id NOT IN (SELECT id FROM t2_tc_05_reg_0084_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_05_reg_0084_it
   WHERE id NOT IN (SELECT id FROM t1_tc_05_reg_0084_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_05_reg_0084_it a JOIN t2_tc_05_reg_0084_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-05-ATR-0007-IT
-- Column attribute preservation: COMMENT
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant
DROP TABLE IF EXISTS t1_tc_05_atr_0007_it, t2_tc_05_atr_0007_it;
CREATE TABLE t1_tc_05_atr_0007_it (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(254) CHARACTER SET utf8mb4 COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_atr_0007_it (target) VALUES ('');
INSERT INTO t1_tc_05_atr_0007_it (target) VALUES ('a');
INSERT INTO t1_tc_05_atr_0007_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_atr_0007_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_atr_0007_it (target) VALUES ('Hello');
ALTER TABLE t1_tc_05_atr_0007_it MODIFY target CHAR(255) CHARACTER SET utf8mb4 COMMENT 'test_comment', ALGORITHM=instant;
INSERT INTO t1_tc_05_atr_0007_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_05_atr_0007_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_05_atr_0007_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
SELECT 'TC-05-ATR-0007-IT' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_05_atr_0007_it' AND column_name='target' AND column_comment='test_comment';

-- Test Case: TC-05-ATR-0008-IT
-- Column attribute preservation: CHARSET
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant
DROP TABLE IF EXISTS t1_tc_05_atr_0008_it, t2_tc_05_atr_0008_it;
CREATE TABLE t1_tc_05_atr_0008_it (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(254) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_atr_0008_it (target) VALUES ('');
INSERT INTO t1_tc_05_atr_0008_it (target) VALUES ('a');
INSERT INTO t1_tc_05_atr_0008_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_atr_0008_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_atr_0008_it (target) VALUES ('Hello');
ALTER TABLE t1_tc_05_atr_0008_it MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=instant;
INSERT INTO t1_tc_05_atr_0008_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_05_atr_0008_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_05_atr_0008_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
SELECT 'TC-05-ATR-0008-IT' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_05_atr_0008_it' AND column_name='target' AND character_set_name='utf8mb4';

-- Test Case: TC-05-ATR-0009-IT
-- Column attribute preservation: COLLATE
-- Type: CHAR(254) -> CHAR(255), Algorithm: instant
DROP TABLE IF EXISTS t1_tc_05_atr_0009_it, t2_tc_05_atr_0009_it;
CREATE TABLE t1_tc_05_atr_0009_it (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(254) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_05_atr_0009_it (target) VALUES ('');
INSERT INTO t1_tc_05_atr_0009_it (target) VALUES ('a');
INSERT INTO t1_tc_05_atr_0009_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_atr_0009_it (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_05_atr_0009_it (target) VALUES ('Hello');
ALTER TABLE t1_tc_05_atr_0009_it MODIFY target CHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, ALGORITHM=instant;
INSERT INTO t1_tc_05_atr_0009_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_05_atr_0009_it (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_05_atr_0009_it (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
SELECT 'TC-05-ATR-0009-IT' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_05_atr_0009_it' AND column_name='target' AND collation_name='utf8mb4_bin';

