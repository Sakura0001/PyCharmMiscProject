-- ============================================================
-- RDS MySQL DDL 秒级/在线修改列类型 测试套件 — 阿里云环境
-- 环境说明: 所有功能开关默认开启
-- 覆盖类型: 整数(SIGNED/UNSIGNED) + CHAR + VARCHAR
-- 覆盖算法: INSTANT + INPLACE
-- ============================================================
-- 本文件由 generate_test_sql.py 自动生成, 请勿手动修改
-- Suite-Revision: 3c46cd9910b1   (生成器源码哈希; 时间戳见 results/generation_manifest.json)
-- 用例 ID 规则: TC-<文件号>-<作用域>-<序号>-<IT|IP>  —— 全局唯一
--   作用域 REG=普通表 OFAT/二元组, ATR=列属性保持, SPE=特殊模式,
--          FK=外键, PTK=分区(目标列是分区键), PNK=分区(目标列非分区键)
-- ============================================================

SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
SET SESSION innodb_lock_wait_timeout = 50;

-- File 34: 索引与约束完整性复验 (SECONDARY / UNIQUE)

-- Test Case: TC-34-IDX-0001-XX
-- Index integrity: SECONDARY index on target
-- Type: TINYINT -> SMALLINT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-1-2
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=0e01fb832503 column_type=smallint index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0001_xx, t2_tc_34_idx_0001_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0001_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TINYINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (-16);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (-15);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (-14);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (-13);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (-12);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (-11);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (-10);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (-9);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (-8);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (-7);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (-6);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (-5);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (-4);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (-3);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (-2);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (-1);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0001_xx (target) VALUES (15);
ANALYZE TABLE t1_tc_34_idx_0001_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0001_xx MODIFY target SMALLINT, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0001_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target SMALLINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (-16);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (-15);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (-14);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (-13);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (-12);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (-11);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (-10);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (-9);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (-8);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (-7);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (-6);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (-5);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (-4);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (-3);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (-2);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (-1);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0001_xx (target) VALUES (15);
ANALYZE TABLE t2_tc_34_idx_0001_xx;
SELECT 'TC-34-IDX-0001-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0001_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0001_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0001-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0001_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0001_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0001_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0001_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0001-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0001_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0001_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0001-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0001_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0001_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0001_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0001_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0001-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='smallint'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=smallint nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0001_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0002-XX
-- Index integrity: UNIQUE index on target
-- Type: TINYINT -> SMALLINT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-1-2
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=7b3f4e03bd6d column_type=smallint index_kind=UNIQUE neg_probe=776bc34c8a0b=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0002_xx, t2_tc_34_idx_0002_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0002_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TINYINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (-16);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (-15);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (-14);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (-13);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (-12);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (-11);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (-10);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (-9);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (-8);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (-7);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (-6);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (-5);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (-4);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (-3);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (-2);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (-1);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (15);
ANALYZE TABLE t1_tc_34_idx_0002_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0002_xx MODIFY target SMALLINT, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0002_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target SMALLINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (-16);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (-15);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (-14);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (-13);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (-12);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (-11);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (-10);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (-9);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (-8);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (-7);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (-6);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (-5);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (-4);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (-3);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (-2);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (-1);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0002_xx (target) VALUES (15);
ANALYZE TABLE t2_tc_34_idx_0002_xx;
SELECT 'TC-34-IDX-0002-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0002_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0002_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0002-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0002_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0002_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0002_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0002_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0002-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0002_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0002_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0002-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0002_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0002_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0002_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0002_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0002-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='smallint'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=smallint nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0002_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0002_xx (target) VALUES (-16);

-- Test Case: TC-34-IDX-0003-XX
-- Index integrity: SECONDARY index on target
-- Type: TINYINT -> MEDIUMINT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-1-3
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=d5a31ae0afb1 column_type=mediumint index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0003_xx, t2_tc_34_idx_0003_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0003_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TINYINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (-16);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (-15);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (-14);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (-13);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (-12);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (-11);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (-10);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (-9);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (-8);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (-7);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (-6);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (-5);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (-4);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (-3);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (-2);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (-1);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0003_xx (target) VALUES (15);
ANALYZE TABLE t1_tc_34_idx_0003_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0003_xx MODIFY target MEDIUMINT, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0003_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (-16);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (-15);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (-14);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (-13);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (-12);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (-11);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (-10);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (-9);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (-8);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (-7);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (-6);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (-5);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (-4);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (-3);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (-2);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (-1);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0003_xx (target) VALUES (15);
ANALYZE TABLE t2_tc_34_idx_0003_xx;
SELECT 'TC-34-IDX-0003-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0003_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0003_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0003-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0003_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0003_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0003_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0003_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0003-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0003_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0003_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0003-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0003_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0003_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0003_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0003_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0003-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='mediumint'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=mediumint nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0003_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0004-XX
-- Index integrity: UNIQUE index on target
-- Type: TINYINT -> MEDIUMINT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-1-3
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=28d513c3a549 column_type=mediumint index_kind=UNIQUE neg_probe=7df40f71ef8e=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0004_xx, t2_tc_34_idx_0004_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0004_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TINYINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (-16);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (-15);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (-14);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (-13);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (-12);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (-11);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (-10);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (-9);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (-8);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (-7);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (-6);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (-5);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (-4);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (-3);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (-2);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (-1);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (15);
ANALYZE TABLE t1_tc_34_idx_0004_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0004_xx MODIFY target MEDIUMINT, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0004_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (-16);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (-15);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (-14);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (-13);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (-12);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (-11);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (-10);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (-9);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (-8);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (-7);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (-6);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (-5);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (-4);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (-3);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (-2);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (-1);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0004_xx (target) VALUES (15);
ANALYZE TABLE t2_tc_34_idx_0004_xx;
SELECT 'TC-34-IDX-0004-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0004_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0004_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0004-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0004_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0004_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0004_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0004_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0004-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0004_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0004_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0004-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0004_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0004_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0004_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0004_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0004-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='mediumint'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=mediumint nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0004_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0004_xx (target) VALUES (-16);

-- Test Case: TC-34-IDX-0005-XX
-- Index integrity: SECONDARY index on target
-- Type: TINYINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-1-4
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=28aa03e59dcb column_type=int index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0005_xx, t2_tc_34_idx_0005_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0005_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TINYINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (-16);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (-15);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (-14);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (-13);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (-12);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (-11);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (-10);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (-9);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (-8);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (-7);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (-6);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (-5);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (-4);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (-3);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (-2);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (-1);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0005_xx (target) VALUES (15);
ANALYZE TABLE t1_tc_34_idx_0005_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0005_xx MODIFY target INT, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0005_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target INT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (-16);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (-15);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (-14);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (-13);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (-12);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (-11);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (-10);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (-9);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (-8);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (-7);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (-6);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (-5);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (-4);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (-3);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (-2);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (-1);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0005_xx (target) VALUES (15);
ANALYZE TABLE t2_tc_34_idx_0005_xx;
SELECT 'TC-34-IDX-0005-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0005_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0005_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0005-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0005_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0005_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0005_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0005_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0005-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0005_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0005_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0005-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0005_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0005_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0005_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0005_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0005-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=int nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0005_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0006-XX
-- Index integrity: UNIQUE index on target
-- Type: TINYINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-1-4
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=343eef21a476 column_type=int index_kind=UNIQUE neg_probe=f38a072f174c=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0006_xx, t2_tc_34_idx_0006_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0006_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TINYINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (-16);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (-15);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (-14);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (-13);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (-12);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (-11);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (-10);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (-9);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (-8);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (-7);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (-6);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (-5);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (-4);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (-3);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (-2);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (-1);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (15);
ANALYZE TABLE t1_tc_34_idx_0006_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0006_xx MODIFY target INT, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0006_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target INT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (-16);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (-15);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (-14);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (-13);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (-12);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (-11);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (-10);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (-9);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (-8);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (-7);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (-6);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (-5);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (-4);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (-3);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (-2);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (-1);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0006_xx (target) VALUES (15);
ANALYZE TABLE t2_tc_34_idx_0006_xx;
SELECT 'TC-34-IDX-0006-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0006_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0006_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0006-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0006_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0006_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0006_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0006_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0006-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0006_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0006_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0006-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0006_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0006_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0006_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0006_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0006-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=int nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0006_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0006_xx (target) VALUES (-16);

-- Test Case: TC-34-IDX-0007-XX
-- Index integrity: SECONDARY index on target
-- Type: TINYINT -> BIGINT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-1-5
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=0329dd52a90a column_type=bigint index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0007_xx, t2_tc_34_idx_0007_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0007_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TINYINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (-16);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (-15);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (-14);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (-13);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (-12);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (-11);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (-10);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (-9);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (-8);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (-7);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (-6);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (-5);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (-4);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (-3);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (-2);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (-1);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0007_xx (target) VALUES (15);
ANALYZE TABLE t1_tc_34_idx_0007_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0007_xx MODIFY target BIGINT, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0007_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIGINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (-16);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (-15);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (-14);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (-13);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (-12);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (-11);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (-10);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (-9);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (-8);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (-7);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (-6);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (-5);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (-4);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (-3);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (-2);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (-1);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0007_xx (target) VALUES (15);
ANALYZE TABLE t2_tc_34_idx_0007_xx;
SELECT 'TC-34-IDX-0007-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0007_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0007_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0007-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0007_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0007_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0007_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0007_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0007-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0007_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0007_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0007-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0007_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0007_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0007_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0007_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0007-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bigint'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=bigint nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0007_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0008-XX
-- Index integrity: UNIQUE index on target
-- Type: TINYINT -> BIGINT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-1-5
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=f364bf113c31 column_type=bigint index_kind=UNIQUE neg_probe=b0dcc627d27d=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0008_xx, t2_tc_34_idx_0008_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0008_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TINYINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (-16);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (-15);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (-14);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (-13);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (-12);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (-11);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (-10);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (-9);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (-8);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (-7);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (-6);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (-5);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (-4);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (-3);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (-2);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (-1);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (15);
ANALYZE TABLE t1_tc_34_idx_0008_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0008_xx MODIFY target BIGINT, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0008_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIGINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (-16);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (-15);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (-14);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (-13);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (-12);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (-11);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (-10);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (-9);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (-8);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (-7);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (-6);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (-5);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (-4);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (-3);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (-2);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (-1);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0008_xx (target) VALUES (15);
ANALYZE TABLE t2_tc_34_idx_0008_xx;
SELECT 'TC-34-IDX-0008-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0008_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0008_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0008-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0008_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0008_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0008_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0008_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0008-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0008_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0008_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0008-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0008_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0008_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0008_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0008_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0008-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bigint'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=bigint nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0008_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0008_xx (target) VALUES (-16);

-- Test Case: TC-34-IDX-0009-XX
-- Index integrity: SECONDARY index on target
-- Type: SMALLINT -> MEDIUMINT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-2-3
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=403f9d2a78da column_type=mediumint index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0009_xx, t2_tc_34_idx_0009_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0009_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target SMALLINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (-16);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (-15);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (-14);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (-13);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (-12);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (-11);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (-10);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (-9);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (-8);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (-7);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (-6);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (-5);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (-4);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (-3);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (-2);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (-1);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0009_xx (target) VALUES (15);
ANALYZE TABLE t1_tc_34_idx_0009_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0009_xx MODIFY target MEDIUMINT, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0009_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (-16);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (-15);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (-14);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (-13);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (-12);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (-11);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (-10);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (-9);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (-8);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (-7);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (-6);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (-5);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (-4);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (-3);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (-2);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (-1);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0009_xx (target) VALUES (15);
ANALYZE TABLE t2_tc_34_idx_0009_xx;
SELECT 'TC-34-IDX-0009-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0009_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0009_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0009-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0009_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0009_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0009_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0009_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0009-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0009_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0009_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0009-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0009_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0009_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0009_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0009_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0009-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='mediumint'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=mediumint nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0009_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0010-XX
-- Index integrity: UNIQUE index on target
-- Type: SMALLINT -> MEDIUMINT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-2-3
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=81dcb727d628 column_type=mediumint index_kind=UNIQUE neg_probe=34271d2a9029=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0010_xx, t2_tc_34_idx_0010_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0010_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target SMALLINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (-16);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (-15);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (-14);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (-13);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (-12);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (-11);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (-10);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (-9);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (-8);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (-7);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (-6);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (-5);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (-4);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (-3);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (-2);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (-1);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (15);
ANALYZE TABLE t1_tc_34_idx_0010_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0010_xx MODIFY target MEDIUMINT, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0010_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (-16);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (-15);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (-14);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (-13);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (-12);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (-11);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (-10);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (-9);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (-8);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (-7);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (-6);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (-5);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (-4);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (-3);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (-2);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (-1);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0010_xx (target) VALUES (15);
ANALYZE TABLE t2_tc_34_idx_0010_xx;
SELECT 'TC-34-IDX-0010-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0010_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0010_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0010-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0010_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0010_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0010_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0010_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0010-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0010_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0010_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0010-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0010_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0010_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0010_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0010_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0010-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='mediumint'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=mediumint nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0010_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0010_xx (target) VALUES (-16);

-- Test Case: TC-34-IDX-0011-XX
-- Index integrity: SECONDARY index on target
-- Type: SMALLINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-2-4
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=e542e3eac31b column_type=int index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0011_xx, t2_tc_34_idx_0011_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0011_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target SMALLINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (-16);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (-15);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (-14);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (-13);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (-12);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (-11);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (-10);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (-9);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (-8);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (-7);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (-6);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (-5);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (-4);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (-3);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (-2);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (-1);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0011_xx (target) VALUES (15);
ANALYZE TABLE t1_tc_34_idx_0011_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0011_xx MODIFY target INT, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0011_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target INT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (-16);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (-15);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (-14);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (-13);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (-12);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (-11);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (-10);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (-9);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (-8);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (-7);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (-6);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (-5);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (-4);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (-3);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (-2);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (-1);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0011_xx (target) VALUES (15);
ANALYZE TABLE t2_tc_34_idx_0011_xx;
SELECT 'TC-34-IDX-0011-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0011_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0011_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0011-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0011_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0011_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0011_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0011_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0011-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0011_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0011_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0011-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0011_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0011_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0011_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0011_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0011-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=int nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0011_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0012-XX
-- Index integrity: UNIQUE index on target
-- Type: SMALLINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-2-4
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=6794f766906b column_type=int index_kind=UNIQUE neg_probe=c6ca869ee002=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0012_xx, t2_tc_34_idx_0012_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0012_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target SMALLINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (-16);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (-15);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (-14);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (-13);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (-12);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (-11);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (-10);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (-9);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (-8);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (-7);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (-6);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (-5);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (-4);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (-3);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (-2);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (-1);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (15);
ANALYZE TABLE t1_tc_34_idx_0012_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0012_xx MODIFY target INT, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0012_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target INT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (-16);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (-15);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (-14);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (-13);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (-12);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (-11);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (-10);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (-9);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (-8);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (-7);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (-6);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (-5);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (-4);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (-3);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (-2);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (-1);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0012_xx (target) VALUES (15);
ANALYZE TABLE t2_tc_34_idx_0012_xx;
SELECT 'TC-34-IDX-0012-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0012_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0012_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0012-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0012_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0012_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0012_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0012_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0012-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0012_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0012_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0012-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0012_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0012_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0012_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0012_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0012-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=int nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0012_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0012_xx (target) VALUES (-16);

-- Test Case: TC-34-IDX-0013-XX
-- Index integrity: SECONDARY index on target
-- Type: SMALLINT -> BIGINT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-2-5
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=cb8d3c16784a column_type=bigint index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0013_xx, t2_tc_34_idx_0013_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0013_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target SMALLINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (-16);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (-15);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (-14);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (-13);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (-12);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (-11);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (-10);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (-9);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (-8);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (-7);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (-6);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (-5);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (-4);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (-3);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (-2);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (-1);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0013_xx (target) VALUES (15);
ANALYZE TABLE t1_tc_34_idx_0013_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0013_xx MODIFY target BIGINT, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0013_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIGINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (-16);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (-15);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (-14);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (-13);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (-12);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (-11);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (-10);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (-9);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (-8);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (-7);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (-6);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (-5);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (-4);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (-3);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (-2);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (-1);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0013_xx (target) VALUES (15);
ANALYZE TABLE t2_tc_34_idx_0013_xx;
SELECT 'TC-34-IDX-0013-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0013_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0013_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0013-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0013_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0013_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0013_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0013_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0013-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0013_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0013_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0013-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0013_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0013_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0013_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0013_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0013-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bigint'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=bigint nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0013_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0014-XX
-- Index integrity: UNIQUE index on target
-- Type: SMALLINT -> BIGINT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-2-5
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=dedcf8f0c6d8 column_type=bigint index_kind=UNIQUE neg_probe=b570fc3fa2de=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0014_xx, t2_tc_34_idx_0014_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0014_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target SMALLINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (-16);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (-15);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (-14);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (-13);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (-12);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (-11);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (-10);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (-9);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (-8);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (-7);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (-6);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (-5);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (-4);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (-3);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (-2);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (-1);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (15);
ANALYZE TABLE t1_tc_34_idx_0014_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0014_xx MODIFY target BIGINT, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0014_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIGINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (-16);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (-15);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (-14);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (-13);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (-12);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (-11);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (-10);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (-9);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (-8);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (-7);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (-6);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (-5);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (-4);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (-3);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (-2);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (-1);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0014_xx (target) VALUES (15);
ANALYZE TABLE t2_tc_34_idx_0014_xx;
SELECT 'TC-34-IDX-0014-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0014_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0014_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0014-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0014_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0014_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0014_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0014_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0014-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0014_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0014_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0014-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0014_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0014_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0014_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0014_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0014-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bigint'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=bigint nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0014_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0014_xx (target) VALUES (-16);

-- Test Case: TC-34-IDX-0015-XX
-- Index integrity: SECONDARY index on target
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=71db4e2db0ab column_type=int index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0015_xx, t2_tc_34_idx_0015_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0015_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (-16);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (-15);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (-14);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (-13);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (-12);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (-11);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (-10);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (-9);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (-8);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (-7);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (-6);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (-5);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (-4);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (-3);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (-2);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (-1);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0015_xx (target) VALUES (15);
ANALYZE TABLE t1_tc_34_idx_0015_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0015_xx MODIFY target INT, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0015_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target INT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (-16);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (-15);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (-14);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (-13);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (-12);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (-11);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (-10);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (-9);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (-8);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (-7);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (-6);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (-5);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (-4);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (-3);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (-2);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (-1);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0015_xx (target) VALUES (15);
ANALYZE TABLE t2_tc_34_idx_0015_xx;
SELECT 'TC-34-IDX-0015-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0015_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0015_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0015-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0015_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0015_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0015_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0015_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0015-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0015_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0015_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0015-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0015_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0015_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0015_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0015_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0015-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=int nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0015_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0016-XX
-- Index integrity: UNIQUE index on target
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=9fc3e9f3e2e9 column_type=int index_kind=UNIQUE neg_probe=8dae6b787480=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0016_xx, t2_tc_34_idx_0016_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0016_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (-16);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (-15);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (-14);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (-13);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (-12);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (-11);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (-10);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (-9);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (-8);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (-7);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (-6);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (-5);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (-4);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (-3);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (-2);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (-1);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (15);
ANALYZE TABLE t1_tc_34_idx_0016_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0016_xx MODIFY target INT, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0016_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target INT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (-16);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (-15);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (-14);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (-13);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (-12);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (-11);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (-10);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (-9);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (-8);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (-7);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (-6);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (-5);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (-4);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (-3);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (-2);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (-1);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0016_xx (target) VALUES (15);
ANALYZE TABLE t2_tc_34_idx_0016_xx;
SELECT 'TC-34-IDX-0016-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0016_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0016_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0016-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0016_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0016_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0016_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0016_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0016-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0016_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0016_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0016-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0016_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0016_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0016_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0016_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0016-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=int nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0016_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0016_xx (target) VALUES (-16);

-- Test Case: TC-34-IDX-0017-XX
-- Index integrity: SECONDARY index on target
-- Type: MEDIUMINT -> BIGINT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-5
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=79f8d8ce3212 column_type=bigint index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0017_xx, t2_tc_34_idx_0017_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0017_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (-16);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (-15);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (-14);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (-13);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (-12);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (-11);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (-10);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (-9);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (-8);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (-7);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (-6);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (-5);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (-4);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (-3);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (-2);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (-1);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0017_xx (target) VALUES (15);
ANALYZE TABLE t1_tc_34_idx_0017_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0017_xx MODIFY target BIGINT, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0017_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIGINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (-16);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (-15);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (-14);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (-13);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (-12);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (-11);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (-10);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (-9);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (-8);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (-7);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (-6);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (-5);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (-4);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (-3);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (-2);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (-1);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0017_xx (target) VALUES (15);
ANALYZE TABLE t2_tc_34_idx_0017_xx;
SELECT 'TC-34-IDX-0017-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0017_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0017_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0017-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0017_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0017_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0017_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0017_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0017-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0017_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0017_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0017-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0017_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0017_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0017_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0017_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0017-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bigint'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=bigint nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0017_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0018-XX
-- Index integrity: UNIQUE index on target
-- Type: MEDIUMINT -> BIGINT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-5
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=83fee1a1150c column_type=bigint index_kind=UNIQUE neg_probe=c5d9a2a7885a=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0018_xx, t2_tc_34_idx_0018_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0018_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (-16);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (-15);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (-14);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (-13);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (-12);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (-11);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (-10);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (-9);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (-8);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (-7);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (-6);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (-5);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (-4);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (-3);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (-2);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (-1);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (15);
ANALYZE TABLE t1_tc_34_idx_0018_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0018_xx MODIFY target BIGINT, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0018_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIGINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (-16);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (-15);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (-14);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (-13);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (-12);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (-11);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (-10);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (-9);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (-8);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (-7);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (-6);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (-5);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (-4);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (-3);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (-2);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (-1);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0018_xx (target) VALUES (15);
ANALYZE TABLE t2_tc_34_idx_0018_xx;
SELECT 'TC-34-IDX-0018-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0018_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0018_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0018-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0018_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0018_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0018_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0018_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0018-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0018_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0018_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0018-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0018_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0018_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0018_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0018_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0018-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bigint'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=bigint nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0018_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0018_xx (target) VALUES (-16);

-- Test Case: TC-34-IDX-0019-XX
-- Index integrity: SECONDARY index on target
-- Type: INT -> BIGINT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-4-5
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=440991f5c508 column_type=bigint index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0019_xx, t2_tc_34_idx_0019_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0019_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target INT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (-16);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (-15);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (-14);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (-13);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (-12);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (-11);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (-10);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (-9);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (-8);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (-7);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (-6);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (-5);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (-4);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (-3);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (-2);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (-1);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0019_xx (target) VALUES (15);
ANALYZE TABLE t1_tc_34_idx_0019_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0019_xx MODIFY target BIGINT, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0019_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIGINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (-16);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (-15);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (-14);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (-13);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (-12);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (-11);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (-10);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (-9);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (-8);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (-7);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (-6);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (-5);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (-4);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (-3);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (-2);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (-1);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0019_xx (target) VALUES (15);
ANALYZE TABLE t2_tc_34_idx_0019_xx;
SELECT 'TC-34-IDX-0019-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0019_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0019_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0019-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0019_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0019_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0019_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0019_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0019-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0019_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0019_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0019-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0019_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0019_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0019_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0019_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0019-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bigint'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=bigint nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0019_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0020-XX
-- Index integrity: UNIQUE index on target
-- Type: INT -> BIGINT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-4-5
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=c1106651cced column_type=bigint index_kind=UNIQUE neg_probe=1f1947229889=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0020_xx, t2_tc_34_idx_0020_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0020_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target INT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (-16);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (-15);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (-14);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (-13);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (-12);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (-11);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (-10);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (-9);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (-8);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (-7);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (-6);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (-5);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (-4);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (-3);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (-2);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (-1);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (15);
ANALYZE TABLE t1_tc_34_idx_0020_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0020_xx MODIFY target BIGINT, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0020_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIGINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (-16);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (-15);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (-14);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (-13);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (-12);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (-11);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (-10);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (-9);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (-8);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (-7);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (-6);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (-5);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (-4);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (-3);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (-2);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (-1);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0020_xx (target) VALUES (15);
ANALYZE TABLE t2_tc_34_idx_0020_xx;
SELECT 'TC-34-IDX-0020-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0020_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0020_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0020-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0020_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0020_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0020_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0020_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0020-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0020_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0020_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0020-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0020_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0020_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0020_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0020_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0020-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bigint'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=bigint nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0020_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0020_xx (target) VALUES (-16);

-- Test Case: TC-34-IDX-0021-XX
-- Index integrity: SECONDARY index on target
-- Type: TINYINT UNSIGNED -> SMALLINT UNSIGNED, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-U-1-2
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=c07b46d82256 column_type=smallint unsigned index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0021_xx, t2_tc_34_idx_0021_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0021_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TINYINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (15);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (16);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (17);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (18);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (19);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (20);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (21);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (22);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (23);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (24);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (25);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (26);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (27);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (28);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (29);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (30);
INSERT INTO t1_tc_34_idx_0021_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_34_idx_0021_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0021_xx MODIFY target SMALLINT UNSIGNED, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0021_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target SMALLINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (15);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (16);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (17);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (18);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (19);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (20);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (21);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (22);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (23);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (24);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (25);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (26);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (27);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (28);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (29);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (30);
INSERT INTO t2_tc_34_idx_0021_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_34_idx_0021_xx;
SELECT 'TC-34-IDX-0021-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0021_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0021_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0021-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0021_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0021_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0021_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0021_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0021-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0021_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0021_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0021-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0021_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0021_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0021_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0021_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0021-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='smallint unsigned'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=smallint unsigned nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0021_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0022-XX
-- Index integrity: UNIQUE index on target
-- Type: TINYINT UNSIGNED -> SMALLINT UNSIGNED, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-U-1-2
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=d21e71c7ed76 column_type=smallint unsigned index_kind=UNIQUE neg_probe=039183d20f06=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0022_xx, t2_tc_34_idx_0022_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0022_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TINYINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (15);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (16);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (17);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (18);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (19);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (20);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (21);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (22);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (23);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (24);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (25);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (26);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (27);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (28);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (29);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (30);
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_34_idx_0022_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0022_xx MODIFY target SMALLINT UNSIGNED, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0022_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target SMALLINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (15);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (16);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (17);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (18);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (19);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (20);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (21);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (22);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (23);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (24);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (25);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (26);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (27);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (28);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (29);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (30);
INSERT INTO t2_tc_34_idx_0022_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_34_idx_0022_xx;
SELECT 'TC-34-IDX-0022-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0022_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0022_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0022-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0022_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0022_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0022_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0022_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0022-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0022_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0022_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0022-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0022_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0022_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0022_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0022_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0022-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='smallint unsigned'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=smallint unsigned nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0022_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0022_xx (target) VALUES (0);

-- Test Case: TC-34-IDX-0023-XX
-- Index integrity: SECONDARY index on target
-- Type: TINYINT UNSIGNED -> MEDIUMINT UNSIGNED, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-U-1-3
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=706320525bc2 column_type=mediumint unsigned index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0023_xx, t2_tc_34_idx_0023_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0023_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TINYINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (15);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (16);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (17);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (18);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (19);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (20);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (21);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (22);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (23);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (24);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (25);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (26);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (27);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (28);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (29);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (30);
INSERT INTO t1_tc_34_idx_0023_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_34_idx_0023_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0023_xx MODIFY target MEDIUMINT UNSIGNED, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0023_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (15);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (16);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (17);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (18);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (19);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (20);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (21);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (22);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (23);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (24);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (25);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (26);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (27);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (28);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (29);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (30);
INSERT INTO t2_tc_34_idx_0023_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_34_idx_0023_xx;
SELECT 'TC-34-IDX-0023-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0023_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0023_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0023-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0023_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0023_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0023_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0023_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0023-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0023_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0023_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0023-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0023_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0023_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0023_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0023_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0023-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='mediumint unsigned'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=mediumint unsigned nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0023_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0024-XX
-- Index integrity: UNIQUE index on target
-- Type: TINYINT UNSIGNED -> MEDIUMINT UNSIGNED, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-U-1-3
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=f6fe187d19cc column_type=mediumint unsigned index_kind=UNIQUE neg_probe=8cf137f7528a=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0024_xx, t2_tc_34_idx_0024_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0024_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TINYINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (15);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (16);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (17);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (18);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (19);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (20);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (21);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (22);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (23);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (24);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (25);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (26);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (27);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (28);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (29);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (30);
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_34_idx_0024_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0024_xx MODIFY target MEDIUMINT UNSIGNED, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0024_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (15);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (16);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (17);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (18);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (19);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (20);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (21);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (22);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (23);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (24);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (25);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (26);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (27);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (28);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (29);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (30);
INSERT INTO t2_tc_34_idx_0024_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_34_idx_0024_xx;
SELECT 'TC-34-IDX-0024-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0024_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0024_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0024-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0024_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0024_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0024_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0024_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0024-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0024_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0024_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0024-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0024_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0024_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0024_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0024_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0024-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='mediumint unsigned'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=mediumint unsigned nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0024_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0024_xx (target) VALUES (0);

-- Test Case: TC-34-IDX-0025-XX
-- Index integrity: SECONDARY index on target
-- Type: TINYINT UNSIGNED -> INT UNSIGNED, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-U-1-4
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=2b13aeafeca7 column_type=int unsigned index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0025_xx, t2_tc_34_idx_0025_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0025_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TINYINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (15);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (16);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (17);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (18);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (19);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (20);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (21);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (22);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (23);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (24);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (25);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (26);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (27);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (28);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (29);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (30);
INSERT INTO t1_tc_34_idx_0025_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_34_idx_0025_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0025_xx MODIFY target INT UNSIGNED, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0025_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target INT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (15);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (16);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (17);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (18);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (19);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (20);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (21);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (22);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (23);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (24);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (25);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (26);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (27);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (28);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (29);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (30);
INSERT INTO t2_tc_34_idx_0025_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_34_idx_0025_xx;
SELECT 'TC-34-IDX-0025-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0025_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0025_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0025-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0025_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0025_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0025_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0025_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0025-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0025_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0025_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0025-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0025_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0025_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0025_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0025_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0025-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int unsigned'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=int unsigned nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0025_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0026-XX
-- Index integrity: UNIQUE index on target
-- Type: TINYINT UNSIGNED -> INT UNSIGNED, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-U-1-4
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=a93d1f71c9b1 column_type=int unsigned index_kind=UNIQUE neg_probe=6e8a0fa86349=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0026_xx, t2_tc_34_idx_0026_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0026_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TINYINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (15);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (16);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (17);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (18);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (19);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (20);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (21);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (22);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (23);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (24);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (25);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (26);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (27);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (28);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (29);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (30);
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_34_idx_0026_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0026_xx MODIFY target INT UNSIGNED, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0026_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target INT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (15);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (16);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (17);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (18);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (19);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (20);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (21);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (22);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (23);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (24);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (25);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (26);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (27);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (28);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (29);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (30);
INSERT INTO t2_tc_34_idx_0026_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_34_idx_0026_xx;
SELECT 'TC-34-IDX-0026-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0026_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0026_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0026-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0026_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0026_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0026_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0026_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0026-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0026_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0026_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0026-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0026_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0026_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0026_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0026_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0026-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int unsigned'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=int unsigned nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0026_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0026_xx (target) VALUES (0);

-- Test Case: TC-34-IDX-0027-XX
-- Index integrity: SECONDARY index on target
-- Type: TINYINT UNSIGNED -> BIGINT UNSIGNED, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-U-1-5
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=085e1b490ea3 column_type=bigint unsigned index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0027_xx, t2_tc_34_idx_0027_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0027_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TINYINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (15);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (16);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (17);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (18);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (19);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (20);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (21);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (22);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (23);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (24);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (25);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (26);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (27);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (28);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (29);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (30);
INSERT INTO t1_tc_34_idx_0027_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_34_idx_0027_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0027_xx MODIFY target BIGINT UNSIGNED, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0027_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIGINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (15);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (16);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (17);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (18);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (19);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (20);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (21);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (22);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (23);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (24);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (25);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (26);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (27);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (28);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (29);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (30);
INSERT INTO t2_tc_34_idx_0027_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_34_idx_0027_xx;
SELECT 'TC-34-IDX-0027-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0027_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0027_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0027-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0027_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0027_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0027_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0027_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0027-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0027_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0027_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0027-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0027_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0027_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0027_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0027_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0027-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bigint unsigned'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=bigint unsigned nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0027_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0028-XX
-- Index integrity: UNIQUE index on target
-- Type: TINYINT UNSIGNED -> BIGINT UNSIGNED, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-U-1-5
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=acaff92c949f column_type=bigint unsigned index_kind=UNIQUE neg_probe=ecd34bebcb60=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0028_xx, t2_tc_34_idx_0028_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0028_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TINYINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (15);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (16);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (17);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (18);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (19);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (20);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (21);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (22);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (23);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (24);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (25);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (26);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (27);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (28);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (29);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (30);
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_34_idx_0028_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0028_xx MODIFY target BIGINT UNSIGNED, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0028_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIGINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (15);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (16);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (17);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (18);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (19);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (20);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (21);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (22);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (23);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (24);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (25);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (26);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (27);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (28);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (29);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (30);
INSERT INTO t2_tc_34_idx_0028_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_34_idx_0028_xx;
SELECT 'TC-34-IDX-0028-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0028_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0028_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0028-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0028_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0028_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0028_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0028_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0028-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0028_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0028_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0028-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0028_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0028_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0028_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0028_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0028-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bigint unsigned'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=bigint unsigned nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0028_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0028_xx (target) VALUES (0);

-- Test Case: TC-34-IDX-0029-XX
-- Index integrity: SECONDARY index on target
-- Type: SMALLINT UNSIGNED -> MEDIUMINT UNSIGNED, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-U-2-3
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=869250fbf89c column_type=mediumint unsigned index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0029_xx, t2_tc_34_idx_0029_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0029_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target SMALLINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (15);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (16);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (17);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (18);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (19);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (20);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (21);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (22);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (23);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (24);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (25);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (26);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (27);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (28);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (29);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (30);
INSERT INTO t1_tc_34_idx_0029_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_34_idx_0029_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0029_xx MODIFY target MEDIUMINT UNSIGNED, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0029_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (15);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (16);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (17);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (18);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (19);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (20);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (21);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (22);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (23);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (24);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (25);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (26);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (27);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (28);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (29);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (30);
INSERT INTO t2_tc_34_idx_0029_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_34_idx_0029_xx;
SELECT 'TC-34-IDX-0029-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0029_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0029_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0029-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0029_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0029_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0029_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0029_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0029-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0029_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0029_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0029-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0029_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0029_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0029_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0029_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0029-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='mediumint unsigned'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=mediumint unsigned nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0029_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0030-XX
-- Index integrity: UNIQUE index on target
-- Type: SMALLINT UNSIGNED -> MEDIUMINT UNSIGNED, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-U-2-3
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=9533f3027a99 column_type=mediumint unsigned index_kind=UNIQUE neg_probe=5312c036a21a=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0030_xx, t2_tc_34_idx_0030_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0030_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target SMALLINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (15);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (16);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (17);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (18);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (19);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (20);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (21);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (22);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (23);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (24);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (25);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (26);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (27);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (28);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (29);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (30);
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_34_idx_0030_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0030_xx MODIFY target MEDIUMINT UNSIGNED, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0030_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (15);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (16);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (17);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (18);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (19);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (20);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (21);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (22);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (23);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (24);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (25);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (26);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (27);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (28);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (29);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (30);
INSERT INTO t2_tc_34_idx_0030_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_34_idx_0030_xx;
SELECT 'TC-34-IDX-0030-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0030_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0030_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0030-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0030_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0030_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0030_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0030_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0030-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0030_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0030_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0030-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0030_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0030_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0030_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0030_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0030-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='mediumint unsigned'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=mediumint unsigned nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0030_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0030_xx (target) VALUES (0);

-- Test Case: TC-34-IDX-0031-XX
-- Index integrity: SECONDARY index on target
-- Type: SMALLINT UNSIGNED -> INT UNSIGNED, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-U-2-4
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=2f1684f3413b column_type=int unsigned index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0031_xx, t2_tc_34_idx_0031_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0031_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target SMALLINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (15);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (16);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (17);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (18);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (19);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (20);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (21);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (22);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (23);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (24);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (25);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (26);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (27);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (28);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (29);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (30);
INSERT INTO t1_tc_34_idx_0031_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_34_idx_0031_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0031_xx MODIFY target INT UNSIGNED, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0031_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target INT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (15);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (16);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (17);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (18);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (19);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (20);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (21);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (22);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (23);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (24);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (25);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (26);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (27);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (28);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (29);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (30);
INSERT INTO t2_tc_34_idx_0031_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_34_idx_0031_xx;
SELECT 'TC-34-IDX-0031-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0031_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0031_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0031-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0031_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0031_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0031_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0031_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0031-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0031_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0031_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0031-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0031_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0031_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0031_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0031_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0031-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int unsigned'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=int unsigned nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0031_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0032-XX
-- Index integrity: UNIQUE index on target
-- Type: SMALLINT UNSIGNED -> INT UNSIGNED, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-U-2-4
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=72196ad83026 column_type=int unsigned index_kind=UNIQUE neg_probe=25d21986f569=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0032_xx, t2_tc_34_idx_0032_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0032_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target SMALLINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (15);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (16);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (17);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (18);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (19);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (20);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (21);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (22);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (23);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (24);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (25);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (26);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (27);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (28);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (29);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (30);
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_34_idx_0032_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0032_xx MODIFY target INT UNSIGNED, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0032_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target INT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (15);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (16);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (17);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (18);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (19);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (20);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (21);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (22);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (23);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (24);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (25);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (26);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (27);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (28);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (29);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (30);
INSERT INTO t2_tc_34_idx_0032_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_34_idx_0032_xx;
SELECT 'TC-34-IDX-0032-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0032_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0032_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0032-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0032_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0032_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0032_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0032_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0032-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0032_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0032_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0032-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0032_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0032_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0032_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0032_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0032-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int unsigned'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=int unsigned nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0032_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0032_xx (target) VALUES (0);

-- Test Case: TC-34-IDX-0033-XX
-- Index integrity: SECONDARY index on target
-- Type: SMALLINT UNSIGNED -> BIGINT UNSIGNED, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-U-2-5
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=66b392ebb445 column_type=bigint unsigned index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0033_xx, t2_tc_34_idx_0033_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0033_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target SMALLINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (15);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (16);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (17);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (18);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (19);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (20);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (21);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (22);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (23);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (24);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (25);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (26);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (27);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (28);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (29);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (30);
INSERT INTO t1_tc_34_idx_0033_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_34_idx_0033_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0033_xx MODIFY target BIGINT UNSIGNED, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0033_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIGINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (15);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (16);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (17);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (18);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (19);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (20);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (21);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (22);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (23);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (24);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (25);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (26);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (27);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (28);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (29);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (30);
INSERT INTO t2_tc_34_idx_0033_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_34_idx_0033_xx;
SELECT 'TC-34-IDX-0033-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0033_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0033_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0033-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0033_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0033_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0033_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0033_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0033-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0033_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0033_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0033-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0033_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0033_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0033_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0033_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0033-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bigint unsigned'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=bigint unsigned nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0033_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0034-XX
-- Index integrity: UNIQUE index on target
-- Type: SMALLINT UNSIGNED -> BIGINT UNSIGNED, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-U-2-5
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=304897a1a8ae column_type=bigint unsigned index_kind=UNIQUE neg_probe=1aa602ef261e=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0034_xx, t2_tc_34_idx_0034_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0034_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target SMALLINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (15);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (16);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (17);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (18);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (19);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (20);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (21);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (22);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (23);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (24);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (25);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (26);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (27);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (28);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (29);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (30);
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_34_idx_0034_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0034_xx MODIFY target BIGINT UNSIGNED, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0034_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIGINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (15);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (16);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (17);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (18);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (19);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (20);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (21);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (22);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (23);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (24);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (25);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (26);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (27);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (28);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (29);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (30);
INSERT INTO t2_tc_34_idx_0034_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_34_idx_0034_xx;
SELECT 'TC-34-IDX-0034-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0034_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0034_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0034-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0034_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0034_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0034_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0034_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0034-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0034_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0034_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0034-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0034_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0034_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0034_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0034_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0034-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bigint unsigned'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=bigint unsigned nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0034_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0034_xx (target) VALUES (0);

-- Test Case: TC-34-IDX-0035-XX
-- Index integrity: SECONDARY index on target
-- Type: MEDIUMINT UNSIGNED -> INT UNSIGNED, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-U-3-4
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=cf0f13162c56 column_type=int unsigned index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0035_xx, t2_tc_34_idx_0035_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0035_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (15);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (16);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (17);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (18);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (19);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (20);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (21);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (22);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (23);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (24);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (25);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (26);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (27);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (28);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (29);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (30);
INSERT INTO t1_tc_34_idx_0035_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_34_idx_0035_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0035_xx MODIFY target INT UNSIGNED, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0035_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target INT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (15);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (16);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (17);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (18);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (19);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (20);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (21);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (22);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (23);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (24);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (25);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (26);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (27);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (28);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (29);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (30);
INSERT INTO t2_tc_34_idx_0035_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_34_idx_0035_xx;
SELECT 'TC-34-IDX-0035-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0035_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0035_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0035-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0035_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0035_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0035_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0035_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0035-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0035_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0035_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0035-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0035_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0035_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0035_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0035_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0035-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int unsigned'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=int unsigned nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0035_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0036-XX
-- Index integrity: UNIQUE index on target
-- Type: MEDIUMINT UNSIGNED -> INT UNSIGNED, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-U-3-4
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=797ffadcf57b column_type=int unsigned index_kind=UNIQUE neg_probe=bb587282a225=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0036_xx, t2_tc_34_idx_0036_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0036_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (15);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (16);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (17);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (18);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (19);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (20);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (21);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (22);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (23);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (24);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (25);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (26);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (27);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (28);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (29);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (30);
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_34_idx_0036_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0036_xx MODIFY target INT UNSIGNED, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0036_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target INT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (15);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (16);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (17);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (18);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (19);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (20);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (21);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (22);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (23);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (24);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (25);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (26);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (27);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (28);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (29);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (30);
INSERT INTO t2_tc_34_idx_0036_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_34_idx_0036_xx;
SELECT 'TC-34-IDX-0036-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0036_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0036_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0036-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0036_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0036_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0036_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0036_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0036-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0036_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0036_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0036-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0036_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0036_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0036_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0036_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0036-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int unsigned'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=int unsigned nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0036_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0036_xx (target) VALUES (0);

-- Test Case: TC-34-IDX-0037-XX
-- Index integrity: SECONDARY index on target
-- Type: MEDIUMINT UNSIGNED -> BIGINT UNSIGNED, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-U-3-5
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=c75cb7918539 column_type=bigint unsigned index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0037_xx, t2_tc_34_idx_0037_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0037_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (15);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (16);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (17);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (18);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (19);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (20);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (21);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (22);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (23);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (24);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (25);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (26);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (27);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (28);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (29);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (30);
INSERT INTO t1_tc_34_idx_0037_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_34_idx_0037_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0037_xx MODIFY target BIGINT UNSIGNED, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0037_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIGINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (15);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (16);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (17);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (18);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (19);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (20);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (21);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (22);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (23);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (24);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (25);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (26);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (27);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (28);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (29);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (30);
INSERT INTO t2_tc_34_idx_0037_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_34_idx_0037_xx;
SELECT 'TC-34-IDX-0037-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0037_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0037_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0037-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0037_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0037_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0037_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0037_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0037-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0037_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0037_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0037-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0037_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0037_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0037_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0037_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0037-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bigint unsigned'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=bigint unsigned nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0037_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0038-XX
-- Index integrity: UNIQUE index on target
-- Type: MEDIUMINT UNSIGNED -> BIGINT UNSIGNED, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-U-3-5
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=4b6d0f9143ae column_type=bigint unsigned index_kind=UNIQUE neg_probe=2c2437452823=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0038_xx, t2_tc_34_idx_0038_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0038_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (15);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (16);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (17);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (18);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (19);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (20);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (21);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (22);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (23);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (24);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (25);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (26);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (27);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (28);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (29);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (30);
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_34_idx_0038_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0038_xx MODIFY target BIGINT UNSIGNED, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0038_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIGINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (15);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (16);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (17);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (18);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (19);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (20);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (21);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (22);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (23);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (24);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (25);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (26);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (27);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (28);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (29);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (30);
INSERT INTO t2_tc_34_idx_0038_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_34_idx_0038_xx;
SELECT 'TC-34-IDX-0038-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0038_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0038_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0038-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0038_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0038_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0038_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0038_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0038-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0038_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0038_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0038-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0038_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0038_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0038_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0038_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0038-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bigint unsigned'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=bigint unsigned nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0038_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0038_xx (target) VALUES (0);

-- Test Case: TC-34-IDX-0039-XX
-- Index integrity: SECONDARY index on target
-- Type: INT UNSIGNED -> BIGINT UNSIGNED, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-U-4-5
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=635014c56a5b column_type=bigint unsigned index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0039_xx, t2_tc_34_idx_0039_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0039_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target INT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (15);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (16);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (17);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (18);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (19);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (20);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (21);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (22);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (23);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (24);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (25);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (26);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (27);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (28);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (29);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (30);
INSERT INTO t1_tc_34_idx_0039_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_34_idx_0039_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0039_xx MODIFY target BIGINT UNSIGNED, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0039_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIGINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (15);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (16);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (17);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (18);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (19);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (20);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (21);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (22);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (23);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (24);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (25);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (26);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (27);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (28);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (29);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (30);
INSERT INTO t2_tc_34_idx_0039_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_34_idx_0039_xx;
SELECT 'TC-34-IDX-0039-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0039_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0039_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0039-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0039_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0039_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0039_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0039_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0039-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0039_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0039_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0039-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0039_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0039_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0039_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0039_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0039-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bigint unsigned'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=bigint unsigned nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0039_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0040-XX
-- Index integrity: UNIQUE index on target
-- Type: INT UNSIGNED -> BIGINT UNSIGNED, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-U-4-5
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=6853303f217a column_type=bigint unsigned index_kind=UNIQUE neg_probe=374fcbe697c9=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0040_xx, t2_tc_34_idx_0040_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0040_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target INT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (0);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (1);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (2);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (3);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (4);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (5);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (6);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (7);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (8);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (9);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (10);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (11);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (12);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (13);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (14);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (15);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (16);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (17);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (18);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (19);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (20);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (21);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (22);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (23);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (24);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (25);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (26);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (27);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (28);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (29);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (30);
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_34_idx_0040_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0040_xx MODIFY target BIGINT UNSIGNED, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0040_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIGINT UNSIGNED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (0);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (1);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (2);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (3);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (4);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (5);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (6);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (7);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (8);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (9);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (10);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (11);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (12);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (13);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (14);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (15);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (16);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (17);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (18);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (19);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (20);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (21);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (22);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (23);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (24);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (25);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (26);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (27);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (28);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (29);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (30);
INSERT INTO t2_tc_34_idx_0040_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_34_idx_0040_xx;
SELECT 'TC-34-IDX-0040-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0040_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0040_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0040-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0040_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0040_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0040_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0040_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0040-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0040_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0040_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0040-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0040_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0040_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0040_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0040_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0040-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bigint unsigned'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=bigint unsigned nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0040_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0040_xx (target) VALUES (0);

-- Test Case: TC-34-IDX-0041-XX
-- Index integrity: SECONDARY index on target
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-01
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=d5bc6315798f column_type=char(2) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0041_xx, t2_tc_34_idx_0041_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0041_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('0');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('1');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('2');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('3');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('4');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('5');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('6');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('7');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('8');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('9');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('a');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('b');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('c');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('d');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('e');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('f');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('g');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('h');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('i');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('j');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('k');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('l');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('m');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('n');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('o');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('p');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('q');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('r');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('s');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('t');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('u');
INSERT INTO t1_tc_34_idx_0041_xx (target) VALUES ('v');
ANALYZE TABLE t1_tc_34_idx_0041_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0041_xx MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0041_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(2) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('0');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('1');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('2');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('3');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('4');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('5');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('6');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('7');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('8');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('9');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('a');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('b');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('c');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('d');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('e');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('f');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('g');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('h');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('i');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('j');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('k');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('l');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('m');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('n');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('o');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('p');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('q');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('r');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('s');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('t');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('u');
INSERT INTO t2_tc_34_idx_0041_xx (target) VALUES ('v');
ANALYZE TABLE t2_tc_34_idx_0041_xx;
SELECT 'TC-34-IDX-0041-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0041_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0041_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0041-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0041_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0041_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0041_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0041_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0041-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0041_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0041_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0041-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0041_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0041_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0041_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0041_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0041-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0041_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0042-XX
-- Index integrity: UNIQUE index on target
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-01
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=b963b84f7494 column_type=char(2) index_kind=UNIQUE neg_probe=73d0170cdf5c=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0042_xx, t2_tc_34_idx_0042_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0042_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('0');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('1');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('2');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('3');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('4');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('5');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('6');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('7');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('8');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('9');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('a');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('b');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('c');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('d');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('e');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('f');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('g');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('h');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('i');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('j');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('k');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('l');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('m');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('n');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('o');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('p');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('q');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('r');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('s');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('t');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('u');
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('v');
ANALYZE TABLE t1_tc_34_idx_0042_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0042_xx MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0042_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(2) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('0');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('1');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('2');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('3');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('4');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('5');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('6');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('7');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('8');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('9');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('a');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('b');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('c');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('d');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('e');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('f');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('g');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('h');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('i');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('j');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('k');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('l');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('m');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('n');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('o');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('p');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('q');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('r');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('s');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('t');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('u');
INSERT INTO t2_tc_34_idx_0042_xx (target) VALUES ('v');
ANALYZE TABLE t2_tc_34_idx_0042_xx;
SELECT 'TC-34-IDX-0042-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0042_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0042_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0042-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0042_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0042_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0042_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0042_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0042-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0042_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0042_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0042-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0042_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0042_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0042_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0042_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0042-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0042_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0042_xx (target) VALUES ('0');

-- Test Case: TC-34-IDX-0043-XX
-- Index integrity: SECONDARY index on target
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-02
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=5f1ca54afd32 column_type=char(64) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0043_xx, t2_tc_34_idx_0043_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0043_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(63) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_34_idx_0043_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_34_idx_0043_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0043_xx MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0043_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(64) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_34_idx_0043_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_34_idx_0043_xx;
SELECT 'TC-34-IDX-0043-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0043_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0043_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0043-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0043_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0043_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0043_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0043_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0043-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0043_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0043_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0043-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0043_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0043_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0043_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0043_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0043-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0043_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0044-XX
-- Index integrity: UNIQUE index on target
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-02
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=2c292d76873e column_type=char(64) index_kind=UNIQUE neg_probe=976c0b3d2665=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0044_xx, t2_tc_34_idx_0044_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0044_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(63) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_34_idx_0044_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0044_xx MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0044_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(64) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_34_idx_0044_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_34_idx_0044_xx;
SELECT 'TC-34-IDX-0044-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0044_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0044_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0044-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0044_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0044_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0044_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0044_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0044-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0044_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0044_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0044-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0044_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0044_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0044_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0044_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0044-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0044_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0044_xx (target) VALUES ('00000000');

-- Test Case: TC-34-IDX-0045-XX
-- Index integrity: SECONDARY index on target
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-03
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=0fd3b727ab11 column_type=char(255) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0045_xx, t2_tc_34_idx_0045_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0045_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(254) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_34_idx_0045_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_34_idx_0045_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0045_xx MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0045_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(255) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_34_idx_0045_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_34_idx_0045_xx;
SELECT 'TC-34-IDX-0045-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0045_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0045_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0045-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0045_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0045_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0045_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0045_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0045-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0045_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0045_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0045-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0045_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0045_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0045_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0045_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0045-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0045_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0046-XX
-- Index integrity: UNIQUE index on target
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-03
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=3da0d90d317a column_type=char(255) index_kind=UNIQUE neg_probe=9829580d332f=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0046_xx, t2_tc_34_idx_0046_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0046_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(254) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_34_idx_0046_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0046_xx MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0046_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(255) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_34_idx_0046_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_34_idx_0046_xx;
SELECT 'TC-34-IDX-0046-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0046_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0046_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0046-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0046_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0046_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0046_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0046_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0046-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0046_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0046_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0046-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0046_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0046_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0046_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0046_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0046-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0046_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0046_xx (target) VALUES ('00000000');

-- Test Case: TC-34-IDX-0047-XX
-- Index integrity: SECONDARY index on target
-- Type: VARCHAR(1) -> VARCHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-01
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=1b4e6bf849b8 column_type=varchar(2) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0047_xx, t2_tc_34_idx_0047_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0047_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('0');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('1');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('2');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('3');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('4');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('5');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('6');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('7');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('8');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('9');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('a');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('b');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('c');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('d');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('e');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('f');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('g');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('h');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('i');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('j');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('k');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('l');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('m');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('n');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('o');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('p');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('q');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('r');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('s');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('t');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('u');
INSERT INTO t1_tc_34_idx_0047_xx (target) VALUES ('v');
ANALYZE TABLE t1_tc_34_idx_0047_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0047_xx MODIFY target VARCHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0047_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(2) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('0');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('1');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('2');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('3');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('4');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('5');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('6');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('7');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('8');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('9');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('a');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('b');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('c');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('d');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('e');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('f');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('g');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('h');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('i');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('j');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('k');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('l');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('m');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('n');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('o');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('p');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('q');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('r');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('s');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('t');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('u');
INSERT INTO t2_tc_34_idx_0047_xx (target) VALUES ('v');
ANALYZE TABLE t2_tc_34_idx_0047_xx;
SELECT 'TC-34-IDX-0047-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0047_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0047_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0047-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0047_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0047_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0047_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0047_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0047-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0047_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0047_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0047-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0047_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0047_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0047_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0047_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0047-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=varchar(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0047_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0048-XX
-- Index integrity: UNIQUE index on target
-- Type: VARCHAR(1) -> VARCHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-01
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=386f0d5fd3d6 column_type=varchar(2) index_kind=UNIQUE neg_probe=d45b7c6c3df7=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0048_xx, t2_tc_34_idx_0048_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0048_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('0');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('1');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('2');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('3');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('4');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('5');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('6');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('7');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('8');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('9');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('a');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('b');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('c');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('d');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('e');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('f');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('g');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('h');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('i');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('j');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('k');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('l');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('m');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('n');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('o');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('p');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('q');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('r');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('s');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('t');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('u');
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('v');
ANALYZE TABLE t1_tc_34_idx_0048_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0048_xx MODIFY target VARCHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0048_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(2) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('0');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('1');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('2');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('3');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('4');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('5');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('6');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('7');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('8');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('9');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('a');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('b');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('c');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('d');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('e');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('f');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('g');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('h');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('i');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('j');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('k');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('l');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('m');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('n');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('o');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('p');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('q');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('r');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('s');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('t');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('u');
INSERT INTO t2_tc_34_idx_0048_xx (target) VALUES ('v');
ANALYZE TABLE t2_tc_34_idx_0048_xx;
SELECT 'TC-34-IDX-0048-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0048_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0048_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0048-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0048_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0048_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0048_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0048_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0048-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0048_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0048_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0048-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0048_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0048_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0048_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0048_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0048-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=varchar(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0048_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0048_xx (target) VALUES ('0');

-- Test Case: TC-34-IDX-0049-XX
-- Index integrity: SECONDARY index on target
-- Type: VARCHAR(254) -> VARCHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-02
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=8fb9d707b43b column_type=varchar(255) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0049_xx, t2_tc_34_idx_0049_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0049_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(254) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_34_idx_0049_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_34_idx_0049_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0049_xx MODIFY target VARCHAR(255) CHARACTER SET latin1, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0049_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(255) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_34_idx_0049_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_34_idx_0049_xx;
SELECT 'TC-34-IDX-0049-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0049_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0049_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0049-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0049_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0049_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0049_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0049_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0049-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0049_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0049_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0049-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0049_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0049_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0049_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0049_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0049-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=varchar(255) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0049_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0050-XX
-- Index integrity: UNIQUE index on target
-- Type: VARCHAR(254) -> VARCHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-02
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=7740496a1988 column_type=varchar(255) index_kind=UNIQUE neg_probe=79d708c5d735=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0050_xx, t2_tc_34_idx_0050_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0050_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(254) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_34_idx_0050_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0050_xx MODIFY target VARCHAR(255) CHARACTER SET latin1, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0050_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(255) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_34_idx_0050_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_34_idx_0050_xx;
SELECT 'TC-34-IDX-0050-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0050_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0050_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0050-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0050_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0050_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0050_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0050_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0050-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0050_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0050_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0050-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0050_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0050_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0050_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0050_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0050-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=varchar(255) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0050_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0050_xx (target) VALUES ('00000000');

-- Test Case: TC-34-IDX-0051-XX
-- Index integrity: SECONDARY index on target
-- Type: VARCHAR(255) -> VARCHAR(256), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-03
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=fdccf15bba73 column_type=varchar(256) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0051_xx, t2_tc_34_idx_0051_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0051_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(255) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_34_idx_0051_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_34_idx_0051_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0051_xx MODIFY target VARCHAR(256) CHARACTER SET latin1, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0051_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(256) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_34_idx_0051_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_34_idx_0051_xx;
SELECT 'TC-34-IDX-0051-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0051_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0051_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0051-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0051_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0051_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0051_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0051_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0051-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0051_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0051_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0051-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0051_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0051_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0051_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0051_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0051-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(256)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=varchar(256) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0051_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0052-XX
-- Index integrity: UNIQUE index on target
-- Type: VARCHAR(255) -> VARCHAR(256), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-03
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=1667cc377882 column_type=varchar(256) index_kind=UNIQUE neg_probe=4951d94c773e=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0052_xx, t2_tc_34_idx_0052_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0052_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(255) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_34_idx_0052_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0052_xx MODIFY target VARCHAR(256) CHARACTER SET latin1, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0052_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(256) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_34_idx_0052_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_34_idx_0052_xx;
SELECT 'TC-34-IDX-0052-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0052_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0052_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0052-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0052_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0052_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0052_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0052_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0052-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0052_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0052_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0052-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0052_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0052_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0052_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0052_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0052-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(256)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=varchar(256) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0052_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0052_xx (target) VALUES ('00000000');

-- Test Case: TC-34-IDX-0053-XX
-- Index integrity: SECONDARY index on target
-- Type: VARCHAR(85) -> VARCHAR(86), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-04
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=041c11586868 column_type=varchar(86) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0053_xx, t2_tc_34_idx_0053_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0053_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(85) CHARACTER SET utf8,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_34_idx_0053_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_34_idx_0053_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0053_xx MODIFY target VARCHAR(86) CHARACTER SET utf8, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0053_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(86) CHARACTER SET utf8,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_34_idx_0053_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_34_idx_0053_xx;
SELECT 'TC-34-IDX-0053-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0053_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0053_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0053-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0053_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0053_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0053_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0053_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0053-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0053_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0053_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0053-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0053_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0053_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0053_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0053_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0053-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(86)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb3')
          AND (MAX(collation_name) <=> 'utf8mb3_general_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=varchar(86) nullable=YES has_default=0 charset=utf8mb3 collation=utf8mb3_general_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0053_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0054-XX
-- Index integrity: UNIQUE index on target
-- Type: VARCHAR(85) -> VARCHAR(86), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-04
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=6113003c899d column_type=varchar(86) index_kind=UNIQUE neg_probe=b14736f726ed=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0054_xx, t2_tc_34_idx_0054_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0054_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(85) CHARACTER SET utf8,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_34_idx_0054_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0054_xx MODIFY target VARCHAR(86) CHARACTER SET utf8, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0054_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(86) CHARACTER SET utf8,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_34_idx_0054_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_34_idx_0054_xx;
SELECT 'TC-34-IDX-0054-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0054_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0054_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0054-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0054_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0054_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0054_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0054_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0054-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0054_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0054_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0054-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0054_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0054_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0054_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0054_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0054-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(86)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb3')
          AND (MAX(collation_name) <=> 'utf8mb3_general_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=varchar(86) nullable=YES has_default=0 charset=utf8mb3 collation=utf8mb3_general_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0054_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0054_xx (target) VALUES ('00000000');

-- Test Case: TC-34-IDX-0055-XX
-- Index integrity: SECONDARY index on target
-- Type: VARCHAR(63) -> VARCHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-05
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=3a84e0496bfd column_type=varchar(64) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0055_xx, t2_tc_34_idx_0055_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0055_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(63) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_34_idx_0055_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_34_idx_0055_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0055_xx MODIFY target VARCHAR(64) CHARACTER SET utf8mb4, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0055_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(64) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_34_idx_0055_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_34_idx_0055_xx;
SELECT 'TC-34-IDX-0055-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0055_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0055_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0055-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0055_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0055_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0055_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0055_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0055-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0055_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0055_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0055-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0055_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0055_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0055_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0055_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0055-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=varchar(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0055_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0056-XX
-- Index integrity: UNIQUE index on target
-- Type: VARCHAR(63) -> VARCHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-05
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=bb4a07220355 column_type=varchar(64) index_kind=UNIQUE neg_probe=075ae6554720=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0056_xx, t2_tc_34_idx_0056_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0056_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(63) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_34_idx_0056_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0056_xx MODIFY target VARCHAR(64) CHARACTER SET utf8mb4, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0056_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(64) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_34_idx_0056_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_34_idx_0056_xx;
SELECT 'TC-34-IDX-0056-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0056_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0056_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0056-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0056_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0056_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0056_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0056_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0056-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0056_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0056_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0056-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0056_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0056_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0056_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0056_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0056-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=varchar(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0056_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0056_xx (target) VALUES ('00000000');

-- Test Case: TC-34-IDX-0057-XX
-- Index integrity: SECONDARY index on target
-- Type: VARCHAR(64) -> VARCHAR(65), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-06
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=b46cef1e1694 column_type=varchar(65) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0057_xx, t2_tc_34_idx_0057_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0057_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(64) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_34_idx_0057_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_34_idx_0057_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0057_xx MODIFY target VARCHAR(65) CHARACTER SET utf8mb4, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0057_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(65) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_34_idx_0057_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_34_idx_0057_xx;
SELECT 'TC-34-IDX-0057-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0057_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0057_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0057-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0057_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0057_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0057_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0057_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0057-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0057_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0057_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0057-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0057_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0057_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0057_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0057_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0057-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(65)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=varchar(65) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0057_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0058-XX
-- Index integrity: UNIQUE index on target
-- Type: VARCHAR(64) -> VARCHAR(65), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-06
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=2136de1abef0 column_type=varchar(65) index_kind=UNIQUE neg_probe=2600bb1fa0a7=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0058_xx, t2_tc_34_idx_0058_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0058_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(64) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_34_idx_0058_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0058_xx MODIFY target VARCHAR(65) CHARACTER SET utf8mb4, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0058_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(65) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_34_idx_0058_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_34_idx_0058_xx;
SELECT 'TC-34-IDX-0058-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0058_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0058_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0058-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0058_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0058_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0058_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0058_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0058-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0058_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0058_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0058-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0058_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0058_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0058_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0058_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0058-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(65)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=varchar(65) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0058_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0058_xx (target) VALUES ('00000000');

-- Test Case: TC-34-IDX-0059-XX
-- Index integrity: SECONDARY index on target
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=5b16b9bf4ded column_type=varchar(200) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0059_xx, t2_tc_34_idx_0059_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0059_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_34_idx_0059_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_34_idx_0059_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0059_xx MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0059_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(200) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_34_idx_0059_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_34_idx_0059_xx;
SELECT 'TC-34-IDX-0059-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0059_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0059_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0059-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0059_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0059_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0059_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0059_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0059-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0059_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0059_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0059-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0059_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0059_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0059_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0059_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0059-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=varchar(200) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0059_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0060-XX
-- Index integrity: UNIQUE index on target
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=5d31262425ee column_type=varchar(200) index_kind=UNIQUE neg_probe=733cf8e5dd6b=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0060_xx, t2_tc_34_idx_0060_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0060_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_34_idx_0060_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0060_xx MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0060_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(200) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_34_idx_0060_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_34_idx_0060_xx;
SELECT 'TC-34-IDX-0060-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0060_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0060_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0060-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0060_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0060_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0060_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0060_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0060-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0060_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0060_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0060-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0060_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0060_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0060_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0060_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0060-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=varchar(200) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0060_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0060_xx (target) VALUES ('00000000');

-- Test Case: TC-34-IDX-0061-XX
-- Index integrity: SECONDARY index on target
-- Type: VARCHAR(16381) -> VARCHAR(16382), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-08
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=a59e3b0b5579 column_type=varchar(16382) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0061_xx, t2_tc_34_idx_0061_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0061_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(16381) CHARACTER SET utf8mb4,
  PRIMARY KEY (id),
  INDEX idx_target (target(64))
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_34_idx_0061_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_34_idx_0061_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0061_xx MODIFY target VARCHAR(16382) CHARACTER SET utf8mb4, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0061_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(16382) CHARACTER SET utf8mb4,
  PRIMARY KEY (id),
  INDEX idx_target (target(64))
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_34_idx_0061_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_34_idx_0061_xx;
SELECT 'TC-34-IDX-0061-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0061_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0061_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0061-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0061_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0061_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0061_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0061_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0061-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0061_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0061_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0061-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0061_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0061_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0061_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0061_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0061-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(16382)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=varchar(16382) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0061_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0062-XX
-- Index integrity: UNIQUE index on target
-- Type: VARCHAR(16381) -> VARCHAR(16382), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-08
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=0baa5a0b3bdc column_type=varchar(16382) index_kind=UNIQUE neg_probe=5e8fd737fb61=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0062_xx, t2_tc_34_idx_0062_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0062_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(16381) CHARACTER SET utf8mb4,
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target(64))
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_34_idx_0062_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0062_xx MODIFY target VARCHAR(16382) CHARACTER SET utf8mb4, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0062_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(16382) CHARACTER SET utf8mb4,
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target(64))
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_34_idx_0062_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_34_idx_0062_xx;
SELECT 'TC-34-IDX-0062-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0062_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0062_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0062-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0062_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0062_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0062_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0062_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0062-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0062_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0062_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0062-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0062_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0062_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0062_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0062_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0062-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(16382)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=varchar(16382) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0062_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0062_xx (target) VALUES ('00000000');

-- Test Case: TC-34-IDX-0063-XX
-- Index integrity: SECONDARY index on target
-- Type: VARCHAR(65527) -> VARCHAR(65528), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-09
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=54fdd36f833d column_type=varchar(65528) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_34_idx_0063_xx, t2_tc_34_idx_0063_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0063_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(65527) CHARACTER SET latin1,
  PRIMARY KEY (id),
  INDEX idx_target (target(64))
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_34_idx_0063_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_34_idx_0063_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0063_xx MODIFY target VARCHAR(65528) CHARACTER SET latin1, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0063_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(65528) CHARACTER SET latin1,
  PRIMARY KEY (id),
  INDEX idx_target (target(64))
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_34_idx_0063_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_34_idx_0063_xx;
SELECT 'TC-34-IDX-0063-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_34_idx_0063_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0063_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-34-IDX-0063-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0063_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0063_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0063_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0063_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-34-IDX-0063-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0063_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0063_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0063-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0063_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0063_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0063_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0063_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0063-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(65528)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=varchar(65528) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0063_xx' AND column_name='target';

-- Test Case: TC-34-IDX-0064-XX
-- Index integrity: UNIQUE index on target
-- Type: VARCHAR(65527) -> VARCHAR(65528), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-09
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=c3bb0ffdd7f7 column_type=varchar(65528) index_kind=UNIQUE neg_probe=3e7181b12044=1062
DROP TABLE IF EXISTS t1_tc_34_idx_0064_xx, t2_tc_34_idx_0064_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_34_idx_0064_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(65527) CHARACTER SET latin1,
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target(64))
) ENGINE=InnoDB;
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_34_idx_0064_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_34_idx_0064_xx MODIFY target VARCHAR(65528) CHARACTER SET latin1, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_34_idx_0064_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(65528) CHARACTER SET latin1,
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target(64))
) ENGINE=InnoDB;
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_34_idx_0064_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_34_idx_0064_xx;
SELECT 'TC-34-IDX-0064-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_34_idx_0064_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0064_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-34-IDX-0064-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_34_idx_0064_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_34_idx_0064_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_34_idx_0064_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_34_idx_0064_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-34-IDX-0064-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0064_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_34_idx_0064_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-34-IDX-0064-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0064_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0064_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_34_idx_0064_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_34_idx_0064_xx),'NULL')) AS mismatch;
SELECT 'TC-34-IDX-0064-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(65528)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=varchar(65528) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_34_idx_0064_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_34_idx_0064_xx (target) VALUES ('00000000');

