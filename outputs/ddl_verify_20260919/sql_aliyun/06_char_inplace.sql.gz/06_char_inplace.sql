-- ============================================================
-- RDS MySQL DDL 秒级/在线修改列类型 测试套件 — 阿里云环境
-- 环境说明: 所有功能开关默认开启
-- 覆盖类型: 整数(SIGNED/UNSIGNED) + CHAR + VARCHAR
-- 覆盖算法: INSTANT + INPLACE
-- ============================================================
-- 本文件由 generate_test_sql.py 自动生成, 请勿手动修改
-- Suite-Revision: 77acedf440f2   (生成器源码哈希; 时间戳见 results/generation_manifest.json)
-- 用例 ID 规则: TC-<文件号>-<作用域>-<序号>-<IT|IP>  —— 全局唯一
--   作用域 REG=普通表 OFAT/二元组, ATR=列属性保持, SPE=特殊模式,
--          FK=外键, PTK=分区(目标列是分区键), PNK=分区(目标列非分区键)
-- ============================================================

SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
SET SESSION innodb_lock_wait_timeout = 50;

-- File 06: CHAR INPLACE

-- Test Case: TC-06-REG-0001-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0001_ip, t2_tc_06_reg_0001_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0001_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0001_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0001_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0001-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0001_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0001_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0001_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0001_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0001_ip a JOIN t2_tc_06_reg_0001_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0002-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0002_ip, t2_tc_06_reg_0002_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0002_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0002_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0002_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0002-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0002_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0002_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0002_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0002_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0002_ip a JOIN t2_tc_06_reg_0002_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0003-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0003_ip, t2_tc_06_reg_0003_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0003_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0003_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0003_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0003-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0003_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0003_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0003_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0003_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0003_ip a JOIN t2_tc_06_reg_0003_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0004-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0004_ip, t2_tc_06_reg_0004_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0004_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('a');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0004_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('x');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0004_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('x');
SELECT 'TC-06-REG-0004-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0004_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0004_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0004_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0004_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0004_ip a JOIN t2_tc_06_reg_0004_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0005-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0005_ip, t2_tc_06_reg_0005_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0005_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0005_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0005_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0005-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0005_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0005_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0005_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0005_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0005_ip a JOIN t2_tc_06_reg_0005_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0006-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0006_ip, t2_tc_06_reg_0006_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0006_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0006_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0006_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0006-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0006_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0006_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0006_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0006_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0006_ip a JOIN t2_tc_06_reg_0006_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0007-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0007_ip, t2_tc_06_reg_0007_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0007_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0007_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0007_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0007-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0007_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0007_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0007_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0007_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0007_ip a JOIN t2_tc_06_reg_0007_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0008-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0008_ip, t2_tc_06_reg_0008_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0008_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0008_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0008_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0008-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0008_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0008_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0008_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0008_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0008_ip a JOIN t2_tc_06_reg_0008_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0009-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0009_ip, t2_tc_06_reg_0009_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0009_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0009_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0009_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0009-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0009_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0009_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0009_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0009_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0009_ip a JOIN t2_tc_06_reg_0009_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0010-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
DROP TABLE IF EXISTS t1_tc_06_reg_0010_ip, t2_tc_06_reg_0010_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0010_ip (
  target CHAR(1) CHARACTER SET latin1,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0010_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0010_ip (
  target CHAR(2) CHARACTER SET latin1,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0010-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0010_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0010_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0010_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0010_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0010_ip a JOIN t2_tc_06_reg_0010_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0011-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
DROP TABLE IF EXISTS t1_tc_06_reg_0011_ip, t2_tc_06_reg_0011_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0011_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target CHAR(1) CHARACTER SET latin1, PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0011_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0011_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target CHAR(2) CHARACTER SET latin1, PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0011-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0011_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0011_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0011_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0011_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0011_ip a JOIN t2_tc_06_reg_0011_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0012-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0012_ip, t2_tc_06_reg_0012_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0012_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('a');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0012_ip MODIFY target CHAR(2) CHARACTER SET latin1 NOT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('x');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0012_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('x');
SELECT 'TC-06-REG-0012-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0012_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0012_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0012_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0012_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0012_ip a JOIN t2_tc_06_reg_0012_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0013-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0013_ip, t2_tc_06_reg_0013_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0013_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0013_ip MODIFY target CHAR(2) CHARACTER SET latin1 DEFAULT '', ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0013_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0013-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0013_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0013_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0013_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0013_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0013_ip a JOIN t2_tc_06_reg_0013_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0014-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0014_ip, t2_tc_06_reg_0014_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0014_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0014_ip MODIFY target CHAR(2) CHARACTER SET latin1 DEFAULT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0014_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0014-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0014_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0014_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0014_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0014_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0014_ip a JOIN t2_tc_06_reg_0014_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0015-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0015_ip, t2_tc_06_reg_0015_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0015_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('a');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0015_ip MODIFY target CHAR(2) CHARACTER SET latin1 NOT NULL DEFAULT '', ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('x');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0015_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('x');
SELECT 'TC-06-REG-0015-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0015_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0015_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0015_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0015_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0015_ip a JOIN t2_tc_06_reg_0015_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0016-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0016_ip, t2_tc_06_reg_0016_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0016_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0016_ip MODIFY target CHAR(2) CHARACTER SET latin1 INVISIBLE, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0016_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0016-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0016_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0016_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0016_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0016_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0016_ip a JOIN t2_tc_06_reg_0016_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0017-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0017_ip, t2_tc_06_reg_0017_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0017_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0017_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0017_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0017_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0017_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
SELECT 'TC-06-REG-0017-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0017_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0017_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0017_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0017_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0017_ip a JOIN t2_tc_06_reg_0017_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0018-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0018_ip, t2_tc_06_reg_0018_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0018_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0018_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0018_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0018_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0018_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0018_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0018_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0018_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0018_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0018_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0018_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0018_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0018_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0018_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0018_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0018_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0018_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0018_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0018_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0018_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0018_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0018-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0018_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0018_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0018_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0018_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0018_ip a JOIN t2_tc_06_reg_0018_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0019-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: CHAR-01
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0019_ip, t2_tc_06_reg_0019_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0019_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0019_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0019_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0019-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0019_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0019_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0019_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0019_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0019_ip a JOIN t2_tc_06_reg_0019_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0020-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: CHAR-01
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0020_ip, t2_tc_06_reg_0020_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0020_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0020_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0020_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0020-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0020_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0020_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0020_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0020_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0020_ip a JOIN t2_tc_06_reg_0020_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0021-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0021_ip, t2_tc_06_reg_0021_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0021_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('a');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0021_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('x');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0021_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('x');
SELECT 'TC-06-REG-0021-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0021_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0021_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0021_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0021_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0021_ip a JOIN t2_tc_06_reg_0021_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0022-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0022_ip, t2_tc_06_reg_0022_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0022_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0022_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0022_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0022-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0022_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0022_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0022_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0022_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0022_ip a JOIN t2_tc_06_reg_0022_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0023-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0023_ip, t2_tc_06_reg_0023_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0023_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0023_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0023_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0023_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0023_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0023_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0023_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0023_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0023_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0023_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0023_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0023_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0023_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0023_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0023_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0023_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0023_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0023_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0023_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0023_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0023_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0023-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0023_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0023_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0023_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0023_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0023_ip a JOIN t2_tc_06_reg_0023_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0024-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=SECONDARY_INDEX
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=SECONDARY_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0024_ip, t2_tc_06_reg_0024_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0024_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0024_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0024_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0024-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0024_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0024_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0024_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0024_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0024_ip a JOIN t2_tc_06_reg_0024_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0025-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=UNIQUE_INDEX
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0025_ip, t2_tc_06_reg_0025_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0025_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0025_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0025_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0025-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0025_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0025_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0025_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0025_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0025_ip a JOIN t2_tc_06_reg_0025_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0026-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=FOREIGN_KEY
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=FOREIGN_KEY, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0026_ip, t2_tc_06_reg_0026_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0026_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0026_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0026_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0026-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0026_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0026_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0026_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0026_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0026_ip a JOIN t2_tc_06_reg_0026_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0027-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=CHECK
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=CHECK, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0027_ip, t2_tc_06_reg_0027_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0027_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0027_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0027_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0027-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0027_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0027_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0027_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0027_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0027_ip a JOIN t2_tc_06_reg_0027_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0028-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0028_ip, t2_tc_06_reg_0028_ip;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_06_reg_0028_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0028_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0028_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0028-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0028_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0028_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0028_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0028_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0028_ip a JOIN t2_tc_06_reg_0028_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0029-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0029_ip, t2_tc_06_reg_0029_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0029_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0029_ip MODIFY target CHAR(2) CHARACTER SET latin1 NOT NULL, ALGORITHM=inplace;
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0029_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0029_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0029_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
SELECT 'TC-06-REG-0029-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0029_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0029_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0029_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0029_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0029_ip a JOIN t2_tc_06_reg_0029_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0030-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-02
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0030_ip, t2_tc_06_reg_0030_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0030_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0030_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0030_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0030_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0030_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0030_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0030_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0030_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0030_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0030_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0030_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0030_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0030_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0030_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0030_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0030_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0030_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0030_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0030_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0030_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0030_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0030-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0030_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0030_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0030_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0030_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0030_ip a JOIN t2_tc_06_reg_0030_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0031-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: CHAR-01
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0031_ip, t2_tc_06_reg_0031_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0031_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0031_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0031_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0031_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0031_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
SELECT 'TC-06-REG-0031-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0031_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0031_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0031_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0031_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0031_ip a JOIN t2_tc_06_reg_0031_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0032-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0032_ip, t2_tc_06_reg_0032_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0032_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0032_ip MODIFY target CHAR(2) CHARACTER SET latin1 NOT NULL DEFAULT '', ALGORITHM=inplace;
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0032_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0032_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0032_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
SELECT 'TC-06-REG-0032-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0032_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0032_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0032_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0032_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0032_ip a JOIN t2_tc_06_reg_0032_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0033-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-05
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
DROP TABLE IF EXISTS t1_tc_06_reg_0033_ip, t2_tc_06_reg_0033_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0033_ip (
  target CHAR(1) CHARACTER SET latin1,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('a');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0033_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('x');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('qqq');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('test');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0033_ip (
  target CHAR(2) CHARACTER SET latin1,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('x');
SELECT 'TC-06-REG-0033-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0033_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0033_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0033_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0033_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0033_ip a JOIN t2_tc_06_reg_0033_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-ATR-0001-IP
-- Column attribute preservation: COMMENT
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace
DROP TABLE IF EXISTS t1_tc_06_atr_0001_ip, t2_tc_06_atr_0001_ip;
CREATE TABLE t1_tc_06_atr_0001_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(1) CHARACTER SET latin1 COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_atr_0001_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0001_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_atr_0001_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_atr_0001_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0001_ip (target) VALUES ('a');
ALTER TABLE t1_tc_06_atr_0001_ip MODIFY target CHAR(2) CHARACTER SET latin1 COMMENT 'test_comment', ALGORITHM=inplace;
INSERT INTO t1_tc_06_atr_0001_ip (target) VALUES ('zz');
INSERT INTO t1_tc_06_atr_0001_ip (target) VALUES ('z');
INSERT INTO t1_tc_06_atr_0001_ip (target) VALUES ('ww');
SELECT 'TC-06-ATR-0001-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0001_ip' AND column_name='target' AND column_comment='test_comment';

-- Test Case: TC-06-ATR-0002-IP
-- Column attribute preservation: CHARSET
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace
DROP TABLE IF EXISTS t1_tc_06_atr_0002_ip, t2_tc_06_atr_0002_ip;
CREATE TABLE t1_tc_06_atr_0002_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_atr_0002_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0002_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_atr_0002_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_atr_0002_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0002_ip (target) VALUES ('a');
ALTER TABLE t1_tc_06_atr_0002_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
INSERT INTO t1_tc_06_atr_0002_ip (target) VALUES ('zz');
INSERT INTO t1_tc_06_atr_0002_ip (target) VALUES ('z');
INSERT INTO t1_tc_06_atr_0002_ip (target) VALUES ('ww');
SELECT 'TC-06-ATR-0002-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0002_ip' AND column_name='target' AND character_set_name='latin1';

-- Test Case: TC-06-ATR-0003-IP
-- Column attribute preservation: COLLATE
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace
DROP TABLE IF EXISTS t1_tc_06_atr_0003_ip, t2_tc_06_atr_0003_ip;
CREATE TABLE t1_tc_06_atr_0003_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(1) CHARACTER SET latin1 COLLATE latin1_bin,
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_atr_0003_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0003_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_atr_0003_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_atr_0003_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0003_ip (target) VALUES ('a');
ALTER TABLE t1_tc_06_atr_0003_ip MODIFY target CHAR(2) CHARACTER SET latin1 COLLATE latin1_bin, ALGORITHM=inplace;
INSERT INTO t1_tc_06_atr_0003_ip (target) VALUES ('zz');
INSERT INTO t1_tc_06_atr_0003_ip (target) VALUES ('z');
INSERT INTO t1_tc_06_atr_0003_ip (target) VALUES ('ww');
SELECT 'TC-06-ATR-0003-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0003_ip' AND column_name='target' AND collation_name='latin1_bin';

-- Test Case: TC-06-REG-0034-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0034_ip, t2_tc_06_reg_0034_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0034_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0034_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0034_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0034-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0034_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0034_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0034_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0034_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0034_ip a JOIN t2_tc_06_reg_0034_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0035-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0035_ip, t2_tc_06_reg_0035_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0035_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0035_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0035_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0035-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0035_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0035_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0035_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0035_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0035_ip a JOIN t2_tc_06_reg_0035_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0036-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0036_ip, t2_tc_06_reg_0036_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0036_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0036_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0036_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0036-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0036_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0036_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0036_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0036_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0036_ip a JOIN t2_tc_06_reg_0036_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0037-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0037_ip, t2_tc_06_reg_0037_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0037_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0037_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0037_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
SELECT 'TC-06-REG-0037-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0037_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0037_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0037_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0037_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0037_ip a JOIN t2_tc_06_reg_0037_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0038-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0038_ip, t2_tc_06_reg_0038_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0038_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0038_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0038_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0038-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0038_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0038_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0038_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0038_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0038_ip a JOIN t2_tc_06_reg_0038_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0039-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0039_ip, t2_tc_06_reg_0039_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0039_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0039_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0039_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0039-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0039_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0039_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0039_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0039_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0039_ip a JOIN t2_tc_06_reg_0039_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0040-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0040_ip, t2_tc_06_reg_0040_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0040_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0040_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0040_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0040-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0040_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0040_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0040_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0040_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0040_ip a JOIN t2_tc_06_reg_0040_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0041-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0041_ip, t2_tc_06_reg_0041_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0041_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0041_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0041_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0041-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0041_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0041_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0041_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0041_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0041_ip a JOIN t2_tc_06_reg_0041_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0042-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0042_ip, t2_tc_06_reg_0042_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0042_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0042_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0042_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0042-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0042_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0042_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0042_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0042_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0042_ip a JOIN t2_tc_06_reg_0042_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0043-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
DROP TABLE IF EXISTS t1_tc_06_reg_0043_ip, t2_tc_06_reg_0043_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0043_ip (
  target CHAR(63) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0043_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0043_ip (
  target CHAR(64) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0043-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0043_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0043_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0043_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0043_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0043_ip a JOIN t2_tc_06_reg_0043_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0044-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
DROP TABLE IF EXISTS t1_tc_06_reg_0044_ip, t2_tc_06_reg_0044_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0044_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target CHAR(63) CHARACTER SET utf8mb4, PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0044_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0044_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target CHAR(64) CHARACTER SET utf8mb4, PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0044-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0044_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0044_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0044_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0044_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0044_ip a JOIN t2_tc_06_reg_0044_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0045-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0045_ip, t2_tc_06_reg_0045_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0045_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0045_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4 NOT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0045_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
SELECT 'TC-06-REG-0045-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0045_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0045_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0045_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0045_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0045_ip a JOIN t2_tc_06_reg_0045_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0046-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0046_ip, t2_tc_06_reg_0046_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0046_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0046_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4 DEFAULT '', ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0046_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0046-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0046_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0046_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0046_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0046_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0046_ip a JOIN t2_tc_06_reg_0046_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0047-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0047_ip, t2_tc_06_reg_0047_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0047_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0047_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4 DEFAULT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0047_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0047-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0047_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0047_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0047_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0047_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0047_ip a JOIN t2_tc_06_reg_0047_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0048-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0048_ip, t2_tc_06_reg_0048_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0048_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0048_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4 NOT NULL DEFAULT '', ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0048_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
SELECT 'TC-06-REG-0048-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0048_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0048_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0048_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0048_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0048_ip a JOIN t2_tc_06_reg_0048_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0049-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0049_ip, t2_tc_06_reg_0049_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0049_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0049_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4 INVISIBLE, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0049_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0049-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0049_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0049_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0049_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0049_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0049_ip a JOIN t2_tc_06_reg_0049_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0050-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0050_ip, t2_tc_06_reg_0050_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0050_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0050_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0050_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0050_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
SELECT 'TC-06-REG-0050-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0050_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0050_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0050_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0050_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0050_ip a JOIN t2_tc_06_reg_0050_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0051-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0051_ip, t2_tc_06_reg_0051_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0051_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0051_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0051_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0051_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0051_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0051_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0051_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0051_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0051_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0051_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0051_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0051_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0051_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0051_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0051_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0051_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0051_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0051_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0051_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0051_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0051-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0051_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0051_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0051_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0051_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0051_ip a JOIN t2_tc_06_reg_0051_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0052-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: CHAR-02
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0052_ip, t2_tc_06_reg_0052_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0052_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0052_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0052_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0052-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0052_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0052_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0052_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0052_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0052_ip a JOIN t2_tc_06_reg_0052_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0053-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: CHAR-02
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0053_ip, t2_tc_06_reg_0053_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0053_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0053_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0053_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0053-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0053_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0053_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0053_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0053_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0053_ip a JOIN t2_tc_06_reg_0053_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0054-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0054_ip, t2_tc_06_reg_0054_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0054_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0054_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0054_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
SELECT 'TC-06-REG-0054-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0054_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0054_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0054_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0054_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0054_ip a JOIN t2_tc_06_reg_0054_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0055-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0055_ip, t2_tc_06_reg_0055_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0055_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0055_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0055_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0055-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0055_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0055_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0055_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0055_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0055_ip a JOIN t2_tc_06_reg_0055_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0056-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0056_ip, t2_tc_06_reg_0056_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0056_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0056_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0056_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0056_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0056_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0056_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0056_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0056_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0056_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0056_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0056_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0056_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0056_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0056_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0056_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0056_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0056_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0056_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0056_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0056_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0056-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0056_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0056_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0056_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0056_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0056_ip a JOIN t2_tc_06_reg_0056_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0057-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=SECONDARY_INDEX
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=SECONDARY_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0057_ip, t2_tc_06_reg_0057_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0057_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0057_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0057_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0057-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0057_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0057_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0057_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0057_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0057_ip a JOIN t2_tc_06_reg_0057_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0058-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=UNIQUE_INDEX
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0058_ip, t2_tc_06_reg_0058_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0058_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0058_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0058_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0058-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0058_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0058_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0058_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0058_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0058_ip a JOIN t2_tc_06_reg_0058_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0059-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=FOREIGN_KEY
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=FOREIGN_KEY, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0059_ip, t2_tc_06_reg_0059_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0059_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0059_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0059_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0059-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0059_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0059_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0059_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0059_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0059_ip a JOIN t2_tc_06_reg_0059_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0060-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=CHECK
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=CHECK, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0060_ip, t2_tc_06_reg_0060_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0060_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0060_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0060_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0060-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0060_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0060_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0060_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0060_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0060_ip a JOIN t2_tc_06_reg_0060_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0061-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0061_ip, t2_tc_06_reg_0061_ip;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_06_reg_0061_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0061_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0061_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0061-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0061_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0061_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0061_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0061_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0061_ip a JOIN t2_tc_06_reg_0061_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0062-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0062_ip, t2_tc_06_reg_0062_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0062_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0062_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4 NOT NULL, ALGORITHM=inplace;
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0062_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0062_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
SELECT 'TC-06-REG-0062-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0062_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0062_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0062_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0062_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0062_ip a JOIN t2_tc_06_reg_0062_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0063-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-02
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0063_ip, t2_tc_06_reg_0063_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0063_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0063_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0063_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0063_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0063_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0063_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0063_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0063_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0063_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0063_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0063_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0063_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0063_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0063_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0063_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0063_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0063_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0063_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0063_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0063_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0063-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0063_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0063_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0063_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0063_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0063_ip a JOIN t2_tc_06_reg_0063_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0064-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: CHAR-02
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0064_ip, t2_tc_06_reg_0064_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0064_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0064_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0064_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0064_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
SELECT 'TC-06-REG-0064-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0064_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0064_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0064_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0064_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0064_ip a JOIN t2_tc_06_reg_0064_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0065-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0065_ip, t2_tc_06_reg_0065_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0065_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0065_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4 NOT NULL DEFAULT '', ALGORITHM=inplace;
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0065_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0065_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
SELECT 'TC-06-REG-0065-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0065_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0065_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0065_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0065_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0065_ip a JOIN t2_tc_06_reg_0065_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0066-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-05
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
DROP TABLE IF EXISTS t1_tc_06_reg_0066_ip, t2_tc_06_reg_0066_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0066_ip (
  target CHAR(63) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0066_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0066_ip (
  target CHAR(64) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
SELECT 'TC-06-REG-0066-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0066_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0066_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0066_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0066_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0066_ip a JOIN t2_tc_06_reg_0066_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-ATR-0004-IP
-- Column attribute preservation: COMMENT
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace
DROP TABLE IF EXISTS t1_tc_06_atr_0004_ip, t2_tc_06_atr_0004_ip;
CREATE TABLE t1_tc_06_atr_0004_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(63) CHARACTER SET utf8mb4 COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_atr_0004_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0004_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_atr_0004_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0004_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0004_ip (target) VALUES ('Hello');
ALTER TABLE t1_tc_06_atr_0004_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4 COMMENT 'test_comment', ALGORITHM=inplace;
INSERT INTO t1_tc_06_atr_0004_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0004_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0004_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
SELECT 'TC-06-ATR-0004-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0004_ip' AND column_name='target' AND column_comment='test_comment';

-- Test Case: TC-06-ATR-0005-IP
-- Column attribute preservation: CHARSET
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace
DROP TABLE IF EXISTS t1_tc_06_atr_0005_ip, t2_tc_06_atr_0005_ip;
CREATE TABLE t1_tc_06_atr_0005_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(63) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_atr_0005_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0005_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_atr_0005_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0005_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0005_ip (target) VALUES ('Hello');
ALTER TABLE t1_tc_06_atr_0005_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
INSERT INTO t1_tc_06_atr_0005_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0005_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0005_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
SELECT 'TC-06-ATR-0005-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0005_ip' AND column_name='target' AND character_set_name='utf8mb4';

-- Test Case: TC-06-ATR-0006-IP
-- Column attribute preservation: COLLATE
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace
DROP TABLE IF EXISTS t1_tc_06_atr_0006_ip, t2_tc_06_atr_0006_ip;
CREATE TABLE t1_tc_06_atr_0006_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(63) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_atr_0006_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0006_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_atr_0006_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0006_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0006_ip (target) VALUES ('Hello');
ALTER TABLE t1_tc_06_atr_0006_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, ALGORITHM=inplace;
INSERT INTO t1_tc_06_atr_0006_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0006_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0006_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
SELECT 'TC-06-ATR-0006-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0006_ip' AND column_name='target' AND collation_name='utf8mb4_bin';

-- Test Case: TC-06-REG-0067-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0067_ip, t2_tc_06_reg_0067_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0067_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0067_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0067_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0067-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0067_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0067_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0067_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0067_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0067_ip a JOIN t2_tc_06_reg_0067_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0068-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0068_ip, t2_tc_06_reg_0068_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0068_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0068_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0068_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0068-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0068_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0068_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0068_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0068_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0068_ip a JOIN t2_tc_06_reg_0068_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0069-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0069_ip, t2_tc_06_reg_0069_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0069_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0069_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0069_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0069-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0069_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0069_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0069_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0069_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0069_ip a JOIN t2_tc_06_reg_0069_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0070-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0070_ip, t2_tc_06_reg_0070_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0070_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0070_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0070_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
SELECT 'TC-06-REG-0070-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0070_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0070_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0070_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0070_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0070_ip a JOIN t2_tc_06_reg_0070_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0071-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0071_ip, t2_tc_06_reg_0071_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0071_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0071_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0071_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0071-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0071_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0071_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0071_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0071_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0071_ip a JOIN t2_tc_06_reg_0071_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0072-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0072_ip, t2_tc_06_reg_0072_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0072_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0072_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0072_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0072-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0072_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0072_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0072_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0072_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0072_ip a JOIN t2_tc_06_reg_0072_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0073-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0073_ip, t2_tc_06_reg_0073_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0073_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0073_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0073_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0073-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0073_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0073_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0073_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0073_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0073_ip a JOIN t2_tc_06_reg_0073_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0074-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0074_ip, t2_tc_06_reg_0074_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0074_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0074_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0074_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0074-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0074_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0074_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0074_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0074_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0074_ip a JOIN t2_tc_06_reg_0074_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0075-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0075_ip, t2_tc_06_reg_0075_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0075_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0075_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0075_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0075-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0075_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0075_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0075_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0075_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0075_ip a JOIN t2_tc_06_reg_0075_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0076-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
DROP TABLE IF EXISTS t1_tc_06_reg_0076_ip, t2_tc_06_reg_0076_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0076_ip (
  target CHAR(254) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0076_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0076_ip (
  target CHAR(255) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0076-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0076_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0076_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0076_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0076_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0076_ip a JOIN t2_tc_06_reg_0076_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0077-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
DROP TABLE IF EXISTS t1_tc_06_reg_0077_ip, t2_tc_06_reg_0077_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0077_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target CHAR(254) CHARACTER SET utf8mb4, PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0077_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0077_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target CHAR(255) CHARACTER SET utf8mb4, PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0077-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0077_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0077_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0077_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0077_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0077_ip a JOIN t2_tc_06_reg_0077_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0078-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0078_ip, t2_tc_06_reg_0078_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0078_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0078_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4 NOT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0078_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
SELECT 'TC-06-REG-0078-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0078_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0078_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0078_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0078_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0078_ip a JOIN t2_tc_06_reg_0078_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0079-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0079_ip, t2_tc_06_reg_0079_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0079_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0079_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4 DEFAULT '', ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0079_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0079-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0079_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0079_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0079_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0079_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0079_ip a JOIN t2_tc_06_reg_0079_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0080-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0080_ip, t2_tc_06_reg_0080_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0080_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0080_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4 DEFAULT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0080_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0080-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0080_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0080_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0080_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0080_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0080_ip a JOIN t2_tc_06_reg_0080_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0081-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0081_ip, t2_tc_06_reg_0081_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0081_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0081_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4 NOT NULL DEFAULT '', ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0081_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
SELECT 'TC-06-REG-0081-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0081_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0081_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0081_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0081_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0081_ip a JOIN t2_tc_06_reg_0081_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0082-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0082_ip, t2_tc_06_reg_0082_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0082_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0082_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4 INVISIBLE, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0082_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0082-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0082_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0082_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0082_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0082_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0082_ip a JOIN t2_tc_06_reg_0082_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0083-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0083_ip, t2_tc_06_reg_0083_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0083_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0083_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0083_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0083_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
SELECT 'TC-06-REG-0083-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0083_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0083_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0083_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0083_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0083_ip a JOIN t2_tc_06_reg_0083_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0084-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0084_ip, t2_tc_06_reg_0084_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0084_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0084_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0084_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0084_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0084_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0084_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0084_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0084_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0084_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0084_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0084_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0084_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0084_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0084_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0084_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0084_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0084_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0084_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0084_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0084_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0084-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0084_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0084_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0084_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0084_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0084_ip a JOIN t2_tc_06_reg_0084_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0085-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: CHAR-03
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0085_ip, t2_tc_06_reg_0085_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0085_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0085_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0085_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0085-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0085_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0085_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0085_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0085_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0085_ip a JOIN t2_tc_06_reg_0085_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0086-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: CHAR-03
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0086_ip, t2_tc_06_reg_0086_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0086_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0086_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0086_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0086-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0086_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0086_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0086_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0086_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0086_ip a JOIN t2_tc_06_reg_0086_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0087-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0087_ip, t2_tc_06_reg_0087_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0087_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0087_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0087_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
SELECT 'TC-06-REG-0087-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0087_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0087_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0087_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0087_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0087_ip a JOIN t2_tc_06_reg_0087_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0088-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0088_ip, t2_tc_06_reg_0088_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0088_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0088_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0088_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0088-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0088_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0088_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0088_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0088_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0088_ip a JOIN t2_tc_06_reg_0088_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0089-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0089_ip, t2_tc_06_reg_0089_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0089_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0089_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0089_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0089_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0089_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0089_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0089_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0089_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0089_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0089_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0089_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0089_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0089_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0089_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0089_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0089_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0089_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0089_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0089_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0089_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0089-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0089_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0089_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0089_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0089_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0089_ip a JOIN t2_tc_06_reg_0089_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0090-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=SECONDARY_INDEX
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=SECONDARY_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0090_ip, t2_tc_06_reg_0090_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0090_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0090_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0090_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0090-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0090_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0090_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0090_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0090_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0090_ip a JOIN t2_tc_06_reg_0090_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0091-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=UNIQUE_INDEX
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0091_ip, t2_tc_06_reg_0091_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0091_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0091_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0091_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0091-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0091_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0091_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0091_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0091_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0091_ip a JOIN t2_tc_06_reg_0091_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0092-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=FOREIGN_KEY
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=FOREIGN_KEY, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0092_ip, t2_tc_06_reg_0092_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0092_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0092_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0092_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0092-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0092_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0092_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0092_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0092_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0092_ip a JOIN t2_tc_06_reg_0092_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0093-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=CHECK
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=CHECK, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0093_ip, t2_tc_06_reg_0093_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0093_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0093_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0093_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0093-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0093_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0093_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0093_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0093_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0093_ip a JOIN t2_tc_06_reg_0093_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0094-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0094_ip, t2_tc_06_reg_0094_ip;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_06_reg_0094_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0094_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0094_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0094-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0094_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0094_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0094_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0094_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0094_ip a JOIN t2_tc_06_reg_0094_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0095-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0095_ip, t2_tc_06_reg_0095_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0095_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0095_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4 NOT NULL, ALGORITHM=inplace;
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0095_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0095_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
SELECT 'TC-06-REG-0095-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0095_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0095_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0095_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0095_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0095_ip a JOIN t2_tc_06_reg_0095_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0096-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-02
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0096_ip, t2_tc_06_reg_0096_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0096_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0096_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0096_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0096_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0096_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0096_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0096_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0096_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0096_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0096_ip (target) VALUES (NULL);
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0096_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0096_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0096_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0096_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0096_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0096_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0096_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0096_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0096_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0096_ip (target) VALUES (NULL);
SELECT 'TC-06-REG-0096-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0096_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0096_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0096_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0096_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0096_ip a JOIN t2_tc_06_reg_0096_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0097-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: CHAR-03
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0097_ip, t2_tc_06_reg_0097_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0097_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0097_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0097_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0097_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
SELECT 'TC-06-REG-0097-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0097_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0097_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0097_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0097_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0097_ip a JOIN t2_tc_06_reg_0097_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0098-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_06_reg_0098_ip, t2_tc_06_reg_0098_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0098_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0098_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4 NOT NULL DEFAULT '', ALGORITHM=inplace;
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0098_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0098_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
SELECT 'TC-06-REG-0098-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0098_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0098_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0098_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0098_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0098_ip a JOIN t2_tc_06_reg_0098_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-REG-0099-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-05
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
DROP TABLE IF EXISTS t1_tc_06_reg_0099_ip, t2_tc_06_reg_0099_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0099_ip (
  target CHAR(254) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0099_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Insert value exceeding new type (expected FAIL on both tables)
-- INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0099_ip (
  target CHAR(255) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
SELECT 'TC-06-REG-0099-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0099_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0099_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0099_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0099_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0099_ip a JOIN t2_tc_06_reg_0099_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-06-ATR-0007-IP
-- Column attribute preservation: COMMENT
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace
DROP TABLE IF EXISTS t1_tc_06_atr_0007_ip, t2_tc_06_atr_0007_ip;
CREATE TABLE t1_tc_06_atr_0007_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(254) CHARACTER SET utf8mb4 COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_atr_0007_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0007_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_atr_0007_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0007_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0007_ip (target) VALUES ('Hello');
ALTER TABLE t1_tc_06_atr_0007_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4 COMMENT 'test_comment', ALGORITHM=inplace;
INSERT INTO t1_tc_06_atr_0007_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0007_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0007_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
SELECT 'TC-06-ATR-0007-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0007_ip' AND column_name='target' AND column_comment='test_comment';

-- Test Case: TC-06-ATR-0008-IP
-- Column attribute preservation: CHARSET
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace
DROP TABLE IF EXISTS t1_tc_06_atr_0008_ip, t2_tc_06_atr_0008_ip;
CREATE TABLE t1_tc_06_atr_0008_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(254) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_atr_0008_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0008_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_atr_0008_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0008_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0008_ip (target) VALUES ('Hello');
ALTER TABLE t1_tc_06_atr_0008_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
INSERT INTO t1_tc_06_atr_0008_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0008_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0008_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
SELECT 'TC-06-ATR-0008-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0008_ip' AND column_name='target' AND character_set_name='utf8mb4';

-- Test Case: TC-06-ATR-0009-IP
-- Column attribute preservation: COLLATE
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace
DROP TABLE IF EXISTS t1_tc_06_atr_0009_ip, t2_tc_06_atr_0009_ip;
CREATE TABLE t1_tc_06_atr_0009_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(254) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_atr_0009_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0009_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_atr_0009_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0009_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0009_ip (target) VALUES ('Hello');
ALTER TABLE t1_tc_06_atr_0009_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, ALGORITHM=inplace;
INSERT INTO t1_tc_06_atr_0009_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0009_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0009_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
SELECT 'TC-06-ATR-0009-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0009_ip' AND column_name='target' AND collation_name='utf8mb4_bin';

