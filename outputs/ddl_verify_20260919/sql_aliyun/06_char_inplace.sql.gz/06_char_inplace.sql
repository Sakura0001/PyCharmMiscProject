-- ============================================================
-- RDS MySQL DDL 秒级/在线修改列类型 测试套件 — 阿里云环境
-- 环境说明: 所有功能开关默认开启
-- 覆盖类型: 整数(SIGNED/UNSIGNED) + CHAR + VARCHAR
-- 覆盖算法: INSTANT + INPLACE
-- ============================================================
-- 本文件由 generate_test_sql.py 自动生成, 请勿手动修改
-- Suite-Revision: fe94a870b930   (生成器源码哈希; 时间戳见 results/generation_manifest.json)
-- 用例 ID 规则: TC-<文件号>-<作用域>-<序号>-<IT|IP>  —— 全局唯一
--   作用域 REG=普通表 OFAT/二元组, ATR=列属性保持, SPE=特殊模式,
--          FK=外键, PTK=分区(目标列是分区键), PNK=分区(目标列非分区键)
-- ============================================================

SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
SET SESSION innodb_lock_wait_timeout = 50;

-- File 06: CHAR INPLACE

-- Test Case: TC-06-REG-0001-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=6dd57092df4c column_type=char(2) neg_probe=ffee393e2053=167|1264|1265|1406 neg_probe=7f84a8a5050d=167|1264|1265|1406 neg_probe=6553686aa0d5=167|1264|1265|1406 neg_probe=1f900694d084=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0001_ip, t2_tc_06_reg_0001_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0001_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0001_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0001_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0001_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0001_ip);
-- probe 1/2 -> t1_tc_06_reg_0001_ip
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0001_ip
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0001_ip
INSERT INTO t1_tc_06_reg_0001_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0001_ip
INSERT INTO t2_tc_06_reg_0001_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0001-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0001_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0001_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0001_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0001_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0001-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0001_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0001_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0001_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0001_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0001_ip a JOIN t2_tc_06_reg_0001_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0001-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0001_ip' AND column_name='target';

-- Test Case: TC-06-REG-0002-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=718294716c21 column_type=char(2) neg_probe=174381ba8df1=167|1264|1265|1406 neg_probe=daf1c5bb238c=167|1264|1265|1406 neg_probe=68fcb46fc29e=167|1264|1265|1406 neg_probe=91b97f8961c8=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0002_ip, t2_tc_06_reg_0002_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0002_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0002_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0002_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0002_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0002_ip);
-- probe 1/2 -> t1_tc_06_reg_0002_ip
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0002_ip
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0002_ip
INSERT INTO t1_tc_06_reg_0002_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0002_ip
INSERT INTO t2_tc_06_reg_0002_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0002-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0002_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0002_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0002_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0002_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0002-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0002_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0002_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0002_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0002_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0002_ip a JOIN t2_tc_06_reg_0002_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0002-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0002_ip' AND column_name='target';

-- Test Case: TC-06-REG-0003-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=89df41dcddbb column_type=char(2) neg_probe=670972f72bfc=167|1264|1265|1406 neg_probe=fc45c0644e1c=167|1264|1265|1406 neg_probe=4f3d5c8edeb9=167|1264|1265|1406 neg_probe=71ca14505e6e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0003_ip, t2_tc_06_reg_0003_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0003_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0003_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0003_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0003_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0003_ip);
-- probe 1/2 -> t1_tc_06_reg_0003_ip
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0003_ip
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0003_ip
INSERT INTO t1_tc_06_reg_0003_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0003_ip
INSERT INTO t2_tc_06_reg_0003_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0003-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0003_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0003_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0003_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0003_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0003-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0003_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0003_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0003_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0003_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0003_ip a JOIN t2_tc_06_reg_0003_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0003-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0003_ip' AND column_name='target';

-- Test Case: TC-06-REG-0004-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=353ffd15ae35 column_type=char(2) neg_probe=edae2c6f3c9c=167|1264|1265|1406 neg_probe=adc5f397ab61=167|1264|1265|1406 neg_probe=7e496f410ff6=167|1264|1265|1406 neg_probe=d6a3572aa598=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0004_ip, t2_tc_06_reg_0004_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0004_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('a');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0004_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('x');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0004_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('x');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0004_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0004_ip);
-- probe 1/2 -> t1_tc_06_reg_0004_ip
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0004_ip
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0004_ip
INSERT INTO t1_tc_06_reg_0004_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0004_ip
INSERT INTO t2_tc_06_reg_0004_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0004-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0004_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0004_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0004_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0004_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0004-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0004_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0004_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0004_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0004_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0004_ip a JOIN t2_tc_06_reg_0004_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0004-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=NO has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0004_ip' AND column_name='target';

-- Test Case: TC-06-REG-0005-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=eb32885a7227 column_type=char(2) neg_probe=cc1b2da85ff9=167|1264|1265|1406 neg_probe=b5a38d36158e=167|1264|1265|1406 neg_probe=379533a21fc6=167|1264|1265|1406 neg_probe=57a7dd7bb396=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0005_ip, t2_tc_06_reg_0005_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0005_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0005_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0005_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0005_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0005_ip);
-- probe 1/2 -> t1_tc_06_reg_0005_ip
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0005_ip
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0005_ip
INSERT INTO t1_tc_06_reg_0005_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0005_ip
INSERT INTO t2_tc_06_reg_0005_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0005-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0005_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0005_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0005_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0005_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0005-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0005_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0005_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0005_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0005_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0005_ip a JOIN t2_tc_06_reg_0005_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0005-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0005_ip' AND column_name='target';

-- Test Case: TC-06-REG-0006-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=677f0c74bd7b column_type=char(2) neg_probe=bc6a120bc338=167|1264|1265|1406 neg_probe=873148b940fa=167|1264|1265|1406 neg_probe=ee88abf593ff=167|1264|1265|1406 neg_probe=feded595dc3b=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0006_ip, t2_tc_06_reg_0006_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0006_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0006_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0006_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0006_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0006_ip);
-- probe 1/2 -> t1_tc_06_reg_0006_ip
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0006_ip
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0006_ip
INSERT INTO t1_tc_06_reg_0006_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0006_ip
INSERT INTO t2_tc_06_reg_0006_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0006-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0006_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0006_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0006_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0006_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0006-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0006_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0006_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0006_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0006_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0006_ip a JOIN t2_tc_06_reg_0006_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0006-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0006_ip' AND column_name='target';

-- Test Case: TC-06-REG-0007-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=57cf7e11748c column_type=char(2) neg_probe=dfdd0cdfa4e3=167|1264|1265|1406 neg_probe=3052482cdf85=167|1264|1265|1406 neg_probe=883b97c6396c=167|1264|1265|1406 neg_probe=6395892842ea=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0007_ip, t2_tc_06_reg_0007_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0007_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0007_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0007_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0007_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0007_ip);
-- probe 1/2 -> t1_tc_06_reg_0007_ip
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0007_ip
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0007_ip
INSERT INTO t1_tc_06_reg_0007_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0007_ip
INSERT INTO t2_tc_06_reg_0007_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0007-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0007_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0007_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0007_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0007_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0007-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0007_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0007_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0007_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0007_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0007_ip a JOIN t2_tc_06_reg_0007_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0007-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0007_ip' AND column_name='target';

-- Test Case: TC-06-REG-0008-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=fe0dfbb6ff8d column_type=char(2) neg_probe=b1ca0181e5a7=167|1264|1265|1406 neg_probe=4139e97e139a=167|1264|1265|1406 neg_probe=a05128e95241=167|1264|1265|1406 neg_probe=44fa34242f2e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0008_ip, t2_tc_06_reg_0008_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0008_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0008_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0008_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0008_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0008_ip);
-- probe 1/2 -> t1_tc_06_reg_0008_ip
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0008_ip
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0008_ip
INSERT INTO t1_tc_06_reg_0008_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0008_ip
INSERT INTO t2_tc_06_reg_0008_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0008-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0008_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0008_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0008_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0008_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0008-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0008_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0008_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0008_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0008_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0008_ip a JOIN t2_tc_06_reg_0008_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0008-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0008_ip' AND column_name='target';

-- Test Case: TC-06-REG-0009-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=0f4663f5a35a column_type=char(2) neg_probe=b1602c580c78=167|1264|1265|1406 neg_probe=0b7bc8065399=167|1264|1265|1406 neg_probe=9007de1fc089=167|1264|1265|1406 neg_probe=2ea2d0130106=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0009_ip, t2_tc_06_reg_0009_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0009_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0009_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0009_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0009_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0009_ip);
-- probe 1/2 -> t1_tc_06_reg_0009_ip
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0009_ip
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0009_ip
INSERT INTO t1_tc_06_reg_0009_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0009_ip
INSERT INTO t2_tc_06_reg_0009_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0009-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0009_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0009_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0009_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0009_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0009-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0009_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0009_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0009_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0009_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0009_ip a JOIN t2_tc_06_reg_0009_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0009-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0009_ip' AND column_name='target';

-- Test Case: TC-06-REG-0010-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=08f6d7d1761b column_type=char(2) neg_probe=92d958f77588=167|1264|1265|1406 neg_probe=66a2f39ec2c5=167|1264|1265|1406 neg_probe=b712d1f873e3=167|1264|1265|1406 neg_probe=cd6a22dd74d9=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0010_ip, t2_tc_06_reg_0010_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0010_ip (
  target CHAR(1) CHARACTER SET latin1,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0010_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0010_ip (
  target CHAR(2) CHARACTER SET latin1,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0010_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0010_ip);
-- probe 1/2 -> t1_tc_06_reg_0010_ip
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0010_ip
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0010_ip
INSERT INTO t1_tc_06_reg_0010_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0010_ip
INSERT INTO t2_tc_06_reg_0010_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0010-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0010_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0010_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0010_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0010_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0010-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0010_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0010_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0010_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0010_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0010_ip a JOIN t2_tc_06_reg_0010_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0010-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0010_ip' AND column_name='target';

-- Test Case: TC-06-REG-0011-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=29c2375211b3 column_type=char(2) neg_probe=19033d3d965d=167|1264|1265|1406 neg_probe=ab7e0f4cd7d8=167|1264|1265|1406 neg_probe=5de88e5f28fd=167|1264|1265|1406 neg_probe=4736937dd189=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0011_ip, t2_tc_06_reg_0011_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0011_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target CHAR(1) CHARACTER SET latin1, PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0011_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0011_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target CHAR(2) CHARACTER SET latin1, PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0011_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0011_ip);
-- probe 1/2 -> t1_tc_06_reg_0011_ip
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0011_ip
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0011_ip
INSERT INTO t1_tc_06_reg_0011_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0011_ip
INSERT INTO t2_tc_06_reg_0011_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0011-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0011_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0011_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0011_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0011_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0011-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0011_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0011_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0011_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0011_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0011_ip a JOIN t2_tc_06_reg_0011_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0011-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=4,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=4]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0011_ip' AND column_name='target';

-- Test Case: TC-06-REG-0012-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=4b85fa0fc9db column_type=char(2) neg_probe=c284389782ca=167|1264|1265|1406 neg_probe=f19e1c409f2a=167|1264|1265|1406 neg_probe=b8a35fefa62c=167|1264|1265|1406 neg_probe=0f8309fa0af1=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0012_ip, t2_tc_06_reg_0012_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0012_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('a');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0012_ip MODIFY target CHAR(2) CHARACTER SET latin1 NOT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('x');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0012_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('x');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0012_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0012_ip);
-- probe 1/2 -> t1_tc_06_reg_0012_ip
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0012_ip
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0012_ip
INSERT INTO t1_tc_06_reg_0012_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0012_ip
INSERT INTO t2_tc_06_reg_0012_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0012-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0012_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0012_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0012_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0012_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0012-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0012_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0012_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0012_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0012_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0012_ip a JOIN t2_tc_06_reg_0012_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0012-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=NO has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0012_ip' AND column_name='target';

-- Test Case: TC-06-REG-0013-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=1458ea08cea7 column_type=char(2) neg_probe=3a3f719448dc=167|1264|1265|1406 neg_probe=869d65d234ee=167|1264|1265|1406 neg_probe=739ae8eb239f=167|1264|1265|1406 neg_probe=e6fe5466da25=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0013_ip, t2_tc_06_reg_0013_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0013_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0013_ip MODIFY target CHAR(2) CHARACTER SET latin1 DEFAULT '', ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0013_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0013_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0013_ip);
-- probe 1/2 -> t1_tc_06_reg_0013_ip
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0013_ip
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0013_ip
INSERT INTO t1_tc_06_reg_0013_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0013_ip
INSERT INTO t2_tc_06_reg_0013_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0013-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0013_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0013_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0013_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0013_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0013-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0013_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0013_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0013_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0013_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0013_ip a JOIN t2_tc_06_reg_0013_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0013-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=1 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0013_ip' AND column_name='target';

-- Test Case: TC-06-REG-0014-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=b4a81c84bb21 column_type=char(2) neg_probe=7ac2ea9e2f1d=167|1264|1265|1406 neg_probe=886fcd0755e0=167|1264|1265|1406 neg_probe=a91727334b65=167|1264|1265|1406 neg_probe=1e04e2618ca5=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0014_ip, t2_tc_06_reg_0014_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0014_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0014_ip MODIFY target CHAR(2) CHARACTER SET latin1 DEFAULT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0014_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0014_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0014_ip);
-- probe 1/2 -> t1_tc_06_reg_0014_ip
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0014_ip
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0014_ip
INSERT INTO t1_tc_06_reg_0014_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0014_ip
INSERT INTO t2_tc_06_reg_0014_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0014-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0014_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0014_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0014_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0014_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0014-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0014_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0014_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0014_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0014_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0014_ip a JOIN t2_tc_06_reg_0014_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0014-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0014_ip' AND column_name='target';

-- Test Case: TC-06-REG-0015-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=014cc820f3c3 column_type=char(2) neg_probe=1879cc48f031=167|1264|1265|1406 neg_probe=bc0a3a5cc5f1=167|1264|1265|1406 neg_probe=57c7ca41ab2a=167|1264|1265|1406 neg_probe=9a91b7be6266=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0015_ip, t2_tc_06_reg_0015_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0015_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('a');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0015_ip MODIFY target CHAR(2) CHARACTER SET latin1 NOT NULL DEFAULT '', ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('x');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0015_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('x');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0015_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0015_ip);
-- probe 1/2 -> t1_tc_06_reg_0015_ip
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0015_ip
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0015_ip
INSERT INTO t1_tc_06_reg_0015_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0015_ip
INSERT INTO t2_tc_06_reg_0015_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0015-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0015_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0015_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0015_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0015_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0015-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0015_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0015_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0015_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0015_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0015_ip a JOIN t2_tc_06_reg_0015_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0015-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=NO has_default=1 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0015_ip' AND column_name='target';

-- Test Case: TC-06-REG-0016-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=53fe9b075177 column_type=char(2) neg_probe=9c654aa53366=167|1264|1265|1406 neg_probe=3d6b4f10fd93=167|1264|1265|1406 neg_probe=944ecd342343=167|1264|1265|1406 neg_probe=e8b5c333a0db=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0016_ip, t2_tc_06_reg_0016_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0016_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0016_ip MODIFY target CHAR(2) CHARACTER SET latin1 INVISIBLE, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0016_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0016_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0016_ip);
-- probe 1/2 -> t1_tc_06_reg_0016_ip
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0016_ip
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0016_ip
INSERT INTO t1_tc_06_reg_0016_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0016_ip
INSERT INTO t2_tc_06_reg_0016_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0016-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0016_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0016_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0016_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0016_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0016-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0016_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0016_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0016_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0016_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0016_ip a JOIN t2_tc_06_reg_0016_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0016-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> 'INVISIBLE')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra=INVISIBLE pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0016_ip' AND column_name='target';

-- Test Case: TC-06-REG-0017-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=ce64468097f2 column_type=char(2) neg_probe=8260f85bff8d=167|1264|1265|1406 neg_probe=585467245b6e=167|1264|1265|1406 neg_probe=6ad954db5584=167|1264|1265|1406 neg_probe=69cf1f459ec8=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0017_ip, t2_tc_06_reg_0017_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0017_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0017_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0017_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0017_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0017_ip);
-- probe 1/2 -> t1_tc_06_reg_0017_ip
INSERT INTO t1_tc_06_reg_0017_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0017_ip
INSERT INTO t2_tc_06_reg_0017_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0017_ip
INSERT INTO t1_tc_06_reg_0017_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0017_ip
INSERT INTO t2_tc_06_reg_0017_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0017-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0017_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0017_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0017_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0017_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0017-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0017_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0017_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0017_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0017_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0017_ip a JOIN t2_tc_06_reg_0017_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0017-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0017_ip' AND column_name='target';

-- Test Case: TC-06-REG-0018-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=f940adc90191 column_type=char(2) neg_probe=9e4a49fcd1b5=167|1264|1265|1406 neg_probe=f4f9a081bc05=167|1264|1265|1406 neg_probe=05b19c87f706=167|1264|1265|1406 neg_probe=379ad579acc0=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0018_ip, t2_tc_06_reg_0018_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0018_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0018_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0018_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0018_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0018_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0018_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0018_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0018_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0018_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0018_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0018_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0018_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0018_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0018_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0018_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0018_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0018_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0018_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0018_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0018_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0018_ip);
-- probe 1/2 -> t1_tc_06_reg_0018_ip
INSERT INTO t1_tc_06_reg_0018_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0018_ip
INSERT INTO t2_tc_06_reg_0018_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0018_ip
INSERT INTO t1_tc_06_reg_0018_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0018_ip
INSERT INTO t2_tc_06_reg_0018_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0018-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0018_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0018_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0018_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0018_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0018-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0018_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0018_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0018_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0018_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0018_ip a JOIN t2_tc_06_reg_0018_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0018-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0018_ip' AND column_name='target';

-- Test Case: TC-06-REG-0019-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: CHAR-01
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=a7cd089ef031 column_type=char(2) neg_probe=9d5f1f8a34de=167|1264|1265|1406 neg_probe=d0520d014c13=167|1264|1265|1406 neg_probe=c93a85c3235f=167|1264|1265|1406 neg_probe=73e1135a545f=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0019_ip, t2_tc_06_reg_0019_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0019_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0019_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0019_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0019_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0019_ip);
-- probe 1/2 -> t1_tc_06_reg_0019_ip
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0019_ip
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0019_ip
INSERT INTO t1_tc_06_reg_0019_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0019_ip
INSERT INTO t2_tc_06_reg_0019_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0019-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0019_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0019_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0019_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0019_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0019-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0019_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0019_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0019_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0019_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0019_ip a JOIN t2_tc_06_reg_0019_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0019-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0019_ip' AND column_name='target';

-- Test Case: TC-06-REG-0020-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: CHAR-01
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=ed91b7fcec30 column_type=char(2) neg_probe=d942edc9b917=167|1264|1265|1406 neg_probe=d4eeffac0609=167|1264|1265|1406 neg_probe=551c7b479fa0=167|1264|1265|1406 neg_probe=85da1957efe9=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0020_ip, t2_tc_06_reg_0020_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0020_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0020_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0020_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0020_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0020_ip);
-- probe 1/2 -> t1_tc_06_reg_0020_ip
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0020_ip
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0020_ip
INSERT INTO t1_tc_06_reg_0020_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0020_ip
INSERT INTO t2_tc_06_reg_0020_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0020-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0020_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0020_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0020_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0020_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0020-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0020_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0020_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0020_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0020_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0020_ip a JOIN t2_tc_06_reg_0020_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0020-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0020_ip' AND column_name='target';

-- Test Case: TC-06-REG-0021-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=58d9cafde701 column_type=char(2) neg_probe=689a9e2446ae=167|1264|1265|1406 neg_probe=e20c6adb8176=167|1264|1265|1406 neg_probe=819afc52dde4=167|1264|1265|1406 neg_probe=65c053c254f9=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0021_ip, t2_tc_06_reg_0021_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0021_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('a');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0021_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('x');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0021_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('x');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0021_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0021_ip);
-- probe 1/2 -> t1_tc_06_reg_0021_ip
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0021_ip
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0021_ip
INSERT INTO t1_tc_06_reg_0021_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0021_ip
INSERT INTO t2_tc_06_reg_0021_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0021-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0021_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0021_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0021_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0021_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0021-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0021_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0021_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0021_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0021_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0021_ip a JOIN t2_tc_06_reg_0021_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0021-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0021_ip' AND column_name='target';

-- Test Case: TC-06-REG-0022-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=614b83aba194 column_type=char(2) neg_probe=b399dce0152c=167|1264|1265|1406 neg_probe=bfb8471447a4=167|1264|1265|1406 neg_probe=ac5f6ee666ca=167|1264|1265|1406 neg_probe=b9b538c14259=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0022_ip, t2_tc_06_reg_0022_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0022_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0022_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0022_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0022_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0022_ip);
-- probe 1/2 -> t1_tc_06_reg_0022_ip
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0022_ip
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0022_ip
INSERT INTO t1_tc_06_reg_0022_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0022_ip
INSERT INTO t2_tc_06_reg_0022_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0022-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0022_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0022_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0022_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0022_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0022-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0022_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0022_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0022_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0022_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0022_ip a JOIN t2_tc_06_reg_0022_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0022-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0022_ip' AND column_name='target';

-- Test Case: TC-06-REG-0023-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=0997aea312e6 column_type=char(2) neg_probe=49f9fafd5c94=167|1264|1265|1406 neg_probe=129bc157396c=167|1264|1265|1406 neg_probe=38e91a896722=167|1264|1265|1406 neg_probe=9bf46e0afa38=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0023_ip, t2_tc_06_reg_0023_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0023_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0023_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0023_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0023_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0023_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0023_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0023_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0023_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0023_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0023_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0023_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0023_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0023_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0023_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0023_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0023_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0023_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0023_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0023_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0023_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0023_ip);
-- probe 1/2 -> t1_tc_06_reg_0023_ip
INSERT INTO t1_tc_06_reg_0023_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0023_ip
INSERT INTO t2_tc_06_reg_0023_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0023_ip
INSERT INTO t1_tc_06_reg_0023_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0023_ip
INSERT INTO t2_tc_06_reg_0023_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0023-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0023_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0023_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0023_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0023_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0023-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0023_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0023_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0023_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0023_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0023_ip a JOIN t2_tc_06_reg_0023_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0023-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0023_ip' AND column_name='target';

-- Test Case: TC-06-REG-0024-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=SECONDARY_INDEX
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=SECONDARY_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=60dbb20eaf5c column_type=char(2) neg_probe=e4a5e37fa166=167|1264|1265|1406 neg_probe=3da9caeae93b=167|1264|1265|1406 neg_probe=48d609ad7f94=167|1264|1265|1406 neg_probe=430139c4ccba=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0024_ip, t2_tc_06_reg_0024_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0024_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0024_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0024_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0024_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0024_ip);
-- probe 1/2 -> t1_tc_06_reg_0024_ip
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0024_ip
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0024_ip
INSERT INTO t1_tc_06_reg_0024_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0024_ip
INSERT INTO t2_tc_06_reg_0024_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0024-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0024_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0024_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0024_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0024_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0024-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0024_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0024_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0024_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0024_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0024_ip a JOIN t2_tc_06_reg_0024_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0024-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0024_ip' AND column_name='target';

-- Test Case: TC-06-REG-0025-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=UNIQUE_INDEX
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=78c1b41a32da column_type=char(2) neg_probe=a65f173af2d6=167|1264|1265|1406 neg_probe=19a0f863df7b=167|1264|1265|1406 neg_probe=c8429de34951=167|1264|1265|1406 neg_probe=84f80146bbfd=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0025_ip, t2_tc_06_reg_0025_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0025_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0025_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0025_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0025_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0025_ip);
-- probe 1/2 -> t1_tc_06_reg_0025_ip
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0025_ip
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0025_ip
INSERT INTO t1_tc_06_reg_0025_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0025_ip
INSERT INTO t2_tc_06_reg_0025_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0025-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0025_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0025_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0025_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0025_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0025-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0025_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0025_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0025_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0025_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0025_ip a JOIN t2_tc_06_reg_0025_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0025-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0025_ip' AND column_name='target';

-- Test Case: TC-06-REG-0026-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=FOREIGN_KEY
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=FOREIGN_KEY, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=69a809e891d8 column_type=char(2) neg_probe=04c0f7c7bd2b=167|1264|1265|1406 neg_probe=1a7bde362c1f=167|1264|1265|1406 neg_probe=221d71098507=167|1264|1265|1406 neg_probe=781c6edffddd=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0026_ip, t2_tc_06_reg_0026_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0026_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0026_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0026_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0026_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0026_ip);
-- probe 1/2 -> t1_tc_06_reg_0026_ip
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0026_ip
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0026_ip
INSERT INTO t1_tc_06_reg_0026_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0026_ip
INSERT INTO t2_tc_06_reg_0026_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0026-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0026_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0026_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0026_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0026_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0026-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0026_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0026_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0026_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0026_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0026_ip a JOIN t2_tc_06_reg_0026_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0026-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0026_ip' AND column_name='target';

-- Test Case: TC-06-REG-0027-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=CHECK
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=CHECK, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=9b0bb28230aa column_type=char(2) neg_probe=d392726570ec=167|1264|1265|1406 neg_probe=c97dfda5d8be=167|1264|1265|1406 neg_probe=6d29c0792203=167|1264|1265|1406 neg_probe=cdda0fc575e6=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0027_ip, t2_tc_06_reg_0027_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0027_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0027_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0027_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0027_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0027_ip);
-- probe 1/2 -> t1_tc_06_reg_0027_ip
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0027_ip
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0027_ip
INSERT INTO t1_tc_06_reg_0027_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0027_ip
INSERT INTO t2_tc_06_reg_0027_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0027-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0027_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0027_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0027_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0027_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0027-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0027_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0027_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0027_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0027_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0027_ip a JOIN t2_tc_06_reg_0027_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0027-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0027_ip' AND column_name='target';

-- Test Case: TC-06-REG-0028-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=e14e75ad95c9 column_type=char(2) neg_probe=0f712415ca7a=ACCEPTED neg_probe=a0a770a24748=ACCEPTED neg_probe=f0851ce8c669=ACCEPTED neg_probe=0b50d6d561a0=ACCEPTED
DROP TABLE IF EXISTS t1_tc_06_reg_0028_ip, t2_tc_06_reg_0028_ip;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_06_reg_0028_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0028_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0028_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0028_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0028_ip);
-- probe 1/2 -> t1_tc_06_reg_0028_ip
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0028_ip
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0028_ip
INSERT INTO t1_tc_06_reg_0028_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0028_ip
INSERT INTO t2_tc_06_reg_0028_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0028-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0028_ip) - @neg_before_t1 = (SELECT COUNT(*) FROM t2_tc_06_reg_0028_ip) - @neg_before_t2,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0028_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0028_ip) - @neg_before_t2,' expect=t1_added = t2_added (非 STRICT: 截断行为必须与对照表一致) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0028-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0028_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0028_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0028_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0028_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0028_ip a JOIN t2_tc_06_reg_0028_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0028-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0028_ip' AND column_name='target';

-- Test Case: TC-06-REG-0029-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=6b14ad37f39c column_type=char(2) neg_probe=ba441392e972=167|1264|1265|1406 neg_probe=374dfd5a2fb5=167|1264|1265|1406 neg_probe=61f2747a271d=167|1264|1265|1406 neg_probe=c8e7e5aa2a68=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0029_ip, t2_tc_06_reg_0029_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0029_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0029_ip MODIFY target CHAR(2) CHARACTER SET latin1 NOT NULL, ALGORITHM=inplace;
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0029_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0029_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0029_ip);
-- probe 1/2 -> t1_tc_06_reg_0029_ip
INSERT INTO t1_tc_06_reg_0029_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0029_ip
INSERT INTO t2_tc_06_reg_0029_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0029_ip
INSERT INTO t1_tc_06_reg_0029_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0029_ip
INSERT INTO t2_tc_06_reg_0029_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0029-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0029_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0029_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0029_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0029_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0029-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0029_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0029_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0029_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0029_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0029_ip a JOIN t2_tc_06_reg_0029_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0029-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=NO has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0029_ip' AND column_name='target';

-- Test Case: TC-06-REG-0030-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-02
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=8f23855a6768 column_type=char(2) neg_probe=f407dd8fefc4=167|1264|1265|1406 neg_probe=9fca358c4d17=167|1264|1265|1406 neg_probe=48649db41f08=167|1264|1265|1406 neg_probe=0e7f82d1b78a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0030_ip, t2_tc_06_reg_0030_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0030_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0030_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0030_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0030_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0030_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0030_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0030_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0030_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0030_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0030_ip (target) VALUES (NULL);
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0030_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0030_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0030_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0030_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0030_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0030_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0030_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0030_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0030_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0030_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0030_ip);
-- probe 1/2 -> t1_tc_06_reg_0030_ip
INSERT INTO t1_tc_06_reg_0030_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0030_ip
INSERT INTO t2_tc_06_reg_0030_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0030_ip
INSERT INTO t1_tc_06_reg_0030_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0030_ip
INSERT INTO t2_tc_06_reg_0030_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0030-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0030_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0030_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0030_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0030_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0030-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0030_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0030_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0030_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0030_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0030_ip a JOIN t2_tc_06_reg_0030_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0030-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0030_ip' AND column_name='target';

-- Test Case: TC-06-REG-0031-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: CHAR-01
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=d3a9c54acdf2 column_type=char(2) neg_probe=d433dfd3a1c4=167|1264|1265|1406 neg_probe=84988bb77075=167|1264|1265|1406 neg_probe=18bb7138c8b0=167|1264|1265|1406 neg_probe=6bc81e3a81c0=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0031_ip, t2_tc_06_reg_0031_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0031_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0031_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0031_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0031_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0031_ip);
-- probe 1/2 -> t1_tc_06_reg_0031_ip
INSERT INTO t1_tc_06_reg_0031_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0031_ip
INSERT INTO t2_tc_06_reg_0031_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0031_ip
INSERT INTO t1_tc_06_reg_0031_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0031_ip
INSERT INTO t2_tc_06_reg_0031_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0031-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0031_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0031_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0031_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0031_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0031-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0031_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0031_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0031_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0031_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0031_ip a JOIN t2_tc_06_reg_0031_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0031-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0031_ip' AND column_name='target';

-- Test Case: TC-06-REG-0032-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=70f4a61b537b column_type=char(2) neg_probe=372664301cf4=167|1264|1265|1406 neg_probe=15669340c876=167|1264|1265|1406 neg_probe=0fe86a976d4e=167|1264|1265|1406 neg_probe=70eb36032361=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0032_ip, t2_tc_06_reg_0032_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0032_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(1) CHARACTER SET latin1 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0032_ip MODIFY target CHAR(2) CHARACTER SET latin1 NOT NULL DEFAULT '', ALGORITHM=inplace;
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0032_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(2) CHARACTER SET latin1 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0032_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0032_ip);
-- probe 1/2 -> t1_tc_06_reg_0032_ip
INSERT INTO t1_tc_06_reg_0032_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0032_ip
INSERT INTO t2_tc_06_reg_0032_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0032_ip
INSERT INTO t1_tc_06_reg_0032_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0032_ip
INSERT INTO t2_tc_06_reg_0032_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0032-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0032_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0032_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0032_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0032_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0032-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0032_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0032_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0032_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0032_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0032_ip a JOIN t2_tc_06_reg_0032_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0032-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=NO has_default=1 charset=latin1 collation=latin1_swedish_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0032_ip' AND column_name='target';

-- Test Case: TC-06-REG-0033-IP
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-05
-- Transition ID: CHAR-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=2 alter_sha=57703f3951a3 column_type=char(2) neg_probe=2572c2a661e3=167|1264|1265|1406 neg_probe=83cf80fd37ef=167|1264|1265|1406 neg_probe=903aa969a980=167|1264|1265|1406 neg_probe=d1028e618afa=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0033_ip, t2_tc_06_reg_0033_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0033_ip (
  target CHAR(1) CHARACTER SET latin1,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('a');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0033_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('zz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('z');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('ww');
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('x');
-- Oracle table: CHAR(2)
CREATE TABLE t2_tc_06_reg_0033_ip (
  target CHAR(2) CHARACTER SET latin1,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=latin1;
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('x');
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('zz');
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('z');
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('ww');
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('x');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0033_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0033_ip);
-- probe 1/2 -> t1_tc_06_reg_0033_ip
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('qqq');
-- probe 1/2 -> t2_tc_06_reg_0033_ip
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('qqq');
-- probe 2/2 -> t1_tc_06_reg_0033_ip
INSERT INTO t1_tc_06_reg_0033_ip (target) VALUES ('test');
-- probe 2/2 -> t2_tc_06_reg_0033_ip
INSERT INTO t2_tc_06_reg_0033_ip (target) VALUES ('test');
SELECT 'TC-06-REG-0033-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0033_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0033_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0033_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0033_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0033-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0033_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0033_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0033_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0033_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0033_ip a JOIN t2_tc_06_reg_0033_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0033-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=NO has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0033_ip' AND column_name='target';

-- Test Case: TC-06-ATR-0001-IP
-- Column attribute preservation: COMMENT
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace
-- Transition ID: CHAR-01
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=a3a105a8857f column_type=char(2)
DROP TABLE IF EXISTS t1_tc_06_atr_0001_ip, t2_tc_06_atr_0001_ip;
CREATE TABLE t1_tc_06_atr_0001_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(1) CHARACTER SET latin1 COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_atr_0001_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0001_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_atr_0001_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_atr_0001_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0001_ip (target) VALUES ('a');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_atr_0001_ip MODIFY target CHAR(2) CHARACTER SET latin1 COMMENT 'test_comment', ALGORITHM=inplace;
INSERT INTO t1_tc_06_atr_0001_ip (target) VALUES ('zz');
INSERT INTO t1_tc_06_atr_0001_ip (target) VALUES ('z');
INSERT INTO t1_tc_06_atr_0001_ip (target) VALUES ('ww');
SELECT 'TC-06-ATR-0001-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0001_ip' AND column_name='target' AND column_comment='test_comment';
SELECT 'TC-06-ATR-0001-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0001_ip' AND column_name='target';

-- Test Case: TC-06-ATR-0002-IP
-- Column attribute preservation: CHARSET
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace
-- Transition ID: CHAR-01
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=ac1a663c2f64 column_type=char(2)
DROP TABLE IF EXISTS t1_tc_06_atr_0002_ip, t2_tc_06_atr_0002_ip;
CREATE TABLE t1_tc_06_atr_0002_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_atr_0002_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0002_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_atr_0002_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_atr_0002_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0002_ip (target) VALUES ('a');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_atr_0002_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=inplace;
INSERT INTO t1_tc_06_atr_0002_ip (target) VALUES ('zz');
INSERT INTO t1_tc_06_atr_0002_ip (target) VALUES ('z');
INSERT INTO t1_tc_06_atr_0002_ip (target) VALUES ('ww');
SELECT 'TC-06-ATR-0002-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0002_ip' AND column_name='target' AND character_set_name='latin1';
SELECT 'TC-06-ATR-0002-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_swedish_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_swedish_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0002_ip' AND column_name='target';

-- Test Case: TC-06-ATR-0003-IP
-- Column attribute preservation: COLLATE
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace
-- Transition ID: CHAR-01
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=7aba48293bc0 column_type=char(2)
DROP TABLE IF EXISTS t1_tc_06_atr_0003_ip, t2_tc_06_atr_0003_ip;
CREATE TABLE t1_tc_06_atr_0003_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(1) CHARACTER SET latin1 COLLATE latin1_bin,
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
INSERT INTO t1_tc_06_atr_0003_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0003_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_atr_0003_ip (target) VALUES ('x');
INSERT INTO t1_tc_06_atr_0003_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0003_ip (target) VALUES ('a');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_atr_0003_ip MODIFY target CHAR(2) CHARACTER SET latin1 COLLATE latin1_bin, ALGORITHM=inplace;
INSERT INTO t1_tc_06_atr_0003_ip (target) VALUES ('zz');
INSERT INTO t1_tc_06_atr_0003_ip (target) VALUES ('z');
INSERT INTO t1_tc_06_atr_0003_ip (target) VALUES ('ww');
SELECT 'TC-06-ATR-0003-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0003_ip' AND column_name='target' AND collation_name='latin1_bin';
SELECT 'TC-06-ATR-0003-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'latin1')
          AND (MAX(collation_name) <=> 'latin1_bin')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(2) nullable=YES has_default=0 charset=latin1 collation=latin1_bin extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0003_ip' AND column_name='target';

-- Test Case: TC-06-REG-0034-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=5aab77510183 column_type=char(64) neg_probe=da9d2276a2c3=167|1264|1265|1406 neg_probe=8fea89e50f20=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0034_ip, t2_tc_06_reg_0034_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0034_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0034_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0034_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0034_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0034_ip);
-- probe 1/1 -> t1_tc_06_reg_0034_ip
INSERT INTO t1_tc_06_reg_0034_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0034_ip
INSERT INTO t2_tc_06_reg_0034_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0034-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0034_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0034_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0034_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0034_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0034-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0034_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0034_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0034_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0034_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0034_ip a JOIN t2_tc_06_reg_0034_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0034-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0034_ip' AND column_name='target';

-- Test Case: TC-06-REG-0035-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=11aa0644fe41 column_type=char(64) neg_probe=b1bc5966184d=167|1264|1265|1406 neg_probe=a29c3734dcce=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0035_ip, t2_tc_06_reg_0035_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0035_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0035_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0035_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0035_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0035_ip);
-- probe 1/1 -> t1_tc_06_reg_0035_ip
INSERT INTO t1_tc_06_reg_0035_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0035_ip
INSERT INTO t2_tc_06_reg_0035_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0035-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0035_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0035_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0035_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0035_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0035-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0035_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0035_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0035_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0035_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0035_ip a JOIN t2_tc_06_reg_0035_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0035-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0035_ip' AND column_name='target';

-- Test Case: TC-06-REG-0036-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=a752bed40241 column_type=char(64) neg_probe=f0746f113387=167|1264|1265|1406 neg_probe=a28605faf7f8=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0036_ip, t2_tc_06_reg_0036_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0036_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0036_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0036_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0036_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0036_ip);
-- probe 1/1 -> t1_tc_06_reg_0036_ip
INSERT INTO t1_tc_06_reg_0036_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0036_ip
INSERT INTO t2_tc_06_reg_0036_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0036-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0036_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0036_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0036_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0036_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0036-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0036_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0036_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0036_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0036_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0036_ip a JOIN t2_tc_06_reg_0036_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0036-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0036_ip' AND column_name='target';

-- Test Case: TC-06-REG-0037-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=fd218f56e1ec column_type=char(64) neg_probe=8390bd15421d=167|1264|1265|1406 neg_probe=43a7f6a7995d=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0037_ip, t2_tc_06_reg_0037_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0037_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0037_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0037_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0037_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0037_ip);
-- probe 1/1 -> t1_tc_06_reg_0037_ip
INSERT INTO t1_tc_06_reg_0037_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0037_ip
INSERT INTO t2_tc_06_reg_0037_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0037-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0037_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0037_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0037_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0037_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0037-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0037_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0037_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0037_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0037_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0037_ip a JOIN t2_tc_06_reg_0037_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0037-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=NO has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0037_ip' AND column_name='target';

-- Test Case: TC-06-REG-0038-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=bbdd795e5c1b column_type=char(64) neg_probe=6328c915f599=167|1264|1265|1406 neg_probe=778972bf2b4a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0038_ip, t2_tc_06_reg_0038_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0038_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0038_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0038_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0038_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0038_ip);
-- probe 1/1 -> t1_tc_06_reg_0038_ip
INSERT INTO t1_tc_06_reg_0038_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0038_ip
INSERT INTO t2_tc_06_reg_0038_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0038-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0038_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0038_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0038_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0038_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0038-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0038_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0038_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0038_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0038_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0038_ip a JOIN t2_tc_06_reg_0038_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0038-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0038_ip' AND column_name='target';

-- Test Case: TC-06-REG-0039-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=b38746b5babd column_type=char(64) neg_probe=97b2774af936=167|1264|1265|1406 neg_probe=00e02fbeb13e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0039_ip, t2_tc_06_reg_0039_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0039_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0039_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0039_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0039_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0039_ip);
-- probe 1/1 -> t1_tc_06_reg_0039_ip
INSERT INTO t1_tc_06_reg_0039_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0039_ip
INSERT INTO t2_tc_06_reg_0039_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0039-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0039_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0039_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0039_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0039_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0039-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0039_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0039_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0039_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0039_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0039_ip a JOIN t2_tc_06_reg_0039_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0039-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0039_ip' AND column_name='target';

-- Test Case: TC-06-REG-0040-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=3f2c5bcb924d column_type=char(64) neg_probe=1be00b1eb1c9=167|1264|1265|1406 neg_probe=43d583efe350=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0040_ip, t2_tc_06_reg_0040_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0040_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0040_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0040_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0040_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0040_ip);
-- probe 1/1 -> t1_tc_06_reg_0040_ip
INSERT INTO t1_tc_06_reg_0040_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0040_ip
INSERT INTO t2_tc_06_reg_0040_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0040-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0040_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0040_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0040_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0040_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0040-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0040_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0040_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0040_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0040_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0040_ip a JOIN t2_tc_06_reg_0040_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0040-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0040_ip' AND column_name='target';

-- Test Case: TC-06-REG-0041-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=6566f10a9f45 column_type=char(64) neg_probe=229be6e05df2=167|1264|1265|1406 neg_probe=1081544357e7=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0041_ip, t2_tc_06_reg_0041_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0041_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0041_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0041_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0041_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0041_ip);
-- probe 1/1 -> t1_tc_06_reg_0041_ip
INSERT INTO t1_tc_06_reg_0041_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0041_ip
INSERT INTO t2_tc_06_reg_0041_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0041-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0041_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0041_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0041_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0041_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0041-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0041_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0041_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0041_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0041_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0041_ip a JOIN t2_tc_06_reg_0041_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0041-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0041_ip' AND column_name='target';

-- Test Case: TC-06-REG-0042-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=bcfcd3e94dcf column_type=char(64) neg_probe=8b94df8113a6=167|1264|1265|1406 neg_probe=51a366e3cb37=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0042_ip, t2_tc_06_reg_0042_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0042_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0042_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0042_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0042_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0042_ip);
-- probe 1/1 -> t1_tc_06_reg_0042_ip
INSERT INTO t1_tc_06_reg_0042_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0042_ip
INSERT INTO t2_tc_06_reg_0042_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0042-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0042_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0042_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0042_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0042_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0042-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0042_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0042_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0042_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0042_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0042_ip a JOIN t2_tc_06_reg_0042_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0042-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0042_ip' AND column_name='target';

-- Test Case: TC-06-REG-0043-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=941979453773 column_type=char(64) neg_probe=5d7c7279d2e4=167|1264|1265|1406 neg_probe=c7fca6232f4a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0043_ip, t2_tc_06_reg_0043_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0043_ip (
  target CHAR(63) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0043_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0043_ip (
  target CHAR(64) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0043_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0043_ip);
-- probe 1/1 -> t1_tc_06_reg_0043_ip
INSERT INTO t1_tc_06_reg_0043_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0043_ip
INSERT INTO t2_tc_06_reg_0043_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0043-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0043_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0043_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0043_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0043_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0043-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0043_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0043_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0043_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0043_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0043_ip a JOIN t2_tc_06_reg_0043_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0043-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0043_ip' AND column_name='target';

-- Test Case: TC-06-REG-0044-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=eb910833e616 column_type=char(64) neg_probe=6c5f0ce644b8=167|1264|1265|1406 neg_probe=bcce9a535ee7=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0044_ip, t2_tc_06_reg_0044_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0044_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target CHAR(63) CHARACTER SET utf8mb4, PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0044_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0044_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target CHAR(64) CHARACTER SET utf8mb4, PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0044_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0044_ip);
-- probe 1/1 -> t1_tc_06_reg_0044_ip
INSERT INTO t1_tc_06_reg_0044_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0044_ip
INSERT INTO t2_tc_06_reg_0044_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0044-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0044_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0044_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0044_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0044_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0044-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0044_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0044_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0044_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0044_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0044_ip a JOIN t2_tc_06_reg_0044_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0044-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=4,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=4]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0044_ip' AND column_name='target';

-- Test Case: TC-06-REG-0045-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=9a671ca4189c column_type=char(64) neg_probe=ce4ce485d2a7=167|1264|1265|1406 neg_probe=84f0273de64d=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0045_ip, t2_tc_06_reg_0045_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0045_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0045_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4 NOT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0045_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0045_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0045_ip);
-- probe 1/1 -> t1_tc_06_reg_0045_ip
INSERT INTO t1_tc_06_reg_0045_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0045_ip
INSERT INTO t2_tc_06_reg_0045_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0045-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0045_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0045_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0045_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0045_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0045-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0045_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0045_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0045_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0045_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0045_ip a JOIN t2_tc_06_reg_0045_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0045-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=NO has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0045_ip' AND column_name='target';

-- Test Case: TC-06-REG-0046-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=79dfeee960f9 column_type=char(64) neg_probe=84ecff0b69c2=167|1264|1265|1406 neg_probe=7f3e07169419=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0046_ip, t2_tc_06_reg_0046_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0046_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0046_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4 DEFAULT '', ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0046_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0046_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0046_ip);
-- probe 1/1 -> t1_tc_06_reg_0046_ip
INSERT INTO t1_tc_06_reg_0046_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0046_ip
INSERT INTO t2_tc_06_reg_0046_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0046-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0046_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0046_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0046_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0046_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0046-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0046_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0046_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0046_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0046_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0046_ip a JOIN t2_tc_06_reg_0046_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0046-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=1 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0046_ip' AND column_name='target';

-- Test Case: TC-06-REG-0047-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=adb472e74fb7 column_type=char(64) neg_probe=140912d6c070=167|1264|1265|1406 neg_probe=df0d1b4b6310=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0047_ip, t2_tc_06_reg_0047_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0047_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0047_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4 DEFAULT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0047_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0047_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0047_ip);
-- probe 1/1 -> t1_tc_06_reg_0047_ip
INSERT INTO t1_tc_06_reg_0047_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0047_ip
INSERT INTO t2_tc_06_reg_0047_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0047-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0047_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0047_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0047_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0047_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0047-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0047_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0047_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0047_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0047_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0047_ip a JOIN t2_tc_06_reg_0047_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0047-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0047_ip' AND column_name='target';

-- Test Case: TC-06-REG-0048-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=47bafaee0072 column_type=char(64) neg_probe=3b5f46067650=167|1264|1265|1406 neg_probe=53e05eb96980=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0048_ip, t2_tc_06_reg_0048_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0048_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0048_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4 NOT NULL DEFAULT '', ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0048_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0048_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0048_ip);
-- probe 1/1 -> t1_tc_06_reg_0048_ip
INSERT INTO t1_tc_06_reg_0048_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0048_ip
INSERT INTO t2_tc_06_reg_0048_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0048-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0048_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0048_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0048_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0048_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0048-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0048_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0048_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0048_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0048_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0048_ip a JOIN t2_tc_06_reg_0048_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0048-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=NO has_default=1 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0048_ip' AND column_name='target';

-- Test Case: TC-06-REG-0049-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=4668551ff87e column_type=char(64) neg_probe=ea98da917c4f=167|1264|1265|1406 neg_probe=ec5b0574ed59=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0049_ip, t2_tc_06_reg_0049_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0049_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0049_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4 INVISIBLE, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0049_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0049_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0049_ip);
-- probe 1/1 -> t1_tc_06_reg_0049_ip
INSERT INTO t1_tc_06_reg_0049_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0049_ip
INSERT INTO t2_tc_06_reg_0049_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0049-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0049_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0049_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0049_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0049_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0049-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0049_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0049_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0049_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0049_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0049_ip a JOIN t2_tc_06_reg_0049_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0049-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> 'INVISIBLE')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra=INVISIBLE pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0049_ip' AND column_name='target';

-- Test Case: TC-06-REG-0050-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=9ef99a5671b3 column_type=char(64) neg_probe=f18248712d0f=167|1264|1265|1406 neg_probe=5b0e184f27fe=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0050_ip, t2_tc_06_reg_0050_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0050_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0050_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0050_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0050_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0050_ip);
-- probe 1/1 -> t1_tc_06_reg_0050_ip
INSERT INTO t1_tc_06_reg_0050_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0050_ip
INSERT INTO t2_tc_06_reg_0050_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0050-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0050_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0050_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0050_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0050_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0050-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0050_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0050_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0050_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0050_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0050_ip a JOIN t2_tc_06_reg_0050_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0050-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0050_ip' AND column_name='target';

-- Test Case: TC-06-REG-0051-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=7d29f7d0b22c column_type=char(64) neg_probe=2b4ef91d4fba=167|1264|1265|1406 neg_probe=0639e3633834=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0051_ip, t2_tc_06_reg_0051_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0051_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0051_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0051_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0051_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0051_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0051_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0051_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0051_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0051_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0051_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0051_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0051_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0051_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0051_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0051_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0051_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0051_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0051_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0051_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0051_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0051_ip);
-- probe 1/1 -> t1_tc_06_reg_0051_ip
INSERT INTO t1_tc_06_reg_0051_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0051_ip
INSERT INTO t2_tc_06_reg_0051_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0051-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0051_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0051_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0051_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0051_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0051-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0051_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0051_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0051_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0051_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0051_ip a JOIN t2_tc_06_reg_0051_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0051-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0051_ip' AND column_name='target';

-- Test Case: TC-06-REG-0052-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: CHAR-02
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=8f432b44ac3a column_type=char(64) neg_probe=11641dff1798=167|1264|1265|1406 neg_probe=99e3f9ae4a38=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0052_ip, t2_tc_06_reg_0052_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0052_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0052_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0052_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0052_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0052_ip);
-- probe 1/1 -> t1_tc_06_reg_0052_ip
INSERT INTO t1_tc_06_reg_0052_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0052_ip
INSERT INTO t2_tc_06_reg_0052_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0052-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0052_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0052_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0052_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0052_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0052-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0052_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0052_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0052_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0052_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0052_ip a JOIN t2_tc_06_reg_0052_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0052-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0052_ip' AND column_name='target';

-- Test Case: TC-06-REG-0053-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: CHAR-02
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=ee5e4bb37868 column_type=char(64) neg_probe=d2d528c654e0=167|1264|1265|1406 neg_probe=1893c3118d7b=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0053_ip, t2_tc_06_reg_0053_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0053_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0053_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0053_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0053_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0053_ip);
-- probe 1/1 -> t1_tc_06_reg_0053_ip
INSERT INTO t1_tc_06_reg_0053_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0053_ip
INSERT INTO t2_tc_06_reg_0053_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0053-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0053_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0053_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0053_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0053_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0053-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0053_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0053_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0053_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0053_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0053_ip a JOIN t2_tc_06_reg_0053_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0053-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0053_ip' AND column_name='target';

-- Test Case: TC-06-REG-0054-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=0024b6309044 column_type=char(64) neg_probe=249d1ff1a9be=167|1264|1265|1406 neg_probe=fbbcb9e2dd32=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0054_ip, t2_tc_06_reg_0054_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0054_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0054_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0054_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0054_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0054_ip);
-- probe 1/1 -> t1_tc_06_reg_0054_ip
INSERT INTO t1_tc_06_reg_0054_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0054_ip
INSERT INTO t2_tc_06_reg_0054_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0054-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0054_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0054_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0054_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0054_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0054-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0054_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0054_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0054_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0054_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0054_ip a JOIN t2_tc_06_reg_0054_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0054-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0054_ip' AND column_name='target';

-- Test Case: TC-06-REG-0055-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=41f391b418d3 column_type=char(64) neg_probe=a7d2d14c8b3f=167|1264|1265|1406 neg_probe=5b9ad63cc381=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0055_ip, t2_tc_06_reg_0055_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0055_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0055_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0055_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0055_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0055_ip);
-- probe 1/1 -> t1_tc_06_reg_0055_ip
INSERT INTO t1_tc_06_reg_0055_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0055_ip
INSERT INTO t2_tc_06_reg_0055_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0055-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0055_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0055_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0055_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0055_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0055-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0055_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0055_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0055_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0055_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0055_ip a JOIN t2_tc_06_reg_0055_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0055-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0055_ip' AND column_name='target';

-- Test Case: TC-06-REG-0056-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=860ff7a1000d column_type=char(64) neg_probe=c093bd8544e0=167|1264|1265|1406 neg_probe=fa3b2a38d85a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0056_ip, t2_tc_06_reg_0056_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0056_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0056_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0056_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0056_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0056_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0056_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0056_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0056_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0056_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0056_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0056_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0056_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0056_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0056_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0056_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0056_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0056_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0056_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0056_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0056_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0056_ip);
-- probe 1/1 -> t1_tc_06_reg_0056_ip
INSERT INTO t1_tc_06_reg_0056_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0056_ip
INSERT INTO t2_tc_06_reg_0056_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0056-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0056_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0056_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0056_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0056_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0056-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0056_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0056_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0056_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0056_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0056_ip a JOIN t2_tc_06_reg_0056_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0056-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0056_ip' AND column_name='target';

-- Test Case: TC-06-REG-0057-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=SECONDARY_INDEX
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=SECONDARY_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=3c3334cd8079 column_type=char(64) neg_probe=3e23288bb2b4=167|1264|1265|1406 neg_probe=3c4eeb8be711=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0057_ip, t2_tc_06_reg_0057_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0057_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0057_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0057_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0057_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0057_ip);
-- probe 1/1 -> t1_tc_06_reg_0057_ip
INSERT INTO t1_tc_06_reg_0057_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0057_ip
INSERT INTO t2_tc_06_reg_0057_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0057-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0057_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0057_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0057_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0057_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0057-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0057_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0057_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0057_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0057_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0057_ip a JOIN t2_tc_06_reg_0057_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0057-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0057_ip' AND column_name='target';

-- Test Case: TC-06-REG-0058-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=UNIQUE_INDEX
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=90c6b863b2bb column_type=char(64) neg_probe=5b575146d461=167|1264|1265|1406 neg_probe=e325305e0e1c=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0058_ip, t2_tc_06_reg_0058_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0058_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0058_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0058_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0058_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0058_ip);
-- probe 1/1 -> t1_tc_06_reg_0058_ip
INSERT INTO t1_tc_06_reg_0058_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0058_ip
INSERT INTO t2_tc_06_reg_0058_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0058-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0058_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0058_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0058_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0058_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0058-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0058_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0058_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0058_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0058_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0058_ip a JOIN t2_tc_06_reg_0058_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0058-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0058_ip' AND column_name='target';

-- Test Case: TC-06-REG-0059-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=FOREIGN_KEY
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=FOREIGN_KEY, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=e0007db34538 column_type=char(64) neg_probe=3184b283214d=167|1264|1265|1406 neg_probe=f876adca8bce=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0059_ip, t2_tc_06_reg_0059_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0059_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0059_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0059_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0059_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0059_ip);
-- probe 1/1 -> t1_tc_06_reg_0059_ip
INSERT INTO t1_tc_06_reg_0059_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0059_ip
INSERT INTO t2_tc_06_reg_0059_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0059-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0059_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0059_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0059_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0059_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0059-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0059_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0059_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0059_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0059_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0059_ip a JOIN t2_tc_06_reg_0059_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0059-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0059_ip' AND column_name='target';

-- Test Case: TC-06-REG-0060-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=CHECK
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=CHECK, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=5fed0d0e3e9a column_type=char(64) neg_probe=0d43ca8eb6e8=167|1264|1265|1406 neg_probe=bba544189367=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0060_ip, t2_tc_06_reg_0060_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0060_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0060_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0060_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0060_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0060_ip);
-- probe 1/1 -> t1_tc_06_reg_0060_ip
INSERT INTO t1_tc_06_reg_0060_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0060_ip
INSERT INTO t2_tc_06_reg_0060_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0060-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0060_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0060_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0060_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0060_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0060-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0060_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0060_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0060_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0060_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0060_ip a JOIN t2_tc_06_reg_0060_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0060-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0060_ip' AND column_name='target';

-- Test Case: TC-06-REG-0061-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=72b77abb6026 column_type=char(64) neg_probe=4b4308ba05ae=ACCEPTED neg_probe=3752779ee67d=ACCEPTED
DROP TABLE IF EXISTS t1_tc_06_reg_0061_ip, t2_tc_06_reg_0061_ip;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_06_reg_0061_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0061_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0061_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0061_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0061_ip);
-- probe 1/1 -> t1_tc_06_reg_0061_ip
INSERT INTO t1_tc_06_reg_0061_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0061_ip
INSERT INTO t2_tc_06_reg_0061_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0061-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0061_ip) - @neg_before_t1 = (SELECT COUNT(*) FROM t2_tc_06_reg_0061_ip) - @neg_before_t2,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0061_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0061_ip) - @neg_before_t2,' expect=t1_added = t2_added (非 STRICT: 截断行为必须与对照表一致) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0061-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0061_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0061_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0061_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0061_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0061_ip a JOIN t2_tc_06_reg_0061_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0061-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0061_ip' AND column_name='target';

-- Test Case: TC-06-REG-0062-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=8aed88bd9d12 column_type=char(64) neg_probe=de12e64f0626=167|1264|1265|1406 neg_probe=84370bf81a79=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0062_ip, t2_tc_06_reg_0062_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0062_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0062_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4 NOT NULL, ALGORITHM=inplace;
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0062_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0062_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0062_ip);
-- probe 1/1 -> t1_tc_06_reg_0062_ip
INSERT INTO t1_tc_06_reg_0062_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0062_ip
INSERT INTO t2_tc_06_reg_0062_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0062-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0062_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0062_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0062_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0062_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0062-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0062_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0062_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0062_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0062_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0062_ip a JOIN t2_tc_06_reg_0062_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0062-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=NO has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0062_ip' AND column_name='target';

-- Test Case: TC-06-REG-0063-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-02
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=9d9a35c66c91 column_type=char(64) neg_probe=29a3c877551f=167|1264|1265|1406 neg_probe=a537a36bd075=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0063_ip, t2_tc_06_reg_0063_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0063_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0063_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0063_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0063_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0063_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0063_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0063_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0063_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0063_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0063_ip (target) VALUES (NULL);
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0063_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0063_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0063_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0063_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0063_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0063_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0063_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0063_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0063_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0063_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0063_ip);
-- probe 1/1 -> t1_tc_06_reg_0063_ip
INSERT INTO t1_tc_06_reg_0063_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0063_ip
INSERT INTO t2_tc_06_reg_0063_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0063-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0063_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0063_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0063_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0063_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0063-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0063_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0063_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0063_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0063_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0063_ip a JOIN t2_tc_06_reg_0063_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0063-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0063_ip' AND column_name='target';

-- Test Case: TC-06-REG-0064-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: CHAR-02
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=dce17de62d9c column_type=char(64) neg_probe=aef3d555a493=167|1264|1265|1406 neg_probe=286936ea3ea0=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0064_ip, t2_tc_06_reg_0064_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0064_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0064_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0064_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0064_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0064_ip);
-- probe 1/1 -> t1_tc_06_reg_0064_ip
INSERT INTO t1_tc_06_reg_0064_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0064_ip
INSERT INTO t2_tc_06_reg_0064_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0064-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0064_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0064_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0064_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0064_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0064-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0064_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0064_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0064_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0064_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0064_ip a JOIN t2_tc_06_reg_0064_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0064-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0064_ip' AND column_name='target';

-- Test Case: TC-06-REG-0065-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=b039f15aaf2d column_type=char(64) neg_probe=c9df0d7e0174=167|1264|1265|1406 neg_probe=91e987368a97=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0065_ip, t2_tc_06_reg_0065_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0065_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(63) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0065_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4 NOT NULL DEFAULT '', ALGORITHM=inplace;
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0065_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(64) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0065_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0065_ip);
-- probe 1/1 -> t1_tc_06_reg_0065_ip
INSERT INTO t1_tc_06_reg_0065_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0065_ip
INSERT INTO t2_tc_06_reg_0065_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0065-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0065_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0065_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0065_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0065_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0065-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0065_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0065_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0065_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0065_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0065_ip a JOIN t2_tc_06_reg_0065_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0065-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=NO has_default=1 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0065_ip' AND column_name='target';

-- Test Case: TC-06-REG-0066-IP
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-05
-- Transition ID: CHAR-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=af7641956cac column_type=char(64) neg_probe=d1deb25ce589=167|1264|1265|1406 neg_probe=b9c7c01bfc0e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0066_ip, t2_tc_06_reg_0066_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0066_ip (
  target CHAR(63) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0066_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Oracle table: CHAR(64)
CREATE TABLE t2_tc_06_reg_0066_ip (
  target CHAR(64) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0066_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0066_ip);
-- probe 1/1 -> t1_tc_06_reg_0066_ip
INSERT INTO t1_tc_06_reg_0066_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0066_ip
INSERT INTO t2_tc_06_reg_0066_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0066-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0066_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0066_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0066_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0066_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0066-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0066_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0066_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0066_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0066_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0066_ip a JOIN t2_tc_06_reg_0066_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0066-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=NO has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0066_ip' AND column_name='target';

-- Test Case: TC-06-ATR-0004-IP
-- Column attribute preservation: COMMENT
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace
-- Transition ID: CHAR-02
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=edd28303660e column_type=char(64)
DROP TABLE IF EXISTS t1_tc_06_atr_0004_ip, t2_tc_06_atr_0004_ip;
CREATE TABLE t1_tc_06_atr_0004_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(63) CHARACTER SET utf8mb4 COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_atr_0004_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0004_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_atr_0004_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0004_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0004_ip (target) VALUES ('Hello');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_atr_0004_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4 COMMENT 'test_comment', ALGORITHM=inplace;
INSERT INTO t1_tc_06_atr_0004_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0004_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0004_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
SELECT 'TC-06-ATR-0004-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0004_ip' AND column_name='target' AND column_comment='test_comment';
SELECT 'TC-06-ATR-0004-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0004_ip' AND column_name='target';

-- Test Case: TC-06-ATR-0005-IP
-- Column attribute preservation: CHARSET
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace
-- Transition ID: CHAR-02
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=cd2ddbcc79f0 column_type=char(64)
DROP TABLE IF EXISTS t1_tc_06_atr_0005_ip, t2_tc_06_atr_0005_ip;
CREATE TABLE t1_tc_06_atr_0005_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(63) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_atr_0005_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0005_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_atr_0005_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0005_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0005_ip (target) VALUES ('Hello');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_atr_0005_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4, ALGORITHM=inplace;
INSERT INTO t1_tc_06_atr_0005_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0005_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0005_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
SELECT 'TC-06-ATR-0005-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0005_ip' AND column_name='target' AND character_set_name='utf8mb4';
SELECT 'TC-06-ATR-0005-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0005_ip' AND column_name='target';

-- Test Case: TC-06-ATR-0006-IP
-- Column attribute preservation: COLLATE
-- Type: CHAR(63) -> CHAR(64), Algorithm: inplace
-- Transition ID: CHAR-02
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=c5c0fa531f17 column_type=char(64)
DROP TABLE IF EXISTS t1_tc_06_atr_0006_ip, t2_tc_06_atr_0006_ip;
CREATE TABLE t1_tc_06_atr_0006_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(63) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_atr_0006_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0006_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_atr_0006_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0006_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0006_ip (target) VALUES ('Hello');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_atr_0006_ip MODIFY target CHAR(64) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, ALGORITHM=inplace;
INSERT INTO t1_tc_06_atr_0006_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0006_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0006_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
SELECT 'TC-06-ATR-0006-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0006_ip' AND column_name='target' AND collation_name='utf8mb4_bin';
SELECT 'TC-06-ATR-0006-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_bin')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(64) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_bin extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0006_ip' AND column_name='target';

-- Test Case: TC-06-REG-0067-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=4b40911ce348 column_type=char(255) neg_probe=493be89e63d1=167|1264|1265|1406 neg_probe=37b60bfa3b52=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0067_ip, t2_tc_06_reg_0067_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0067_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0067_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0067_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0067_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0067_ip);
-- probe 1/1 -> t1_tc_06_reg_0067_ip
INSERT INTO t1_tc_06_reg_0067_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0067_ip
INSERT INTO t2_tc_06_reg_0067_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0067-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0067_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0067_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0067_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0067_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0067-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0067_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0067_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0067_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0067_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0067_ip a JOIN t2_tc_06_reg_0067_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0067-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0067_ip' AND column_name='target';

-- Test Case: TC-06-REG-0068-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=522a883e31f5 column_type=char(255) neg_probe=ef1c5048e5de=167|1264|1265|1406 neg_probe=0b7ff8f2b27b=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0068_ip, t2_tc_06_reg_0068_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0068_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0068_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0068_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0068_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0068_ip);
-- probe 1/1 -> t1_tc_06_reg_0068_ip
INSERT INTO t1_tc_06_reg_0068_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0068_ip
INSERT INTO t2_tc_06_reg_0068_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0068-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0068_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0068_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0068_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0068_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0068-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0068_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0068_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0068_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0068_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0068_ip a JOIN t2_tc_06_reg_0068_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0068-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0068_ip' AND column_name='target';

-- Test Case: TC-06-REG-0069-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=090cfea6b192 column_type=char(255) neg_probe=20f1edff3ff0=167|1264|1265|1406 neg_probe=b70abbb32e55=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0069_ip, t2_tc_06_reg_0069_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0069_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0069_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0069_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0069_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0069_ip);
-- probe 1/1 -> t1_tc_06_reg_0069_ip
INSERT INTO t1_tc_06_reg_0069_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0069_ip
INSERT INTO t2_tc_06_reg_0069_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0069-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0069_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0069_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0069_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0069_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0069-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0069_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0069_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0069_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0069_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0069_ip a JOIN t2_tc_06_reg_0069_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0069-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0069_ip' AND column_name='target';

-- Test Case: TC-06-REG-0070-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=a3a92aa4b526 column_type=char(255) neg_probe=87c04e82c675=167|1264|1265|1406 neg_probe=25c2ac98987c=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0070_ip, t2_tc_06_reg_0070_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0070_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0070_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0070_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0070_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0070_ip);
-- probe 1/1 -> t1_tc_06_reg_0070_ip
INSERT INTO t1_tc_06_reg_0070_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0070_ip
INSERT INTO t2_tc_06_reg_0070_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0070-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0070_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0070_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0070_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0070_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0070-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0070_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0070_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0070_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0070_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0070_ip a JOIN t2_tc_06_reg_0070_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0070-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=NO has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0070_ip' AND column_name='target';

-- Test Case: TC-06-REG-0071-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=ea393221ccdf column_type=char(255) neg_probe=d46fe7e669dc=167|1264|1265|1406 neg_probe=0b3478785c6a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0071_ip, t2_tc_06_reg_0071_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0071_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0071_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0071_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0071_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0071_ip);
-- probe 1/1 -> t1_tc_06_reg_0071_ip
INSERT INTO t1_tc_06_reg_0071_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0071_ip
INSERT INTO t2_tc_06_reg_0071_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0071-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0071_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0071_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0071_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0071_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0071-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0071_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0071_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0071_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0071_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0071_ip a JOIN t2_tc_06_reg_0071_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0071-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0071_ip' AND column_name='target';

-- Test Case: TC-06-REG-0072-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=e2562adf03e9 column_type=char(255) neg_probe=72bf1de091f9=167|1264|1265|1406 neg_probe=ad010901382b=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0072_ip, t2_tc_06_reg_0072_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0072_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0072_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0072_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0072_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0072_ip);
-- probe 1/1 -> t1_tc_06_reg_0072_ip
INSERT INTO t1_tc_06_reg_0072_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0072_ip
INSERT INTO t2_tc_06_reg_0072_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0072-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0072_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0072_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0072_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0072_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0072-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0072_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0072_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0072_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0072_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0072_ip a JOIN t2_tc_06_reg_0072_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0072-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0072_ip' AND column_name='target';

-- Test Case: TC-06-REG-0073-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=0a3843d3b2c0 column_type=char(255) neg_probe=08ede480108c=167|1264|1265|1406 neg_probe=5726781e836f=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0073_ip, t2_tc_06_reg_0073_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0073_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0073_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0073_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0073_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0073_ip);
-- probe 1/1 -> t1_tc_06_reg_0073_ip
INSERT INTO t1_tc_06_reg_0073_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0073_ip
INSERT INTO t2_tc_06_reg_0073_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0073-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0073_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0073_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0073_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0073_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0073-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0073_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0073_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0073_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0073_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0073_ip a JOIN t2_tc_06_reg_0073_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0073-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0073_ip' AND column_name='target';

-- Test Case: TC-06-REG-0074-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=2199224f71ba column_type=char(255) neg_probe=3f3da151f072=167|1264|1265|1406 neg_probe=486c5b3b5eda=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0074_ip, t2_tc_06_reg_0074_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0074_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0074_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0074_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0074_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0074_ip);
-- probe 1/1 -> t1_tc_06_reg_0074_ip
INSERT INTO t1_tc_06_reg_0074_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0074_ip
INSERT INTO t2_tc_06_reg_0074_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0074-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0074_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0074_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0074_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0074_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0074-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0074_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0074_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0074_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0074_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0074_ip a JOIN t2_tc_06_reg_0074_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0074-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0074_ip' AND column_name='target';

-- Test Case: TC-06-REG-0075-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=36e971a3c947 column_type=char(255) neg_probe=ffeb55b5f960=167|1264|1265|1406 neg_probe=c3bded47e21d=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0075_ip, t2_tc_06_reg_0075_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0075_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0075_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0075_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0075_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0075_ip);
-- probe 1/1 -> t1_tc_06_reg_0075_ip
INSERT INTO t1_tc_06_reg_0075_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0075_ip
INSERT INTO t2_tc_06_reg_0075_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0075-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0075_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0075_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0075_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0075_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0075-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0075_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0075_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0075_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0075_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0075_ip a JOIN t2_tc_06_reg_0075_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0075-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0075_ip' AND column_name='target';

-- Test Case: TC-06-REG-0076-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=7e535a76607c column_type=char(255) neg_probe=5394317a9578=167|1264|1265|1406 neg_probe=c0af15721d27=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0076_ip, t2_tc_06_reg_0076_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0076_ip (
  target CHAR(254) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0076_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0076_ip (
  target CHAR(255) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0076_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0076_ip);
-- probe 1/1 -> t1_tc_06_reg_0076_ip
INSERT INTO t1_tc_06_reg_0076_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0076_ip
INSERT INTO t2_tc_06_reg_0076_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0076-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0076_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0076_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0076_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0076_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0076-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0076_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0076_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0076_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0076_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0076_ip a JOIN t2_tc_06_reg_0076_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0076-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0076_ip' AND column_name='target';

-- Test Case: TC-06-REG-0077-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=926446a02669 column_type=char(255) neg_probe=9ae10b57185b=167|1264|1265|1406 neg_probe=b0ad1447340d=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0077_ip, t2_tc_06_reg_0077_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0077_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target CHAR(254) CHARACTER SET utf8mb4, PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0077_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0077_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target CHAR(255) CHARACTER SET utf8mb4, PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0077_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0077_ip);
-- probe 1/1 -> t1_tc_06_reg_0077_ip
INSERT INTO t1_tc_06_reg_0077_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0077_ip
INSERT INTO t2_tc_06_reg_0077_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0077-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0077_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0077_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0077_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0077_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0077-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0077_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0077_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0077_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0077_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0077_ip a JOIN t2_tc_06_reg_0077_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0077-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=4,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=4]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0077_ip' AND column_name='target';

-- Test Case: TC-06-REG-0078-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=46a31f150b22 column_type=char(255) neg_probe=325add7c2e31=167|1264|1265|1406 neg_probe=f28269578715=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0078_ip, t2_tc_06_reg_0078_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0078_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0078_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4 NOT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0078_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0078_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0078_ip);
-- probe 1/1 -> t1_tc_06_reg_0078_ip
INSERT INTO t1_tc_06_reg_0078_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0078_ip
INSERT INTO t2_tc_06_reg_0078_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0078-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0078_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0078_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0078_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0078_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0078-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0078_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0078_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0078_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0078_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0078_ip a JOIN t2_tc_06_reg_0078_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0078-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=NO has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0078_ip' AND column_name='target';

-- Test Case: TC-06-REG-0079-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=f3675f835e48 column_type=char(255) neg_probe=95f907706357=167|1264|1265|1406 neg_probe=951affe21ad1=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0079_ip, t2_tc_06_reg_0079_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0079_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0079_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4 DEFAULT '', ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0079_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0079_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0079_ip);
-- probe 1/1 -> t1_tc_06_reg_0079_ip
INSERT INTO t1_tc_06_reg_0079_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0079_ip
INSERT INTO t2_tc_06_reg_0079_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0079-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0079_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0079_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0079_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0079_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0079-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0079_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0079_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0079_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0079_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0079_ip a JOIN t2_tc_06_reg_0079_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0079-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=1 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0079_ip' AND column_name='target';

-- Test Case: TC-06-REG-0080-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=2e7eac79f178 column_type=char(255) neg_probe=824a3d612289=167|1264|1265|1406 neg_probe=6e4ee8da5d03=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0080_ip, t2_tc_06_reg_0080_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0080_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0080_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4 DEFAULT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0080_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0080_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0080_ip);
-- probe 1/1 -> t1_tc_06_reg_0080_ip
INSERT INTO t1_tc_06_reg_0080_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0080_ip
INSERT INTO t2_tc_06_reg_0080_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0080-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0080_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0080_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0080_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0080_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0080-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0080_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0080_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0080_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0080_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0080_ip a JOIN t2_tc_06_reg_0080_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0080-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0080_ip' AND column_name='target';

-- Test Case: TC-06-REG-0081-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=059775cee5f8 column_type=char(255) neg_probe=978bcdf16b0d=167|1264|1265|1406 neg_probe=2f45d586651f=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0081_ip, t2_tc_06_reg_0081_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0081_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0081_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4 NOT NULL DEFAULT '', ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0081_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0081_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0081_ip);
-- probe 1/1 -> t1_tc_06_reg_0081_ip
INSERT INTO t1_tc_06_reg_0081_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0081_ip
INSERT INTO t2_tc_06_reg_0081_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0081-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0081_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0081_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0081_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0081_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0081-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0081_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0081_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0081_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0081_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0081_ip a JOIN t2_tc_06_reg_0081_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0081-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=NO has_default=1 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0081_ip' AND column_name='target';

-- Test Case: TC-06-REG-0082-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=d16859c7be3b column_type=char(255) neg_probe=df9bec0c522d=167|1264|1265|1406 neg_probe=082d41de8fa5=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0082_ip, t2_tc_06_reg_0082_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0082_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0082_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4 INVISIBLE, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0082_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0082_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0082_ip);
-- probe 1/1 -> t1_tc_06_reg_0082_ip
INSERT INTO t1_tc_06_reg_0082_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0082_ip
INSERT INTO t2_tc_06_reg_0082_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0082-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0082_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0082_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0082_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0082_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0082-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0082_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0082_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0082_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0082_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0082_ip a JOIN t2_tc_06_reg_0082_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0082-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> 'INVISIBLE')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra=INVISIBLE pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0082_ip' AND column_name='target';

-- Test Case: TC-06-REG-0083-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=a16d209b2860 column_type=char(255) neg_probe=90404423b415=167|1264|1265|1406 neg_probe=1a2419970ee4=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0083_ip, t2_tc_06_reg_0083_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0083_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0083_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0083_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0083_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0083_ip);
-- probe 1/1 -> t1_tc_06_reg_0083_ip
INSERT INTO t1_tc_06_reg_0083_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0083_ip
INSERT INTO t2_tc_06_reg_0083_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0083-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0083_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0083_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0083_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0083_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0083-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0083_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0083_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0083_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0083_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0083_ip a JOIN t2_tc_06_reg_0083_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0083-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0083_ip' AND column_name='target';

-- Test Case: TC-06-REG-0084-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=045b915aaac7 column_type=char(255) neg_probe=aaa7cf48537e=167|1264|1265|1406 neg_probe=d7343c052c4a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0084_ip, t2_tc_06_reg_0084_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0084_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0084_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0084_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0084_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0084_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0084_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0084_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0084_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0084_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0084_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0084_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0084_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0084_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0084_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0084_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0084_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0084_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0084_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0084_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0084_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0084_ip);
-- probe 1/1 -> t1_tc_06_reg_0084_ip
INSERT INTO t1_tc_06_reg_0084_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0084_ip
INSERT INTO t2_tc_06_reg_0084_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0084-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0084_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0084_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0084_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0084_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0084-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0084_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0084_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0084_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0084_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0084_ip a JOIN t2_tc_06_reg_0084_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0084-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0084_ip' AND column_name='target';

-- Test Case: TC-06-REG-0085-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: CHAR-03
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=b736cccfc433 column_type=char(255) neg_probe=a6a8c10cfb3b=167|1264|1265|1406 neg_probe=21a997061845=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0085_ip, t2_tc_06_reg_0085_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0085_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0085_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0085_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0085_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0085_ip);
-- probe 1/1 -> t1_tc_06_reg_0085_ip
INSERT INTO t1_tc_06_reg_0085_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0085_ip
INSERT INTO t2_tc_06_reg_0085_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0085-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0085_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0085_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0085_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0085_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0085-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0085_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0085_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0085_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0085_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0085_ip a JOIN t2_tc_06_reg_0085_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0085-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0085_ip' AND column_name='target';

-- Test Case: TC-06-REG-0086-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: CHAR-03
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=cc4f214b5708 column_type=char(255) neg_probe=4e7276c73483=167|1264|1265|1406 neg_probe=1d1fe8fc4cac=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0086_ip, t2_tc_06_reg_0086_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0086_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0086_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0086_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0086_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0086_ip);
-- probe 1/1 -> t1_tc_06_reg_0086_ip
INSERT INTO t1_tc_06_reg_0086_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0086_ip
INSERT INTO t2_tc_06_reg_0086_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0086-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0086_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0086_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0086_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0086_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0086-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0086_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0086_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0086_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0086_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0086_ip a JOIN t2_tc_06_reg_0086_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0086-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0086_ip' AND column_name='target';

-- Test Case: TC-06-REG-0087-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=2a1627a66a36 column_type=char(255) neg_probe=bccd175249d9=167|1264|1265|1406 neg_probe=244eecd374ea=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0087_ip, t2_tc_06_reg_0087_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0087_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0087_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0087_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0087_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0087_ip);
-- probe 1/1 -> t1_tc_06_reg_0087_ip
INSERT INTO t1_tc_06_reg_0087_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0087_ip
INSERT INTO t2_tc_06_reg_0087_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0087-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0087_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0087_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0087_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0087_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0087-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0087_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0087_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0087_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0087_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0087_ip a JOIN t2_tc_06_reg_0087_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0087-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0087_ip' AND column_name='target';

-- Test Case: TC-06-REG-0088-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=9e9e421d57e7 column_type=char(255) neg_probe=12e0a376aa55=167|1264|1265|1406 neg_probe=f21bae93e56e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0088_ip, t2_tc_06_reg_0088_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0088_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0088_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0088_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0088_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0088_ip);
-- probe 1/1 -> t1_tc_06_reg_0088_ip
INSERT INTO t1_tc_06_reg_0088_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0088_ip
INSERT INTO t2_tc_06_reg_0088_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0088-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0088_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0088_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0088_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0088_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0088-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0088_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0088_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0088_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0088_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0088_ip a JOIN t2_tc_06_reg_0088_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0088-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0088_ip' AND column_name='target';

-- Test Case: TC-06-REG-0089-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=f489f5650d4b column_type=char(255) neg_probe=d083fde796a0=167|1264|1265|1406 neg_probe=1d73db7b62f0=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0089_ip, t2_tc_06_reg_0089_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0089_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0089_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0089_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0089_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0089_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0089_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0089_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0089_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0089_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0089_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0089_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0089_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0089_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0089_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0089_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0089_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0089_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0089_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0089_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0089_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0089_ip);
-- probe 1/1 -> t1_tc_06_reg_0089_ip
INSERT INTO t1_tc_06_reg_0089_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0089_ip
INSERT INTO t2_tc_06_reg_0089_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0089-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0089_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0089_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0089_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0089_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0089-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0089_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0089_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0089_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0089_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0089_ip a JOIN t2_tc_06_reg_0089_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0089-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0089_ip' AND column_name='target';

-- Test Case: TC-06-REG-0090-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=SECONDARY_INDEX
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=SECONDARY_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=d37bb37fab21 column_type=char(255) neg_probe=a7a2aff7ee1b=167|1264|1265|1406 neg_probe=0f3ee9dc522a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0090_ip, t2_tc_06_reg_0090_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0090_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0090_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0090_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0090_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0090_ip);
-- probe 1/1 -> t1_tc_06_reg_0090_ip
INSERT INTO t1_tc_06_reg_0090_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0090_ip
INSERT INTO t2_tc_06_reg_0090_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0090-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0090_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0090_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0090_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0090_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0090-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0090_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0090_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0090_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0090_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0090_ip a JOIN t2_tc_06_reg_0090_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0090-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0090_ip' AND column_name='target';

-- Test Case: TC-06-REG-0091-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=UNIQUE_INDEX
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=30b570d8f8f0 column_type=char(255) neg_probe=88ef18f01a63=167|1264|1265|1406 neg_probe=c730bc1d0210=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0091_ip, t2_tc_06_reg_0091_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0091_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0091_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0091_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0091_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0091_ip);
-- probe 1/1 -> t1_tc_06_reg_0091_ip
INSERT INTO t1_tc_06_reg_0091_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0091_ip
INSERT INTO t2_tc_06_reg_0091_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0091-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0091_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0091_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0091_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0091_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0091-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0091_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0091_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0091_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0091_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0091_ip a JOIN t2_tc_06_reg_0091_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0091-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0091_ip' AND column_name='target';

-- Test Case: TC-06-REG-0092-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=FOREIGN_KEY
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=FOREIGN_KEY, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=6606f7b04f7b column_type=char(255) neg_probe=00dd91b153bf=167|1264|1265|1406 neg_probe=6300e6f4f47f=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0092_ip, t2_tc_06_reg_0092_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0092_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0092_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0092_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0092_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0092_ip);
-- probe 1/1 -> t1_tc_06_reg_0092_ip
INSERT INTO t1_tc_06_reg_0092_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0092_ip
INSERT INTO t2_tc_06_reg_0092_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0092-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0092_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0092_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0092_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0092_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0092-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0092_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0092_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0092_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0092_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0092_ip a JOIN t2_tc_06_reg_0092_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0092-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0092_ip' AND column_name='target';

-- Test Case: TC-06-REG-0093-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=CHECK
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=CHECK, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=d8c94fce88ae column_type=char(255) neg_probe=2b599fde1bb9=167|1264|1265|1406 neg_probe=f38429ab487a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0093_ip, t2_tc_06_reg_0093_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0093_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0093_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0093_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0093_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0093_ip);
-- probe 1/1 -> t1_tc_06_reg_0093_ip
INSERT INTO t1_tc_06_reg_0093_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0093_ip
INSERT INTO t2_tc_06_reg_0093_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0093-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0093_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0093_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0093_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0093_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0093-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0093_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0093_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0093_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0093_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0093_ip a JOIN t2_tc_06_reg_0093_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0093-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0093_ip' AND column_name='target';

-- Test Case: TC-06-REG-0094-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=daec29b50889 column_type=char(255) neg_probe=caa794c6eaf7=ACCEPTED neg_probe=24d481d2a100=ACCEPTED
DROP TABLE IF EXISTS t1_tc_06_reg_0094_ip, t2_tc_06_reg_0094_ip;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_06_reg_0094_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('🎉');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0094_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0094_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0094_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0094_ip);
-- probe 1/1 -> t1_tc_06_reg_0094_ip
INSERT INTO t1_tc_06_reg_0094_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0094_ip
INSERT INTO t2_tc_06_reg_0094_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0094-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0094_ip) - @neg_before_t1 = (SELECT COUNT(*) FROM t2_tc_06_reg_0094_ip) - @neg_before_t2,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0094_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0094_ip) - @neg_before_t2,' expect=t1_added = t2_added (非 STRICT: 截断行为必须与对照表一致) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0094-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0094_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0094_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0094_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0094_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0094_ip a JOIN t2_tc_06_reg_0094_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0094-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0094_ip' AND column_name='target';

-- Test Case: TC-06-REG-0095-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=23b251e13d8b column_type=char(255) neg_probe=ccd9b7054b76=167|1264|1265|1406 neg_probe=e3b5de40a8b4=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0095_ip, t2_tc_06_reg_0095_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0095_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0095_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4 NOT NULL, ALGORITHM=inplace;
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0095_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0095_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0095_ip);
-- probe 1/1 -> t1_tc_06_reg_0095_ip
INSERT INTO t1_tc_06_reg_0095_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0095_ip
INSERT INTO t2_tc_06_reg_0095_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0095-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0095_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0095_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0095_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0095_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0095-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0095_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0095_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0095_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0095_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0095_ip a JOIN t2_tc_06_reg_0095_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0095-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=NO has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0095_ip' AND column_name='target';

-- Test Case: TC-06-REG-0096-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-02
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=5351f7aecf1c column_type=char(255) neg_probe=ba48191b882f=167|1264|1265|1406 neg_probe=dc844edcaba7=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0096_ip, t2_tc_06_reg_0096_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0096_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0096_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0096_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0096_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0096_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0096_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0096_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0096_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0096_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0096_ip (target) VALUES (NULL);
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0096_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0096_ip (target) VALUES (NULL);
INSERT INTO t2_tc_06_reg_0096_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0096_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0096_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0096_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0096_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0096_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0096_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0096_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0096_ip);
-- probe 1/1 -> t1_tc_06_reg_0096_ip
INSERT INTO t1_tc_06_reg_0096_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0096_ip
INSERT INTO t2_tc_06_reg_0096_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0096-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0096_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0096_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0096_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0096_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0096-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0096_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0096_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0096_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0096_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0096_ip a JOIN t2_tc_06_reg_0096_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0096-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0096_ip' AND column_name='target';

-- Test Case: TC-06-REG-0097-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: CHAR-03
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=7eb270a99e2f column_type=char(255) neg_probe=299b967fd99b=167|1264|1265|1406 neg_probe=0c77358522ed=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0097_ip, t2_tc_06_reg_0097_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0097_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0097_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0097_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0097_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0097_ip);
-- probe 1/1 -> t1_tc_06_reg_0097_ip
INSERT INTO t1_tc_06_reg_0097_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0097_ip
INSERT INTO t2_tc_06_reg_0097_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0097-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0097_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0097_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0097_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0097_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0097-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0097_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0097_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0097_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0097_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0097_ip a JOIN t2_tc_06_reg_0097_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0097-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0097_ip' AND column_name='target';

-- Test Case: TC-06-REG-0098-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=f715ea4e4a82 column_type=char(255) neg_probe=9979a38ddeb1=167|1264|1265|1406 neg_probe=9dd0562062a5=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0098_ip, t2_tc_06_reg_0098_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0098_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(254) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0098_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4 NOT NULL DEFAULT '', ALGORITHM=inplace;
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0098_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target CHAR(255) CHARACTER SET utf8mb4 NOT NULL DEFAULT '',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0098_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0098_ip);
-- probe 1/1 -> t1_tc_06_reg_0098_ip
INSERT INTO t1_tc_06_reg_0098_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0098_ip
INSERT INTO t2_tc_06_reg_0098_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0098-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0098_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0098_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0098_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0098_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0098-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0098_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0098_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0098_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0098_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0098_ip a JOIN t2_tc_06_reg_0098_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0098-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=NO has_default=1 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0098_ip' AND column_name='target';

-- Test Case: TC-06-REG-0099-IP
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-05
-- Transition ID: CHAR-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=30e5feb86e88 column_type=char(255) neg_probe=91f350960ce8=167|1264|1265|1406 neg_probe=ece12760a00e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_06_reg_0099_ip, t2_tc_06_reg_0099_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_06_reg_0099_ip (
  target CHAR(254) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('Hello');
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('你好');
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('🎉');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_reg_0099_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('');
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Oracle table: CHAR(255)
CREATE TABLE t2_tc_06_reg_0099_ip (
  target CHAR(255) CHARACTER SET utf8mb4,
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC DEFAULT CHARSET=utf8mb4;
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('Hello');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('你好');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('🎉');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('a');
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_06_reg_0099_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_06_reg_0099_ip);
-- probe 1/1 -> t1_tc_06_reg_0099_ip
INSERT INTO t1_tc_06_reg_0099_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
-- probe 1/1 -> t2_tc_06_reg_0099_ip
INSERT INTO t2_tc_06_reg_0099_ip (target) VALUES ('qqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqqq');
SELECT 'TC-06-REG-0099-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_06_reg_0099_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_06_reg_0099_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_06_reg_0099_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_06_reg_0099_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-06-REG-0099-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_06_reg_0099_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_06_reg_0099_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_06_reg_0099_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_06_reg_0099_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_06_reg_0099_ip a JOIN t2_tc_06_reg_0099_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-06-REG-0099-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=NO has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_reg_0099_ip' AND column_name='target';

-- Test Case: TC-06-ATR-0007-IP
-- Column attribute preservation: COMMENT
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace
-- Transition ID: CHAR-03
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=e283b5037a65 column_type=char(255)
DROP TABLE IF EXISTS t1_tc_06_atr_0007_ip, t2_tc_06_atr_0007_ip;
CREATE TABLE t1_tc_06_atr_0007_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(254) CHARACTER SET utf8mb4 COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_atr_0007_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0007_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_atr_0007_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0007_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0007_ip (target) VALUES ('Hello');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_atr_0007_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4 COMMENT 'test_comment', ALGORITHM=inplace;
INSERT INTO t1_tc_06_atr_0007_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0007_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0007_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
SELECT 'TC-06-ATR-0007-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0007_ip' AND column_name='target' AND column_comment='test_comment';
SELECT 'TC-06-ATR-0007-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0007_ip' AND column_name='target';

-- Test Case: TC-06-ATR-0008-IP
-- Column attribute preservation: CHARSET
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace
-- Transition ID: CHAR-03
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=5c8e421dbf00 column_type=char(255)
DROP TABLE IF EXISTS t1_tc_06_atr_0008_ip, t2_tc_06_atr_0008_ip;
CREATE TABLE t1_tc_06_atr_0008_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(254) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_atr_0008_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0008_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_atr_0008_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0008_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0008_ip (target) VALUES ('Hello');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_atr_0008_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4, ALGORITHM=inplace;
INSERT INTO t1_tc_06_atr_0008_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0008_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0008_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
SELECT 'TC-06-ATR-0008-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0008_ip' AND column_name='target' AND character_set_name='utf8mb4';
SELECT 'TC-06-ATR-0008-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0008_ip' AND column_name='target';

-- Test Case: TC-06-ATR-0009-IP
-- Column attribute preservation: COLLATE
-- Type: CHAR(254) -> CHAR(255), Algorithm: inplace
-- Transition ID: CHAR-03
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=abe8942d39a3 column_type=char(255)
DROP TABLE IF EXISTS t1_tc_06_atr_0009_ip, t2_tc_06_atr_0009_ip;
CREATE TABLE t1_tc_06_atr_0009_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target CHAR(254) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin,
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
INSERT INTO t1_tc_06_atr_0009_ip (target) VALUES ('');
INSERT INTO t1_tc_06_atr_0009_ip (target) VALUES ('a');
INSERT INTO t1_tc_06_atr_0009_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0009_ip (target) VALUES ('xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx');
INSERT INTO t1_tc_06_atr_0009_ip (target) VALUES ('Hello');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_06_atr_0009_ip MODIFY target CHAR(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin, ALGORITHM=inplace;
INSERT INTO t1_tc_06_atr_0009_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0009_ip (target) VALUES ('zzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzzz');
INSERT INTO t1_tc_06_atr_0009_ip (target) VALUES ('wwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwwww');
SELECT 'TC-06-ATR-0009-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0009_ip' AND column_name='target' AND collation_name='utf8mb4_bin';
SELECT 'TC-06-ATR-0009-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_bin')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=char(255) nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_bin extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_06_atr_0009_ip' AND column_name='target';

