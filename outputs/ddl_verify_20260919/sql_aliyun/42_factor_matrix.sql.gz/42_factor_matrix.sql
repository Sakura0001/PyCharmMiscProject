-- ============================================================
-- RDS MySQL DDL 秒级/在线修改列类型 测试套件 — 阿里云环境
-- 环境说明: 所有功能开关默认开启
-- 覆盖类型: 整数(SIGNED/UNSIGNED) + CHAR + VARCHAR
-- 覆盖算法: INSTANT + INPLACE
-- ============================================================
-- 本文件由 generate_test_sql.py 自动生成, 请勿手动修改
-- Suite-Revision: ebbfa1c38daa   (生成器源码哈希; 时间戳见 results/generation_manifest.json)
-- 用例 ID 规则: TC-<文件号>-<作用域>-<序号>-<IT|IP>  —— 全局唯一
--   作用域 REG=普通表 OFAT/二元组, ATR=列属性保持, SPE=特殊模式,
--          FK=外键, PTK=分区(目标列是分区键), PNK=分区(目标列非分区键)
-- ============================================================

SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
SET SESSION innodb_lock_wait_timeout = 50;

-- File 42: 因子矩阵 (索引形态/依赖对象/表选项/引擎/会话与sql_mode/数据规模)

-- Test Case: TC-42-FCT-0001-IT
-- Factor probe: IDX_FUNCTIONAL
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 函数/表达式索引（引用目标列）
DROP TABLE IF EXISTS t1_tc_42_fct_0001_it, t2_tc_42_fct_0001_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=ea81163432ad factor=IDX_FUNCTIONAL
CREATE TABLE t1_tc_42_fct_0001_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_fn ((CONCAT(target, ''))),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0001_it (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0001_it (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0001_it (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0001_it MODIFY target INT, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0001-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0001_it';
SELECT 'TC-42-FCT-0001-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0001_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0002-IP
-- Factor probe: IDX_FUNCTIONAL
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 函数/表达式索引（引用目标列）
DROP TABLE IF EXISTS t1_tc_42_fct_0002_ip, t2_tc_42_fct_0002_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=a521338aa863 factor=IDX_FUNCTIONAL
CREATE TABLE t1_tc_42_fct_0002_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_fn ((CONCAT(target, ''))),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0002_ip (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0002_ip (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0002_ip (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0002_ip MODIFY target INT, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0002-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0002_ip';
SELECT 'TC-42-FCT-0002-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0002_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0003-DF
-- Factor probe: IDX_FUNCTIONAL
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 函数/表达式索引（引用目标列）
DROP TABLE IF EXISTS t1_tc_42_fct_0003_df, t2_tc_42_fct_0003_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=71c3bb96fd66 factor=IDX_FUNCTIONAL
CREATE TABLE t1_tc_42_fct_0003_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_fn ((CONCAT(target, ''))),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0003_df (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0003_df (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0003_df (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0003_df MODIFY target INT;
SELECT 'TC-42-FCT-0003-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0003_df';
SELECT 'TC-42-FCT-0003-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0003_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0004-IT
-- Factor probe: IDX_FUNCTIONAL
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 函数/表达式索引（引用目标列）
DROP TABLE IF EXISTS t1_tc_42_fct_0004_it, t2_tc_42_fct_0004_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=c369d9aa802c factor=IDX_FUNCTIONAL
CREATE TABLE t1_tc_42_fct_0004_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_fn ((CONCAT(target, ''))),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0004_it (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0004_it (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0004_it (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0004_it MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0004-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0004_it';
SELECT 'TC-42-FCT-0004-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0004_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0005-IP
-- Factor probe: IDX_FUNCTIONAL
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 函数/表达式索引（引用目标列）
DROP TABLE IF EXISTS t1_tc_42_fct_0005_ip, t2_tc_42_fct_0005_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=483ead1f73fc factor=IDX_FUNCTIONAL
CREATE TABLE t1_tc_42_fct_0005_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_fn ((CONCAT(target, ''))),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0005_ip (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0005_ip (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0005_ip (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0005_ip MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0005-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0005_ip';
SELECT 'TC-42-FCT-0005-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0005_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0006-DF
-- Factor probe: IDX_FUNCTIONAL
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 函数/表达式索引（引用目标列）
DROP TABLE IF EXISTS t1_tc_42_fct_0006_df, t2_tc_42_fct_0006_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=d712cd9fec62 factor=IDX_FUNCTIONAL
CREATE TABLE t1_tc_42_fct_0006_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_fn ((CONCAT(target, ''))),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0006_df (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0006_df (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0006_df (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0006_df MODIFY target VARCHAR(200) CHARACTER SET utf8mb4;
SELECT 'TC-42-FCT-0006-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0006_df';
SELECT 'TC-42-FCT-0006-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0006_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0007-IT
-- Factor probe: IDX_FUNCTIONAL
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 函数/表达式索引（引用目标列）
DROP TABLE IF EXISTS t1_tc_42_fct_0007_it, t2_tc_42_fct_0007_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=b9046bad4559 factor=IDX_FUNCTIONAL
CREATE TABLE t1_tc_42_fct_0007_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_fn ((CONCAT(target, ''))),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0007_it (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0007_it (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0007_it (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0007_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0007-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0007_it';
SELECT 'TC-42-FCT-0007-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0007_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0008-IP
-- Factor probe: IDX_FUNCTIONAL
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 函数/表达式索引（引用目标列）
DROP TABLE IF EXISTS t1_tc_42_fct_0008_ip, t2_tc_42_fct_0008_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=631e2b485449 factor=IDX_FUNCTIONAL
CREATE TABLE t1_tc_42_fct_0008_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_fn ((CONCAT(target, ''))),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0008_ip (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0008_ip (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0008_ip (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0008_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0008-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0008_ip';
SELECT 'TC-42-FCT-0008-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0008_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0009-DF
-- Factor probe: IDX_FUNCTIONAL
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 函数/表达式索引（引用目标列）
DROP TABLE IF EXISTS t1_tc_42_fct_0009_df, t2_tc_42_fct_0009_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=9193bd54728f factor=IDX_FUNCTIONAL
CREATE TABLE t1_tc_42_fct_0009_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_fn ((CONCAT(target, ''))),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0009_df (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0009_df (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0009_df (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0009_df MODIFY target CHAR(2) CHARACTER SET latin1;
SELECT 'TC-42-FCT-0009-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0009_df';
SELECT 'TC-42-FCT-0009-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0009_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0010-IT
-- Factor probe: DEP_GEN_STORED
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: STORED 生成列引用目标列 + 其上的索引
DROP TABLE IF EXISTS t1_tc_42_fct_0010_it, t2_tc_42_fct_0010_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=6f4512e06fe1 factor=DEP_GEN_STORED
CREATE TABLE t1_tc_42_fct_0010_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  gen_c VARCHAR(64) AS (CONCAT('v', target)) STORED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_gen (gen_c),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0010_it (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0010_it (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0010_it (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0010_it MODIFY target INT, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0010-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0010_it';
SELECT 'TC-42-FCT-0010-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0010_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0011-IP
-- Factor probe: DEP_GEN_STORED
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: STORED 生成列引用目标列 + 其上的索引
DROP TABLE IF EXISTS t1_tc_42_fct_0011_ip, t2_tc_42_fct_0011_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=7dc81cb47128 factor=DEP_GEN_STORED
CREATE TABLE t1_tc_42_fct_0011_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  gen_c VARCHAR(64) AS (CONCAT('v', target)) STORED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_gen (gen_c),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0011_ip (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0011_ip (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0011_ip (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0011_ip MODIFY target INT, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0011-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0011_ip';
SELECT 'TC-42-FCT-0011-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0011_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0012-DF
-- Factor probe: DEP_GEN_STORED
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: STORED 生成列引用目标列 + 其上的索引
DROP TABLE IF EXISTS t1_tc_42_fct_0012_df, t2_tc_42_fct_0012_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=d72a3559b451 factor=DEP_GEN_STORED
CREATE TABLE t1_tc_42_fct_0012_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  gen_c VARCHAR(64) AS (CONCAT('v', target)) STORED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_gen (gen_c),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0012_df (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0012_df (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0012_df (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0012_df MODIFY target INT;
SELECT 'TC-42-FCT-0012-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0012_df';
SELECT 'TC-42-FCT-0012-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0012_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0013-IT
-- Factor probe: DEP_GEN_STORED
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: STORED 生成列引用目标列 + 其上的索引
DROP TABLE IF EXISTS t1_tc_42_fct_0013_it, t2_tc_42_fct_0013_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=5870aca9c5d9 factor=DEP_GEN_STORED
CREATE TABLE t1_tc_42_fct_0013_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  gen_c VARCHAR(64) AS (CONCAT('v', target)) STORED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_gen (gen_c),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0013_it (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0013_it (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0013_it (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0013_it MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0013-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0013_it';
SELECT 'TC-42-FCT-0013-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0013_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0014-IP
-- Factor probe: DEP_GEN_STORED
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: STORED 生成列引用目标列 + 其上的索引
DROP TABLE IF EXISTS t1_tc_42_fct_0014_ip, t2_tc_42_fct_0014_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=94b0f74ee4a0 factor=DEP_GEN_STORED
CREATE TABLE t1_tc_42_fct_0014_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  gen_c VARCHAR(64) AS (CONCAT('v', target)) STORED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_gen (gen_c),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0014_ip (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0014_ip (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0014_ip (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0014_ip MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0014-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0014_ip';
SELECT 'TC-42-FCT-0014-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0014_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0015-DF
-- Factor probe: DEP_GEN_STORED
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: STORED 生成列引用目标列 + 其上的索引
DROP TABLE IF EXISTS t1_tc_42_fct_0015_df, t2_tc_42_fct_0015_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=5f2df4fa00c3 factor=DEP_GEN_STORED
CREATE TABLE t1_tc_42_fct_0015_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  gen_c VARCHAR(64) AS (CONCAT('v', target)) STORED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_gen (gen_c),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0015_df (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0015_df (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0015_df (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0015_df MODIFY target VARCHAR(200) CHARACTER SET utf8mb4;
SELECT 'TC-42-FCT-0015-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0015_df';
SELECT 'TC-42-FCT-0015-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0015_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0016-IT
-- Factor probe: DEP_GEN_STORED
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: STORED 生成列引用目标列 + 其上的索引
DROP TABLE IF EXISTS t1_tc_42_fct_0016_it, t2_tc_42_fct_0016_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=2cc65c1d1eef factor=DEP_GEN_STORED
CREATE TABLE t1_tc_42_fct_0016_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  gen_c VARCHAR(64) AS (CONCAT('v', target)) STORED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_gen (gen_c),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0016_it (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0016_it (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0016_it (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0016_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0016-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0016_it';
SELECT 'TC-42-FCT-0016-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0016_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0017-IP
-- Factor probe: DEP_GEN_STORED
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: STORED 生成列引用目标列 + 其上的索引
DROP TABLE IF EXISTS t1_tc_42_fct_0017_ip, t2_tc_42_fct_0017_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=000fd9341895 factor=DEP_GEN_STORED
CREATE TABLE t1_tc_42_fct_0017_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  gen_c VARCHAR(64) AS (CONCAT('v', target)) STORED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_gen (gen_c),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0017_ip (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0017_ip (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0017_ip (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0017_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0017-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0017_ip';
SELECT 'TC-42-FCT-0017-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0017_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0018-DF
-- Factor probe: DEP_GEN_STORED
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: STORED 生成列引用目标列 + 其上的索引
DROP TABLE IF EXISTS t1_tc_42_fct_0018_df, t2_tc_42_fct_0018_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=fe65d8c20d14 factor=DEP_GEN_STORED
CREATE TABLE t1_tc_42_fct_0018_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  gen_c VARCHAR(64) AS (CONCAT('v', target)) STORED,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_gen (gen_c),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0018_df (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0018_df (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0018_df (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0018_df MODIFY target CHAR(2) CHARACTER SET latin1;
SELECT 'TC-42-FCT-0018-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0018_df';
SELECT 'TC-42-FCT-0018-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0018_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0019-IT
-- Factor probe: IDX_DESC
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: FAIL
-- Transition ID: INT-S-3-4
-- Factor note: 降序索引
DROP TABLE IF EXISTS t1_tc_42_fct_0019_it, t2_tc_42_fct_0019_it;
-- @expect alter=FAIL build=SUCCESS assertions=2 alter_sha=29373032089c factor=IDX_DESC errno=[1845]
CREATE TABLE t1_tc_42_fct_0019_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_desc (target DESC),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0019_it (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0019_it (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0019_it (target) VALUES (1);
-- ALTER expected FAIL (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0019_it MODIFY target INT, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0019-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0019_it';
SELECT 'TC-42-FCT-0019-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='mediumint','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=mediumint nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0019_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0020-IP
-- Factor probe: IDX_DESC
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 降序索引
DROP TABLE IF EXISTS t1_tc_42_fct_0020_ip, t2_tc_42_fct_0020_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=0425b5f6a5eb factor=IDX_DESC
CREATE TABLE t1_tc_42_fct_0020_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_desc (target DESC),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0020_ip (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0020_ip (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0020_ip (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0020_ip MODIFY target INT, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0020-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0020_ip';
SELECT 'TC-42-FCT-0020-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0020_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0021-DF
-- Factor probe: IDX_DESC
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 降序索引
DROP TABLE IF EXISTS t1_tc_42_fct_0021_df, t2_tc_42_fct_0021_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=27c8dcc849d8 factor=IDX_DESC
CREATE TABLE t1_tc_42_fct_0021_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_desc (target DESC),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0021_df (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0021_df (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0021_df (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0021_df MODIFY target INT;
SELECT 'TC-42-FCT-0021-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0021_df';
SELECT 'TC-42-FCT-0021-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0021_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0022-IT
-- Factor probe: IDX_DESC
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: FAIL
-- Transition ID: VC-07
-- Factor note: 降序索引
DROP TABLE IF EXISTS t1_tc_42_fct_0022_it, t2_tc_42_fct_0022_it;
-- @expect alter=FAIL build=SUCCESS assertions=2 alter_sha=5047ea64b6bb factor=IDX_DESC errno=[1845]
CREATE TABLE t1_tc_42_fct_0022_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_desc (target DESC),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0022_it (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0022_it (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0022_it (target) VALUES ('00000002');
-- ALTER expected FAIL (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0022_it MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0022-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0022_it';
SELECT 'TC-42-FCT-0022-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(100)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(100) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0022_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0023-IP
-- Factor probe: IDX_DESC
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 降序索引
DROP TABLE IF EXISTS t1_tc_42_fct_0023_ip, t2_tc_42_fct_0023_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=fc8641db1491 factor=IDX_DESC
CREATE TABLE t1_tc_42_fct_0023_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_desc (target DESC),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0023_ip (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0023_ip (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0023_ip (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0023_ip MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0023-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0023_ip';
SELECT 'TC-42-FCT-0023-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0023_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0024-DF
-- Factor probe: IDX_DESC
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 降序索引
DROP TABLE IF EXISTS t1_tc_42_fct_0024_df, t2_tc_42_fct_0024_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=bf7ad2851415 factor=IDX_DESC
CREATE TABLE t1_tc_42_fct_0024_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_desc (target DESC),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0024_df (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0024_df (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0024_df (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0024_df MODIFY target VARCHAR(200) CHARACTER SET utf8mb4;
SELECT 'TC-42-FCT-0024-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0024_df';
SELECT 'TC-42-FCT-0024-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0024_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0025-IT
-- Factor probe: IDX_DESC
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: FAIL
-- Transition ID: CHAR-01
-- Factor note: 降序索引
DROP TABLE IF EXISTS t1_tc_42_fct_0025_it, t2_tc_42_fct_0025_it;
-- @expect alter=FAIL build=SUCCESS assertions=2 alter_sha=b6b0292223ed factor=IDX_DESC errno=[1845]
CREATE TABLE t1_tc_42_fct_0025_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_desc (target DESC),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0025_it (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0025_it (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0025_it (target) VALUES ('2');
-- ALTER expected FAIL (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0025_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0025-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0025_it';
SELECT 'TC-42-FCT-0025-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(1)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(1) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0025_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0026-IP
-- Factor probe: IDX_DESC
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 降序索引
DROP TABLE IF EXISTS t1_tc_42_fct_0026_ip, t2_tc_42_fct_0026_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=7d9771a8c8c5 factor=IDX_DESC
CREATE TABLE t1_tc_42_fct_0026_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_desc (target DESC),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0026_ip (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0026_ip (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0026_ip (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0026_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0026-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0026_ip';
SELECT 'TC-42-FCT-0026-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0026_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0027-DF
-- Factor probe: IDX_DESC
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 降序索引
DROP TABLE IF EXISTS t1_tc_42_fct_0027_df, t2_tc_42_fct_0027_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=7f010e4b32ac factor=IDX_DESC
CREATE TABLE t1_tc_42_fct_0027_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_desc (target DESC),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0027_df (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0027_df (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0027_df (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0027_df MODIFY target CHAR(2) CHARACTER SET latin1;
SELECT 'TC-42-FCT-0027-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0027_df';
SELECT 'TC-42-FCT-0027-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0027_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0028-IT
-- Factor probe: IDX_INVISIBLE
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: FAIL
-- Transition ID: INT-S-3-4
-- Factor note: 不可见索引
DROP TABLE IF EXISTS t1_tc_42_fct_0028_it, t2_tc_42_fct_0028_it;
-- @expect alter=FAIL build=SUCCESS assertions=2 alter_sha=0321fb3517dd factor=IDX_INVISIBLE errno=[1845]
CREATE TABLE t1_tc_42_fct_0028_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_inv (target) INVISIBLE,
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0028_it (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0028_it (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0028_it (target) VALUES (1);
-- ALTER expected FAIL (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0028_it MODIFY target INT, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0028-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0028_it';
SELECT 'TC-42-FCT-0028-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='mediumint','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=mediumint nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0028_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0029-IP
-- Factor probe: IDX_INVISIBLE
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 不可见索引
DROP TABLE IF EXISTS t1_tc_42_fct_0029_ip, t2_tc_42_fct_0029_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=4fb756f2816c factor=IDX_INVISIBLE
CREATE TABLE t1_tc_42_fct_0029_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_inv (target) INVISIBLE,
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0029_ip (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0029_ip (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0029_ip (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0029_ip MODIFY target INT, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0029-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0029_ip';
SELECT 'TC-42-FCT-0029-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0029_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0030-DF
-- Factor probe: IDX_INVISIBLE
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 不可见索引
DROP TABLE IF EXISTS t1_tc_42_fct_0030_df, t2_tc_42_fct_0030_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=eeaff2bf77c0 factor=IDX_INVISIBLE
CREATE TABLE t1_tc_42_fct_0030_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_inv (target) INVISIBLE,
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0030_df (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0030_df (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0030_df (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0030_df MODIFY target INT;
SELECT 'TC-42-FCT-0030-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0030_df';
SELECT 'TC-42-FCT-0030-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0030_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0031-IT
-- Factor probe: IDX_INVISIBLE
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: FAIL
-- Transition ID: VC-07
-- Factor note: 不可见索引
DROP TABLE IF EXISTS t1_tc_42_fct_0031_it, t2_tc_42_fct_0031_it;
-- @expect alter=FAIL build=SUCCESS assertions=2 alter_sha=bbc418a4e606 factor=IDX_INVISIBLE errno=[1845]
CREATE TABLE t1_tc_42_fct_0031_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_inv (target) INVISIBLE,
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0031_it (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0031_it (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0031_it (target) VALUES ('00000002');
-- ALTER expected FAIL (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0031_it MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0031-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0031_it';
SELECT 'TC-42-FCT-0031-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(100)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(100) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0031_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0032-IP
-- Factor probe: IDX_INVISIBLE
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 不可见索引
DROP TABLE IF EXISTS t1_tc_42_fct_0032_ip, t2_tc_42_fct_0032_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=8a7f0f9326ce factor=IDX_INVISIBLE
CREATE TABLE t1_tc_42_fct_0032_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_inv (target) INVISIBLE,
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0032_ip (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0032_ip (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0032_ip (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0032_ip MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0032-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0032_ip';
SELECT 'TC-42-FCT-0032-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0032_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0033-DF
-- Factor probe: IDX_INVISIBLE
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 不可见索引
DROP TABLE IF EXISTS t1_tc_42_fct_0033_df, t2_tc_42_fct_0033_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=04fbc30bd530 factor=IDX_INVISIBLE
CREATE TABLE t1_tc_42_fct_0033_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_inv (target) INVISIBLE,
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0033_df (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0033_df (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0033_df (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0033_df MODIFY target VARCHAR(200) CHARACTER SET utf8mb4;
SELECT 'TC-42-FCT-0033-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0033_df';
SELECT 'TC-42-FCT-0033-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0033_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0034-IT
-- Factor probe: IDX_INVISIBLE
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: FAIL
-- Transition ID: CHAR-01
-- Factor note: 不可见索引
DROP TABLE IF EXISTS t1_tc_42_fct_0034_it, t2_tc_42_fct_0034_it;
-- @expect alter=FAIL build=SUCCESS assertions=2 alter_sha=62dbc334ea51 factor=IDX_INVISIBLE errno=[1845]
CREATE TABLE t1_tc_42_fct_0034_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_inv (target) INVISIBLE,
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0034_it (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0034_it (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0034_it (target) VALUES ('2');
-- ALTER expected FAIL (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0034_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0034-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0034_it';
SELECT 'TC-42-FCT-0034-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(1)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(1) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0034_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0035-IP
-- Factor probe: IDX_INVISIBLE
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 不可见索引
DROP TABLE IF EXISTS t1_tc_42_fct_0035_ip, t2_tc_42_fct_0035_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=6bd3317f2a1e factor=IDX_INVISIBLE
CREATE TABLE t1_tc_42_fct_0035_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_inv (target) INVISIBLE,
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0035_ip (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0035_ip (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0035_ip (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0035_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0035-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0035_ip';
SELECT 'TC-42-FCT-0035-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0035_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0036-DF
-- Factor probe: IDX_INVISIBLE
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 不可见索引
DROP TABLE IF EXISTS t1_tc_42_fct_0036_df, t2_tc_42_fct_0036_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=45ceee850f6f factor=IDX_INVISIBLE
CREATE TABLE t1_tc_42_fct_0036_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_inv (target) INVISIBLE,
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0036_df (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0036_df (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0036_df (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0036_df MODIFY target CHAR(2) CHARACTER SET latin1;
SELECT 'TC-42-FCT-0036-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0036_df';
SELECT 'TC-42-FCT-0036-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0036_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0037-IT
-- Factor probe: IDX_FULLTEXT_OTHER
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: FAIL
-- Transition ID: INT-S-3-4
-- Factor note: 表上有 FULLTEXT 索引（非目标列）—— 会改变 INPLACE 可行性
DROP TABLE IF EXISTS t1_tc_42_fct_0037_it, t2_tc_42_fct_0037_it;
-- @expect alter=FAIL build=SUCCESS assertions=2 alter_sha=d256310c6055 factor=IDX_FULLTEXT_OTHER errno=[1846]
CREATE TABLE t1_tc_42_fct_0037_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  ft TEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  FULLTEXT INDEX ft_idx (ft),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0037_it (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0037_it (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0037_it (target) VALUES (1);
-- ALTER expected FAIL (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0037_it MODIFY target INT, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0037-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0037_it';
SELECT 'TC-42-FCT-0037-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='mediumint','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=mediumint nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0037_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0038-IP
-- Factor probe: IDX_FULLTEXT_OTHER
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: FAIL
-- Transition ID: INT-S-3-4
-- Factor note: 表上有 FULLTEXT 索引（非目标列）—— 会改变 INPLACE 可行性
DROP TABLE IF EXISTS t1_tc_42_fct_0038_ip, t2_tc_42_fct_0038_ip;
-- @expect alter=FAIL build=SUCCESS assertions=2 alter_sha=aca8855d0b1e factor=IDX_FULLTEXT_OTHER errno=[1846]
CREATE TABLE t1_tc_42_fct_0038_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  ft TEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  FULLTEXT INDEX ft_idx (ft),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0038_ip (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0038_ip (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0038_ip (target) VALUES (1);
-- ALTER expected FAIL (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0038_ip MODIFY target INT, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0038-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0038_ip';
SELECT 'TC-42-FCT-0038-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='mediumint','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=mediumint nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0038_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0039-DF
-- Factor probe: IDX_FULLTEXT_OTHER
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 表上有 FULLTEXT 索引（非目标列）—— 会改变 INPLACE 可行性
DROP TABLE IF EXISTS t1_tc_42_fct_0039_df, t2_tc_42_fct_0039_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=d135bdddef01 factor=IDX_FULLTEXT_OTHER
CREATE TABLE t1_tc_42_fct_0039_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  ft TEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  FULLTEXT INDEX ft_idx (ft),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0039_df (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0039_df (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0039_df (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0039_df MODIFY target INT;
SELECT 'TC-42-FCT-0039-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0039_df';
SELECT 'TC-42-FCT-0039-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0039_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0040-IT
-- Factor probe: IDX_FULLTEXT_OTHER
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: FAIL
-- Transition ID: VC-07
-- Factor note: 表上有 FULLTEXT 索引（非目标列）—— 会改变 INPLACE 可行性
DROP TABLE IF EXISTS t1_tc_42_fct_0040_it, t2_tc_42_fct_0040_it;
-- @expect alter=FAIL build=SUCCESS assertions=2 alter_sha=b43bfe3711bc factor=IDX_FULLTEXT_OTHER errno=[1845]
CREATE TABLE t1_tc_42_fct_0040_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  ft TEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  FULLTEXT INDEX ft_idx (ft),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0040_it (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0040_it (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0040_it (target) VALUES ('00000002');
-- ALTER expected FAIL (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0040_it MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0040-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0040_it';
SELECT 'TC-42-FCT-0040-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(100)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(100) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0040_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0041-IP
-- Factor probe: IDX_FULLTEXT_OTHER
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 表上有 FULLTEXT 索引（非目标列）—— 会改变 INPLACE 可行性
DROP TABLE IF EXISTS t1_tc_42_fct_0041_ip, t2_tc_42_fct_0041_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=4f1d979a91e3 factor=IDX_FULLTEXT_OTHER
CREATE TABLE t1_tc_42_fct_0041_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  ft TEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  FULLTEXT INDEX ft_idx (ft),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0041_ip (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0041_ip (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0041_ip (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0041_ip MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0041-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0041_ip';
SELECT 'TC-42-FCT-0041-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0041_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0042-DF
-- Factor probe: IDX_FULLTEXT_OTHER
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 表上有 FULLTEXT 索引（非目标列）—— 会改变 INPLACE 可行性
DROP TABLE IF EXISTS t1_tc_42_fct_0042_df, t2_tc_42_fct_0042_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=ac257995f50b factor=IDX_FULLTEXT_OTHER
CREATE TABLE t1_tc_42_fct_0042_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  ft TEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  FULLTEXT INDEX ft_idx (ft),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0042_df (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0042_df (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0042_df (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0042_df MODIFY target VARCHAR(200) CHARACTER SET utf8mb4;
SELECT 'TC-42-FCT-0042-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0042_df';
SELECT 'TC-42-FCT-0042-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0042_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0043-IT
-- Factor probe: IDX_FULLTEXT_OTHER
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: FAIL
-- Transition ID: CHAR-01
-- Factor note: 表上有 FULLTEXT 索引（非目标列）—— 会改变 INPLACE 可行性
DROP TABLE IF EXISTS t1_tc_42_fct_0043_it, t2_tc_42_fct_0043_it;
-- @expect alter=FAIL build=SUCCESS assertions=2 alter_sha=59e0756ce8d6 factor=IDX_FULLTEXT_OTHER errno=[1846]
CREATE TABLE t1_tc_42_fct_0043_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  ft TEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  FULLTEXT INDEX ft_idx (ft),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0043_it (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0043_it (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0043_it (target) VALUES ('2');
-- ALTER expected FAIL (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0043_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0043-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0043_it';
SELECT 'TC-42-FCT-0043-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(1)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(1) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0043_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0044-IP
-- Factor probe: IDX_FULLTEXT_OTHER
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: FAIL
-- Transition ID: CHAR-01
-- Factor note: 表上有 FULLTEXT 索引（非目标列）—— 会改变 INPLACE 可行性
DROP TABLE IF EXISTS t1_tc_42_fct_0044_ip, t2_tc_42_fct_0044_ip;
-- @expect alter=FAIL build=SUCCESS assertions=2 alter_sha=6a784738fad5 factor=IDX_FULLTEXT_OTHER errno=[1846]
CREATE TABLE t1_tc_42_fct_0044_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  ft TEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  FULLTEXT INDEX ft_idx (ft),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0044_ip (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0044_ip (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0044_ip (target) VALUES ('2');
-- ALTER expected FAIL (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0044_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0044-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0044_ip';
SELECT 'TC-42-FCT-0044-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(1)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(1) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0044_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0045-DF
-- Factor probe: IDX_FULLTEXT_OTHER
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 表上有 FULLTEXT 索引（非目标列）—— 会改变 INPLACE 可行性
DROP TABLE IF EXISTS t1_tc_42_fct_0045_df, t2_tc_42_fct_0045_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=e7a2e72ad85b factor=IDX_FULLTEXT_OTHER
CREATE TABLE t1_tc_42_fct_0045_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  ft TEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  FULLTEXT INDEX ft_idx (ft),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0045_df (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0045_df (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0045_df (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0045_df MODIFY target CHAR(2) CHARACTER SET latin1;
SELECT 'TC-42-FCT-0045-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0045_df';
SELECT 'TC-42-FCT-0045-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0045_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0046-IT
-- Factor probe: IDX_SPATIAL_OTHER
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 表上有 SPATIAL 索引（非目标列）
DROP TABLE IF EXISTS t1_tc_42_fct_0046_it, t2_tc_42_fct_0046_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=8f2f1a5f92bb factor=IDX_SPATIAL_OTHER
CREATE TABLE t1_tc_42_fct_0046_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  g POINT NOT NULL SRID 0 DEFAULT (ST_PointFromText('POINT(0 0)')),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  SPATIAL INDEX sp_idx (g),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0046_it (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0046_it (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0046_it (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0046_it MODIFY target INT, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0046-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0046_it';
SELECT 'TC-42-FCT-0046-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0046_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0047-IP
-- Factor probe: IDX_SPATIAL_OTHER
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 表上有 SPATIAL 索引（非目标列）
DROP TABLE IF EXISTS t1_tc_42_fct_0047_ip, t2_tc_42_fct_0047_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=37fe931a8426 factor=IDX_SPATIAL_OTHER
CREATE TABLE t1_tc_42_fct_0047_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  g POINT NOT NULL SRID 0 DEFAULT (ST_PointFromText('POINT(0 0)')),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  SPATIAL INDEX sp_idx (g),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0047_ip (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0047_ip (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0047_ip (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0047_ip MODIFY target INT, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0047-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0047_ip';
SELECT 'TC-42-FCT-0047-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0047_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0048-DF
-- Factor probe: IDX_SPATIAL_OTHER
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 表上有 SPATIAL 索引（非目标列）
DROP TABLE IF EXISTS t1_tc_42_fct_0048_df, t2_tc_42_fct_0048_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=fa16047399eb factor=IDX_SPATIAL_OTHER
CREATE TABLE t1_tc_42_fct_0048_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  g POINT NOT NULL SRID 0 DEFAULT (ST_PointFromText('POINT(0 0)')),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  SPATIAL INDEX sp_idx (g),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0048_df (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0048_df (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0048_df (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0048_df MODIFY target INT;
SELECT 'TC-42-FCT-0048-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0048_df';
SELECT 'TC-42-FCT-0048-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0048_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0049-IT
-- Factor probe: IDX_SPATIAL_OTHER
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 表上有 SPATIAL 索引（非目标列）
DROP TABLE IF EXISTS t1_tc_42_fct_0049_it, t2_tc_42_fct_0049_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=ff31c498caa6 factor=IDX_SPATIAL_OTHER
CREATE TABLE t1_tc_42_fct_0049_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  g POINT NOT NULL SRID 0 DEFAULT (ST_PointFromText('POINT(0 0)')),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  SPATIAL INDEX sp_idx (g),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0049_it (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0049_it (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0049_it (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0049_it MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0049-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0049_it';
SELECT 'TC-42-FCT-0049-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0049_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0050-IP
-- Factor probe: IDX_SPATIAL_OTHER
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 表上有 SPATIAL 索引（非目标列）
DROP TABLE IF EXISTS t1_tc_42_fct_0050_ip, t2_tc_42_fct_0050_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=9dbad97435c1 factor=IDX_SPATIAL_OTHER
CREATE TABLE t1_tc_42_fct_0050_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  g POINT NOT NULL SRID 0 DEFAULT (ST_PointFromText('POINT(0 0)')),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  SPATIAL INDEX sp_idx (g),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0050_ip (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0050_ip (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0050_ip (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0050_ip MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0050-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0050_ip';
SELECT 'TC-42-FCT-0050-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0050_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0051-DF
-- Factor probe: IDX_SPATIAL_OTHER
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 表上有 SPATIAL 索引（非目标列）
DROP TABLE IF EXISTS t1_tc_42_fct_0051_df, t2_tc_42_fct_0051_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=33395715d2fc factor=IDX_SPATIAL_OTHER
CREATE TABLE t1_tc_42_fct_0051_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  g POINT NOT NULL SRID 0 DEFAULT (ST_PointFromText('POINT(0 0)')),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  SPATIAL INDEX sp_idx (g),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0051_df (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0051_df (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0051_df (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0051_df MODIFY target VARCHAR(200) CHARACTER SET utf8mb4;
SELECT 'TC-42-FCT-0051-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0051_df';
SELECT 'TC-42-FCT-0051-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0051_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0052-IT
-- Factor probe: IDX_SPATIAL_OTHER
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 表上有 SPATIAL 索引（非目标列）
DROP TABLE IF EXISTS t1_tc_42_fct_0052_it, t2_tc_42_fct_0052_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=c00ee79785bf factor=IDX_SPATIAL_OTHER
CREATE TABLE t1_tc_42_fct_0052_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  g POINT NOT NULL SRID 0 DEFAULT (ST_PointFromText('POINT(0 0)')),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  SPATIAL INDEX sp_idx (g),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0052_it (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0052_it (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0052_it (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0052_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0052-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0052_it';
SELECT 'TC-42-FCT-0052-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0052_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0053-IP
-- Factor probe: IDX_SPATIAL_OTHER
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 表上有 SPATIAL 索引（非目标列）
DROP TABLE IF EXISTS t1_tc_42_fct_0053_ip, t2_tc_42_fct_0053_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=f0dc349942be factor=IDX_SPATIAL_OTHER
CREATE TABLE t1_tc_42_fct_0053_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  g POINT NOT NULL SRID 0 DEFAULT (ST_PointFromText('POINT(0 0)')),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  SPATIAL INDEX sp_idx (g),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0053_ip (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0053_ip (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0053_ip (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0053_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0053-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0053_ip';
SELECT 'TC-42-FCT-0053-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0053_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0054-DF
-- Factor probe: IDX_SPATIAL_OTHER
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 表上有 SPATIAL 索引（非目标列）
DROP TABLE IF EXISTS t1_tc_42_fct_0054_df, t2_tc_42_fct_0054_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=87558208d57d factor=IDX_SPATIAL_OTHER
CREATE TABLE t1_tc_42_fct_0054_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  g POINT NOT NULL SRID 0 DEFAULT (ST_PointFromText('POINT(0 0)')),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  SPATIAL INDEX sp_idx (g),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0054_df (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0054_df (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0054_df (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0054_df MODIFY target CHAR(2) CHARACTER SET latin1;
SELECT 'TC-42-FCT-0054-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0054_df';
SELECT 'TC-42-FCT-0054-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0054_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0055-IT
-- Factor probe: DEP_TRIGGER
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 表上有 BEFORE INSERT 触发器引用目标列
DROP TRIGGER IF EXISTS trg_tc_42_fct_0055_it;
DROP TABLE IF EXISTS t1_tc_42_fct_0055_it, t2_tc_42_fct_0055_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=808f68dd93b5 factor=DEP_TRIGGER
CREATE TABLE t1_tc_42_fct_0055_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
CREATE TRIGGER trg_tc_42_fct_0055_it BEFORE INSERT ON t1_tc_42_fct_0055_it FOR EACH ROW SET NEW.pad = CONCAT('t', IFNULL(NEW.target,''));
INSERT INTO t1_tc_42_fct_0055_it (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0055_it (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0055_it (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0055_it MODIFY target INT, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0055-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0055_it';
SELECT 'TC-42-FCT-0055-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0055_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）
DROP TRIGGER IF EXISTS trg_tc_42_fct_0055_it;

-- Test Case: TC-42-FCT-0056-IP
-- Factor probe: DEP_TRIGGER
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 表上有 BEFORE INSERT 触发器引用目标列
DROP TRIGGER IF EXISTS trg_tc_42_fct_0056_ip;
DROP TABLE IF EXISTS t1_tc_42_fct_0056_ip, t2_tc_42_fct_0056_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=04924789a163 factor=DEP_TRIGGER
CREATE TABLE t1_tc_42_fct_0056_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
CREATE TRIGGER trg_tc_42_fct_0056_ip BEFORE INSERT ON t1_tc_42_fct_0056_ip FOR EACH ROW SET NEW.pad = CONCAT('t', IFNULL(NEW.target,''));
INSERT INTO t1_tc_42_fct_0056_ip (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0056_ip (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0056_ip (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0056_ip MODIFY target INT, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0056-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0056_ip';
SELECT 'TC-42-FCT-0056-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0056_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）
DROP TRIGGER IF EXISTS trg_tc_42_fct_0056_ip;

-- Test Case: TC-42-FCT-0057-DF
-- Factor probe: DEP_TRIGGER
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 表上有 BEFORE INSERT 触发器引用目标列
DROP TRIGGER IF EXISTS trg_tc_42_fct_0057_df;
DROP TABLE IF EXISTS t1_tc_42_fct_0057_df, t2_tc_42_fct_0057_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=a5b0b373a0db factor=DEP_TRIGGER
CREATE TABLE t1_tc_42_fct_0057_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
CREATE TRIGGER trg_tc_42_fct_0057_df BEFORE INSERT ON t1_tc_42_fct_0057_df FOR EACH ROW SET NEW.pad = CONCAT('t', IFNULL(NEW.target,''));
INSERT INTO t1_tc_42_fct_0057_df (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0057_df (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0057_df (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0057_df MODIFY target INT;
SELECT 'TC-42-FCT-0057-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0057_df';
SELECT 'TC-42-FCT-0057-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0057_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）
DROP TRIGGER IF EXISTS trg_tc_42_fct_0057_df;

-- Test Case: TC-42-FCT-0058-IT
-- Factor probe: DEP_TRIGGER
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 表上有 BEFORE INSERT 触发器引用目标列
DROP TRIGGER IF EXISTS trg_tc_42_fct_0058_it;
DROP TABLE IF EXISTS t1_tc_42_fct_0058_it, t2_tc_42_fct_0058_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=12f114c460e1 factor=DEP_TRIGGER
CREATE TABLE t1_tc_42_fct_0058_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
CREATE TRIGGER trg_tc_42_fct_0058_it BEFORE INSERT ON t1_tc_42_fct_0058_it FOR EACH ROW SET NEW.pad = CONCAT('t', IFNULL(NEW.target,''));
INSERT INTO t1_tc_42_fct_0058_it (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0058_it (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0058_it (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0058_it MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0058-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0058_it';
SELECT 'TC-42-FCT-0058-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0058_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）
DROP TRIGGER IF EXISTS trg_tc_42_fct_0058_it;

-- Test Case: TC-42-FCT-0059-IP
-- Factor probe: DEP_TRIGGER
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 表上有 BEFORE INSERT 触发器引用目标列
DROP TRIGGER IF EXISTS trg_tc_42_fct_0059_ip;
DROP TABLE IF EXISTS t1_tc_42_fct_0059_ip, t2_tc_42_fct_0059_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=bf659afca2d5 factor=DEP_TRIGGER
CREATE TABLE t1_tc_42_fct_0059_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
CREATE TRIGGER trg_tc_42_fct_0059_ip BEFORE INSERT ON t1_tc_42_fct_0059_ip FOR EACH ROW SET NEW.pad = CONCAT('t', IFNULL(NEW.target,''));
INSERT INTO t1_tc_42_fct_0059_ip (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0059_ip (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0059_ip (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0059_ip MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0059-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0059_ip';
SELECT 'TC-42-FCT-0059-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0059_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）
DROP TRIGGER IF EXISTS trg_tc_42_fct_0059_ip;

-- Test Case: TC-42-FCT-0060-DF
-- Factor probe: DEP_TRIGGER
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 表上有 BEFORE INSERT 触发器引用目标列
DROP TRIGGER IF EXISTS trg_tc_42_fct_0060_df;
DROP TABLE IF EXISTS t1_tc_42_fct_0060_df, t2_tc_42_fct_0060_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=dc80b1e99bca factor=DEP_TRIGGER
CREATE TABLE t1_tc_42_fct_0060_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
CREATE TRIGGER trg_tc_42_fct_0060_df BEFORE INSERT ON t1_tc_42_fct_0060_df FOR EACH ROW SET NEW.pad = CONCAT('t', IFNULL(NEW.target,''));
INSERT INTO t1_tc_42_fct_0060_df (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0060_df (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0060_df (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0060_df MODIFY target VARCHAR(200) CHARACTER SET utf8mb4;
SELECT 'TC-42-FCT-0060-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0060_df';
SELECT 'TC-42-FCT-0060-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0060_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）
DROP TRIGGER IF EXISTS trg_tc_42_fct_0060_df;

-- Test Case: TC-42-FCT-0061-IT
-- Factor probe: DEP_TRIGGER
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 表上有 BEFORE INSERT 触发器引用目标列
DROP TRIGGER IF EXISTS trg_tc_42_fct_0061_it;
DROP TABLE IF EXISTS t1_tc_42_fct_0061_it, t2_tc_42_fct_0061_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=999c9e446113 factor=DEP_TRIGGER
CREATE TABLE t1_tc_42_fct_0061_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
CREATE TRIGGER trg_tc_42_fct_0061_it BEFORE INSERT ON t1_tc_42_fct_0061_it FOR EACH ROW SET NEW.pad = CONCAT('t', IFNULL(NEW.target,''));
INSERT INTO t1_tc_42_fct_0061_it (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0061_it (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0061_it (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0061_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0061-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0061_it';
SELECT 'TC-42-FCT-0061-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0061_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）
DROP TRIGGER IF EXISTS trg_tc_42_fct_0061_it;

-- Test Case: TC-42-FCT-0062-IP
-- Factor probe: DEP_TRIGGER
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 表上有 BEFORE INSERT 触发器引用目标列
DROP TRIGGER IF EXISTS trg_tc_42_fct_0062_ip;
DROP TABLE IF EXISTS t1_tc_42_fct_0062_ip, t2_tc_42_fct_0062_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=2ab5dc29bed2 factor=DEP_TRIGGER
CREATE TABLE t1_tc_42_fct_0062_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
CREATE TRIGGER trg_tc_42_fct_0062_ip BEFORE INSERT ON t1_tc_42_fct_0062_ip FOR EACH ROW SET NEW.pad = CONCAT('t', IFNULL(NEW.target,''));
INSERT INTO t1_tc_42_fct_0062_ip (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0062_ip (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0062_ip (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0062_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0062-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0062_ip';
SELECT 'TC-42-FCT-0062-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0062_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）
DROP TRIGGER IF EXISTS trg_tc_42_fct_0062_ip;

-- Test Case: TC-42-FCT-0063-DF
-- Factor probe: DEP_TRIGGER
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 表上有 BEFORE INSERT 触发器引用目标列
DROP TRIGGER IF EXISTS trg_tc_42_fct_0063_df;
DROP TABLE IF EXISTS t1_tc_42_fct_0063_df, t2_tc_42_fct_0063_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=5115cd77e6d3 factor=DEP_TRIGGER
CREATE TABLE t1_tc_42_fct_0063_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
CREATE TRIGGER trg_tc_42_fct_0063_df BEFORE INSERT ON t1_tc_42_fct_0063_df FOR EACH ROW SET NEW.pad = CONCAT('t', IFNULL(NEW.target,''));
INSERT INTO t1_tc_42_fct_0063_df (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0063_df (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0063_df (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0063_df MODIFY target CHAR(2) CHARACTER SET latin1;
SELECT 'TC-42-FCT-0063-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0063_df';
SELECT 'TC-42-FCT-0063-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0063_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）
DROP TRIGGER IF EXISTS trg_tc_42_fct_0063_df;

-- Test Case: TC-42-FCT-0064-IT
-- Factor probe: DEP_VIEW
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 存在依赖目标列的视图
DROP VIEW IF EXISTS vw_tc_42_fct_0064_it;
DROP TABLE IF EXISTS t1_tc_42_fct_0064_it, t2_tc_42_fct_0064_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=3a4a13634fc6 factor=DEP_VIEW
CREATE TABLE t1_tc_42_fct_0064_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
CREATE OR REPLACE VIEW vw_tc_42_fct_0064_it AS SELECT id, target FROM t1_tc_42_fct_0064_it;
INSERT INTO t1_tc_42_fct_0064_it (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0064_it (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0064_it (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0064_it MODIFY target INT, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0064-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0064_it';
SELECT 'TC-42-FCT-0064-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0064_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）
DROP VIEW IF EXISTS vw_tc_42_fct_0064_it;

-- Test Case: TC-42-FCT-0065-IP
-- Factor probe: DEP_VIEW
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 存在依赖目标列的视图
DROP VIEW IF EXISTS vw_tc_42_fct_0065_ip;
DROP TABLE IF EXISTS t1_tc_42_fct_0065_ip, t2_tc_42_fct_0065_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=2c3bb9ea7ea1 factor=DEP_VIEW
CREATE TABLE t1_tc_42_fct_0065_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
CREATE OR REPLACE VIEW vw_tc_42_fct_0065_ip AS SELECT id, target FROM t1_tc_42_fct_0065_ip;
INSERT INTO t1_tc_42_fct_0065_ip (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0065_ip (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0065_ip (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0065_ip MODIFY target INT, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0065-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0065_ip';
SELECT 'TC-42-FCT-0065-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0065_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）
DROP VIEW IF EXISTS vw_tc_42_fct_0065_ip;

-- Test Case: TC-42-FCT-0066-DF
-- Factor probe: DEP_VIEW
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 存在依赖目标列的视图
DROP VIEW IF EXISTS vw_tc_42_fct_0066_df;
DROP TABLE IF EXISTS t1_tc_42_fct_0066_df, t2_tc_42_fct_0066_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=2ac522297ad3 factor=DEP_VIEW
CREATE TABLE t1_tc_42_fct_0066_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
CREATE OR REPLACE VIEW vw_tc_42_fct_0066_df AS SELECT id, target FROM t1_tc_42_fct_0066_df;
INSERT INTO t1_tc_42_fct_0066_df (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0066_df (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0066_df (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0066_df MODIFY target INT;
SELECT 'TC-42-FCT-0066-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0066_df';
SELECT 'TC-42-FCT-0066-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0066_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）
DROP VIEW IF EXISTS vw_tc_42_fct_0066_df;

-- Test Case: TC-42-FCT-0067-IT
-- Factor probe: DEP_VIEW
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 存在依赖目标列的视图
DROP VIEW IF EXISTS vw_tc_42_fct_0067_it;
DROP TABLE IF EXISTS t1_tc_42_fct_0067_it, t2_tc_42_fct_0067_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=5d8a718ef08c factor=DEP_VIEW
CREATE TABLE t1_tc_42_fct_0067_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
CREATE OR REPLACE VIEW vw_tc_42_fct_0067_it AS SELECT id, target FROM t1_tc_42_fct_0067_it;
INSERT INTO t1_tc_42_fct_0067_it (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0067_it (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0067_it (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0067_it MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0067-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0067_it';
SELECT 'TC-42-FCT-0067-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0067_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）
DROP VIEW IF EXISTS vw_tc_42_fct_0067_it;

-- Test Case: TC-42-FCT-0068-IP
-- Factor probe: DEP_VIEW
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 存在依赖目标列的视图
DROP VIEW IF EXISTS vw_tc_42_fct_0068_ip;
DROP TABLE IF EXISTS t1_tc_42_fct_0068_ip, t2_tc_42_fct_0068_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=1324a1027222 factor=DEP_VIEW
CREATE TABLE t1_tc_42_fct_0068_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
CREATE OR REPLACE VIEW vw_tc_42_fct_0068_ip AS SELECT id, target FROM t1_tc_42_fct_0068_ip;
INSERT INTO t1_tc_42_fct_0068_ip (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0068_ip (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0068_ip (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0068_ip MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0068-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0068_ip';
SELECT 'TC-42-FCT-0068-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0068_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）
DROP VIEW IF EXISTS vw_tc_42_fct_0068_ip;

-- Test Case: TC-42-FCT-0069-DF
-- Factor probe: DEP_VIEW
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 存在依赖目标列的视图
DROP VIEW IF EXISTS vw_tc_42_fct_0069_df;
DROP TABLE IF EXISTS t1_tc_42_fct_0069_df, t2_tc_42_fct_0069_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=957d3948d536 factor=DEP_VIEW
CREATE TABLE t1_tc_42_fct_0069_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
CREATE OR REPLACE VIEW vw_tc_42_fct_0069_df AS SELECT id, target FROM t1_tc_42_fct_0069_df;
INSERT INTO t1_tc_42_fct_0069_df (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0069_df (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0069_df (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0069_df MODIFY target VARCHAR(200) CHARACTER SET utf8mb4;
SELECT 'TC-42-FCT-0069-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0069_df';
SELECT 'TC-42-FCT-0069-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0069_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）
DROP VIEW IF EXISTS vw_tc_42_fct_0069_df;

-- Test Case: TC-42-FCT-0070-IT
-- Factor probe: DEP_VIEW
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 存在依赖目标列的视图
DROP VIEW IF EXISTS vw_tc_42_fct_0070_it;
DROP TABLE IF EXISTS t1_tc_42_fct_0070_it, t2_tc_42_fct_0070_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=d74dca5bee1a factor=DEP_VIEW
CREATE TABLE t1_tc_42_fct_0070_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
CREATE OR REPLACE VIEW vw_tc_42_fct_0070_it AS SELECT id, target FROM t1_tc_42_fct_0070_it;
INSERT INTO t1_tc_42_fct_0070_it (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0070_it (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0070_it (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0070_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0070-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0070_it';
SELECT 'TC-42-FCT-0070-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0070_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）
DROP VIEW IF EXISTS vw_tc_42_fct_0070_it;

-- Test Case: TC-42-FCT-0071-IP
-- Factor probe: DEP_VIEW
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 存在依赖目标列的视图
DROP VIEW IF EXISTS vw_tc_42_fct_0071_ip;
DROP TABLE IF EXISTS t1_tc_42_fct_0071_ip, t2_tc_42_fct_0071_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=01e6c08b2b04 factor=DEP_VIEW
CREATE TABLE t1_tc_42_fct_0071_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
CREATE OR REPLACE VIEW vw_tc_42_fct_0071_ip AS SELECT id, target FROM t1_tc_42_fct_0071_ip;
INSERT INTO t1_tc_42_fct_0071_ip (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0071_ip (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0071_ip (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0071_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0071-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0071_ip';
SELECT 'TC-42-FCT-0071-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0071_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）
DROP VIEW IF EXISTS vw_tc_42_fct_0071_ip;

-- Test Case: TC-42-FCT-0072-DF
-- Factor probe: DEP_VIEW
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 存在依赖目标列的视图
DROP VIEW IF EXISTS vw_tc_42_fct_0072_df;
DROP TABLE IF EXISTS t1_tc_42_fct_0072_df, t2_tc_42_fct_0072_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=2b603dc08394 factor=DEP_VIEW
CREATE TABLE t1_tc_42_fct_0072_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
CREATE OR REPLACE VIEW vw_tc_42_fct_0072_df AS SELECT id, target FROM t1_tc_42_fct_0072_df;
INSERT INTO t1_tc_42_fct_0072_df (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0072_df (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0072_df (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0072_df MODIFY target CHAR(2) CHARACTER SET latin1;
SELECT 'TC-42-FCT-0072-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0072_df';
SELECT 'TC-42-FCT-0072-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0072_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）
DROP VIEW IF EXISTS vw_tc_42_fct_0072_df;

-- Test Case: TC-42-FCT-0073-IT
-- Factor probe: DEP_GEN_VIRTUAL_IDX
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: VIRTUAL 生成列 + 生成列索引（生成列不得引用自增列）
DROP TABLE IF EXISTS t1_tc_42_fct_0073_it, t2_tc_42_fct_0073_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=62dd534ca207 factor=DEP_GEN_VIRTUAL_IDX
CREATE TABLE t1_tc_42_fct_0073_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  seed INT DEFAULT 1, vcol BIGINT AS (seed * 2) VIRTUAL,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_v (vcol),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0073_it (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0073_it (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0073_it (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0073_it MODIFY target INT, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0073-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0073_it';
SELECT 'TC-42-FCT-0073-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0073_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0074-IP
-- Factor probe: DEP_GEN_VIRTUAL_IDX
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: VIRTUAL 生成列 + 生成列索引（生成列不得引用自增列）
DROP TABLE IF EXISTS t1_tc_42_fct_0074_ip, t2_tc_42_fct_0074_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=fed6627db8d4 factor=DEP_GEN_VIRTUAL_IDX
CREATE TABLE t1_tc_42_fct_0074_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  seed INT DEFAULT 1, vcol BIGINT AS (seed * 2) VIRTUAL,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_v (vcol),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0074_ip (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0074_ip (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0074_ip (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0074_ip MODIFY target INT, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0074-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0074_ip';
SELECT 'TC-42-FCT-0074-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0074_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0075-DF
-- Factor probe: DEP_GEN_VIRTUAL_IDX
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: VIRTUAL 生成列 + 生成列索引（生成列不得引用自增列）
DROP TABLE IF EXISTS t1_tc_42_fct_0075_df, t2_tc_42_fct_0075_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=07a90af230e9 factor=DEP_GEN_VIRTUAL_IDX
CREATE TABLE t1_tc_42_fct_0075_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  seed INT DEFAULT 1, vcol BIGINT AS (seed * 2) VIRTUAL,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_v (vcol),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0075_df (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0075_df (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0075_df (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0075_df MODIFY target INT;
SELECT 'TC-42-FCT-0075-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0075_df';
SELECT 'TC-42-FCT-0075-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0075_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0076-IT
-- Factor probe: DEP_GEN_VIRTUAL_IDX
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: VIRTUAL 生成列 + 生成列索引（生成列不得引用自增列）
DROP TABLE IF EXISTS t1_tc_42_fct_0076_it, t2_tc_42_fct_0076_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=59e8b949d088 factor=DEP_GEN_VIRTUAL_IDX
CREATE TABLE t1_tc_42_fct_0076_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  seed INT DEFAULT 1, vcol BIGINT AS (seed * 2) VIRTUAL,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_v (vcol),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0076_it (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0076_it (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0076_it (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0076_it MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0076-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0076_it';
SELECT 'TC-42-FCT-0076-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0076_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0077-IP
-- Factor probe: DEP_GEN_VIRTUAL_IDX
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: VIRTUAL 生成列 + 生成列索引（生成列不得引用自增列）
DROP TABLE IF EXISTS t1_tc_42_fct_0077_ip, t2_tc_42_fct_0077_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=080d29204193 factor=DEP_GEN_VIRTUAL_IDX
CREATE TABLE t1_tc_42_fct_0077_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  seed INT DEFAULT 1, vcol BIGINT AS (seed * 2) VIRTUAL,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_v (vcol),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0077_ip (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0077_ip (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0077_ip (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0077_ip MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0077-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0077_ip';
SELECT 'TC-42-FCT-0077-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0077_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0078-DF
-- Factor probe: DEP_GEN_VIRTUAL_IDX
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: VIRTUAL 生成列 + 生成列索引（生成列不得引用自增列）
DROP TABLE IF EXISTS t1_tc_42_fct_0078_df, t2_tc_42_fct_0078_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=c62286e8c99c factor=DEP_GEN_VIRTUAL_IDX
CREATE TABLE t1_tc_42_fct_0078_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  seed INT DEFAULT 1, vcol BIGINT AS (seed * 2) VIRTUAL,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_v (vcol),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0078_df (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0078_df (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0078_df (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0078_df MODIFY target VARCHAR(200) CHARACTER SET utf8mb4;
SELECT 'TC-42-FCT-0078-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0078_df';
SELECT 'TC-42-FCT-0078-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0078_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0079-IT
-- Factor probe: DEP_GEN_VIRTUAL_IDX
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: VIRTUAL 生成列 + 生成列索引（生成列不得引用自增列）
DROP TABLE IF EXISTS t1_tc_42_fct_0079_it, t2_tc_42_fct_0079_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=66c61ce3edfb factor=DEP_GEN_VIRTUAL_IDX
CREATE TABLE t1_tc_42_fct_0079_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  seed INT DEFAULT 1, vcol BIGINT AS (seed * 2) VIRTUAL,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_v (vcol),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0079_it (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0079_it (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0079_it (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0079_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0079-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0079_it';
SELECT 'TC-42-FCT-0079-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0079_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0080-IP
-- Factor probe: DEP_GEN_VIRTUAL_IDX
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: VIRTUAL 生成列 + 生成列索引（生成列不得引用自增列）
DROP TABLE IF EXISTS t1_tc_42_fct_0080_ip, t2_tc_42_fct_0080_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=539274f7d158 factor=DEP_GEN_VIRTUAL_IDX
CREATE TABLE t1_tc_42_fct_0080_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  seed INT DEFAULT 1, vcol BIGINT AS (seed * 2) VIRTUAL,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_v (vcol),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0080_ip (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0080_ip (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0080_ip (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0080_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0080-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0080_ip';
SELECT 'TC-42-FCT-0080-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0080_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0081-DF
-- Factor probe: DEP_GEN_VIRTUAL_IDX
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: VIRTUAL 生成列 + 生成列索引（生成列不得引用自增列）
DROP TABLE IF EXISTS t1_tc_42_fct_0081_df, t2_tc_42_fct_0081_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=76b0c1aca4cc factor=DEP_GEN_VIRTUAL_IDX
CREATE TABLE t1_tc_42_fct_0081_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  seed INT DEFAULT 1, vcol BIGINT AS (seed * 2) VIRTUAL,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_v (vcol),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0081_df (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0081_df (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0081_df (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0081_df MODIFY target CHAR(2) CHARACTER SET latin1;
SELECT 'TC-42-FCT-0081-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0081_df';
SELECT 'TC-42-FCT-0081-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0081_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0082-IT
-- Factor probe: OPT_ROW_COMPRESSED
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: FAIL
-- Transition ID: INT-S-3-4
-- Factor note: COMPRESSED 行格式（PRD 排除项，必须作为负向用例存在）
DROP TABLE IF EXISTS t1_tc_42_fct_0082_it, t2_tc_42_fct_0082_it;
-- @expect alter=FAIL build=SUCCESS assertions=2 alter_sha=fd88ed9bca5e factor=OPT_ROW_COMPRESSED errno=[1845]
CREATE TABLE t1_tc_42_fct_0082_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB ROW_FORMAT=COMPRESSED KEY_BLOCK_SIZE=8;
INSERT INTO t1_tc_42_fct_0082_it (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0082_it (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0082_it (target) VALUES (1);
-- ALTER expected FAIL (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0082_it MODIFY target INT, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0082-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0082_it';
SELECT 'TC-42-FCT-0082-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='mediumint','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=mediumint nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0082_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0083-IP
-- Factor probe: OPT_ROW_COMPRESSED
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: COMPRESSED 行格式（PRD 排除项，必须作为负向用例存在）
DROP TABLE IF EXISTS t1_tc_42_fct_0083_ip, t2_tc_42_fct_0083_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=73bd95210f03 factor=OPT_ROW_COMPRESSED
CREATE TABLE t1_tc_42_fct_0083_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB ROW_FORMAT=COMPRESSED KEY_BLOCK_SIZE=8;
INSERT INTO t1_tc_42_fct_0083_ip (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0083_ip (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0083_ip (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0083_ip MODIFY target INT, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0083-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0083_ip';
SELECT 'TC-42-FCT-0083-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0083_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0084-DF
-- Factor probe: OPT_ROW_COMPRESSED
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: COMPRESSED 行格式（PRD 排除项，必须作为负向用例存在）
DROP TABLE IF EXISTS t1_tc_42_fct_0084_df, t2_tc_42_fct_0084_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=269e8342ca94 factor=OPT_ROW_COMPRESSED
CREATE TABLE t1_tc_42_fct_0084_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB ROW_FORMAT=COMPRESSED KEY_BLOCK_SIZE=8;
INSERT INTO t1_tc_42_fct_0084_df (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0084_df (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0084_df (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0084_df MODIFY target INT;
SELECT 'TC-42-FCT-0084-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0084_df';
SELECT 'TC-42-FCT-0084-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0084_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0085-IT
-- Factor probe: OPT_ROW_COMPRESSED
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: FAIL
-- Transition ID: VC-07
-- Factor note: COMPRESSED 行格式（PRD 排除项，必须作为负向用例存在）
DROP TABLE IF EXISTS t1_tc_42_fct_0085_it, t2_tc_42_fct_0085_it;
-- @expect alter=FAIL build=SUCCESS assertions=2 alter_sha=1d0fb9fb220b factor=OPT_ROW_COMPRESSED errno=[1845]
CREATE TABLE t1_tc_42_fct_0085_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB ROW_FORMAT=COMPRESSED KEY_BLOCK_SIZE=8;
INSERT INTO t1_tc_42_fct_0085_it (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0085_it (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0085_it (target) VALUES ('00000002');
-- ALTER expected FAIL (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0085_it MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0085-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0085_it';
SELECT 'TC-42-FCT-0085-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(100)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(100) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0085_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0086-IP
-- Factor probe: OPT_ROW_COMPRESSED
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: COMPRESSED 行格式（PRD 排除项，必须作为负向用例存在）
DROP TABLE IF EXISTS t1_tc_42_fct_0086_ip, t2_tc_42_fct_0086_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=1695afb2e54e factor=OPT_ROW_COMPRESSED
CREATE TABLE t1_tc_42_fct_0086_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB ROW_FORMAT=COMPRESSED KEY_BLOCK_SIZE=8;
INSERT INTO t1_tc_42_fct_0086_ip (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0086_ip (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0086_ip (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0086_ip MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0086-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0086_ip';
SELECT 'TC-42-FCT-0086-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0086_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0087-DF
-- Factor probe: OPT_ROW_COMPRESSED
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: COMPRESSED 行格式（PRD 排除项，必须作为负向用例存在）
DROP TABLE IF EXISTS t1_tc_42_fct_0087_df, t2_tc_42_fct_0087_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=bf24544817ab factor=OPT_ROW_COMPRESSED
CREATE TABLE t1_tc_42_fct_0087_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB ROW_FORMAT=COMPRESSED KEY_BLOCK_SIZE=8;
INSERT INTO t1_tc_42_fct_0087_df (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0087_df (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0087_df (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0087_df MODIFY target VARCHAR(200) CHARACTER SET utf8mb4;
SELECT 'TC-42-FCT-0087-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0087_df';
SELECT 'TC-42-FCT-0087-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0087_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0088-IT
-- Factor probe: OPT_ROW_COMPRESSED
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: FAIL
-- Transition ID: CHAR-01
-- Factor note: COMPRESSED 行格式（PRD 排除项，必须作为负向用例存在）
DROP TABLE IF EXISTS t1_tc_42_fct_0088_it, t2_tc_42_fct_0088_it;
-- @expect alter=FAIL build=SUCCESS assertions=2 alter_sha=41fa80505565 factor=OPT_ROW_COMPRESSED errno=[1845]
CREATE TABLE t1_tc_42_fct_0088_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB ROW_FORMAT=COMPRESSED KEY_BLOCK_SIZE=8;
INSERT INTO t1_tc_42_fct_0088_it (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0088_it (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0088_it (target) VALUES ('2');
-- ALTER expected FAIL (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0088_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0088-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0088_it';
SELECT 'TC-42-FCT-0088-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(1)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(1) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0088_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0089-IP
-- Factor probe: OPT_ROW_COMPRESSED
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: COMPRESSED 行格式（PRD 排除项，必须作为负向用例存在）
DROP TABLE IF EXISTS t1_tc_42_fct_0089_ip, t2_tc_42_fct_0089_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=ffbe25df9d2b factor=OPT_ROW_COMPRESSED
CREATE TABLE t1_tc_42_fct_0089_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB ROW_FORMAT=COMPRESSED KEY_BLOCK_SIZE=8;
INSERT INTO t1_tc_42_fct_0089_ip (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0089_ip (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0089_ip (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0089_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0089-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0089_ip';
SELECT 'TC-42-FCT-0089-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0089_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0090-DF
-- Factor probe: OPT_ROW_COMPRESSED
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: COMPRESSED 行格式（PRD 排除项，必须作为负向用例存在）
DROP TABLE IF EXISTS t1_tc_42_fct_0090_df, t2_tc_42_fct_0090_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=6a0cf5a8d92d factor=OPT_ROW_COMPRESSED
CREATE TABLE t1_tc_42_fct_0090_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB ROW_FORMAT=COMPRESSED KEY_BLOCK_SIZE=8;
INSERT INTO t1_tc_42_fct_0090_df (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0090_df (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0090_df (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0090_df MODIFY target CHAR(2) CHARACTER SET latin1;
SELECT 'TC-42-FCT-0090-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0090_df';
SELECT 'TC-42-FCT-0090-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0090_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0091-IT
-- Factor probe: OPT_PAGE_COMPRESSION
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: InnoDB 页压缩
DROP TABLE IF EXISTS t1_tc_42_fct_0091_it, t2_tc_42_fct_0091_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=58a0ec1bece6 factor=OPT_PAGE_COMPRESSION
CREATE TABLE t1_tc_42_fct_0091_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB COMPRESSION='zlib';
INSERT INTO t1_tc_42_fct_0091_it (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0091_it (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0091_it (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0091_it MODIFY target INT, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0091-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0091_it';
SELECT 'TC-42-FCT-0091-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0091_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0092-IP
-- Factor probe: OPT_PAGE_COMPRESSION
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: InnoDB 页压缩
DROP TABLE IF EXISTS t1_tc_42_fct_0092_ip, t2_tc_42_fct_0092_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=539a5d6fa435 factor=OPT_PAGE_COMPRESSION
CREATE TABLE t1_tc_42_fct_0092_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB COMPRESSION='zlib';
INSERT INTO t1_tc_42_fct_0092_ip (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0092_ip (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0092_ip (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0092_ip MODIFY target INT, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0092-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0092_ip';
SELECT 'TC-42-FCT-0092-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0092_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0093-DF
-- Factor probe: OPT_PAGE_COMPRESSION
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: InnoDB 页压缩
DROP TABLE IF EXISTS t1_tc_42_fct_0093_df, t2_tc_42_fct_0093_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=94729d3801b9 factor=OPT_PAGE_COMPRESSION
CREATE TABLE t1_tc_42_fct_0093_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB COMPRESSION='zlib';
INSERT INTO t1_tc_42_fct_0093_df (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0093_df (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0093_df (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0093_df MODIFY target INT;
SELECT 'TC-42-FCT-0093-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0093_df';
SELECT 'TC-42-FCT-0093-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0093_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0094-IT
-- Factor probe: OPT_PAGE_COMPRESSION
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: InnoDB 页压缩
DROP TABLE IF EXISTS t1_tc_42_fct_0094_it, t2_tc_42_fct_0094_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=c7b828a6ad41 factor=OPT_PAGE_COMPRESSION
CREATE TABLE t1_tc_42_fct_0094_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB COMPRESSION='zlib';
INSERT INTO t1_tc_42_fct_0094_it (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0094_it (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0094_it (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0094_it MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0094-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0094_it';
SELECT 'TC-42-FCT-0094-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0094_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0095-IP
-- Factor probe: OPT_PAGE_COMPRESSION
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: InnoDB 页压缩
DROP TABLE IF EXISTS t1_tc_42_fct_0095_ip, t2_tc_42_fct_0095_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=3c469ec85d2e factor=OPT_PAGE_COMPRESSION
CREATE TABLE t1_tc_42_fct_0095_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB COMPRESSION='zlib';
INSERT INTO t1_tc_42_fct_0095_ip (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0095_ip (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0095_ip (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0095_ip MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0095-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0095_ip';
SELECT 'TC-42-FCT-0095-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0095_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0096-DF
-- Factor probe: OPT_PAGE_COMPRESSION
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: InnoDB 页压缩
DROP TABLE IF EXISTS t1_tc_42_fct_0096_df, t2_tc_42_fct_0096_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=ec6faca1871e factor=OPT_PAGE_COMPRESSION
CREATE TABLE t1_tc_42_fct_0096_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB COMPRESSION='zlib';
INSERT INTO t1_tc_42_fct_0096_df (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0096_df (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0096_df (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0096_df MODIFY target VARCHAR(200) CHARACTER SET utf8mb4;
SELECT 'TC-42-FCT-0096-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0096_df';
SELECT 'TC-42-FCT-0096-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0096_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0097-IT
-- Factor probe: OPT_PAGE_COMPRESSION
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: InnoDB 页压缩
DROP TABLE IF EXISTS t1_tc_42_fct_0097_it, t2_tc_42_fct_0097_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=8d02cabf1439 factor=OPT_PAGE_COMPRESSION
CREATE TABLE t1_tc_42_fct_0097_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB COMPRESSION='zlib';
INSERT INTO t1_tc_42_fct_0097_it (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0097_it (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0097_it (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0097_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0097-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0097_it';
SELECT 'TC-42-FCT-0097-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0097_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0098-IP
-- Factor probe: OPT_PAGE_COMPRESSION
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: InnoDB 页压缩
DROP TABLE IF EXISTS t1_tc_42_fct_0098_ip, t2_tc_42_fct_0098_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=9cedd6ff6cad factor=OPT_PAGE_COMPRESSION
CREATE TABLE t1_tc_42_fct_0098_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB COMPRESSION='zlib';
INSERT INTO t1_tc_42_fct_0098_ip (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0098_ip (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0098_ip (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0098_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0098-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0098_ip';
SELECT 'TC-42-FCT-0098-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0098_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0099-DF
-- Factor probe: OPT_PAGE_COMPRESSION
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: InnoDB 页压缩
DROP TABLE IF EXISTS t1_tc_42_fct_0099_df, t2_tc_42_fct_0099_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=5238929d7655 factor=OPT_PAGE_COMPRESSION
CREATE TABLE t1_tc_42_fct_0099_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB COMPRESSION='zlib';
INSERT INTO t1_tc_42_fct_0099_df (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0099_df (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0099_df (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0099_df MODIFY target CHAR(2) CHARACTER SET latin1;
SELECT 'TC-42-FCT-0099-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0099_df';
SELECT 'TC-42-FCT-0099-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0099_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0100-IT
-- Factor probe: OPT_ENCRYPTION
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: FAIL
-- Transition ID: INT-S-3-4
-- Factor note: 表空间加密（无 keyring 时应建表失败）
DROP TABLE IF EXISTS t1_tc_42_fct_0100_it, t2_tc_42_fct_0100_it;
-- @expect alter=N/A build=FAIL assertions=1 factor=OPT_ENCRYPTION
CREATE TABLE t1_tc_42_fct_0100_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB ENCRYPTION='Y';
SELECT 'TC-42-FCT-0100-IT#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor OPT_ENCRYPTION is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0100_it';

-- Test Case: TC-42-FCT-0101-IP
-- Factor probe: OPT_ENCRYPTION
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: FAIL
-- Transition ID: INT-S-3-4
-- Factor note: 表空间加密（无 keyring 时应建表失败）
DROP TABLE IF EXISTS t1_tc_42_fct_0101_ip, t2_tc_42_fct_0101_ip;
-- @expect alter=N/A build=FAIL assertions=1 factor=OPT_ENCRYPTION
CREATE TABLE t1_tc_42_fct_0101_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB ENCRYPTION='Y';
SELECT 'TC-42-FCT-0101-IP#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor OPT_ENCRYPTION is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0101_ip';

-- Test Case: TC-42-FCT-0102-DF
-- Factor probe: OPT_ENCRYPTION
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: FAIL
-- Transition ID: INT-S-3-4
-- Factor note: 表空间加密（无 keyring 时应建表失败）
DROP TABLE IF EXISTS t1_tc_42_fct_0102_df, t2_tc_42_fct_0102_df;
-- @expect alter=N/A build=FAIL assertions=1 factor=OPT_ENCRYPTION
CREATE TABLE t1_tc_42_fct_0102_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB ENCRYPTION='Y';
SELECT 'TC-42-FCT-0102-DF#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor OPT_ENCRYPTION is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0102_df';

-- Test Case: TC-42-FCT-0103-IT
-- Factor probe: OPT_ENCRYPTION
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: FAIL
-- Transition ID: VC-07
-- Factor note: 表空间加密（无 keyring 时应建表失败）
DROP TABLE IF EXISTS t1_tc_42_fct_0103_it, t2_tc_42_fct_0103_it;
-- @expect alter=N/A build=FAIL assertions=1 factor=OPT_ENCRYPTION
CREATE TABLE t1_tc_42_fct_0103_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB ENCRYPTION='Y';
SELECT 'TC-42-FCT-0103-IT#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor OPT_ENCRYPTION is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0103_it';

-- Test Case: TC-42-FCT-0104-IP
-- Factor probe: OPT_ENCRYPTION
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: FAIL
-- Transition ID: VC-07
-- Factor note: 表空间加密（无 keyring 时应建表失败）
DROP TABLE IF EXISTS t1_tc_42_fct_0104_ip, t2_tc_42_fct_0104_ip;
-- @expect alter=N/A build=FAIL assertions=1 factor=OPT_ENCRYPTION
CREATE TABLE t1_tc_42_fct_0104_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB ENCRYPTION='Y';
SELECT 'TC-42-FCT-0104-IP#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor OPT_ENCRYPTION is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0104_ip';

-- Test Case: TC-42-FCT-0105-DF
-- Factor probe: OPT_ENCRYPTION
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: FAIL
-- Transition ID: VC-07
-- Factor note: 表空间加密（无 keyring 时应建表失败）
DROP TABLE IF EXISTS t1_tc_42_fct_0105_df, t2_tc_42_fct_0105_df;
-- @expect alter=N/A build=FAIL assertions=1 factor=OPT_ENCRYPTION
CREATE TABLE t1_tc_42_fct_0105_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB ENCRYPTION='Y';
SELECT 'TC-42-FCT-0105-DF#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor OPT_ENCRYPTION is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0105_df';

-- Test Case: TC-42-FCT-0106-IT
-- Factor probe: OPT_ENCRYPTION
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: FAIL
-- Transition ID: CHAR-01
-- Factor note: 表空间加密（无 keyring 时应建表失败）
DROP TABLE IF EXISTS t1_tc_42_fct_0106_it, t2_tc_42_fct_0106_it;
-- @expect alter=N/A build=FAIL assertions=1 factor=OPT_ENCRYPTION
CREATE TABLE t1_tc_42_fct_0106_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB ENCRYPTION='Y';
SELECT 'TC-42-FCT-0106-IT#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor OPT_ENCRYPTION is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0106_it';

-- Test Case: TC-42-FCT-0107-IP
-- Factor probe: OPT_ENCRYPTION
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: FAIL
-- Transition ID: CHAR-01
-- Factor note: 表空间加密（无 keyring 时应建表失败）
DROP TABLE IF EXISTS t1_tc_42_fct_0107_ip, t2_tc_42_fct_0107_ip;
-- @expect alter=N/A build=FAIL assertions=1 factor=OPT_ENCRYPTION
CREATE TABLE t1_tc_42_fct_0107_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB ENCRYPTION='Y';
SELECT 'TC-42-FCT-0107-IP#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor OPT_ENCRYPTION is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0107_ip';

-- Test Case: TC-42-FCT-0108-DF
-- Factor probe: OPT_ENCRYPTION
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: FAIL
-- Transition ID: CHAR-01
-- Factor note: 表空间加密（无 keyring 时应建表失败）
DROP TABLE IF EXISTS t1_tc_42_fct_0108_df, t2_tc_42_fct_0108_df;
-- @expect alter=N/A build=FAIL assertions=1 factor=OPT_ENCRYPTION
CREATE TABLE t1_tc_42_fct_0108_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB ENCRYPTION='Y';
SELECT 'TC-42-FCT-0108-DF#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor OPT_ENCRYPTION is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0108_df';

-- Test Case: TC-42-FCT-0109-IT
-- Factor probe: OPT_TABLESPACE
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 显式表空间
DROP TABLE IF EXISTS t1_tc_42_fct_0109_it, t2_tc_42_fct_0109_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=2f680876e437 factor=OPT_TABLESPACE
CREATE TABLE t1_tc_42_fct_0109_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB TABLESPACE innodb_file_per_table;
INSERT INTO t1_tc_42_fct_0109_it (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0109_it (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0109_it (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0109_it MODIFY target INT, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0109-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0109_it';
SELECT 'TC-42-FCT-0109-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0109_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0110-IP
-- Factor probe: OPT_TABLESPACE
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 显式表空间
DROP TABLE IF EXISTS t1_tc_42_fct_0110_ip, t2_tc_42_fct_0110_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=82c4fce2d609 factor=OPT_TABLESPACE
CREATE TABLE t1_tc_42_fct_0110_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB TABLESPACE innodb_file_per_table;
INSERT INTO t1_tc_42_fct_0110_ip (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0110_ip (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0110_ip (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0110_ip MODIFY target INT, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0110-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0110_ip';
SELECT 'TC-42-FCT-0110-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0110_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0111-DF
-- Factor probe: OPT_TABLESPACE
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 显式表空间
DROP TABLE IF EXISTS t1_tc_42_fct_0111_df, t2_tc_42_fct_0111_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=c1a6e73c0b11 factor=OPT_TABLESPACE
CREATE TABLE t1_tc_42_fct_0111_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB TABLESPACE innodb_file_per_table;
INSERT INTO t1_tc_42_fct_0111_df (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0111_df (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0111_df (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0111_df MODIFY target INT;
SELECT 'TC-42-FCT-0111-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0111_df';
SELECT 'TC-42-FCT-0111-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0111_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0112-IT
-- Factor probe: OPT_TABLESPACE
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 显式表空间
DROP TABLE IF EXISTS t1_tc_42_fct_0112_it, t2_tc_42_fct_0112_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=5ba899874ca6 factor=OPT_TABLESPACE
CREATE TABLE t1_tc_42_fct_0112_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB TABLESPACE innodb_file_per_table;
INSERT INTO t1_tc_42_fct_0112_it (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0112_it (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0112_it (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0112_it MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0112-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0112_it';
SELECT 'TC-42-FCT-0112-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0112_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0113-IP
-- Factor probe: OPT_TABLESPACE
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 显式表空间
DROP TABLE IF EXISTS t1_tc_42_fct_0113_ip, t2_tc_42_fct_0113_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=d24e74d2e7f1 factor=OPT_TABLESPACE
CREATE TABLE t1_tc_42_fct_0113_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB TABLESPACE innodb_file_per_table;
INSERT INTO t1_tc_42_fct_0113_ip (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0113_ip (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0113_ip (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0113_ip MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0113-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0113_ip';
SELECT 'TC-42-FCT-0113-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0113_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0114-DF
-- Factor probe: OPT_TABLESPACE
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 显式表空间
DROP TABLE IF EXISTS t1_tc_42_fct_0114_df, t2_tc_42_fct_0114_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=b06d06a66d32 factor=OPT_TABLESPACE
CREATE TABLE t1_tc_42_fct_0114_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB TABLESPACE innodb_file_per_table;
INSERT INTO t1_tc_42_fct_0114_df (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0114_df (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0114_df (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0114_df MODIFY target VARCHAR(200) CHARACTER SET utf8mb4;
SELECT 'TC-42-FCT-0114-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0114_df';
SELECT 'TC-42-FCT-0114-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0114_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0115-IT
-- Factor probe: OPT_TABLESPACE
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 显式表空间
DROP TABLE IF EXISTS t1_tc_42_fct_0115_it, t2_tc_42_fct_0115_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=77aadb0ee817 factor=OPT_TABLESPACE
CREATE TABLE t1_tc_42_fct_0115_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB TABLESPACE innodb_file_per_table;
INSERT INTO t1_tc_42_fct_0115_it (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0115_it (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0115_it (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0115_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0115-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0115_it';
SELECT 'TC-42-FCT-0115-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0115_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0116-IP
-- Factor probe: OPT_TABLESPACE
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 显式表空间
DROP TABLE IF EXISTS t1_tc_42_fct_0116_ip, t2_tc_42_fct_0116_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=029c37e8029c factor=OPT_TABLESPACE
CREATE TABLE t1_tc_42_fct_0116_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB TABLESPACE innodb_file_per_table;
INSERT INTO t1_tc_42_fct_0116_ip (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0116_ip (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0116_ip (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0116_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0116-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0116_ip';
SELECT 'TC-42-FCT-0116-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0116_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0117-DF
-- Factor probe: OPT_TABLESPACE
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 显式表空间
DROP TABLE IF EXISTS t1_tc_42_fct_0117_df, t2_tc_42_fct_0117_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=78731294b6a4 factor=OPT_TABLESPACE
CREATE TABLE t1_tc_42_fct_0117_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB TABLESPACE innodb_file_per_table;
INSERT INTO t1_tc_42_fct_0117_df (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0117_df (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0117_df (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0117_df MODIFY target CHAR(2) CHARACTER SET latin1;
SELECT 'TC-42-FCT-0117-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0117_df';
SELECT 'TC-42-FCT-0117-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0117_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0118-IT
-- Factor probe: OPT_STATS_PERSISTENT
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 统计信息持久化且关闭自动重算（DDL 后统计信息是否更新）
DROP TABLE IF EXISTS t1_tc_42_fct_0118_it, t2_tc_42_fct_0118_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=fe90fff0ba39 factor=OPT_STATS_PERSISTENT
CREATE TABLE t1_tc_42_fct_0118_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB STATS_PERSISTENT=1 STATS_AUTO_RECALC=0;
INSERT INTO t1_tc_42_fct_0118_it (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0118_it (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0118_it (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0118_it MODIFY target INT, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0118-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0118_it';
SELECT 'TC-42-FCT-0118-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0118_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0119-IP
-- Factor probe: OPT_STATS_PERSISTENT
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 统计信息持久化且关闭自动重算（DDL 后统计信息是否更新）
DROP TABLE IF EXISTS t1_tc_42_fct_0119_ip, t2_tc_42_fct_0119_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=18df22c64bef factor=OPT_STATS_PERSISTENT
CREATE TABLE t1_tc_42_fct_0119_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB STATS_PERSISTENT=1 STATS_AUTO_RECALC=0;
INSERT INTO t1_tc_42_fct_0119_ip (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0119_ip (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0119_ip (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0119_ip MODIFY target INT, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0119-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0119_ip';
SELECT 'TC-42-FCT-0119-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0119_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0120-DF
-- Factor probe: OPT_STATS_PERSISTENT
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 统计信息持久化且关闭自动重算（DDL 后统计信息是否更新）
DROP TABLE IF EXISTS t1_tc_42_fct_0120_df, t2_tc_42_fct_0120_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=c79a5b4d8465 factor=OPT_STATS_PERSISTENT
CREATE TABLE t1_tc_42_fct_0120_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB STATS_PERSISTENT=1 STATS_AUTO_RECALC=0;
INSERT INTO t1_tc_42_fct_0120_df (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0120_df (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0120_df (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0120_df MODIFY target INT;
SELECT 'TC-42-FCT-0120-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0120_df';
SELECT 'TC-42-FCT-0120-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0120_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0121-IT
-- Factor probe: OPT_STATS_PERSISTENT
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 统计信息持久化且关闭自动重算（DDL 后统计信息是否更新）
DROP TABLE IF EXISTS t1_tc_42_fct_0121_it, t2_tc_42_fct_0121_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=083d04671133 factor=OPT_STATS_PERSISTENT
CREATE TABLE t1_tc_42_fct_0121_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB STATS_PERSISTENT=1 STATS_AUTO_RECALC=0;
INSERT INTO t1_tc_42_fct_0121_it (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0121_it (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0121_it (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0121_it MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0121-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0121_it';
SELECT 'TC-42-FCT-0121-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0121_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0122-IP
-- Factor probe: OPT_STATS_PERSISTENT
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 统计信息持久化且关闭自动重算（DDL 后统计信息是否更新）
DROP TABLE IF EXISTS t1_tc_42_fct_0122_ip, t2_tc_42_fct_0122_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=bd4362086295 factor=OPT_STATS_PERSISTENT
CREATE TABLE t1_tc_42_fct_0122_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB STATS_PERSISTENT=1 STATS_AUTO_RECALC=0;
INSERT INTO t1_tc_42_fct_0122_ip (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0122_ip (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0122_ip (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0122_ip MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0122-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0122_ip';
SELECT 'TC-42-FCT-0122-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0122_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0123-DF
-- Factor probe: OPT_STATS_PERSISTENT
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 统计信息持久化且关闭自动重算（DDL 后统计信息是否更新）
DROP TABLE IF EXISTS t1_tc_42_fct_0123_df, t2_tc_42_fct_0123_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=07080dd902f4 factor=OPT_STATS_PERSISTENT
CREATE TABLE t1_tc_42_fct_0123_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB STATS_PERSISTENT=1 STATS_AUTO_RECALC=0;
INSERT INTO t1_tc_42_fct_0123_df (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0123_df (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0123_df (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0123_df MODIFY target VARCHAR(200) CHARACTER SET utf8mb4;
SELECT 'TC-42-FCT-0123-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0123_df';
SELECT 'TC-42-FCT-0123-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0123_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0124-IT
-- Factor probe: OPT_STATS_PERSISTENT
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 统计信息持久化且关闭自动重算（DDL 后统计信息是否更新）
DROP TABLE IF EXISTS t1_tc_42_fct_0124_it, t2_tc_42_fct_0124_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=d5de5b51a641 factor=OPT_STATS_PERSISTENT
CREATE TABLE t1_tc_42_fct_0124_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB STATS_PERSISTENT=1 STATS_AUTO_RECALC=0;
INSERT INTO t1_tc_42_fct_0124_it (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0124_it (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0124_it (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0124_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0124-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0124_it';
SELECT 'TC-42-FCT-0124-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0124_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0125-IP
-- Factor probe: OPT_STATS_PERSISTENT
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 统计信息持久化且关闭自动重算（DDL 后统计信息是否更新）
DROP TABLE IF EXISTS t1_tc_42_fct_0125_ip, t2_tc_42_fct_0125_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=63ae7aff6262 factor=OPT_STATS_PERSISTENT
CREATE TABLE t1_tc_42_fct_0125_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB STATS_PERSISTENT=1 STATS_AUTO_RECALC=0;
INSERT INTO t1_tc_42_fct_0125_ip (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0125_ip (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0125_ip (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0125_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0125-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0125_ip';
SELECT 'TC-42-FCT-0125-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0125_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0126-DF
-- Factor probe: OPT_STATS_PERSISTENT
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 统计信息持久化且关闭自动重算（DDL 后统计信息是否更新）
DROP TABLE IF EXISTS t1_tc_42_fct_0126_df, t2_tc_42_fct_0126_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=95ad235536dd factor=OPT_STATS_PERSISTENT
CREATE TABLE t1_tc_42_fct_0126_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB STATS_PERSISTENT=1 STATS_AUTO_RECALC=0;
INSERT INTO t1_tc_42_fct_0126_df (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0126_df (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0126_df (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0126_df MODIFY target CHAR(2) CHARACTER SET latin1;
SELECT 'TC-42-FCT-0126-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0126_df';
SELECT 'TC-42-FCT-0126-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0126_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0127-IT
-- Factor probe: ENG_MYISAM
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: FAIL
-- Transition ID: INT-S-3-4
-- Factor note: 非 InnoDB 引擎（INSTANT/INPLACE 不适用）
DROP TABLE IF EXISTS t1_tc_42_fct_0127_it, t2_tc_42_fct_0127_it;
-- @expect alter=N/A build=FAIL assertions=1 factor=ENG_MYISAM
CREATE TABLE t1_tc_42_fct_0127_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=MyISAM;
SELECT 'TC-42-FCT-0127-IT#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor ENG_MYISAM is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0127_it';

-- Test Case: TC-42-FCT-0128-IP
-- Factor probe: ENG_MYISAM
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: FAIL
-- Transition ID: INT-S-3-4
-- Factor note: 非 InnoDB 引擎（INSTANT/INPLACE 不适用）
DROP TABLE IF EXISTS t1_tc_42_fct_0128_ip, t2_tc_42_fct_0128_ip;
-- @expect alter=N/A build=FAIL assertions=1 factor=ENG_MYISAM
CREATE TABLE t1_tc_42_fct_0128_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=MyISAM;
SELECT 'TC-42-FCT-0128-IP#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor ENG_MYISAM is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0128_ip';

-- Test Case: TC-42-FCT-0129-DF
-- Factor probe: ENG_MYISAM
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: FAIL
-- Transition ID: INT-S-3-4
-- Factor note: 非 InnoDB 引擎（INSTANT/INPLACE 不适用）
DROP TABLE IF EXISTS t1_tc_42_fct_0129_df, t2_tc_42_fct_0129_df;
-- @expect alter=N/A build=FAIL assertions=1 factor=ENG_MYISAM
CREATE TABLE t1_tc_42_fct_0129_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=MyISAM;
SELECT 'TC-42-FCT-0129-DF#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor ENG_MYISAM is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0129_df';

-- Test Case: TC-42-FCT-0130-IT
-- Factor probe: ENG_MYISAM
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: FAIL
-- Transition ID: VC-07
-- Factor note: 非 InnoDB 引擎（INSTANT/INPLACE 不适用）
DROP TABLE IF EXISTS t1_tc_42_fct_0130_it, t2_tc_42_fct_0130_it;
-- @expect alter=N/A build=FAIL assertions=1 factor=ENG_MYISAM
CREATE TABLE t1_tc_42_fct_0130_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=MyISAM;
SELECT 'TC-42-FCT-0130-IT#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor ENG_MYISAM is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0130_it';

-- Test Case: TC-42-FCT-0131-IP
-- Factor probe: ENG_MYISAM
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: FAIL
-- Transition ID: VC-07
-- Factor note: 非 InnoDB 引擎（INSTANT/INPLACE 不适用）
DROP TABLE IF EXISTS t1_tc_42_fct_0131_ip, t2_tc_42_fct_0131_ip;
-- @expect alter=N/A build=FAIL assertions=1 factor=ENG_MYISAM
CREATE TABLE t1_tc_42_fct_0131_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=MyISAM;
SELECT 'TC-42-FCT-0131-IP#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor ENG_MYISAM is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0131_ip';

-- Test Case: TC-42-FCT-0132-DF
-- Factor probe: ENG_MYISAM
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: FAIL
-- Transition ID: VC-07
-- Factor note: 非 InnoDB 引擎（INSTANT/INPLACE 不适用）
DROP TABLE IF EXISTS t1_tc_42_fct_0132_df, t2_tc_42_fct_0132_df;
-- @expect alter=N/A build=FAIL assertions=1 factor=ENG_MYISAM
CREATE TABLE t1_tc_42_fct_0132_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=MyISAM;
SELECT 'TC-42-FCT-0132-DF#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor ENG_MYISAM is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0132_df';

-- Test Case: TC-42-FCT-0133-IT
-- Factor probe: ENG_MYISAM
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: FAIL
-- Transition ID: CHAR-01
-- Factor note: 非 InnoDB 引擎（INSTANT/INPLACE 不适用）
DROP TABLE IF EXISTS t1_tc_42_fct_0133_it, t2_tc_42_fct_0133_it;
-- @expect alter=N/A build=FAIL assertions=1 factor=ENG_MYISAM
CREATE TABLE t1_tc_42_fct_0133_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=MyISAM;
SELECT 'TC-42-FCT-0133-IT#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor ENG_MYISAM is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0133_it';

-- Test Case: TC-42-FCT-0134-IP
-- Factor probe: ENG_MYISAM
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: FAIL
-- Transition ID: CHAR-01
-- Factor note: 非 InnoDB 引擎（INSTANT/INPLACE 不适用）
DROP TABLE IF EXISTS t1_tc_42_fct_0134_ip, t2_tc_42_fct_0134_ip;
-- @expect alter=N/A build=FAIL assertions=1 factor=ENG_MYISAM
CREATE TABLE t1_tc_42_fct_0134_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=MyISAM;
SELECT 'TC-42-FCT-0134-IP#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor ENG_MYISAM is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0134_ip';

-- Test Case: TC-42-FCT-0135-DF
-- Factor probe: ENG_MYISAM
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: FAIL
-- Transition ID: CHAR-01
-- Factor note: 非 InnoDB 引擎（INSTANT/INPLACE 不适用）
DROP TABLE IF EXISTS t1_tc_42_fct_0135_df, t2_tc_42_fct_0135_df;
-- @expect alter=N/A build=FAIL assertions=1 factor=ENG_MYISAM
CREATE TABLE t1_tc_42_fct_0135_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=MyISAM;
SELECT 'TC-42-FCT-0135-DF#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor ENG_MYISAM is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0135_df';

-- Test Case: TC-42-FCT-0136-IT
-- Factor probe: ENG_MEMORY
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: FAIL
-- Transition ID: INT-S-3-4
-- Factor note: MEMORY 引擎
DROP TABLE IF EXISTS t1_tc_42_fct_0136_it, t2_tc_42_fct_0136_it;
-- @expect alter=N/A build=FAIL assertions=1 factor=ENG_MEMORY
CREATE TABLE t1_tc_42_fct_0136_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=MEMORY;
SELECT 'TC-42-FCT-0136-IT#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor ENG_MEMORY is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0136_it';

-- Test Case: TC-42-FCT-0137-IP
-- Factor probe: ENG_MEMORY
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: FAIL
-- Transition ID: INT-S-3-4
-- Factor note: MEMORY 引擎
DROP TABLE IF EXISTS t1_tc_42_fct_0137_ip, t2_tc_42_fct_0137_ip;
-- @expect alter=N/A build=FAIL assertions=1 factor=ENG_MEMORY
CREATE TABLE t1_tc_42_fct_0137_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=MEMORY;
SELECT 'TC-42-FCT-0137-IP#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor ENG_MEMORY is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0137_ip';

-- Test Case: TC-42-FCT-0138-DF
-- Factor probe: ENG_MEMORY
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: FAIL
-- Transition ID: INT-S-3-4
-- Factor note: MEMORY 引擎
DROP TABLE IF EXISTS t1_tc_42_fct_0138_df, t2_tc_42_fct_0138_df;
-- @expect alter=N/A build=FAIL assertions=1 factor=ENG_MEMORY
CREATE TABLE t1_tc_42_fct_0138_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=MEMORY;
SELECT 'TC-42-FCT-0138-DF#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor ENG_MEMORY is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0138_df';

-- Test Case: TC-42-FCT-0139-IT
-- Factor probe: ENG_MEMORY
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: FAIL
-- Transition ID: VC-07
-- Factor note: MEMORY 引擎
DROP TABLE IF EXISTS t1_tc_42_fct_0139_it, t2_tc_42_fct_0139_it;
-- @expect alter=N/A build=FAIL assertions=1 factor=ENG_MEMORY
CREATE TABLE t1_tc_42_fct_0139_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=MEMORY;
SELECT 'TC-42-FCT-0139-IT#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor ENG_MEMORY is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0139_it';

-- Test Case: TC-42-FCT-0140-IP
-- Factor probe: ENG_MEMORY
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: FAIL
-- Transition ID: VC-07
-- Factor note: MEMORY 引擎
DROP TABLE IF EXISTS t1_tc_42_fct_0140_ip, t2_tc_42_fct_0140_ip;
-- @expect alter=N/A build=FAIL assertions=1 factor=ENG_MEMORY
CREATE TABLE t1_tc_42_fct_0140_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=MEMORY;
SELECT 'TC-42-FCT-0140-IP#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor ENG_MEMORY is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0140_ip';

-- Test Case: TC-42-FCT-0141-DF
-- Factor probe: ENG_MEMORY
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: FAIL
-- Transition ID: VC-07
-- Factor note: MEMORY 引擎
DROP TABLE IF EXISTS t1_tc_42_fct_0141_df, t2_tc_42_fct_0141_df;
-- @expect alter=N/A build=FAIL assertions=1 factor=ENG_MEMORY
CREATE TABLE t1_tc_42_fct_0141_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=MEMORY;
SELECT 'TC-42-FCT-0141-DF#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor ENG_MEMORY is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0141_df';

-- Test Case: TC-42-FCT-0142-IT
-- Factor probe: ENG_MEMORY
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: FAIL
-- Transition ID: CHAR-01
-- Factor note: MEMORY 引擎
DROP TABLE IF EXISTS t1_tc_42_fct_0142_it, t2_tc_42_fct_0142_it;
-- @expect alter=N/A build=FAIL assertions=1 factor=ENG_MEMORY
CREATE TABLE t1_tc_42_fct_0142_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=MEMORY;
SELECT 'TC-42-FCT-0142-IT#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor ENG_MEMORY is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0142_it';

-- Test Case: TC-42-FCT-0143-IP
-- Factor probe: ENG_MEMORY
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: FAIL
-- Transition ID: CHAR-01
-- Factor note: MEMORY 引擎
DROP TABLE IF EXISTS t1_tc_42_fct_0143_ip, t2_tc_42_fct_0143_ip;
-- @expect alter=N/A build=FAIL assertions=1 factor=ENG_MEMORY
CREATE TABLE t1_tc_42_fct_0143_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=MEMORY;
SELECT 'TC-42-FCT-0143-IP#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor ENG_MEMORY is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0143_ip';

-- Test Case: TC-42-FCT-0144-DF
-- Factor probe: ENG_MEMORY
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: FAIL
-- Transition ID: CHAR-01
-- Factor note: MEMORY 引擎
DROP TABLE IF EXISTS t1_tc_42_fct_0144_df, t2_tc_42_fct_0144_df;
-- @expect alter=N/A build=FAIL assertions=1 factor=ENG_MEMORY
CREATE TABLE t1_tc_42_fct_0144_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=MEMORY;
SELECT 'TC-42-FCT-0144-DF#BUILD_REJECTED' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'','table was created although factor ENG_MEMORY is known to reject CREATE on this instance (engine disabled / no keyring / etc.) - factor golden needs review') AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0144_df';

-- Test Case: TC-42-FCT-0145-IT
-- Factor probe: MODE_PAD_CHAR
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: PAD_CHAR_TO_FULL_LENGTH：直接改变 CHAR 取值语义与对照结果
SET SESSION sql_mode='STRICT_TRANS_TABLES,PAD_CHAR_TO_FULL_LENGTH';
DROP TABLE IF EXISTS t1_tc_42_fct_0145_it, t2_tc_42_fct_0145_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=60754c2bdfdb factor=MODE_PAD_CHAR
CREATE TABLE t1_tc_42_fct_0145_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0145_it (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0145_it (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0145_it (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0145_it MODIFY target INT, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0145-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0145_it';
SELECT 'TC-42-FCT-0145-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0145_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0146-IP
-- Factor probe: MODE_PAD_CHAR
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: PAD_CHAR_TO_FULL_LENGTH：直接改变 CHAR 取值语义与对照结果
SET SESSION sql_mode='STRICT_TRANS_TABLES,PAD_CHAR_TO_FULL_LENGTH';
DROP TABLE IF EXISTS t1_tc_42_fct_0146_ip, t2_tc_42_fct_0146_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=1efbfa6eecb4 factor=MODE_PAD_CHAR
CREATE TABLE t1_tc_42_fct_0146_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0146_ip (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0146_ip (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0146_ip (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0146_ip MODIFY target INT, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0146-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0146_ip';
SELECT 'TC-42-FCT-0146-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0146_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0147-DF
-- Factor probe: MODE_PAD_CHAR
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: PAD_CHAR_TO_FULL_LENGTH：直接改变 CHAR 取值语义与对照结果
SET SESSION sql_mode='STRICT_TRANS_TABLES,PAD_CHAR_TO_FULL_LENGTH';
DROP TABLE IF EXISTS t1_tc_42_fct_0147_df, t2_tc_42_fct_0147_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=0a9b81781bcf factor=MODE_PAD_CHAR
CREATE TABLE t1_tc_42_fct_0147_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0147_df (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0147_df (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0147_df (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0147_df MODIFY target INT;
SELECT 'TC-42-FCT-0147-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0147_df';
SELECT 'TC-42-FCT-0147-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0147_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0148-IT
-- Factor probe: MODE_PAD_CHAR
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: PAD_CHAR_TO_FULL_LENGTH：直接改变 CHAR 取值语义与对照结果
SET SESSION sql_mode='STRICT_TRANS_TABLES,PAD_CHAR_TO_FULL_LENGTH';
DROP TABLE IF EXISTS t1_tc_42_fct_0148_it, t2_tc_42_fct_0148_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=b44b25d0f8c7 factor=MODE_PAD_CHAR
CREATE TABLE t1_tc_42_fct_0148_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0148_it (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0148_it (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0148_it (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0148_it MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0148-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0148_it';
SELECT 'TC-42-FCT-0148-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0148_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0149-IP
-- Factor probe: MODE_PAD_CHAR
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: PAD_CHAR_TO_FULL_LENGTH：直接改变 CHAR 取值语义与对照结果
SET SESSION sql_mode='STRICT_TRANS_TABLES,PAD_CHAR_TO_FULL_LENGTH';
DROP TABLE IF EXISTS t1_tc_42_fct_0149_ip, t2_tc_42_fct_0149_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=6788ddb889ee factor=MODE_PAD_CHAR
CREATE TABLE t1_tc_42_fct_0149_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0149_ip (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0149_ip (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0149_ip (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0149_ip MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0149-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0149_ip';
SELECT 'TC-42-FCT-0149-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0149_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0150-DF
-- Factor probe: MODE_PAD_CHAR
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: PAD_CHAR_TO_FULL_LENGTH：直接改变 CHAR 取值语义与对照结果
SET SESSION sql_mode='STRICT_TRANS_TABLES,PAD_CHAR_TO_FULL_LENGTH';
DROP TABLE IF EXISTS t1_tc_42_fct_0150_df, t2_tc_42_fct_0150_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=c0250c0b9ea2 factor=MODE_PAD_CHAR
CREATE TABLE t1_tc_42_fct_0150_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0150_df (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0150_df (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0150_df (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0150_df MODIFY target VARCHAR(200) CHARACTER SET utf8mb4;
SELECT 'TC-42-FCT-0150-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0150_df';
SELECT 'TC-42-FCT-0150-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0150_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0151-IT
-- Factor probe: MODE_PAD_CHAR
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: PAD_CHAR_TO_FULL_LENGTH：直接改变 CHAR 取值语义与对照结果
SET SESSION sql_mode='STRICT_TRANS_TABLES,PAD_CHAR_TO_FULL_LENGTH';
DROP TABLE IF EXISTS t1_tc_42_fct_0151_it, t2_tc_42_fct_0151_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=964773458b70 factor=MODE_PAD_CHAR
CREATE TABLE t1_tc_42_fct_0151_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0151_it (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0151_it (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0151_it (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0151_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0151-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0151_it';
SELECT 'TC-42-FCT-0151-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0151_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0152-IP
-- Factor probe: MODE_PAD_CHAR
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: PAD_CHAR_TO_FULL_LENGTH：直接改变 CHAR 取值语义与对照结果
SET SESSION sql_mode='STRICT_TRANS_TABLES,PAD_CHAR_TO_FULL_LENGTH';
DROP TABLE IF EXISTS t1_tc_42_fct_0152_ip, t2_tc_42_fct_0152_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=6950e60d6c7a factor=MODE_PAD_CHAR
CREATE TABLE t1_tc_42_fct_0152_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0152_ip (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0152_ip (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0152_ip (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0152_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0152-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0152_ip';
SELECT 'TC-42-FCT-0152-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0152_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0153-DF
-- Factor probe: MODE_PAD_CHAR
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: PAD_CHAR_TO_FULL_LENGTH：直接改变 CHAR 取值语义与对照结果
SET SESSION sql_mode='STRICT_TRANS_TABLES,PAD_CHAR_TO_FULL_LENGTH';
DROP TABLE IF EXISTS t1_tc_42_fct_0153_df, t2_tc_42_fct_0153_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=76fed3df4d44 factor=MODE_PAD_CHAR
CREATE TABLE t1_tc_42_fct_0153_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0153_df (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0153_df (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0153_df (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0153_df MODIFY target CHAR(2) CHARACTER SET latin1;
SELECT 'TC-42-FCT-0153-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0153_df';
SELECT 'TC-42-FCT-0153-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0153_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0154-IT
-- Factor probe: MODE_TRADITIONAL
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: TRADITIONAL 严格模式
SET SESSION sql_mode='TRADITIONAL';
DROP TABLE IF EXISTS t1_tc_42_fct_0154_it, t2_tc_42_fct_0154_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=6416cd08f42c factor=MODE_TRADITIONAL
CREATE TABLE t1_tc_42_fct_0154_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0154_it (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0154_it (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0154_it (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0154_it MODIFY target INT, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0154-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0154_it';
SELECT 'TC-42-FCT-0154-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0154_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0155-IP
-- Factor probe: MODE_TRADITIONAL
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: TRADITIONAL 严格模式
SET SESSION sql_mode='TRADITIONAL';
DROP TABLE IF EXISTS t1_tc_42_fct_0155_ip, t2_tc_42_fct_0155_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=0e697b4c5534 factor=MODE_TRADITIONAL
CREATE TABLE t1_tc_42_fct_0155_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0155_ip (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0155_ip (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0155_ip (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0155_ip MODIFY target INT, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0155-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0155_ip';
SELECT 'TC-42-FCT-0155-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0155_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0156-DF
-- Factor probe: MODE_TRADITIONAL
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: TRADITIONAL 严格模式
SET SESSION sql_mode='TRADITIONAL';
DROP TABLE IF EXISTS t1_tc_42_fct_0156_df, t2_tc_42_fct_0156_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=903551b40365 factor=MODE_TRADITIONAL
CREATE TABLE t1_tc_42_fct_0156_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0156_df (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0156_df (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0156_df (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0156_df MODIFY target INT;
SELECT 'TC-42-FCT-0156-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0156_df';
SELECT 'TC-42-FCT-0156-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0156_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0157-IT
-- Factor probe: MODE_TRADITIONAL
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: TRADITIONAL 严格模式
SET SESSION sql_mode='TRADITIONAL';
DROP TABLE IF EXISTS t1_tc_42_fct_0157_it, t2_tc_42_fct_0157_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=ec6e6c9e3a19 factor=MODE_TRADITIONAL
CREATE TABLE t1_tc_42_fct_0157_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0157_it (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0157_it (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0157_it (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0157_it MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0157-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0157_it';
SELECT 'TC-42-FCT-0157-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0157_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0158-IP
-- Factor probe: MODE_TRADITIONAL
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: TRADITIONAL 严格模式
SET SESSION sql_mode='TRADITIONAL';
DROP TABLE IF EXISTS t1_tc_42_fct_0158_ip, t2_tc_42_fct_0158_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=e3d15d624903 factor=MODE_TRADITIONAL
CREATE TABLE t1_tc_42_fct_0158_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0158_ip (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0158_ip (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0158_ip (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0158_ip MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0158-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0158_ip';
SELECT 'TC-42-FCT-0158-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0158_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0159-DF
-- Factor probe: MODE_TRADITIONAL
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: TRADITIONAL 严格模式
SET SESSION sql_mode='TRADITIONAL';
DROP TABLE IF EXISTS t1_tc_42_fct_0159_df, t2_tc_42_fct_0159_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=84bbaf0e2dd2 factor=MODE_TRADITIONAL
CREATE TABLE t1_tc_42_fct_0159_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0159_df (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0159_df (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0159_df (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0159_df MODIFY target VARCHAR(200) CHARACTER SET utf8mb4;
SELECT 'TC-42-FCT-0159-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0159_df';
SELECT 'TC-42-FCT-0159-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0159_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0160-IT
-- Factor probe: MODE_TRADITIONAL
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: TRADITIONAL 严格模式
SET SESSION sql_mode='TRADITIONAL';
DROP TABLE IF EXISTS t1_tc_42_fct_0160_it, t2_tc_42_fct_0160_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=3cfa35d2c523 factor=MODE_TRADITIONAL
CREATE TABLE t1_tc_42_fct_0160_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0160_it (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0160_it (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0160_it (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0160_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0160-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0160_it';
SELECT 'TC-42-FCT-0160-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0160_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0161-IP
-- Factor probe: MODE_TRADITIONAL
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: TRADITIONAL 严格模式
SET SESSION sql_mode='TRADITIONAL';
DROP TABLE IF EXISTS t1_tc_42_fct_0161_ip, t2_tc_42_fct_0161_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=bf73f64745e1 factor=MODE_TRADITIONAL
CREATE TABLE t1_tc_42_fct_0161_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0161_ip (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0161_ip (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0161_ip (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0161_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0161-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0161_ip';
SELECT 'TC-42-FCT-0161-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0161_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0162-DF
-- Factor probe: MODE_TRADITIONAL
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: TRADITIONAL 严格模式
SET SESSION sql_mode='TRADITIONAL';
DROP TABLE IF EXISTS t1_tc_42_fct_0162_df, t2_tc_42_fct_0162_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=51746f8ac5ad factor=MODE_TRADITIONAL
CREATE TABLE t1_tc_42_fct_0162_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0162_df (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0162_df (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0162_df (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0162_df MODIFY target CHAR(2) CHARACTER SET latin1;
SELECT 'TC-42-FCT-0162-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0162_df';
SELECT 'TC-42-FCT-0162-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0162_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0163-IT
-- Factor probe: MODE_ANSI
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: ANSI 模式（引号/除法语义变化）
SET SESSION sql_mode='ANSI';
DROP TABLE IF EXISTS t1_tc_42_fct_0163_it, t2_tc_42_fct_0163_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=aea5d119d965 factor=MODE_ANSI
CREATE TABLE t1_tc_42_fct_0163_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0163_it (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0163_it (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0163_it (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0163_it MODIFY target INT, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0163-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0163_it';
SELECT 'TC-42-FCT-0163-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0163_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0164-IP
-- Factor probe: MODE_ANSI
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: ANSI 模式（引号/除法语义变化）
SET SESSION sql_mode='ANSI';
DROP TABLE IF EXISTS t1_tc_42_fct_0164_ip, t2_tc_42_fct_0164_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=e970dd1210cc factor=MODE_ANSI
CREATE TABLE t1_tc_42_fct_0164_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0164_ip (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0164_ip (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0164_ip (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0164_ip MODIFY target INT, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0164-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0164_ip';
SELECT 'TC-42-FCT-0164-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0164_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0165-DF
-- Factor probe: MODE_ANSI
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: ANSI 模式（引号/除法语义变化）
SET SESSION sql_mode='ANSI';
DROP TABLE IF EXISTS t1_tc_42_fct_0165_df, t2_tc_42_fct_0165_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=911c4c80b52c factor=MODE_ANSI
CREATE TABLE t1_tc_42_fct_0165_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0165_df (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0165_df (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0165_df (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0165_df MODIFY target INT;
SELECT 'TC-42-FCT-0165-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0165_df';
SELECT 'TC-42-FCT-0165-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0165_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0166-IT
-- Factor probe: MODE_ANSI
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: ANSI 模式（引号/除法语义变化）
SET SESSION sql_mode='ANSI';
DROP TABLE IF EXISTS t1_tc_42_fct_0166_it, t2_tc_42_fct_0166_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=ac74447aed79 factor=MODE_ANSI
CREATE TABLE t1_tc_42_fct_0166_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0166_it (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0166_it (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0166_it (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0166_it MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0166-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0166_it';
SELECT 'TC-42-FCT-0166-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0166_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0167-IP
-- Factor probe: MODE_ANSI
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: ANSI 模式（引号/除法语义变化）
SET SESSION sql_mode='ANSI';
DROP TABLE IF EXISTS t1_tc_42_fct_0167_ip, t2_tc_42_fct_0167_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=4bbd9a22bc48 factor=MODE_ANSI
CREATE TABLE t1_tc_42_fct_0167_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0167_ip (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0167_ip (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0167_ip (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0167_ip MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0167-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0167_ip';
SELECT 'TC-42-FCT-0167-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0167_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0168-DF
-- Factor probe: MODE_ANSI
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: ANSI 模式（引号/除法语义变化）
SET SESSION sql_mode='ANSI';
DROP TABLE IF EXISTS t1_tc_42_fct_0168_df, t2_tc_42_fct_0168_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=95575851d7ae factor=MODE_ANSI
CREATE TABLE t1_tc_42_fct_0168_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0168_df (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0168_df (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0168_df (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0168_df MODIFY target VARCHAR(200) CHARACTER SET utf8mb4;
SELECT 'TC-42-FCT-0168-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0168_df';
SELECT 'TC-42-FCT-0168-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0168_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0169-IT
-- Factor probe: MODE_ANSI
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: ANSI 模式（引号/除法语义变化）
SET SESSION sql_mode='ANSI';
DROP TABLE IF EXISTS t1_tc_42_fct_0169_it, t2_tc_42_fct_0169_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=97ee6705b613 factor=MODE_ANSI
CREATE TABLE t1_tc_42_fct_0169_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0169_it (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0169_it (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0169_it (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0169_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0169-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0169_it';
SELECT 'TC-42-FCT-0169-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0169_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0170-IP
-- Factor probe: MODE_ANSI
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: ANSI 模式（引号/除法语义变化）
SET SESSION sql_mode='ANSI';
DROP TABLE IF EXISTS t1_tc_42_fct_0170_ip, t2_tc_42_fct_0170_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=e72460ac92b3 factor=MODE_ANSI
CREATE TABLE t1_tc_42_fct_0170_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0170_ip (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0170_ip (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0170_ip (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0170_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0170-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0170_ip';
SELECT 'TC-42-FCT-0170-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0170_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0171-DF
-- Factor probe: MODE_ANSI
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: ANSI 模式（引号/除法语义变化）
SET SESSION sql_mode='ANSI';
DROP TABLE IF EXISTS t1_tc_42_fct_0171_df, t2_tc_42_fct_0171_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=605e09e8df98 factor=MODE_ANSI
CREATE TABLE t1_tc_42_fct_0171_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0171_df (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0171_df (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0171_df (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0171_df MODIFY target CHAR(2) CHARACTER SET latin1;
SELECT 'TC-42-FCT-0171-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0171_df';
SELECT 'TC-42-FCT-0171-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0171_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0172-IT
-- Factor probe: MODE_NO_ZERO_DATE
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: NO_ZERO_DATE / NO_ZERO_IN_DATE
SET SESSION sql_mode='STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE';
DROP TABLE IF EXISTS t1_tc_42_fct_0172_it, t2_tc_42_fct_0172_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=4bf5bbb21b41 factor=MODE_NO_ZERO_DATE
CREATE TABLE t1_tc_42_fct_0172_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0172_it (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0172_it (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0172_it (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0172_it MODIFY target INT, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0172-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0172_it';
SELECT 'TC-42-FCT-0172-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0172_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0173-IP
-- Factor probe: MODE_NO_ZERO_DATE
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: NO_ZERO_DATE / NO_ZERO_IN_DATE
SET SESSION sql_mode='STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE';
DROP TABLE IF EXISTS t1_tc_42_fct_0173_ip, t2_tc_42_fct_0173_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=71bd6b17346e factor=MODE_NO_ZERO_DATE
CREATE TABLE t1_tc_42_fct_0173_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0173_ip (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0173_ip (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0173_ip (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0173_ip MODIFY target INT, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0173-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0173_ip';
SELECT 'TC-42-FCT-0173-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0173_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0174-DF
-- Factor probe: MODE_NO_ZERO_DATE
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: NO_ZERO_DATE / NO_ZERO_IN_DATE
SET SESSION sql_mode='STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE';
DROP TABLE IF EXISTS t1_tc_42_fct_0174_df, t2_tc_42_fct_0174_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=3ae8c78a855e factor=MODE_NO_ZERO_DATE
CREATE TABLE t1_tc_42_fct_0174_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0174_df (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0174_df (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0174_df (target) VALUES (1);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0174_df MODIFY target INT;
SELECT 'TC-42-FCT-0174-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0174_df';
SELECT 'TC-42-FCT-0174-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0174_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0175-IT
-- Factor probe: MODE_NO_ZERO_DATE
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: NO_ZERO_DATE / NO_ZERO_IN_DATE
SET SESSION sql_mode='STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE';
DROP TABLE IF EXISTS t1_tc_42_fct_0175_it, t2_tc_42_fct_0175_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=756d98f83cd6 factor=MODE_NO_ZERO_DATE
CREATE TABLE t1_tc_42_fct_0175_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0175_it (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0175_it (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0175_it (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0175_it MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0175-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0175_it';
SELECT 'TC-42-FCT-0175-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0175_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0176-IP
-- Factor probe: MODE_NO_ZERO_DATE
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: NO_ZERO_DATE / NO_ZERO_IN_DATE
SET SESSION sql_mode='STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE';
DROP TABLE IF EXISTS t1_tc_42_fct_0176_ip, t2_tc_42_fct_0176_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=5607943fe2b2 factor=MODE_NO_ZERO_DATE
CREATE TABLE t1_tc_42_fct_0176_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0176_ip (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0176_ip (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0176_ip (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0176_ip MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0176-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0176_ip';
SELECT 'TC-42-FCT-0176-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0176_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0177-DF
-- Factor probe: MODE_NO_ZERO_DATE
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: NO_ZERO_DATE / NO_ZERO_IN_DATE
SET SESSION sql_mode='STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE';
DROP TABLE IF EXISTS t1_tc_42_fct_0177_df, t2_tc_42_fct_0177_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=894906331d1f factor=MODE_NO_ZERO_DATE
CREATE TABLE t1_tc_42_fct_0177_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0177_df (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0177_df (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0177_df (target) VALUES ('00000002');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0177_df MODIFY target VARCHAR(200) CHARACTER SET utf8mb4;
SELECT 'TC-42-FCT-0177-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0177_df';
SELECT 'TC-42-FCT-0177-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0177_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0178-IT
-- Factor probe: MODE_NO_ZERO_DATE
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: NO_ZERO_DATE / NO_ZERO_IN_DATE
SET SESSION sql_mode='STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE';
DROP TABLE IF EXISTS t1_tc_42_fct_0178_it, t2_tc_42_fct_0178_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=9639db958700 factor=MODE_NO_ZERO_DATE
CREATE TABLE t1_tc_42_fct_0178_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0178_it (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0178_it (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0178_it (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0178_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0178-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0178_it';
SELECT 'TC-42-FCT-0178-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0178_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0179-IP
-- Factor probe: MODE_NO_ZERO_DATE
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: NO_ZERO_DATE / NO_ZERO_IN_DATE
SET SESSION sql_mode='STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE';
DROP TABLE IF EXISTS t1_tc_42_fct_0179_ip, t2_tc_42_fct_0179_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=7dc2cef8c133 factor=MODE_NO_ZERO_DATE
CREATE TABLE t1_tc_42_fct_0179_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0179_ip (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0179_ip (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0179_ip (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0179_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0179-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0179_ip';
SELECT 'TC-42-FCT-0179-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0179_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0180-DF
-- Factor probe: MODE_NO_ZERO_DATE
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: NO_ZERO_DATE / NO_ZERO_IN_DATE
SET SESSION sql_mode='STRICT_TRANS_TABLES,NO_ZERO_DATE,NO_ZERO_IN_DATE';
DROP TABLE IF EXISTS t1_tc_42_fct_0180_df, t2_tc_42_fct_0180_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=1093373fb558 factor=MODE_NO_ZERO_DATE
CREATE TABLE t1_tc_42_fct_0180_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0180_df (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0180_df (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0180_df (target) VALUES ('2');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0180_df MODIFY target CHAR(2) CHARACTER SET latin1;
SELECT 'TC-42-FCT-0180-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0180_df';
SELECT 'TC-42-FCT-0180-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0180_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0181-IT
-- Factor probe: SCALE_10K
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 中等数据规模：10,000 行（旧套件只有 0/1/100 行）
DROP TABLE IF EXISTS t1_tc_42_fct_0181_it, t2_tc_42_fct_0181_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=2453d91f6671 factor=SCALE_10K
CREATE TABLE t1_tc_42_fct_0181_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0181_it (target) VALUES (-31);
INSERT INTO t1_tc_42_fct_0181_it (target) SELECT target FROM t1_tc_42_fct_0181_it;
INSERT INTO t1_tc_42_fct_0181_it (target) SELECT target FROM t1_tc_42_fct_0181_it;
INSERT INTO t1_tc_42_fct_0181_it (target) SELECT target FROM t1_tc_42_fct_0181_it;
INSERT INTO t1_tc_42_fct_0181_it (target) SELECT target FROM t1_tc_42_fct_0181_it;
INSERT INTO t1_tc_42_fct_0181_it (target) SELECT target FROM t1_tc_42_fct_0181_it;
INSERT INTO t1_tc_42_fct_0181_it (target) SELECT target FROM t1_tc_42_fct_0181_it;
INSERT INTO t1_tc_42_fct_0181_it (target) SELECT target FROM t1_tc_42_fct_0181_it;
INSERT INTO t1_tc_42_fct_0181_it (target) SELECT target FROM t1_tc_42_fct_0181_it;
INSERT INTO t1_tc_42_fct_0181_it (target) SELECT target FROM t1_tc_42_fct_0181_it;
INSERT INTO t1_tc_42_fct_0181_it (target) SELECT target FROM t1_tc_42_fct_0181_it;
INSERT INTO t1_tc_42_fct_0181_it (target) SELECT target FROM t1_tc_42_fct_0181_it;
INSERT INTO t1_tc_42_fct_0181_it (target) SELECT target FROM t1_tc_42_fct_0181_it;
INSERT INTO t1_tc_42_fct_0181_it (target) SELECT target FROM t1_tc_42_fct_0181_it;
INSERT INTO t1_tc_42_fct_0181_it (target) SELECT target FROM t1_tc_42_fct_0181_it;
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0181_it MODIFY target INT, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0181-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0181_it';
SELECT 'TC-42-FCT-0181-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0181_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0182-IP
-- Factor probe: SCALE_10K
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 中等数据规模：10,000 行（旧套件只有 0/1/100 行）
DROP TABLE IF EXISTS t1_tc_42_fct_0182_ip, t2_tc_42_fct_0182_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=94a36bddfa5c factor=SCALE_10K
CREATE TABLE t1_tc_42_fct_0182_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0182_ip (target) VALUES (-31);
INSERT INTO t1_tc_42_fct_0182_ip (target) SELECT target FROM t1_tc_42_fct_0182_ip;
INSERT INTO t1_tc_42_fct_0182_ip (target) SELECT target FROM t1_tc_42_fct_0182_ip;
INSERT INTO t1_tc_42_fct_0182_ip (target) SELECT target FROM t1_tc_42_fct_0182_ip;
INSERT INTO t1_tc_42_fct_0182_ip (target) SELECT target FROM t1_tc_42_fct_0182_ip;
INSERT INTO t1_tc_42_fct_0182_ip (target) SELECT target FROM t1_tc_42_fct_0182_ip;
INSERT INTO t1_tc_42_fct_0182_ip (target) SELECT target FROM t1_tc_42_fct_0182_ip;
INSERT INTO t1_tc_42_fct_0182_ip (target) SELECT target FROM t1_tc_42_fct_0182_ip;
INSERT INTO t1_tc_42_fct_0182_ip (target) SELECT target FROM t1_tc_42_fct_0182_ip;
INSERT INTO t1_tc_42_fct_0182_ip (target) SELECT target FROM t1_tc_42_fct_0182_ip;
INSERT INTO t1_tc_42_fct_0182_ip (target) SELECT target FROM t1_tc_42_fct_0182_ip;
INSERT INTO t1_tc_42_fct_0182_ip (target) SELECT target FROM t1_tc_42_fct_0182_ip;
INSERT INTO t1_tc_42_fct_0182_ip (target) SELECT target FROM t1_tc_42_fct_0182_ip;
INSERT INTO t1_tc_42_fct_0182_ip (target) SELECT target FROM t1_tc_42_fct_0182_ip;
INSERT INTO t1_tc_42_fct_0182_ip (target) SELECT target FROM t1_tc_42_fct_0182_ip;
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0182_ip MODIFY target INT, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0182-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0182_ip';
SELECT 'TC-42-FCT-0182-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0182_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0183-DF
-- Factor probe: SCALE_10K
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 中等数据规模：10,000 行（旧套件只有 0/1/100 行）
DROP TABLE IF EXISTS t1_tc_42_fct_0183_df, t2_tc_42_fct_0183_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=7ab511e5c0f4 factor=SCALE_10K
CREATE TABLE t1_tc_42_fct_0183_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0183_df (target) VALUES (-31);
INSERT INTO t1_tc_42_fct_0183_df (target) SELECT target FROM t1_tc_42_fct_0183_df;
INSERT INTO t1_tc_42_fct_0183_df (target) SELECT target FROM t1_tc_42_fct_0183_df;
INSERT INTO t1_tc_42_fct_0183_df (target) SELECT target FROM t1_tc_42_fct_0183_df;
INSERT INTO t1_tc_42_fct_0183_df (target) SELECT target FROM t1_tc_42_fct_0183_df;
INSERT INTO t1_tc_42_fct_0183_df (target) SELECT target FROM t1_tc_42_fct_0183_df;
INSERT INTO t1_tc_42_fct_0183_df (target) SELECT target FROM t1_tc_42_fct_0183_df;
INSERT INTO t1_tc_42_fct_0183_df (target) SELECT target FROM t1_tc_42_fct_0183_df;
INSERT INTO t1_tc_42_fct_0183_df (target) SELECT target FROM t1_tc_42_fct_0183_df;
INSERT INTO t1_tc_42_fct_0183_df (target) SELECT target FROM t1_tc_42_fct_0183_df;
INSERT INTO t1_tc_42_fct_0183_df (target) SELECT target FROM t1_tc_42_fct_0183_df;
INSERT INTO t1_tc_42_fct_0183_df (target) SELECT target FROM t1_tc_42_fct_0183_df;
INSERT INTO t1_tc_42_fct_0183_df (target) SELECT target FROM t1_tc_42_fct_0183_df;
INSERT INTO t1_tc_42_fct_0183_df (target) SELECT target FROM t1_tc_42_fct_0183_df;
INSERT INTO t1_tc_42_fct_0183_df (target) SELECT target FROM t1_tc_42_fct_0183_df;
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0183_df MODIFY target INT;
SELECT 'TC-42-FCT-0183-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0183_df';
SELECT 'TC-42-FCT-0183-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0183_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0184-IT
-- Factor probe: SCALE_10K
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 中等数据规模：10,000 行（旧套件只有 0/1/100 行）
DROP TABLE IF EXISTS t1_tc_42_fct_0184_it, t2_tc_42_fct_0184_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=669f82992d9f factor=SCALE_10K
CREATE TABLE t1_tc_42_fct_0184_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0184_it (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0184_it (target) SELECT target FROM t1_tc_42_fct_0184_it;
INSERT INTO t1_tc_42_fct_0184_it (target) SELECT target FROM t1_tc_42_fct_0184_it;
INSERT INTO t1_tc_42_fct_0184_it (target) SELECT target FROM t1_tc_42_fct_0184_it;
INSERT INTO t1_tc_42_fct_0184_it (target) SELECT target FROM t1_tc_42_fct_0184_it;
INSERT INTO t1_tc_42_fct_0184_it (target) SELECT target FROM t1_tc_42_fct_0184_it;
INSERT INTO t1_tc_42_fct_0184_it (target) SELECT target FROM t1_tc_42_fct_0184_it;
INSERT INTO t1_tc_42_fct_0184_it (target) SELECT target FROM t1_tc_42_fct_0184_it;
INSERT INTO t1_tc_42_fct_0184_it (target) SELECT target FROM t1_tc_42_fct_0184_it;
INSERT INTO t1_tc_42_fct_0184_it (target) SELECT target FROM t1_tc_42_fct_0184_it;
INSERT INTO t1_tc_42_fct_0184_it (target) SELECT target FROM t1_tc_42_fct_0184_it;
INSERT INTO t1_tc_42_fct_0184_it (target) SELECT target FROM t1_tc_42_fct_0184_it;
INSERT INTO t1_tc_42_fct_0184_it (target) SELECT target FROM t1_tc_42_fct_0184_it;
INSERT INTO t1_tc_42_fct_0184_it (target) SELECT target FROM t1_tc_42_fct_0184_it;
INSERT INTO t1_tc_42_fct_0184_it (target) SELECT target FROM t1_tc_42_fct_0184_it;
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0184_it MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0184-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0184_it';
SELECT 'TC-42-FCT-0184-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0184_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0185-IP
-- Factor probe: SCALE_10K
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 中等数据规模：10,000 行（旧套件只有 0/1/100 行）
DROP TABLE IF EXISTS t1_tc_42_fct_0185_ip, t2_tc_42_fct_0185_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=3311145f8ba3 factor=SCALE_10K
CREATE TABLE t1_tc_42_fct_0185_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0185_ip (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0185_ip (target) SELECT target FROM t1_tc_42_fct_0185_ip;
INSERT INTO t1_tc_42_fct_0185_ip (target) SELECT target FROM t1_tc_42_fct_0185_ip;
INSERT INTO t1_tc_42_fct_0185_ip (target) SELECT target FROM t1_tc_42_fct_0185_ip;
INSERT INTO t1_tc_42_fct_0185_ip (target) SELECT target FROM t1_tc_42_fct_0185_ip;
INSERT INTO t1_tc_42_fct_0185_ip (target) SELECT target FROM t1_tc_42_fct_0185_ip;
INSERT INTO t1_tc_42_fct_0185_ip (target) SELECT target FROM t1_tc_42_fct_0185_ip;
INSERT INTO t1_tc_42_fct_0185_ip (target) SELECT target FROM t1_tc_42_fct_0185_ip;
INSERT INTO t1_tc_42_fct_0185_ip (target) SELECT target FROM t1_tc_42_fct_0185_ip;
INSERT INTO t1_tc_42_fct_0185_ip (target) SELECT target FROM t1_tc_42_fct_0185_ip;
INSERT INTO t1_tc_42_fct_0185_ip (target) SELECT target FROM t1_tc_42_fct_0185_ip;
INSERT INTO t1_tc_42_fct_0185_ip (target) SELECT target FROM t1_tc_42_fct_0185_ip;
INSERT INTO t1_tc_42_fct_0185_ip (target) SELECT target FROM t1_tc_42_fct_0185_ip;
INSERT INTO t1_tc_42_fct_0185_ip (target) SELECT target FROM t1_tc_42_fct_0185_ip;
INSERT INTO t1_tc_42_fct_0185_ip (target) SELECT target FROM t1_tc_42_fct_0185_ip;
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0185_ip MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0185-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0185_ip';
SELECT 'TC-42-FCT-0185-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0185_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0186-DF
-- Factor probe: SCALE_10K
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 中等数据规模：10,000 行（旧套件只有 0/1/100 行）
DROP TABLE IF EXISTS t1_tc_42_fct_0186_df, t2_tc_42_fct_0186_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=4912aad78d08 factor=SCALE_10K
CREATE TABLE t1_tc_42_fct_0186_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0186_df (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0186_df (target) SELECT target FROM t1_tc_42_fct_0186_df;
INSERT INTO t1_tc_42_fct_0186_df (target) SELECT target FROM t1_tc_42_fct_0186_df;
INSERT INTO t1_tc_42_fct_0186_df (target) SELECT target FROM t1_tc_42_fct_0186_df;
INSERT INTO t1_tc_42_fct_0186_df (target) SELECT target FROM t1_tc_42_fct_0186_df;
INSERT INTO t1_tc_42_fct_0186_df (target) SELECT target FROM t1_tc_42_fct_0186_df;
INSERT INTO t1_tc_42_fct_0186_df (target) SELECT target FROM t1_tc_42_fct_0186_df;
INSERT INTO t1_tc_42_fct_0186_df (target) SELECT target FROM t1_tc_42_fct_0186_df;
INSERT INTO t1_tc_42_fct_0186_df (target) SELECT target FROM t1_tc_42_fct_0186_df;
INSERT INTO t1_tc_42_fct_0186_df (target) SELECT target FROM t1_tc_42_fct_0186_df;
INSERT INTO t1_tc_42_fct_0186_df (target) SELECT target FROM t1_tc_42_fct_0186_df;
INSERT INTO t1_tc_42_fct_0186_df (target) SELECT target FROM t1_tc_42_fct_0186_df;
INSERT INTO t1_tc_42_fct_0186_df (target) SELECT target FROM t1_tc_42_fct_0186_df;
INSERT INTO t1_tc_42_fct_0186_df (target) SELECT target FROM t1_tc_42_fct_0186_df;
INSERT INTO t1_tc_42_fct_0186_df (target) SELECT target FROM t1_tc_42_fct_0186_df;
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0186_df MODIFY target VARCHAR(200) CHARACTER SET utf8mb4;
SELECT 'TC-42-FCT-0186-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0186_df';
SELECT 'TC-42-FCT-0186-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0186_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0187-IT
-- Factor probe: SCALE_10K
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 中等数据规模：10,000 行（旧套件只有 0/1/100 行）
DROP TABLE IF EXISTS t1_tc_42_fct_0187_it, t2_tc_42_fct_0187_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=71d4b2d91eca factor=SCALE_10K
CREATE TABLE t1_tc_42_fct_0187_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0187_it (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0187_it (target) SELECT target FROM t1_tc_42_fct_0187_it;
INSERT INTO t1_tc_42_fct_0187_it (target) SELECT target FROM t1_tc_42_fct_0187_it;
INSERT INTO t1_tc_42_fct_0187_it (target) SELECT target FROM t1_tc_42_fct_0187_it;
INSERT INTO t1_tc_42_fct_0187_it (target) SELECT target FROM t1_tc_42_fct_0187_it;
INSERT INTO t1_tc_42_fct_0187_it (target) SELECT target FROM t1_tc_42_fct_0187_it;
INSERT INTO t1_tc_42_fct_0187_it (target) SELECT target FROM t1_tc_42_fct_0187_it;
INSERT INTO t1_tc_42_fct_0187_it (target) SELECT target FROM t1_tc_42_fct_0187_it;
INSERT INTO t1_tc_42_fct_0187_it (target) SELECT target FROM t1_tc_42_fct_0187_it;
INSERT INTO t1_tc_42_fct_0187_it (target) SELECT target FROM t1_tc_42_fct_0187_it;
INSERT INTO t1_tc_42_fct_0187_it (target) SELECT target FROM t1_tc_42_fct_0187_it;
INSERT INTO t1_tc_42_fct_0187_it (target) SELECT target FROM t1_tc_42_fct_0187_it;
INSERT INTO t1_tc_42_fct_0187_it (target) SELECT target FROM t1_tc_42_fct_0187_it;
INSERT INTO t1_tc_42_fct_0187_it (target) SELECT target FROM t1_tc_42_fct_0187_it;
INSERT INTO t1_tc_42_fct_0187_it (target) SELECT target FROM t1_tc_42_fct_0187_it;
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0187_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0187-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0187_it';
SELECT 'TC-42-FCT-0187-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0187_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0188-IP
-- Factor probe: SCALE_10K
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 中等数据规模：10,000 行（旧套件只有 0/1/100 行）
DROP TABLE IF EXISTS t1_tc_42_fct_0188_ip, t2_tc_42_fct_0188_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=1f4ff6d14f2e factor=SCALE_10K
CREATE TABLE t1_tc_42_fct_0188_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0188_ip (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0188_ip (target) SELECT target FROM t1_tc_42_fct_0188_ip;
INSERT INTO t1_tc_42_fct_0188_ip (target) SELECT target FROM t1_tc_42_fct_0188_ip;
INSERT INTO t1_tc_42_fct_0188_ip (target) SELECT target FROM t1_tc_42_fct_0188_ip;
INSERT INTO t1_tc_42_fct_0188_ip (target) SELECT target FROM t1_tc_42_fct_0188_ip;
INSERT INTO t1_tc_42_fct_0188_ip (target) SELECT target FROM t1_tc_42_fct_0188_ip;
INSERT INTO t1_tc_42_fct_0188_ip (target) SELECT target FROM t1_tc_42_fct_0188_ip;
INSERT INTO t1_tc_42_fct_0188_ip (target) SELECT target FROM t1_tc_42_fct_0188_ip;
INSERT INTO t1_tc_42_fct_0188_ip (target) SELECT target FROM t1_tc_42_fct_0188_ip;
INSERT INTO t1_tc_42_fct_0188_ip (target) SELECT target FROM t1_tc_42_fct_0188_ip;
INSERT INTO t1_tc_42_fct_0188_ip (target) SELECT target FROM t1_tc_42_fct_0188_ip;
INSERT INTO t1_tc_42_fct_0188_ip (target) SELECT target FROM t1_tc_42_fct_0188_ip;
INSERT INTO t1_tc_42_fct_0188_ip (target) SELECT target FROM t1_tc_42_fct_0188_ip;
INSERT INTO t1_tc_42_fct_0188_ip (target) SELECT target FROM t1_tc_42_fct_0188_ip;
INSERT INTO t1_tc_42_fct_0188_ip (target) SELECT target FROM t1_tc_42_fct_0188_ip;
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0188_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0188-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0188_ip';
SELECT 'TC-42-FCT-0188-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0188_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0189-DF
-- Factor probe: SCALE_10K
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 中等数据规模：10,000 行（旧套件只有 0/1/100 行）
DROP TABLE IF EXISTS t1_tc_42_fct_0189_df, t2_tc_42_fct_0189_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=16ded09720dd factor=SCALE_10K
CREATE TABLE t1_tc_42_fct_0189_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0189_df (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0189_df (target) SELECT target FROM t1_tc_42_fct_0189_df;
INSERT INTO t1_tc_42_fct_0189_df (target) SELECT target FROM t1_tc_42_fct_0189_df;
INSERT INTO t1_tc_42_fct_0189_df (target) SELECT target FROM t1_tc_42_fct_0189_df;
INSERT INTO t1_tc_42_fct_0189_df (target) SELECT target FROM t1_tc_42_fct_0189_df;
INSERT INTO t1_tc_42_fct_0189_df (target) SELECT target FROM t1_tc_42_fct_0189_df;
INSERT INTO t1_tc_42_fct_0189_df (target) SELECT target FROM t1_tc_42_fct_0189_df;
INSERT INTO t1_tc_42_fct_0189_df (target) SELECT target FROM t1_tc_42_fct_0189_df;
INSERT INTO t1_tc_42_fct_0189_df (target) SELECT target FROM t1_tc_42_fct_0189_df;
INSERT INTO t1_tc_42_fct_0189_df (target) SELECT target FROM t1_tc_42_fct_0189_df;
INSERT INTO t1_tc_42_fct_0189_df (target) SELECT target FROM t1_tc_42_fct_0189_df;
INSERT INTO t1_tc_42_fct_0189_df (target) SELECT target FROM t1_tc_42_fct_0189_df;
INSERT INTO t1_tc_42_fct_0189_df (target) SELECT target FROM t1_tc_42_fct_0189_df;
INSERT INTO t1_tc_42_fct_0189_df (target) SELECT target FROM t1_tc_42_fct_0189_df;
INSERT INTO t1_tc_42_fct_0189_df (target) SELECT target FROM t1_tc_42_fct_0189_df;
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0189_df MODIFY target CHAR(2) CHARACTER SET latin1;
SELECT 'TC-42-FCT-0189-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0189_df';
SELECT 'TC-42-FCT-0189-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0189_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0190-IT
-- Factor probe: WIDE_200_COLS
-- Type: MEDIUMINT -> INT, Algorithm: instant, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 宽表：200 列（行宽与字典压力）
DROP TABLE IF EXISTS t1_tc_42_fct_0190_it, t2_tc_42_fct_0190_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=a1e703375c05 factor=WIDE_200_COLS
CREATE TABLE t1_tc_42_fct_0190_it (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  w0 INT,
  w1 INT,
  w2 INT,
  w3 INT,
  w4 INT,
  w5 INT,
  w6 INT,
  w7 INT,
  w8 INT,
  w9 INT,
  w10 INT,
  w11 INT,
  w12 INT,
  w13 INT,
  w14 INT,
  w15 INT,
  w16 INT,
  w17 INT,
  w18 INT,
  w19 INT,
  w20 INT,
  w21 INT,
  w22 INT,
  w23 INT,
  w24 INT,
  w25 INT,
  w26 INT,
  w27 INT,
  w28 INT,
  w29 INT,
  w30 INT,
  w31 INT,
  w32 INT,
  w33 INT,
  w34 INT,
  w35 INT,
  w36 INT,
  w37 INT,
  w38 INT,
  w39 INT,
  w40 INT,
  w41 INT,
  w42 INT,
  w43 INT,
  w44 INT,
  w45 INT,
  w46 INT,
  w47 INT,
  w48 INT,
  w49 INT,
  w50 INT,
  w51 INT,
  w52 INT,
  w53 INT,
  w54 INT,
  w55 INT,
  w56 INT,
  w57 INT,
  w58 INT,
  w59 INT,
  w60 INT,
  w61 INT,
  w62 INT,
  w63 INT,
  w64 INT,
  w65 INT,
  w66 INT,
  w67 INT,
  w68 INT,
  w69 INT,
  w70 INT,
  w71 INT,
  w72 INT,
  w73 INT,
  w74 INT,
  w75 INT,
  w76 INT,
  w77 INT,
  w78 INT,
  w79 INT,
  w80 INT,
  w81 INT,
  w82 INT,
  w83 INT,
  w84 INT,
  w85 INT,
  w86 INT,
  w87 INT,
  w88 INT,
  w89 INT,
  w90 INT,
  w91 INT,
  w92 INT,
  w93 INT,
  w94 INT,
  w95 INT,
  w96 INT,
  w97 INT,
  w98 INT,
  w99 INT,
  w100 INT,
  w101 INT,
  w102 INT,
  w103 INT,
  w104 INT,
  w105 INT,
  w106 INT,
  w107 INT,
  w108 INT,
  w109 INT,
  w110 INT,
  w111 INT,
  w112 INT,
  w113 INT,
  w114 INT,
  w115 INT,
  w116 INT,
  w117 INT,
  w118 INT,
  w119 INT,
  w120 INT,
  w121 INT,
  w122 INT,
  w123 INT,
  w124 INT,
  w125 INT,
  w126 INT,
  w127 INT,
  w128 INT,
  w129 INT,
  w130 INT,
  w131 INT,
  w132 INT,
  w133 INT,
  w134 INT,
  w135 INT,
  w136 INT,
  w137 INT,
  w138 INT,
  w139 INT,
  w140 INT,
  w141 INT,
  w142 INT,
  w143 INT,
  w144 INT,
  w145 INT,
  w146 INT,
  w147 INT,
  w148 INT,
  w149 INT,
  w150 INT,
  w151 INT,
  w152 INT,
  w153 INT,
  w154 INT,
  w155 INT,
  w156 INT,
  w157 INT,
  w158 INT,
  w159 INT,
  w160 INT,
  w161 INT,
  w162 INT,
  w163 INT,
  w164 INT,
  w165 INT,
  w166 INT,
  w167 INT,
  w168 INT,
  w169 INT,
  w170 INT,
  w171 INT,
  w172 INT,
  w173 INT,
  w174 INT,
  w175 INT,
  w176 INT,
  w177 INT,
  w178 INT,
  w179 INT,
  w180 INT,
  w181 INT,
  w182 INT,
  w183 INT,
  w184 INT,
  w185 INT,
  w186 INT,
  w187 INT,
  w188 INT,
  w189 INT,
  w190 INT,
  w191 INT,
  w192 INT,
  w193 INT,
  w194 INT,
  w195 INT,
  w196 INT,
  w197 INT,
  w198 INT,
  w199 INT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0190_it (target) VALUES (-10);
INSERT INTO t1_tc_42_fct_0190_it (target) VALUES (-9);
INSERT INTO t1_tc_42_fct_0190_it (target) VALUES (-8);
INSERT INTO t1_tc_42_fct_0190_it (target) VALUES (-7);
INSERT INTO t1_tc_42_fct_0190_it (target) VALUES (-6);
INSERT INTO t1_tc_42_fct_0190_it (target) VALUES (-5);
INSERT INTO t1_tc_42_fct_0190_it (target) VALUES (-4);
INSERT INTO t1_tc_42_fct_0190_it (target) VALUES (-3);
INSERT INTO t1_tc_42_fct_0190_it (target) VALUES (-2);
INSERT INTO t1_tc_42_fct_0190_it (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0190_it (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0190_it (target) VALUES (1);
INSERT INTO t1_tc_42_fct_0190_it (target) VALUES (2);
INSERT INTO t1_tc_42_fct_0190_it (target) VALUES (3);
INSERT INTO t1_tc_42_fct_0190_it (target) VALUES (4);
INSERT INTO t1_tc_42_fct_0190_it (target) VALUES (5);
INSERT INTO t1_tc_42_fct_0190_it (target) VALUES (6);
INSERT INTO t1_tc_42_fct_0190_it (target) VALUES (7);
INSERT INTO t1_tc_42_fct_0190_it (target) VALUES (8);
INSERT INTO t1_tc_42_fct_0190_it (target) VALUES (9);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0190_it MODIFY target INT, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0190-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0190_it';
SELECT 'TC-42-FCT-0190-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0190_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0191-IP
-- Factor probe: WIDE_200_COLS
-- Type: MEDIUMINT -> INT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 宽表：200 列（行宽与字典压力）
DROP TABLE IF EXISTS t1_tc_42_fct_0191_ip, t2_tc_42_fct_0191_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=dd200f95ee40 factor=WIDE_200_COLS
CREATE TABLE t1_tc_42_fct_0191_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  w0 INT,
  w1 INT,
  w2 INT,
  w3 INT,
  w4 INT,
  w5 INT,
  w6 INT,
  w7 INT,
  w8 INT,
  w9 INT,
  w10 INT,
  w11 INT,
  w12 INT,
  w13 INT,
  w14 INT,
  w15 INT,
  w16 INT,
  w17 INT,
  w18 INT,
  w19 INT,
  w20 INT,
  w21 INT,
  w22 INT,
  w23 INT,
  w24 INT,
  w25 INT,
  w26 INT,
  w27 INT,
  w28 INT,
  w29 INT,
  w30 INT,
  w31 INT,
  w32 INT,
  w33 INT,
  w34 INT,
  w35 INT,
  w36 INT,
  w37 INT,
  w38 INT,
  w39 INT,
  w40 INT,
  w41 INT,
  w42 INT,
  w43 INT,
  w44 INT,
  w45 INT,
  w46 INT,
  w47 INT,
  w48 INT,
  w49 INT,
  w50 INT,
  w51 INT,
  w52 INT,
  w53 INT,
  w54 INT,
  w55 INT,
  w56 INT,
  w57 INT,
  w58 INT,
  w59 INT,
  w60 INT,
  w61 INT,
  w62 INT,
  w63 INT,
  w64 INT,
  w65 INT,
  w66 INT,
  w67 INT,
  w68 INT,
  w69 INT,
  w70 INT,
  w71 INT,
  w72 INT,
  w73 INT,
  w74 INT,
  w75 INT,
  w76 INT,
  w77 INT,
  w78 INT,
  w79 INT,
  w80 INT,
  w81 INT,
  w82 INT,
  w83 INT,
  w84 INT,
  w85 INT,
  w86 INT,
  w87 INT,
  w88 INT,
  w89 INT,
  w90 INT,
  w91 INT,
  w92 INT,
  w93 INT,
  w94 INT,
  w95 INT,
  w96 INT,
  w97 INT,
  w98 INT,
  w99 INT,
  w100 INT,
  w101 INT,
  w102 INT,
  w103 INT,
  w104 INT,
  w105 INT,
  w106 INT,
  w107 INT,
  w108 INT,
  w109 INT,
  w110 INT,
  w111 INT,
  w112 INT,
  w113 INT,
  w114 INT,
  w115 INT,
  w116 INT,
  w117 INT,
  w118 INT,
  w119 INT,
  w120 INT,
  w121 INT,
  w122 INT,
  w123 INT,
  w124 INT,
  w125 INT,
  w126 INT,
  w127 INT,
  w128 INT,
  w129 INT,
  w130 INT,
  w131 INT,
  w132 INT,
  w133 INT,
  w134 INT,
  w135 INT,
  w136 INT,
  w137 INT,
  w138 INT,
  w139 INT,
  w140 INT,
  w141 INT,
  w142 INT,
  w143 INT,
  w144 INT,
  w145 INT,
  w146 INT,
  w147 INT,
  w148 INT,
  w149 INT,
  w150 INT,
  w151 INT,
  w152 INT,
  w153 INT,
  w154 INT,
  w155 INT,
  w156 INT,
  w157 INT,
  w158 INT,
  w159 INT,
  w160 INT,
  w161 INT,
  w162 INT,
  w163 INT,
  w164 INT,
  w165 INT,
  w166 INT,
  w167 INT,
  w168 INT,
  w169 INT,
  w170 INT,
  w171 INT,
  w172 INT,
  w173 INT,
  w174 INT,
  w175 INT,
  w176 INT,
  w177 INT,
  w178 INT,
  w179 INT,
  w180 INT,
  w181 INT,
  w182 INT,
  w183 INT,
  w184 INT,
  w185 INT,
  w186 INT,
  w187 INT,
  w188 INT,
  w189 INT,
  w190 INT,
  w191 INT,
  w192 INT,
  w193 INT,
  w194 INT,
  w195 INT,
  w196 INT,
  w197 INT,
  w198 INT,
  w199 INT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0191_ip (target) VALUES (-10);
INSERT INTO t1_tc_42_fct_0191_ip (target) VALUES (-9);
INSERT INTO t1_tc_42_fct_0191_ip (target) VALUES (-8);
INSERT INTO t1_tc_42_fct_0191_ip (target) VALUES (-7);
INSERT INTO t1_tc_42_fct_0191_ip (target) VALUES (-6);
INSERT INTO t1_tc_42_fct_0191_ip (target) VALUES (-5);
INSERT INTO t1_tc_42_fct_0191_ip (target) VALUES (-4);
INSERT INTO t1_tc_42_fct_0191_ip (target) VALUES (-3);
INSERT INTO t1_tc_42_fct_0191_ip (target) VALUES (-2);
INSERT INTO t1_tc_42_fct_0191_ip (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0191_ip (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0191_ip (target) VALUES (1);
INSERT INTO t1_tc_42_fct_0191_ip (target) VALUES (2);
INSERT INTO t1_tc_42_fct_0191_ip (target) VALUES (3);
INSERT INTO t1_tc_42_fct_0191_ip (target) VALUES (4);
INSERT INTO t1_tc_42_fct_0191_ip (target) VALUES (5);
INSERT INTO t1_tc_42_fct_0191_ip (target) VALUES (6);
INSERT INTO t1_tc_42_fct_0191_ip (target) VALUES (7);
INSERT INTO t1_tc_42_fct_0191_ip (target) VALUES (8);
INSERT INTO t1_tc_42_fct_0191_ip (target) VALUES (9);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0191_ip MODIFY target INT, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0191-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0191_ip';
SELECT 'TC-42-FCT-0191-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0191_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0192-DF
-- Factor probe: WIDE_200_COLS
-- Type: MEDIUMINT -> INT, Algorithm: default, Expected: SUCCESS
-- Transition ID: INT-S-3-4
-- Factor note: 宽表：200 列（行宽与字典压力）
DROP TABLE IF EXISTS t1_tc_42_fct_0192_df, t2_tc_42_fct_0192_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=5117b95b1f3c factor=WIDE_200_COLS
CREATE TABLE t1_tc_42_fct_0192_df (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMINT,
  w0 INT,
  w1 INT,
  w2 INT,
  w3 INT,
  w4 INT,
  w5 INT,
  w6 INT,
  w7 INT,
  w8 INT,
  w9 INT,
  w10 INT,
  w11 INT,
  w12 INT,
  w13 INT,
  w14 INT,
  w15 INT,
  w16 INT,
  w17 INT,
  w18 INT,
  w19 INT,
  w20 INT,
  w21 INT,
  w22 INT,
  w23 INT,
  w24 INT,
  w25 INT,
  w26 INT,
  w27 INT,
  w28 INT,
  w29 INT,
  w30 INT,
  w31 INT,
  w32 INT,
  w33 INT,
  w34 INT,
  w35 INT,
  w36 INT,
  w37 INT,
  w38 INT,
  w39 INT,
  w40 INT,
  w41 INT,
  w42 INT,
  w43 INT,
  w44 INT,
  w45 INT,
  w46 INT,
  w47 INT,
  w48 INT,
  w49 INT,
  w50 INT,
  w51 INT,
  w52 INT,
  w53 INT,
  w54 INT,
  w55 INT,
  w56 INT,
  w57 INT,
  w58 INT,
  w59 INT,
  w60 INT,
  w61 INT,
  w62 INT,
  w63 INT,
  w64 INT,
  w65 INT,
  w66 INT,
  w67 INT,
  w68 INT,
  w69 INT,
  w70 INT,
  w71 INT,
  w72 INT,
  w73 INT,
  w74 INT,
  w75 INT,
  w76 INT,
  w77 INT,
  w78 INT,
  w79 INT,
  w80 INT,
  w81 INT,
  w82 INT,
  w83 INT,
  w84 INT,
  w85 INT,
  w86 INT,
  w87 INT,
  w88 INT,
  w89 INT,
  w90 INT,
  w91 INT,
  w92 INT,
  w93 INT,
  w94 INT,
  w95 INT,
  w96 INT,
  w97 INT,
  w98 INT,
  w99 INT,
  w100 INT,
  w101 INT,
  w102 INT,
  w103 INT,
  w104 INT,
  w105 INT,
  w106 INT,
  w107 INT,
  w108 INT,
  w109 INT,
  w110 INT,
  w111 INT,
  w112 INT,
  w113 INT,
  w114 INT,
  w115 INT,
  w116 INT,
  w117 INT,
  w118 INT,
  w119 INT,
  w120 INT,
  w121 INT,
  w122 INT,
  w123 INT,
  w124 INT,
  w125 INT,
  w126 INT,
  w127 INT,
  w128 INT,
  w129 INT,
  w130 INT,
  w131 INT,
  w132 INT,
  w133 INT,
  w134 INT,
  w135 INT,
  w136 INT,
  w137 INT,
  w138 INT,
  w139 INT,
  w140 INT,
  w141 INT,
  w142 INT,
  w143 INT,
  w144 INT,
  w145 INT,
  w146 INT,
  w147 INT,
  w148 INT,
  w149 INT,
  w150 INT,
  w151 INT,
  w152 INT,
  w153 INT,
  w154 INT,
  w155 INT,
  w156 INT,
  w157 INT,
  w158 INT,
  w159 INT,
  w160 INT,
  w161 INT,
  w162 INT,
  w163 INT,
  w164 INT,
  w165 INT,
  w166 INT,
  w167 INT,
  w168 INT,
  w169 INT,
  w170 INT,
  w171 INT,
  w172 INT,
  w173 INT,
  w174 INT,
  w175 INT,
  w176 INT,
  w177 INT,
  w178 INT,
  w179 INT,
  w180 INT,
  w181 INT,
  w182 INT,
  w183 INT,
  w184 INT,
  w185 INT,
  w186 INT,
  w187 INT,
  w188 INT,
  w189 INT,
  w190 INT,
  w191 INT,
  w192 INT,
  w193 INT,
  w194 INT,
  w195 INT,
  w196 INT,
  w197 INT,
  w198 INT,
  w199 INT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0192_df (target) VALUES (-10);
INSERT INTO t1_tc_42_fct_0192_df (target) VALUES (-9);
INSERT INTO t1_tc_42_fct_0192_df (target) VALUES (-8);
INSERT INTO t1_tc_42_fct_0192_df (target) VALUES (-7);
INSERT INTO t1_tc_42_fct_0192_df (target) VALUES (-6);
INSERT INTO t1_tc_42_fct_0192_df (target) VALUES (-5);
INSERT INTO t1_tc_42_fct_0192_df (target) VALUES (-4);
INSERT INTO t1_tc_42_fct_0192_df (target) VALUES (-3);
INSERT INTO t1_tc_42_fct_0192_df (target) VALUES (-2);
INSERT INTO t1_tc_42_fct_0192_df (target) VALUES (-1);
INSERT INTO t1_tc_42_fct_0192_df (target) VALUES (0);
INSERT INTO t1_tc_42_fct_0192_df (target) VALUES (1);
INSERT INTO t1_tc_42_fct_0192_df (target) VALUES (2);
INSERT INTO t1_tc_42_fct_0192_df (target) VALUES (3);
INSERT INTO t1_tc_42_fct_0192_df (target) VALUES (4);
INSERT INTO t1_tc_42_fct_0192_df (target) VALUES (5);
INSERT INTO t1_tc_42_fct_0192_df (target) VALUES (6);
INSERT INTO t1_tc_42_fct_0192_df (target) VALUES (7);
INSERT INTO t1_tc_42_fct_0192_df (target) VALUES (8);
INSERT INTO t1_tc_42_fct_0192_df (target) VALUES (9);
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0192_df MODIFY target INT;
SELECT 'TC-42-FCT-0192-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0192_df';
SELECT 'TC-42-FCT-0192-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='int','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=int nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0192_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0193-IT
-- Factor probe: WIDE_200_COLS
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: instant, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 宽表：200 列（行宽与字典压力）
DROP TABLE IF EXISTS t1_tc_42_fct_0193_it, t2_tc_42_fct_0193_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=b6cfe6f1b696 factor=WIDE_200_COLS
CREATE TABLE t1_tc_42_fct_0193_it (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  w0 INT,
  w1 INT,
  w2 INT,
  w3 INT,
  w4 INT,
  w5 INT,
  w6 INT,
  w7 INT,
  w8 INT,
  w9 INT,
  w10 INT,
  w11 INT,
  w12 INT,
  w13 INT,
  w14 INT,
  w15 INT,
  w16 INT,
  w17 INT,
  w18 INT,
  w19 INT,
  w20 INT,
  w21 INT,
  w22 INT,
  w23 INT,
  w24 INT,
  w25 INT,
  w26 INT,
  w27 INT,
  w28 INT,
  w29 INT,
  w30 INT,
  w31 INT,
  w32 INT,
  w33 INT,
  w34 INT,
  w35 INT,
  w36 INT,
  w37 INT,
  w38 INT,
  w39 INT,
  w40 INT,
  w41 INT,
  w42 INT,
  w43 INT,
  w44 INT,
  w45 INT,
  w46 INT,
  w47 INT,
  w48 INT,
  w49 INT,
  w50 INT,
  w51 INT,
  w52 INT,
  w53 INT,
  w54 INT,
  w55 INT,
  w56 INT,
  w57 INT,
  w58 INT,
  w59 INT,
  w60 INT,
  w61 INT,
  w62 INT,
  w63 INT,
  w64 INT,
  w65 INT,
  w66 INT,
  w67 INT,
  w68 INT,
  w69 INT,
  w70 INT,
  w71 INT,
  w72 INT,
  w73 INT,
  w74 INT,
  w75 INT,
  w76 INT,
  w77 INT,
  w78 INT,
  w79 INT,
  w80 INT,
  w81 INT,
  w82 INT,
  w83 INT,
  w84 INT,
  w85 INT,
  w86 INT,
  w87 INT,
  w88 INT,
  w89 INT,
  w90 INT,
  w91 INT,
  w92 INT,
  w93 INT,
  w94 INT,
  w95 INT,
  w96 INT,
  w97 INT,
  w98 INT,
  w99 INT,
  w100 INT,
  w101 INT,
  w102 INT,
  w103 INT,
  w104 INT,
  w105 INT,
  w106 INT,
  w107 INT,
  w108 INT,
  w109 INT,
  w110 INT,
  w111 INT,
  w112 INT,
  w113 INT,
  w114 INT,
  w115 INT,
  w116 INT,
  w117 INT,
  w118 INT,
  w119 INT,
  w120 INT,
  w121 INT,
  w122 INT,
  w123 INT,
  w124 INT,
  w125 INT,
  w126 INT,
  w127 INT,
  w128 INT,
  w129 INT,
  w130 INT,
  w131 INT,
  w132 INT,
  w133 INT,
  w134 INT,
  w135 INT,
  w136 INT,
  w137 INT,
  w138 INT,
  w139 INT,
  w140 INT,
  w141 INT,
  w142 INT,
  w143 INT,
  w144 INT,
  w145 INT,
  w146 INT,
  w147 INT,
  w148 INT,
  w149 INT,
  w150 INT,
  w151 INT,
  w152 INT,
  w153 INT,
  w154 INT,
  w155 INT,
  w156 INT,
  w157 INT,
  w158 INT,
  w159 INT,
  w160 INT,
  w161 INT,
  w162 INT,
  w163 INT,
  w164 INT,
  w165 INT,
  w166 INT,
  w167 INT,
  w168 INT,
  w169 INT,
  w170 INT,
  w171 INT,
  w172 INT,
  w173 INT,
  w174 INT,
  w175 INT,
  w176 INT,
  w177 INT,
  w178 INT,
  w179 INT,
  w180 INT,
  w181 INT,
  w182 INT,
  w183 INT,
  w184 INT,
  w185 INT,
  w186 INT,
  w187 INT,
  w188 INT,
  w189 INT,
  w190 INT,
  w191 INT,
  w192 INT,
  w193 INT,
  w194 INT,
  w195 INT,
  w196 INT,
  w197 INT,
  w198 INT,
  w199 INT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0193_it (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0193_it (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0193_it (target) VALUES ('00000002');
INSERT INTO t1_tc_42_fct_0193_it (target) VALUES ('00000003');
INSERT INTO t1_tc_42_fct_0193_it (target) VALUES ('00000004');
INSERT INTO t1_tc_42_fct_0193_it (target) VALUES ('00000005');
INSERT INTO t1_tc_42_fct_0193_it (target) VALUES ('00000006');
INSERT INTO t1_tc_42_fct_0193_it (target) VALUES ('00000007');
INSERT INTO t1_tc_42_fct_0193_it (target) VALUES ('00000008');
INSERT INTO t1_tc_42_fct_0193_it (target) VALUES ('00000009');
INSERT INTO t1_tc_42_fct_0193_it (target) VALUES ('0000000a');
INSERT INTO t1_tc_42_fct_0193_it (target) VALUES ('0000000b');
INSERT INTO t1_tc_42_fct_0193_it (target) VALUES ('0000000c');
INSERT INTO t1_tc_42_fct_0193_it (target) VALUES ('0000000d');
INSERT INTO t1_tc_42_fct_0193_it (target) VALUES ('0000000e');
INSERT INTO t1_tc_42_fct_0193_it (target) VALUES ('0000000f');
INSERT INTO t1_tc_42_fct_0193_it (target) VALUES ('0000000g');
INSERT INTO t1_tc_42_fct_0193_it (target) VALUES ('0000000h');
INSERT INTO t1_tc_42_fct_0193_it (target) VALUES ('0000000i');
INSERT INTO t1_tc_42_fct_0193_it (target) VALUES ('0000000j');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0193_it MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0193-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0193_it';
SELECT 'TC-42-FCT-0193-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0193_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0194-IP
-- Factor probe: WIDE_200_COLS
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 宽表：200 列（行宽与字典压力）
DROP TABLE IF EXISTS t1_tc_42_fct_0194_ip, t2_tc_42_fct_0194_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=342a3b065789 factor=WIDE_200_COLS
CREATE TABLE t1_tc_42_fct_0194_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  w0 INT,
  w1 INT,
  w2 INT,
  w3 INT,
  w4 INT,
  w5 INT,
  w6 INT,
  w7 INT,
  w8 INT,
  w9 INT,
  w10 INT,
  w11 INT,
  w12 INT,
  w13 INT,
  w14 INT,
  w15 INT,
  w16 INT,
  w17 INT,
  w18 INT,
  w19 INT,
  w20 INT,
  w21 INT,
  w22 INT,
  w23 INT,
  w24 INT,
  w25 INT,
  w26 INT,
  w27 INT,
  w28 INT,
  w29 INT,
  w30 INT,
  w31 INT,
  w32 INT,
  w33 INT,
  w34 INT,
  w35 INT,
  w36 INT,
  w37 INT,
  w38 INT,
  w39 INT,
  w40 INT,
  w41 INT,
  w42 INT,
  w43 INT,
  w44 INT,
  w45 INT,
  w46 INT,
  w47 INT,
  w48 INT,
  w49 INT,
  w50 INT,
  w51 INT,
  w52 INT,
  w53 INT,
  w54 INT,
  w55 INT,
  w56 INT,
  w57 INT,
  w58 INT,
  w59 INT,
  w60 INT,
  w61 INT,
  w62 INT,
  w63 INT,
  w64 INT,
  w65 INT,
  w66 INT,
  w67 INT,
  w68 INT,
  w69 INT,
  w70 INT,
  w71 INT,
  w72 INT,
  w73 INT,
  w74 INT,
  w75 INT,
  w76 INT,
  w77 INT,
  w78 INT,
  w79 INT,
  w80 INT,
  w81 INT,
  w82 INT,
  w83 INT,
  w84 INT,
  w85 INT,
  w86 INT,
  w87 INT,
  w88 INT,
  w89 INT,
  w90 INT,
  w91 INT,
  w92 INT,
  w93 INT,
  w94 INT,
  w95 INT,
  w96 INT,
  w97 INT,
  w98 INT,
  w99 INT,
  w100 INT,
  w101 INT,
  w102 INT,
  w103 INT,
  w104 INT,
  w105 INT,
  w106 INT,
  w107 INT,
  w108 INT,
  w109 INT,
  w110 INT,
  w111 INT,
  w112 INT,
  w113 INT,
  w114 INT,
  w115 INT,
  w116 INT,
  w117 INT,
  w118 INT,
  w119 INT,
  w120 INT,
  w121 INT,
  w122 INT,
  w123 INT,
  w124 INT,
  w125 INT,
  w126 INT,
  w127 INT,
  w128 INT,
  w129 INT,
  w130 INT,
  w131 INT,
  w132 INT,
  w133 INT,
  w134 INT,
  w135 INT,
  w136 INT,
  w137 INT,
  w138 INT,
  w139 INT,
  w140 INT,
  w141 INT,
  w142 INT,
  w143 INT,
  w144 INT,
  w145 INT,
  w146 INT,
  w147 INT,
  w148 INT,
  w149 INT,
  w150 INT,
  w151 INT,
  w152 INT,
  w153 INT,
  w154 INT,
  w155 INT,
  w156 INT,
  w157 INT,
  w158 INT,
  w159 INT,
  w160 INT,
  w161 INT,
  w162 INT,
  w163 INT,
  w164 INT,
  w165 INT,
  w166 INT,
  w167 INT,
  w168 INT,
  w169 INT,
  w170 INT,
  w171 INT,
  w172 INT,
  w173 INT,
  w174 INT,
  w175 INT,
  w176 INT,
  w177 INT,
  w178 INT,
  w179 INT,
  w180 INT,
  w181 INT,
  w182 INT,
  w183 INT,
  w184 INT,
  w185 INT,
  w186 INT,
  w187 INT,
  w188 INT,
  w189 INT,
  w190 INT,
  w191 INT,
  w192 INT,
  w193 INT,
  w194 INT,
  w195 INT,
  w196 INT,
  w197 INT,
  w198 INT,
  w199 INT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0194_ip (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0194_ip (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0194_ip (target) VALUES ('00000002');
INSERT INTO t1_tc_42_fct_0194_ip (target) VALUES ('00000003');
INSERT INTO t1_tc_42_fct_0194_ip (target) VALUES ('00000004');
INSERT INTO t1_tc_42_fct_0194_ip (target) VALUES ('00000005');
INSERT INTO t1_tc_42_fct_0194_ip (target) VALUES ('00000006');
INSERT INTO t1_tc_42_fct_0194_ip (target) VALUES ('00000007');
INSERT INTO t1_tc_42_fct_0194_ip (target) VALUES ('00000008');
INSERT INTO t1_tc_42_fct_0194_ip (target) VALUES ('00000009');
INSERT INTO t1_tc_42_fct_0194_ip (target) VALUES ('0000000a');
INSERT INTO t1_tc_42_fct_0194_ip (target) VALUES ('0000000b');
INSERT INTO t1_tc_42_fct_0194_ip (target) VALUES ('0000000c');
INSERT INTO t1_tc_42_fct_0194_ip (target) VALUES ('0000000d');
INSERT INTO t1_tc_42_fct_0194_ip (target) VALUES ('0000000e');
INSERT INTO t1_tc_42_fct_0194_ip (target) VALUES ('0000000f');
INSERT INTO t1_tc_42_fct_0194_ip (target) VALUES ('0000000g');
INSERT INTO t1_tc_42_fct_0194_ip (target) VALUES ('0000000h');
INSERT INTO t1_tc_42_fct_0194_ip (target) VALUES ('0000000i');
INSERT INTO t1_tc_42_fct_0194_ip (target) VALUES ('0000000j');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0194_ip MODIFY target VARCHAR(200) CHARACTER SET utf8mb4, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0194-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0194_ip';
SELECT 'TC-42-FCT-0194-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0194_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0195-DF
-- Factor probe: WIDE_200_COLS
-- Type: VARCHAR(100) -> VARCHAR(200), Algorithm: default, Expected: SUCCESS
-- Transition ID: VC-07
-- Factor note: 宽表：200 列（行宽与字典压力）
DROP TABLE IF EXISTS t1_tc_42_fct_0195_df, t2_tc_42_fct_0195_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=9297b1e048d0 factor=WIDE_200_COLS
CREATE TABLE t1_tc_42_fct_0195_df (
  id INT NOT NULL AUTO_INCREMENT,
  target VARCHAR(100) CHARACTER SET utf8mb4,
  w0 INT,
  w1 INT,
  w2 INT,
  w3 INT,
  w4 INT,
  w5 INT,
  w6 INT,
  w7 INT,
  w8 INT,
  w9 INT,
  w10 INT,
  w11 INT,
  w12 INT,
  w13 INT,
  w14 INT,
  w15 INT,
  w16 INT,
  w17 INT,
  w18 INT,
  w19 INT,
  w20 INT,
  w21 INT,
  w22 INT,
  w23 INT,
  w24 INT,
  w25 INT,
  w26 INT,
  w27 INT,
  w28 INT,
  w29 INT,
  w30 INT,
  w31 INT,
  w32 INT,
  w33 INT,
  w34 INT,
  w35 INT,
  w36 INT,
  w37 INT,
  w38 INT,
  w39 INT,
  w40 INT,
  w41 INT,
  w42 INT,
  w43 INT,
  w44 INT,
  w45 INT,
  w46 INT,
  w47 INT,
  w48 INT,
  w49 INT,
  w50 INT,
  w51 INT,
  w52 INT,
  w53 INT,
  w54 INT,
  w55 INT,
  w56 INT,
  w57 INT,
  w58 INT,
  w59 INT,
  w60 INT,
  w61 INT,
  w62 INT,
  w63 INT,
  w64 INT,
  w65 INT,
  w66 INT,
  w67 INT,
  w68 INT,
  w69 INT,
  w70 INT,
  w71 INT,
  w72 INT,
  w73 INT,
  w74 INT,
  w75 INT,
  w76 INT,
  w77 INT,
  w78 INT,
  w79 INT,
  w80 INT,
  w81 INT,
  w82 INT,
  w83 INT,
  w84 INT,
  w85 INT,
  w86 INT,
  w87 INT,
  w88 INT,
  w89 INT,
  w90 INT,
  w91 INT,
  w92 INT,
  w93 INT,
  w94 INT,
  w95 INT,
  w96 INT,
  w97 INT,
  w98 INT,
  w99 INT,
  w100 INT,
  w101 INT,
  w102 INT,
  w103 INT,
  w104 INT,
  w105 INT,
  w106 INT,
  w107 INT,
  w108 INT,
  w109 INT,
  w110 INT,
  w111 INT,
  w112 INT,
  w113 INT,
  w114 INT,
  w115 INT,
  w116 INT,
  w117 INT,
  w118 INT,
  w119 INT,
  w120 INT,
  w121 INT,
  w122 INT,
  w123 INT,
  w124 INT,
  w125 INT,
  w126 INT,
  w127 INT,
  w128 INT,
  w129 INT,
  w130 INT,
  w131 INT,
  w132 INT,
  w133 INT,
  w134 INT,
  w135 INT,
  w136 INT,
  w137 INT,
  w138 INT,
  w139 INT,
  w140 INT,
  w141 INT,
  w142 INT,
  w143 INT,
  w144 INT,
  w145 INT,
  w146 INT,
  w147 INT,
  w148 INT,
  w149 INT,
  w150 INT,
  w151 INT,
  w152 INT,
  w153 INT,
  w154 INT,
  w155 INT,
  w156 INT,
  w157 INT,
  w158 INT,
  w159 INT,
  w160 INT,
  w161 INT,
  w162 INT,
  w163 INT,
  w164 INT,
  w165 INT,
  w166 INT,
  w167 INT,
  w168 INT,
  w169 INT,
  w170 INT,
  w171 INT,
  w172 INT,
  w173 INT,
  w174 INT,
  w175 INT,
  w176 INT,
  w177 INT,
  w178 INT,
  w179 INT,
  w180 INT,
  w181 INT,
  w182 INT,
  w183 INT,
  w184 INT,
  w185 INT,
  w186 INT,
  w187 INT,
  w188 INT,
  w189 INT,
  w190 INT,
  w191 INT,
  w192 INT,
  w193 INT,
  w194 INT,
  w195 INT,
  w196 INT,
  w197 INT,
  w198 INT,
  w199 INT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0195_df (target) VALUES ('00000000');
INSERT INTO t1_tc_42_fct_0195_df (target) VALUES ('00000001');
INSERT INTO t1_tc_42_fct_0195_df (target) VALUES ('00000002');
INSERT INTO t1_tc_42_fct_0195_df (target) VALUES ('00000003');
INSERT INTO t1_tc_42_fct_0195_df (target) VALUES ('00000004');
INSERT INTO t1_tc_42_fct_0195_df (target) VALUES ('00000005');
INSERT INTO t1_tc_42_fct_0195_df (target) VALUES ('00000006');
INSERT INTO t1_tc_42_fct_0195_df (target) VALUES ('00000007');
INSERT INTO t1_tc_42_fct_0195_df (target) VALUES ('00000008');
INSERT INTO t1_tc_42_fct_0195_df (target) VALUES ('00000009');
INSERT INTO t1_tc_42_fct_0195_df (target) VALUES ('0000000a');
INSERT INTO t1_tc_42_fct_0195_df (target) VALUES ('0000000b');
INSERT INTO t1_tc_42_fct_0195_df (target) VALUES ('0000000c');
INSERT INTO t1_tc_42_fct_0195_df (target) VALUES ('0000000d');
INSERT INTO t1_tc_42_fct_0195_df (target) VALUES ('0000000e');
INSERT INTO t1_tc_42_fct_0195_df (target) VALUES ('0000000f');
INSERT INTO t1_tc_42_fct_0195_df (target) VALUES ('0000000g');
INSERT INTO t1_tc_42_fct_0195_df (target) VALUES ('0000000h');
INSERT INTO t1_tc_42_fct_0195_df (target) VALUES ('0000000i');
INSERT INTO t1_tc_42_fct_0195_df (target) VALUES ('0000000j');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0195_df MODIFY target VARCHAR(200) CHARACTER SET utf8mb4;
SELECT 'TC-42-FCT-0195-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0195_df';
SELECT 'TC-42-FCT-0195-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varchar(200)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varchar(200) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0195_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0196-IT
-- Factor probe: WIDE_200_COLS
-- Type: CHAR(1) -> CHAR(2), Algorithm: instant, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 宽表：200 列（行宽与字典压力）
DROP TABLE IF EXISTS t1_tc_42_fct_0196_it, t2_tc_42_fct_0196_it;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=31db637bb78a factor=WIDE_200_COLS
CREATE TABLE t1_tc_42_fct_0196_it (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  w0 INT,
  w1 INT,
  w2 INT,
  w3 INT,
  w4 INT,
  w5 INT,
  w6 INT,
  w7 INT,
  w8 INT,
  w9 INT,
  w10 INT,
  w11 INT,
  w12 INT,
  w13 INT,
  w14 INT,
  w15 INT,
  w16 INT,
  w17 INT,
  w18 INT,
  w19 INT,
  w20 INT,
  w21 INT,
  w22 INT,
  w23 INT,
  w24 INT,
  w25 INT,
  w26 INT,
  w27 INT,
  w28 INT,
  w29 INT,
  w30 INT,
  w31 INT,
  w32 INT,
  w33 INT,
  w34 INT,
  w35 INT,
  w36 INT,
  w37 INT,
  w38 INT,
  w39 INT,
  w40 INT,
  w41 INT,
  w42 INT,
  w43 INT,
  w44 INT,
  w45 INT,
  w46 INT,
  w47 INT,
  w48 INT,
  w49 INT,
  w50 INT,
  w51 INT,
  w52 INT,
  w53 INT,
  w54 INT,
  w55 INT,
  w56 INT,
  w57 INT,
  w58 INT,
  w59 INT,
  w60 INT,
  w61 INT,
  w62 INT,
  w63 INT,
  w64 INT,
  w65 INT,
  w66 INT,
  w67 INT,
  w68 INT,
  w69 INT,
  w70 INT,
  w71 INT,
  w72 INT,
  w73 INT,
  w74 INT,
  w75 INT,
  w76 INT,
  w77 INT,
  w78 INT,
  w79 INT,
  w80 INT,
  w81 INT,
  w82 INT,
  w83 INT,
  w84 INT,
  w85 INT,
  w86 INT,
  w87 INT,
  w88 INT,
  w89 INT,
  w90 INT,
  w91 INT,
  w92 INT,
  w93 INT,
  w94 INT,
  w95 INT,
  w96 INT,
  w97 INT,
  w98 INT,
  w99 INT,
  w100 INT,
  w101 INT,
  w102 INT,
  w103 INT,
  w104 INT,
  w105 INT,
  w106 INT,
  w107 INT,
  w108 INT,
  w109 INT,
  w110 INT,
  w111 INT,
  w112 INT,
  w113 INT,
  w114 INT,
  w115 INT,
  w116 INT,
  w117 INT,
  w118 INT,
  w119 INT,
  w120 INT,
  w121 INT,
  w122 INT,
  w123 INT,
  w124 INT,
  w125 INT,
  w126 INT,
  w127 INT,
  w128 INT,
  w129 INT,
  w130 INT,
  w131 INT,
  w132 INT,
  w133 INT,
  w134 INT,
  w135 INT,
  w136 INT,
  w137 INT,
  w138 INT,
  w139 INT,
  w140 INT,
  w141 INT,
  w142 INT,
  w143 INT,
  w144 INT,
  w145 INT,
  w146 INT,
  w147 INT,
  w148 INT,
  w149 INT,
  w150 INT,
  w151 INT,
  w152 INT,
  w153 INT,
  w154 INT,
  w155 INT,
  w156 INT,
  w157 INT,
  w158 INT,
  w159 INT,
  w160 INT,
  w161 INT,
  w162 INT,
  w163 INT,
  w164 INT,
  w165 INT,
  w166 INT,
  w167 INT,
  w168 INT,
  w169 INT,
  w170 INT,
  w171 INT,
  w172 INT,
  w173 INT,
  w174 INT,
  w175 INT,
  w176 INT,
  w177 INT,
  w178 INT,
  w179 INT,
  w180 INT,
  w181 INT,
  w182 INT,
  w183 INT,
  w184 INT,
  w185 INT,
  w186 INT,
  w187 INT,
  w188 INT,
  w189 INT,
  w190 INT,
  w191 INT,
  w192 INT,
  w193 INT,
  w194 INT,
  w195 INT,
  w196 INT,
  w197 INT,
  w198 INT,
  w199 INT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0196_it (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0196_it (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0196_it (target) VALUES ('2');
INSERT INTO t1_tc_42_fct_0196_it (target) VALUES ('3');
INSERT INTO t1_tc_42_fct_0196_it (target) VALUES ('4');
INSERT INTO t1_tc_42_fct_0196_it (target) VALUES ('5');
INSERT INTO t1_tc_42_fct_0196_it (target) VALUES ('6');
INSERT INTO t1_tc_42_fct_0196_it (target) VALUES ('7');
INSERT INTO t1_tc_42_fct_0196_it (target) VALUES ('8');
INSERT INTO t1_tc_42_fct_0196_it (target) VALUES ('9');
INSERT INTO t1_tc_42_fct_0196_it (target) VALUES ('a');
INSERT INTO t1_tc_42_fct_0196_it (target) VALUES ('b');
INSERT INTO t1_tc_42_fct_0196_it (target) VALUES ('c');
INSERT INTO t1_tc_42_fct_0196_it (target) VALUES ('d');
INSERT INTO t1_tc_42_fct_0196_it (target) VALUES ('e');
INSERT INTO t1_tc_42_fct_0196_it (target) VALUES ('f');
INSERT INTO t1_tc_42_fct_0196_it (target) VALUES ('g');
INSERT INTO t1_tc_42_fct_0196_it (target) VALUES ('h');
INSERT INTO t1_tc_42_fct_0196_it (target) VALUES ('i');
INSERT INTO t1_tc_42_fct_0196_it (target) VALUES ('j');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0196_it MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INSTANT;
SELECT 'TC-42-FCT-0196-IT#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0196_it';
SELECT 'TC-42-FCT-0196-IT#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0196_it' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0197-IP
-- Factor probe: WIDE_200_COLS
-- Type: CHAR(1) -> CHAR(2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 宽表：200 列（行宽与字典压力）
DROP TABLE IF EXISTS t1_tc_42_fct_0197_ip, t2_tc_42_fct_0197_ip;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=009726cba8fb factor=WIDE_200_COLS
CREATE TABLE t1_tc_42_fct_0197_ip (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  w0 INT,
  w1 INT,
  w2 INT,
  w3 INT,
  w4 INT,
  w5 INT,
  w6 INT,
  w7 INT,
  w8 INT,
  w9 INT,
  w10 INT,
  w11 INT,
  w12 INT,
  w13 INT,
  w14 INT,
  w15 INT,
  w16 INT,
  w17 INT,
  w18 INT,
  w19 INT,
  w20 INT,
  w21 INT,
  w22 INT,
  w23 INT,
  w24 INT,
  w25 INT,
  w26 INT,
  w27 INT,
  w28 INT,
  w29 INT,
  w30 INT,
  w31 INT,
  w32 INT,
  w33 INT,
  w34 INT,
  w35 INT,
  w36 INT,
  w37 INT,
  w38 INT,
  w39 INT,
  w40 INT,
  w41 INT,
  w42 INT,
  w43 INT,
  w44 INT,
  w45 INT,
  w46 INT,
  w47 INT,
  w48 INT,
  w49 INT,
  w50 INT,
  w51 INT,
  w52 INT,
  w53 INT,
  w54 INT,
  w55 INT,
  w56 INT,
  w57 INT,
  w58 INT,
  w59 INT,
  w60 INT,
  w61 INT,
  w62 INT,
  w63 INT,
  w64 INT,
  w65 INT,
  w66 INT,
  w67 INT,
  w68 INT,
  w69 INT,
  w70 INT,
  w71 INT,
  w72 INT,
  w73 INT,
  w74 INT,
  w75 INT,
  w76 INT,
  w77 INT,
  w78 INT,
  w79 INT,
  w80 INT,
  w81 INT,
  w82 INT,
  w83 INT,
  w84 INT,
  w85 INT,
  w86 INT,
  w87 INT,
  w88 INT,
  w89 INT,
  w90 INT,
  w91 INT,
  w92 INT,
  w93 INT,
  w94 INT,
  w95 INT,
  w96 INT,
  w97 INT,
  w98 INT,
  w99 INT,
  w100 INT,
  w101 INT,
  w102 INT,
  w103 INT,
  w104 INT,
  w105 INT,
  w106 INT,
  w107 INT,
  w108 INT,
  w109 INT,
  w110 INT,
  w111 INT,
  w112 INT,
  w113 INT,
  w114 INT,
  w115 INT,
  w116 INT,
  w117 INT,
  w118 INT,
  w119 INT,
  w120 INT,
  w121 INT,
  w122 INT,
  w123 INT,
  w124 INT,
  w125 INT,
  w126 INT,
  w127 INT,
  w128 INT,
  w129 INT,
  w130 INT,
  w131 INT,
  w132 INT,
  w133 INT,
  w134 INT,
  w135 INT,
  w136 INT,
  w137 INT,
  w138 INT,
  w139 INT,
  w140 INT,
  w141 INT,
  w142 INT,
  w143 INT,
  w144 INT,
  w145 INT,
  w146 INT,
  w147 INT,
  w148 INT,
  w149 INT,
  w150 INT,
  w151 INT,
  w152 INT,
  w153 INT,
  w154 INT,
  w155 INT,
  w156 INT,
  w157 INT,
  w158 INT,
  w159 INT,
  w160 INT,
  w161 INT,
  w162 INT,
  w163 INT,
  w164 INT,
  w165 INT,
  w166 INT,
  w167 INT,
  w168 INT,
  w169 INT,
  w170 INT,
  w171 INT,
  w172 INT,
  w173 INT,
  w174 INT,
  w175 INT,
  w176 INT,
  w177 INT,
  w178 INT,
  w179 INT,
  w180 INT,
  w181 INT,
  w182 INT,
  w183 INT,
  w184 INT,
  w185 INT,
  w186 INT,
  w187 INT,
  w188 INT,
  w189 INT,
  w190 INT,
  w191 INT,
  w192 INT,
  w193 INT,
  w194 INT,
  w195 INT,
  w196 INT,
  w197 INT,
  w198 INT,
  w199 INT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0197_ip (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0197_ip (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0197_ip (target) VALUES ('2');
INSERT INTO t1_tc_42_fct_0197_ip (target) VALUES ('3');
INSERT INTO t1_tc_42_fct_0197_ip (target) VALUES ('4');
INSERT INTO t1_tc_42_fct_0197_ip (target) VALUES ('5');
INSERT INTO t1_tc_42_fct_0197_ip (target) VALUES ('6');
INSERT INTO t1_tc_42_fct_0197_ip (target) VALUES ('7');
INSERT INTO t1_tc_42_fct_0197_ip (target) VALUES ('8');
INSERT INTO t1_tc_42_fct_0197_ip (target) VALUES ('9');
INSERT INTO t1_tc_42_fct_0197_ip (target) VALUES ('a');
INSERT INTO t1_tc_42_fct_0197_ip (target) VALUES ('b');
INSERT INTO t1_tc_42_fct_0197_ip (target) VALUES ('c');
INSERT INTO t1_tc_42_fct_0197_ip (target) VALUES ('d');
INSERT INTO t1_tc_42_fct_0197_ip (target) VALUES ('e');
INSERT INTO t1_tc_42_fct_0197_ip (target) VALUES ('f');
INSERT INTO t1_tc_42_fct_0197_ip (target) VALUES ('g');
INSERT INTO t1_tc_42_fct_0197_ip (target) VALUES ('h');
INSERT INTO t1_tc_42_fct_0197_ip (target) VALUES ('i');
INSERT INTO t1_tc_42_fct_0197_ip (target) VALUES ('j');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0197_ip MODIFY target CHAR(2) CHARACTER SET latin1, ALGORITHM=INPLACE;
SELECT 'TC-42-FCT-0197-IP#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0197_ip';
SELECT 'TC-42-FCT-0197-IP#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0197_ip' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

-- Test Case: TC-42-FCT-0198-DF
-- Factor probe: WIDE_200_COLS
-- Type: CHAR(1) -> CHAR(2), Algorithm: default, Expected: SUCCESS
-- Transition ID: CHAR-01
-- Factor note: 宽表：200 列（行宽与字典压力）
DROP TABLE IF EXISTS t1_tc_42_fct_0198_df, t2_tc_42_fct_0198_df;
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=4dc4465aa162 factor=WIDE_200_COLS
CREATE TABLE t1_tc_42_fct_0198_df (
  id INT NOT NULL AUTO_INCREMENT,
  target CHAR(1) CHARACTER SET latin1,
  w0 INT,
  w1 INT,
  w2 INT,
  w3 INT,
  w4 INT,
  w5 INT,
  w6 INT,
  w7 INT,
  w8 INT,
  w9 INT,
  w10 INT,
  w11 INT,
  w12 INT,
  w13 INT,
  w14 INT,
  w15 INT,
  w16 INT,
  w17 INT,
  w18 INT,
  w19 INT,
  w20 INT,
  w21 INT,
  w22 INT,
  w23 INT,
  w24 INT,
  w25 INT,
  w26 INT,
  w27 INT,
  w28 INT,
  w29 INT,
  w30 INT,
  w31 INT,
  w32 INT,
  w33 INT,
  w34 INT,
  w35 INT,
  w36 INT,
  w37 INT,
  w38 INT,
  w39 INT,
  w40 INT,
  w41 INT,
  w42 INT,
  w43 INT,
  w44 INT,
  w45 INT,
  w46 INT,
  w47 INT,
  w48 INT,
  w49 INT,
  w50 INT,
  w51 INT,
  w52 INT,
  w53 INT,
  w54 INT,
  w55 INT,
  w56 INT,
  w57 INT,
  w58 INT,
  w59 INT,
  w60 INT,
  w61 INT,
  w62 INT,
  w63 INT,
  w64 INT,
  w65 INT,
  w66 INT,
  w67 INT,
  w68 INT,
  w69 INT,
  w70 INT,
  w71 INT,
  w72 INT,
  w73 INT,
  w74 INT,
  w75 INT,
  w76 INT,
  w77 INT,
  w78 INT,
  w79 INT,
  w80 INT,
  w81 INT,
  w82 INT,
  w83 INT,
  w84 INT,
  w85 INT,
  w86 INT,
  w87 INT,
  w88 INT,
  w89 INT,
  w90 INT,
  w91 INT,
  w92 INT,
  w93 INT,
  w94 INT,
  w95 INT,
  w96 INT,
  w97 INT,
  w98 INT,
  w99 INT,
  w100 INT,
  w101 INT,
  w102 INT,
  w103 INT,
  w104 INT,
  w105 INT,
  w106 INT,
  w107 INT,
  w108 INT,
  w109 INT,
  w110 INT,
  w111 INT,
  w112 INT,
  w113 INT,
  w114 INT,
  w115 INT,
  w116 INT,
  w117 INT,
  w118 INT,
  w119 INT,
  w120 INT,
  w121 INT,
  w122 INT,
  w123 INT,
  w124 INT,
  w125 INT,
  w126 INT,
  w127 INT,
  w128 INT,
  w129 INT,
  w130 INT,
  w131 INT,
  w132 INT,
  w133 INT,
  w134 INT,
  w135 INT,
  w136 INT,
  w137 INT,
  w138 INT,
  w139 INT,
  w140 INT,
  w141 INT,
  w142 INT,
  w143 INT,
  w144 INT,
  w145 INT,
  w146 INT,
  w147 INT,
  w148 INT,
  w149 INT,
  w150 INT,
  w151 INT,
  w152 INT,
  w153 INT,
  w154 INT,
  w155 INT,
  w156 INT,
  w157 INT,
  w158 INT,
  w159 INT,
  w160 INT,
  w161 INT,
  w162 INT,
  w163 INT,
  w164 INT,
  w165 INT,
  w166 INT,
  w167 INT,
  w168 INT,
  w169 INT,
  w170 INT,
  w171 INT,
  w172 INT,
  w173 INT,
  w174 INT,
  w175 INT,
  w176 INT,
  w177 INT,
  w178 INT,
  w179 INT,
  w180 INT,
  w181 INT,
  w182 INT,
  w183 INT,
  w184 INT,
  w185 INT,
  w186 INT,
  w187 INT,
  w188 INT,
  w189 INT,
  w190 INT,
  w191 INT,
  w192 INT,
  w193 INT,
  w194 INT,
  w195 INT,
  w196 INT,
  w197 INT,
  w198 INT,
  w199 INT,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_pad (pad)
) ENGINE=InnoDB;
INSERT INTO t1_tc_42_fct_0198_df (target) VALUES ('0');
INSERT INTO t1_tc_42_fct_0198_df (target) VALUES ('1');
INSERT INTO t1_tc_42_fct_0198_df (target) VALUES ('2');
INSERT INTO t1_tc_42_fct_0198_df (target) VALUES ('3');
INSERT INTO t1_tc_42_fct_0198_df (target) VALUES ('4');
INSERT INTO t1_tc_42_fct_0198_df (target) VALUES ('5');
INSERT INTO t1_tc_42_fct_0198_df (target) VALUES ('6');
INSERT INTO t1_tc_42_fct_0198_df (target) VALUES ('7');
INSERT INTO t1_tc_42_fct_0198_df (target) VALUES ('8');
INSERT INTO t1_tc_42_fct_0198_df (target) VALUES ('9');
INSERT INTO t1_tc_42_fct_0198_df (target) VALUES ('a');
INSERT INTO t1_tc_42_fct_0198_df (target) VALUES ('b');
INSERT INTO t1_tc_42_fct_0198_df (target) VALUES ('c');
INSERT INTO t1_tc_42_fct_0198_df (target) VALUES ('d');
INSERT INTO t1_tc_42_fct_0198_df (target) VALUES ('e');
INSERT INTO t1_tc_42_fct_0198_df (target) VALUES ('f');
INSERT INTO t1_tc_42_fct_0198_df (target) VALUES ('g');
INSERT INTO t1_tc_42_fct_0198_df (target) VALUES ('h');
INSERT INTO t1_tc_42_fct_0198_df (target) VALUES ('i');
INSERT INTO t1_tc_42_fct_0198_df (target) VALUES ('j');
-- ALTER expected SUCCESS (build expected SUCCESS)
ALTER TABLE t1_tc_42_fct_0198_df MODIFY target CHAR(2) CHARACTER SET latin1;
SELECT 'TC-42-FCT-0198-DF#BUILD_CHECK' AS test_id, 'PASS' AS result,
       CONCAT('table_exists=',COUNT(*)) AS mismatch
FROM information_schema.tables
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0198_df';
SELECT 'TC-42-FCT-0198-DF#META_TYPE' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='char(2)','PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=char(2) nullable=YES has_default=0 charset=* collation=* extra=* pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_42_fct_0198_df' AND column_name='target';
-- 收尾：清掉触发器/视图（表按项目要求保留）

