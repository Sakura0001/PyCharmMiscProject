-- ============================================================
-- RDS MySQL DDL 秒级/在线修改列类型 测试套件 — 内网环境
-- 环境说明: 所有功能开关默认开启
-- 覆盖类型: BINARY + VARBINARY + DECIMAL + TEXT + BLOB + BIT
-- 覆盖算法: INSTANT + INPLACE (增强类型 INSTANT 预期成功: BINARY/VARBINARY/DECIMAL 已确认支持)
-- ============================================================
-- 本文件由 generate_test_sql.py 自动生成, 请勿手动修改
-- Suite-Revision: 1186b16f779b   (生成器源码哈希; 时间戳见 results/generation_manifest.json)
-- 用例 ID 规则: TC-<文件号>-<作用域>-<序号>-<IT|IP>  —— 全局唯一
--   作用域 REG=普通表 OFAT/二元组, ATR=列属性保持, SPE=特殊模式,
--          FK=外键, PTK=分区(目标列是分区键), PNK=分区(目标列非分区键)
-- ============================================================

SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
SET SESSION innodb_lock_wait_timeout = 50;

-- File 25: BIT INSTANT

-- Test Case: TC-25-REG-0001-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=7c6660b195d5 column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0001_it, t2_tc_25_reg_0001_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0001_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0001_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0001_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0001_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0001_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0001_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0001_it MODIFY target BIT(8), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0001_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0001_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0001_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0001_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0001_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0001_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0001_it (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0001_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0001_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0001_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0001_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0001_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0001_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0001_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0001_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0001_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0001_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0001_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0001_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0001_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0001-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0001_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0001_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0001_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0001_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0001_it a JOIN t2_tc_25_reg_0001_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0001-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0001_it' AND column_name='target';

-- Test Case: TC-25-REG-0002-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=14029d415b71 column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0002_it, t2_tc_25_reg_0002_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0002_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t1_tc_25_reg_0002_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0002_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0002_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0002_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0002_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0002_it MODIFY target BIT(8), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0002_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0002_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0002_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0002_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0002_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0002_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0002_it (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0002_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t2_tc_25_reg_0002_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0002_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0002_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0002_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0002_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0002_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0002_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0002_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0002_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0002_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0002_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0002_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0002-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0002_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0002_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0002_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0002_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0002_it a JOIN t2_tc_25_reg_0002_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0002-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0002_it' AND column_name='target';

-- Test Case: TC-25-REG-0003-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=cef1261529c6 column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0003_it, t2_tc_25_reg_0003_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0003_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t1_tc_25_reg_0003_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0003_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0003_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0003_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0003_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0003_it MODIFY target BIT(8), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0003_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0003_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0003_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0003_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0003_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0003_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0003_it (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0003_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t2_tc_25_reg_0003_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0003_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0003_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0003_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0003_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0003_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0003_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0003_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0003_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0003_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0003_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0003_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0003-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0003_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0003_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0003_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0003_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0003_it a JOIN t2_tc_25_reg_0003_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0003-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0003_it' AND column_name='target';

-- Test Case: TC-25-REG-0004-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: FAIL
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=FAIL build=SUCCESS assertions=2 neg_probes=0 alter_sha=a41109ae9323 errno=[1659,1845,1846,3780] column_type=bit(1)
DROP TABLE IF EXISTS t1_tc_25_reg_0004_it, t2_tc_25_reg_0004_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0004_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0004_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0004_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0004_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0004_it (target) VALUES (b'0');
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_25_reg_0004_it MODIFY target BIT(8), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0004_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0004_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0004_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0004_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0004_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0004_it (target) VALUES (b'1010');
-- Oracle table: BIT(1)
CREATE TABLE t2_tc_25_reg_0004_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0004_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0004_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0004_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0004_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0004_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0004_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0004_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0004_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0004_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0004_it (target) VALUES (b'1010');
SELECT 'TC-25-REG-0004-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0004_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0004_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0004_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0004_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0004_it a JOIN t2_tc_25_reg_0004_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0004-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(1)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(1) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0004_it' AND column_name='target';

-- Test Case: TC-25-REG-0005-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=c4a4dbdd92ef column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0005_it, t2_tc_25_reg_0005_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0005_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0005_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0005_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0005_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0005_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0005_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0005_it MODIFY target BIT(8), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0005_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0005_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0005_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0005_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0005_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0005_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0005_it (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0005_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0005_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0005_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0005_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0005_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0005_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0005_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0005_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0005_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0005_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0005_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0005_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0005_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0005-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0005_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0005_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0005_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0005_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0005_it a JOIN t2_tc_25_reg_0005_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0005-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0005_it' AND column_name='target';

-- Test Case: TC-25-REG-0006-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=6acee86966ba column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0006_it, t2_tc_25_reg_0006_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0006_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0006_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0006_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0006_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0006_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0006_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0006_it MODIFY target BIT(8), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0006_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0006_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0006_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0006_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0006_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0006_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0006_it (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0006_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0006_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0006_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0006_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0006_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0006_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0006_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0006_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0006_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0006_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0006_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0006_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0006_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0006-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0006_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0006_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0006_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0006_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0006_it a JOIN t2_tc_25_reg_0006_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0006-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0006_it' AND column_name='target';

-- Test Case: TC-25-REG-0007-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=2416bb2ece09 column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0007_it, t2_tc_25_reg_0007_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0007_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0007_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0007_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0007_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0007_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0007_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0007_it MODIFY target BIT(8), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0007_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0007_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0007_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0007_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0007_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0007_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0007_it (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0007_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0007_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0007_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0007_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0007_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0007_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0007_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0007_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0007_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0007_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0007_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0007_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0007_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0007-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0007_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0007_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0007_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0007_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0007_it a JOIN t2_tc_25_reg_0007_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0007-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0007_it' AND column_name='target';

-- Test Case: TC-25-REG-0008-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=4541132cfdb9 column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0008_it, t2_tc_25_reg_0008_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0008_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0008_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0008_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0008_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0008_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0008_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0008_it MODIFY target BIT(8), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0008_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0008_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0008_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0008_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0008_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0008_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0008_it (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0008_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0008_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0008_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0008_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0008_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0008_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0008_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0008_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0008_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0008_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0008_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0008_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0008_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0008-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0008_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0008_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0008_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0008_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0008_it a JOIN t2_tc_25_reg_0008_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0008-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0008_it' AND column_name='target';

-- Test Case: TC-25-REG-0009-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=a23d494c2edd column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0009_it, t2_tc_25_reg_0009_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0009_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0009_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0009_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0009_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0009_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0009_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0009_it MODIFY target BIT(8), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0009_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0009_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0009_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0009_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0009_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0009_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0009_it (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0009_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0009_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0009_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0009_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0009_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0009_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0009_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0009_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0009_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0009_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0009_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0009_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0009_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0009-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0009_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0009_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0009_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0009_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0009_it a JOIN t2_tc_25_reg_0009_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0009-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0009_it' AND column_name='target';

-- Test Case: TC-25-REG-0010-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=cc600e358d99 column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0010_it, t2_tc_25_reg_0010_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0010_it (
  target BIT(1),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0010_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0010_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0010_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0010_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0010_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0010_it MODIFY target BIT(8), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0010_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0010_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0010_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0010_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0010_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0010_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0010_it (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0010_it (
  target BIT(8),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0010_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0010_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0010_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0010_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0010_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0010_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0010_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0010_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0010_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0010_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0010_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0010_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0010-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0010_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0010_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0010_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0010_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0010_it a JOIN t2_tc_25_reg_0010_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0010-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0010_it' AND column_name='target';

-- Test Case: TC-25-REG-0011-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=1ac940c7ba5f column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0011_it, t2_tc_25_reg_0011_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0011_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BIT(1), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0011_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0011_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0011_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0011_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0011_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0011_it MODIFY target BIT(8), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0011_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0011_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0011_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0011_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0011_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0011_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0011_it (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0011_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BIT(8), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0011_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0011_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0011_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0011_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0011_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0011_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0011_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0011_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0011_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0011_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0011_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0011_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0011-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0011_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0011_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0011_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0011_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0011_it a JOIN t2_tc_25_reg_0011_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0011-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=4,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=4]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0011_it' AND column_name='target';

-- Test Case: TC-25-REG-0012-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=dbc19a379adc column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0012_it, t2_tc_25_reg_0012_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0012_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0012_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0012_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0012_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0012_it (target) VALUES (b'0');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0012_it MODIFY target BIT(8) NOT NULL, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0012_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0012_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0012_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0012_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0012_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0012_it (target) VALUES (b'1010');
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0012_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0012_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0012_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0012_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0012_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0012_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0012_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0012_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0012_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0012_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0012_it (target) VALUES (b'1010');
SELECT 'TC-25-REG-0012-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0012_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0012_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0012_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0012_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0012_it a JOIN t2_tc_25_reg_0012_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0012-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0012_it' AND column_name='target';

-- Test Case: TC-25-REG-0013-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=fd07da120398 column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0013_it, t2_tc_25_reg_0013_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0013_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1) DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0013_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0013_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0013_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0013_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0013_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0013_it MODIFY target BIT(8) DEFAULT b'0', ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0013_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0013_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0013_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0013_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0013_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0013_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0013_it (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0013_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0013_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0013_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0013_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0013_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0013_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0013_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0013_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0013_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0013_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0013_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0013_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0013_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0013-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0013_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0013_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0013_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0013_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0013_it a JOIN t2_tc_25_reg_0013_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0013-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0013_it' AND column_name='target';

-- Test Case: TC-25-REG-0014-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=94675972e59d column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0014_it, t2_tc_25_reg_0014_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0014_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0014_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0014_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0014_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0014_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0014_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0014_it MODIFY target BIT(8) DEFAULT NULL, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0014_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0014_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0014_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0014_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0014_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0014_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0014_it (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0014_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0014_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0014_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0014_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0014_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0014_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0014_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0014_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0014_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0014_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0014_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0014_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0014_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0014-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0014_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0014_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0014_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0014_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0014_it a JOIN t2_tc_25_reg_0014_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0014-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0014_it' AND column_name='target';

-- Test Case: TC-25-REG-0015-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=a3c9589129dc column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0015_it, t2_tc_25_reg_0015_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0015_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0015_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0015_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0015_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0015_it (target) VALUES (b'0');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0015_it MODIFY target BIT(8) NOT NULL DEFAULT b'0', ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0015_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0015_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0015_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0015_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0015_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0015_it (target) VALUES (b'1010');
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0015_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0015_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0015_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0015_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0015_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0015_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0015_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0015_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0015_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0015_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0015_it (target) VALUES (b'1010');
SELECT 'TC-25-REG-0015-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0015_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0015_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0015_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0015_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0015_it a JOIN t2_tc_25_reg_0015_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0015-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=NO has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0015_it' AND column_name='target';

-- Test Case: TC-25-REG-0016-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=25e990c1b4e3 column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0016_it, t2_tc_25_reg_0016_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0016_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0016_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0016_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0016_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0016_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0016_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0016_it MODIFY target BIT(8) INVISIBLE, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0016_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0016_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0016_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0016_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0016_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0016_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0016_it (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0016_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0016_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0016_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0016_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0016_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0016_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0016_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0016_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0016_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0016_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0016_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0016_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0016_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0016-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0016_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0016_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0016_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0016_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0016_it a JOIN t2_tc_25_reg_0016_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0016-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> 'INVISIBLE')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra=INVISIBLE pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0016_it' AND column_name='target';

-- Test Case: TC-25-REG-0017-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=dc7d30c3c054 column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0017_it, t2_tc_25_reg_0017_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0017_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0017_it MODIFY target BIT(8), ALGORITHM=instant;
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0017_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-25-REG-0017-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0017_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0017_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0017_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0017_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0017_it a JOIN t2_tc_25_reg_0017_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0017-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0017_it' AND column_name='target';

-- Test Case: TC-25-REG-0018-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=02127e082dc6 column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0018_it, t2_tc_25_reg_0018_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0018_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0018_it (target) VALUES (b'0');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0018_it MODIFY target BIT(8), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0018_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0018_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0018_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0018_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0018_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0018_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0018_it (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0018_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0018_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0018_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0018_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0018_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0018_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0018_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0018_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0018_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0018-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0018_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0018_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0018_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0018_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0018_it a JOIN t2_tc_25_reg_0018_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0018-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0018_it' AND column_name='target';

-- Test Case: TC-25-REG-0019-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: BIT-01
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=33864f02841c column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0019_it, t2_tc_25_reg_0019_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0019_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0019_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0019_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0019_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0019_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0019_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0019_it MODIFY target BIT(8), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0019_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0019_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0019_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0019_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0019_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0019_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0019_it (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0019_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0019_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0019_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0019_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0019_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0019_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0019_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0019_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0019_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0019_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0019_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0019_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0019_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0019-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0019_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0019_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0019_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0019_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0019_it a JOIN t2_tc_25_reg_0019_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0019-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0019_it' AND column_name='target';

-- Test Case: TC-25-REG-0020-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: BIT-01
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=b3436437dcb2 column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0020_it, t2_tc_25_reg_0020_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0020_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0020_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0020_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0020_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0020_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0020_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0020_it MODIFY target BIT(8), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0020_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0020_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0020_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0020_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0020_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0020_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0020_it (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0020_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0020_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0020_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0020_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0020_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0020_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0020_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0020_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0020_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0020_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0020_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0020_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0020_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0020-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0020_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0020_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0020_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0020_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0020_it a JOIN t2_tc_25_reg_0020_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0020-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0020_it' AND column_name='target';

-- Test Case: TC-25-REG-0021-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=fcdf551c02f7 column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0021_it, t2_tc_25_reg_0021_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0021_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0021_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0021_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0021_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0021_it (target) VALUES (b'0');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0021_it MODIFY target BIT(8), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0021_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0021_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0021_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0021_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0021_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0021_it (target) VALUES (b'1010');
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0021_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0021_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0021_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0021_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0021_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0021_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0021_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0021_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0021_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0021_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0021_it (target) VALUES (b'1010');
SELECT 'TC-25-REG-0021-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0021_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0021_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0021_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0021_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0021_it a JOIN t2_tc_25_reg_0021_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0021-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0021_it' AND column_name='target';

-- Test Case: TC-25-REG-0022-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=17a41a2241a3 column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0022_it, t2_tc_25_reg_0022_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0022_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0022_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0022_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0022_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0022_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0022_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0022_it MODIFY target BIT(8), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0022_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0022_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0022_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0022_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0022_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0022_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0022_it (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0022_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0022_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0022_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0022_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0022_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0022_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0022_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0022_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0022_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0022_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0022_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0022_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0022_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0022-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0022_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0022_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0022_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0022_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0022_it a JOIN t2_tc_25_reg_0022_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0022-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0022_it' AND column_name='target';

-- Test Case: TC-25-REG-0023-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=d64ef809cf9b column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0023_it, t2_tc_25_reg_0023_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0023_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0023_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0023_it MODIFY target BIT(8), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0023_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0023_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0023_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0023_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0023_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0023_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0023_it (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0023_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0023_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0023_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0023_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0023_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0023_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0023_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0023_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0023_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0023-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0023_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0023_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0023_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0023_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0023_it a JOIN t2_tc_25_reg_0023_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0023-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0023_it' AND column_name='target';

-- Test Case: TC-25-REG-0024-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=778744cf1469 column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0024_it, t2_tc_25_reg_0024_it;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_25_reg_0024_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0024_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0024_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0024_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0024_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0024_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0024_it MODIFY target BIT(8), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0024_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0024_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0024_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0024_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0024_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0024_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0024_it (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0024_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0024_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0024_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0024_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0024_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0024_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0024_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0024_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0024_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0024_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0024_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0024_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0024_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0024-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0024_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0024_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0024_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0024_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0024_it a JOIN t2_tc_25_reg_0024_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0024-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0024_it' AND column_name='target';

-- Test Case: TC-25-REG-0025-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=7a09fc6c44ae column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0025_it, t2_tc_25_reg_0025_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0025_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0025_it MODIFY target BIT(8) NOT NULL, ALGORITHM=instant;
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0025_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-25-REG-0025-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0025_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0025_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0025_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0025_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0025_it a JOIN t2_tc_25_reg_0025_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0025-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0025_it' AND column_name='target';

-- Test Case: TC-25-REG-0026-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: BIT-01
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=7e1722f32e02 column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0026_it, t2_tc_25_reg_0026_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0026_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0026_it MODIFY target BIT(8), ALGORITHM=instant;
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0026_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-25-REG-0026-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0026_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0026_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0026_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0026_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0026_it a JOIN t2_tc_25_reg_0026_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0026-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0026_it' AND column_name='target';

-- Test Case: TC-25-REG-0027-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=1d5a05cae9fa column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0027_it, t2_tc_25_reg_0027_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0027_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0027_it MODIFY target BIT(8) NOT NULL DEFAULT b'0', ALGORITHM=instant;
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0027_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-25-REG-0027-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0027_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0027_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0027_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0027_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0027_it a JOIN t2_tc_25_reg_0027_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0027-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=NO has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0027_it' AND column_name='target';

-- Test Case: TC-25-REG-0028-IT
-- Type: BIT(1) -> BIT(8), Algorithm: instant, Expected: FAIL
-- Varied factor: KP-05
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=FAIL build=SUCCESS assertions=2 neg_probes=0 alter_sha=560fb349a4ee errno=[1659,1845,1846,3780] column_type=bit(1)
DROP TABLE IF EXISTS t1_tc_25_reg_0028_it, t2_tc_25_reg_0028_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0028_it (
  target BIT(1),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0028_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0028_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0028_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0028_it (target) VALUES (b'0');
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_25_reg_0028_it MODIFY target BIT(8), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0028_it (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0028_it (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0028_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0028_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0028_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0028_it (target) VALUES (b'1010');
-- Oracle table: BIT(1)
CREATE TABLE t2_tc_25_reg_0028_it (
  target BIT(1),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0028_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0028_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0028_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0028_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0028_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0028_it (target) VALUES (b'11');
INSERT INTO t2_tc_25_reg_0028_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0028_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0028_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0028_it (target) VALUES (b'1010');
SELECT 'TC-25-REG-0028-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0028_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0028_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0028_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0028_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0028_it a JOIN t2_tc_25_reg_0028_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0028-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(1)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(1) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0028_it' AND column_name='target';

-- Test Case: TC-25-ATR-0001-IT
-- Column attribute preservation: COMMENT
-- Type: BIT(1) -> BIT(8), Algorithm: instant
-- Transition ID: BIT-01
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=f3e50b553849 column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_atr_0001_it, t2_tc_25_atr_0001_it;
CREATE TABLE t1_tc_25_atr_0001_it (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target BIT(1) COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB;
INSERT INTO t1_tc_25_atr_0001_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_atr_0001_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_atr_0001_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_atr_0001_it (target) VALUES (b'0');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_atr_0001_it MODIFY target BIT(8) COMMENT 'test_comment', ALGORITHM=instant;
INSERT INTO t1_tc_25_atr_0001_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_atr_0001_it (target) VALUES (b'11');
INSERT INTO t1_tc_25_atr_0001_it (target) VALUES (b'1');
SELECT 'TC-25-ATR-0001-IT' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_25_atr_0001_it' AND column_name='target' AND column_comment='test_comment';
SELECT 'TC-25-ATR-0001-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_atr_0001_it' AND column_name='target';

-- Test Case: TC-25-REG-0029-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=07cdeb02996f column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0029_it, t2_tc_25_reg_0029_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0029_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0029_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0029_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0029_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0029_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0029_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0029_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0029_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0029_it MODIFY target BIT(16), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0029_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0029_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0029_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0029_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0029_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0029_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0029_it (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0029_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0029_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0029_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0029_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0029_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0029_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0029_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0029_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0029_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0029_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0029_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0029_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0029_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0029_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0029_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0029-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0029_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0029_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0029_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0029_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0029_it a JOIN t2_tc_25_reg_0029_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0029-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0029_it' AND column_name='target';

-- Test Case: TC-25-REG-0030-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=136fe1a3cd9f column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0030_it, t2_tc_25_reg_0030_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0030_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t1_tc_25_reg_0030_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0030_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0030_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0030_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0030_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0030_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0030_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0030_it MODIFY target BIT(16), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0030_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0030_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0030_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0030_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0030_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0030_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0030_it (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0030_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t2_tc_25_reg_0030_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0030_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0030_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0030_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0030_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0030_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0030_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0030_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0030_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0030_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0030_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0030_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0030_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0030_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0030-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0030_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0030_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0030_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0030_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0030_it a JOIN t2_tc_25_reg_0030_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0030-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0030_it' AND column_name='target';

-- Test Case: TC-25-REG-0031-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=71061f5c81d5 column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0031_it, t2_tc_25_reg_0031_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0031_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t1_tc_25_reg_0031_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0031_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0031_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0031_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0031_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0031_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0031_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0031_it MODIFY target BIT(16), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0031_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0031_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0031_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0031_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0031_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0031_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0031_it (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0031_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t2_tc_25_reg_0031_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0031_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0031_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0031_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0031_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0031_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0031_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0031_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0031_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0031_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0031_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0031_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0031_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0031_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0031-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0031_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0031_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0031_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0031_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0031_it a JOIN t2_tc_25_reg_0031_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0031-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0031_it' AND column_name='target';

-- Test Case: TC-25-REG-0032-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: FAIL
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=FAIL build=SUCCESS assertions=2 neg_probes=0 alter_sha=35efceecb42d errno=[1659,1845,1846,3780] column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0032_it, t2_tc_25_reg_0032_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0032_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0032_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0032_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0032_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0032_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0032_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0032_it (target) VALUES (b'11111111');
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_25_reg_0032_it MODIFY target BIT(16), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0032_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0032_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0032_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0032_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0032_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0032_it (target) VALUES (b'1010');
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0032_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0032_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0032_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0032_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0032_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0032_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0032_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0032_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0032_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0032_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0032_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0032_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0032_it (target) VALUES (b'1010');
SELECT 'TC-25-REG-0032-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0032_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0032_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0032_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0032_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0032_it a JOIN t2_tc_25_reg_0032_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0032-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0032_it' AND column_name='target';

-- Test Case: TC-25-REG-0033-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=e675cf4e70f1 column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0033_it, t2_tc_25_reg_0033_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0033_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0033_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0033_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0033_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0033_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0033_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0033_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0033_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0033_it MODIFY target BIT(16), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0033_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0033_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0033_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0033_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0033_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0033_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0033_it (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0033_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0033_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0033_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0033_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0033_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0033_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0033_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0033_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0033_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0033_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0033_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0033_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0033_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0033_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0033_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0033-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0033_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0033_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0033_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0033_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0033_it a JOIN t2_tc_25_reg_0033_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0033-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0033_it' AND column_name='target';

-- Test Case: TC-25-REG-0034-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=c23f15b36600 column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0034_it, t2_tc_25_reg_0034_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0034_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0034_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0034_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0034_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0034_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0034_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0034_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0034_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0034_it MODIFY target BIT(16), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0034_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0034_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0034_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0034_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0034_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0034_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0034_it (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0034_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0034_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0034_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0034_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0034_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0034_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0034_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0034_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0034_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0034_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0034_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0034_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0034_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0034_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0034_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0034-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0034_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0034_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0034_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0034_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0034_it a JOIN t2_tc_25_reg_0034_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0034-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0034_it' AND column_name='target';

-- Test Case: TC-25-REG-0035-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=a49498b0aaf9 column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0035_it, t2_tc_25_reg_0035_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0035_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0035_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0035_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0035_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0035_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0035_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0035_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0035_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0035_it MODIFY target BIT(16), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0035_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0035_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0035_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0035_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0035_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0035_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0035_it (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0035_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0035_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0035_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0035_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0035_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0035_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0035_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0035_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0035_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0035_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0035_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0035_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0035_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0035_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0035_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0035-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0035_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0035_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0035_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0035_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0035_it a JOIN t2_tc_25_reg_0035_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0035-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0035_it' AND column_name='target';

-- Test Case: TC-25-REG-0036-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=f7c33c94de7d column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0036_it, t2_tc_25_reg_0036_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0036_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0036_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0036_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0036_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0036_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0036_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0036_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0036_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0036_it MODIFY target BIT(16), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0036_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0036_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0036_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0036_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0036_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0036_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0036_it (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0036_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0036_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0036_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0036_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0036_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0036_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0036_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0036_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0036_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0036_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0036_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0036_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0036_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0036_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0036_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0036-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0036_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0036_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0036_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0036_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0036_it a JOIN t2_tc_25_reg_0036_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0036-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0036_it' AND column_name='target';

-- Test Case: TC-25-REG-0037-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=55fecc868593 column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0037_it, t2_tc_25_reg_0037_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0037_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0037_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0037_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0037_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0037_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0037_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0037_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0037_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0037_it MODIFY target BIT(16), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0037_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0037_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0037_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0037_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0037_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0037_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0037_it (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0037_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0037_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0037_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0037_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0037_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0037_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0037_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0037_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0037_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0037_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0037_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0037_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0037_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0037_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0037_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0037-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0037_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0037_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0037_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0037_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0037_it a JOIN t2_tc_25_reg_0037_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0037-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0037_it' AND column_name='target';

-- Test Case: TC-25-REG-0038-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=372dd6a099e3 column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0038_it, t2_tc_25_reg_0038_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0038_it (
  target BIT(8),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0038_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0038_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0038_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0038_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0038_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0038_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0038_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0038_it MODIFY target BIT(16), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0038_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0038_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0038_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0038_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0038_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0038_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0038_it (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0038_it (
  target BIT(16),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0038_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0038_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0038_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0038_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0038_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0038_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0038_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0038_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0038_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0038_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0038_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0038_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0038_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0038_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0038-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0038_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0038_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0038_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0038_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0038_it a JOIN t2_tc_25_reg_0038_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0038-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0038_it' AND column_name='target';

-- Test Case: TC-25-REG-0039-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=d28a2219b9c5 column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0039_it, t2_tc_25_reg_0039_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0039_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BIT(8), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0039_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0039_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0039_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0039_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0039_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0039_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0039_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0039_it MODIFY target BIT(16), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0039_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0039_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0039_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0039_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0039_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0039_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0039_it (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0039_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BIT(16), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0039_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0039_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0039_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0039_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0039_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0039_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0039_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0039_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0039_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0039_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0039_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0039_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0039_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0039_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0039-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0039_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0039_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0039_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0039_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0039_it a JOIN t2_tc_25_reg_0039_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0039-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=4,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=4]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0039_it' AND column_name='target';

-- Test Case: TC-25-REG-0040-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=1b5e23223bc1 column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0040_it, t2_tc_25_reg_0040_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0040_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0040_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0040_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0040_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0040_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0040_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0040_it (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0040_it MODIFY target BIT(16) NOT NULL, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0040_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0040_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0040_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0040_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0040_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0040_it (target) VALUES (b'1010');
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0040_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0040_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0040_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0040_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0040_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0040_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0040_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0040_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0040_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0040_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0040_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0040_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0040_it (target) VALUES (b'1010');
SELECT 'TC-25-REG-0040-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0040_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0040_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0040_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0040_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0040_it a JOIN t2_tc_25_reg_0040_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0040-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0040_it' AND column_name='target';

-- Test Case: TC-25-REG-0041-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=3c9100335f1a column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0041_it, t2_tc_25_reg_0041_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0041_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0041_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0041_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0041_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0041_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0041_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0041_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0041_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0041_it MODIFY target BIT(16) DEFAULT b'0', ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0041_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0041_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0041_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0041_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0041_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0041_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0041_it (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0041_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0041_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0041_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0041_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0041_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0041_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0041_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0041_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0041_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0041_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0041_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0041_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0041_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0041_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0041_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0041-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0041_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0041_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0041_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0041_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0041_it a JOIN t2_tc_25_reg_0041_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0041-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0041_it' AND column_name='target';

-- Test Case: TC-25-REG-0042-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=b0b2f2dcfd07 column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0042_it, t2_tc_25_reg_0042_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0042_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0042_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0042_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0042_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0042_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0042_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0042_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0042_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0042_it MODIFY target BIT(16) DEFAULT NULL, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0042_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0042_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0042_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0042_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0042_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0042_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0042_it (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0042_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0042_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0042_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0042_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0042_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0042_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0042_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0042_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0042_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0042_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0042_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0042_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0042_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0042_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0042_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0042-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0042_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0042_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0042_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0042_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0042_it a JOIN t2_tc_25_reg_0042_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0042-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0042_it' AND column_name='target';

-- Test Case: TC-25-REG-0043-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=b2c15428e3de column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0043_it, t2_tc_25_reg_0043_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0043_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0043_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0043_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0043_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0043_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0043_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0043_it (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0043_it MODIFY target BIT(16) NOT NULL DEFAULT b'0', ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0043_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0043_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0043_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0043_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0043_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0043_it (target) VALUES (b'1010');
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0043_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0043_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0043_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0043_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0043_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0043_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0043_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0043_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0043_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0043_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0043_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0043_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0043_it (target) VALUES (b'1010');
SELECT 'TC-25-REG-0043-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0043_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0043_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0043_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0043_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0043_it a JOIN t2_tc_25_reg_0043_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0043-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=NO has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0043_it' AND column_name='target';

-- Test Case: TC-25-REG-0044-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=1c0f6b0f222a column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0044_it, t2_tc_25_reg_0044_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0044_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0044_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0044_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0044_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0044_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0044_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0044_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0044_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0044_it MODIFY target BIT(16) INVISIBLE, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0044_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0044_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0044_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0044_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0044_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0044_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0044_it (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0044_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0044_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0044_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0044_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0044_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0044_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0044_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0044_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0044_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0044_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0044_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0044_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0044_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0044_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0044_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0044-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0044_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0044_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0044_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0044_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0044_it a JOIN t2_tc_25_reg_0044_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0044-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> 'INVISIBLE')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra=INVISIBLE pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0044_it' AND column_name='target';

-- Test Case: TC-25-REG-0045-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=249d11821869 column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0045_it, t2_tc_25_reg_0045_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0045_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0045_it MODIFY target BIT(16), ALGORITHM=instant;
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0045_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-25-REG-0045-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0045_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0045_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0045_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0045_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0045_it a JOIN t2_tc_25_reg_0045_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0045-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0045_it' AND column_name='target';

-- Test Case: TC-25-REG-0046-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=9a84cfce47fb column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0046_it, t2_tc_25_reg_0046_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0046_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0046_it (target) VALUES (b'0');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0046_it MODIFY target BIT(16), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0046_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0046_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0046_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0046_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0046_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0046_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0046_it (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0046_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0046_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0046_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0046_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0046_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0046_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0046_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0046_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0046_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0046-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0046_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0046_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0046_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0046_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0046_it a JOIN t2_tc_25_reg_0046_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0046-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0046_it' AND column_name='target';

-- Test Case: TC-25-REG-0047-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: BIT-02
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=8c85c690f772 column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0047_it, t2_tc_25_reg_0047_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0047_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0047_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0047_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0047_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0047_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0047_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0047_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0047_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0047_it MODIFY target BIT(16), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0047_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0047_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0047_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0047_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0047_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0047_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0047_it (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0047_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0047_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0047_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0047_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0047_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0047_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0047_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0047_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0047_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0047_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0047_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0047_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0047_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0047_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0047_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0047-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0047_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0047_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0047_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0047_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0047_it a JOIN t2_tc_25_reg_0047_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0047-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0047_it' AND column_name='target';

-- Test Case: TC-25-REG-0048-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: BIT-02
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=6aa564889628 column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0048_it, t2_tc_25_reg_0048_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0048_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0048_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0048_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0048_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0048_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0048_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0048_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0048_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0048_it MODIFY target BIT(16), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0048_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0048_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0048_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0048_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0048_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0048_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0048_it (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0048_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0048_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0048_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0048_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0048_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0048_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0048_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0048_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0048_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0048_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0048_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0048_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0048_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0048_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0048_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0048-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0048_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0048_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0048_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0048_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0048_it a JOIN t2_tc_25_reg_0048_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0048-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0048_it' AND column_name='target';

-- Test Case: TC-25-REG-0049-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=c31e54028a7f column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0049_it, t2_tc_25_reg_0049_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0049_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0049_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0049_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0049_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0049_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0049_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0049_it (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0049_it MODIFY target BIT(16), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0049_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0049_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0049_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0049_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0049_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0049_it (target) VALUES (b'1010');
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0049_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0049_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0049_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0049_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0049_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0049_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0049_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0049_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0049_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0049_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0049_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0049_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0049_it (target) VALUES (b'1010');
SELECT 'TC-25-REG-0049-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0049_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0049_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0049_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0049_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0049_it a JOIN t2_tc_25_reg_0049_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0049-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0049_it' AND column_name='target';

-- Test Case: TC-25-REG-0050-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=53d38f90c4ab column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0050_it, t2_tc_25_reg_0050_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0050_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0050_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0050_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0050_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0050_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0050_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0050_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0050_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0050_it MODIFY target BIT(16), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0050_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0050_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0050_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0050_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0050_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0050_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0050_it (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0050_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0050_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0050_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0050_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0050_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0050_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0050_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0050_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0050_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0050_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0050_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0050_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0050_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0050_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0050_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0050-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0050_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0050_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0050_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0050_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0050_it a JOIN t2_tc_25_reg_0050_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0050-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0050_it' AND column_name='target';

-- Test Case: TC-25-REG-0051-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=d65d6f544d95 column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0051_it, t2_tc_25_reg_0051_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0051_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0051_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0051_it MODIFY target BIT(16), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0051_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0051_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0051_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0051_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0051_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0051_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0051_it (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0051_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0051_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0051_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0051_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0051_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0051_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0051_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0051_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0051_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0051-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0051_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0051_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0051_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0051_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0051_it a JOIN t2_tc_25_reg_0051_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0051-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0051_it' AND column_name='target';

-- Test Case: TC-25-REG-0052-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=b80bbdbbf9e1 column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0052_it, t2_tc_25_reg_0052_it;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_25_reg_0052_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0052_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0052_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0052_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0052_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0052_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0052_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0052_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0052_it MODIFY target BIT(16), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0052_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0052_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0052_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0052_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0052_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0052_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0052_it (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0052_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0052_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0052_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0052_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0052_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0052_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0052_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0052_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0052_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0052_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0052_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0052_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0052_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0052_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0052_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0052-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0052_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0052_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0052_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0052_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0052_it a JOIN t2_tc_25_reg_0052_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0052-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0052_it' AND column_name='target';

-- Test Case: TC-25-REG-0053-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=3d858e8445c7 column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0053_it, t2_tc_25_reg_0053_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0053_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0053_it MODIFY target BIT(16) NOT NULL, ALGORITHM=instant;
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0053_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-25-REG-0053-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0053_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0053_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0053_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0053_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0053_it a JOIN t2_tc_25_reg_0053_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0053-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0053_it' AND column_name='target';

-- Test Case: TC-25-REG-0054-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: BIT-02
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=da52a7009ce2 column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0054_it, t2_tc_25_reg_0054_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0054_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0054_it MODIFY target BIT(16), ALGORITHM=instant;
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0054_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-25-REG-0054-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0054_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0054_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0054_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0054_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0054_it a JOIN t2_tc_25_reg_0054_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0054-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0054_it' AND column_name='target';

-- Test Case: TC-25-REG-0055-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=4fcd315a72b5 column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0055_it, t2_tc_25_reg_0055_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0055_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0055_it MODIFY target BIT(16) NOT NULL DEFAULT b'0', ALGORITHM=instant;
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0055_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-25-REG-0055-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0055_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0055_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0055_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0055_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0055_it a JOIN t2_tc_25_reg_0055_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0055-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=NO has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0055_it' AND column_name='target';

-- Test Case: TC-25-REG-0056-IT
-- Type: BIT(8) -> BIT(16), Algorithm: instant, Expected: FAIL
-- Varied factor: KP-05
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=FAIL build=SUCCESS assertions=2 neg_probes=0 alter_sha=513c64b62c90 errno=[1659,1845,1846,3780] column_type=bit(8)
DROP TABLE IF EXISTS t1_tc_25_reg_0056_it, t2_tc_25_reg_0056_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0056_it (
  target BIT(8),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0056_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0056_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0056_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0056_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0056_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0056_it (target) VALUES (b'11111111');
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_25_reg_0056_it MODIFY target BIT(16), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0056_it (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0056_it (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0056_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0056_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0056_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0056_it (target) VALUES (b'1010');
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_25_reg_0056_it (
  target BIT(8),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0056_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0056_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0056_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0056_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0056_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0056_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0056_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0056_it (target) VALUES (b'111111111');
INSERT INTO t2_tc_25_reg_0056_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0056_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0056_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0056_it (target) VALUES (b'1010');
SELECT 'TC-25-REG-0056-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0056_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0056_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0056_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0056_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0056_it a JOIN t2_tc_25_reg_0056_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0056-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0056_it' AND column_name='target';

-- Test Case: TC-25-ATR-0002-IT
-- Column attribute preservation: COMMENT
-- Type: BIT(8) -> BIT(16), Algorithm: instant
-- Transition ID: BIT-02
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=bed93fe61918 column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_atr_0002_it, t2_tc_25_atr_0002_it;
CREATE TABLE t1_tc_25_atr_0002_it (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target BIT(8) COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB;
INSERT INTO t1_tc_25_atr_0002_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_atr_0002_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_atr_0002_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_atr_0002_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_atr_0002_it (target) VALUES (b'1010');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_atr_0002_it MODIFY target BIT(16) COMMENT 'test_comment', ALGORITHM=instant;
INSERT INTO t1_tc_25_atr_0002_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_atr_0002_it (target) VALUES (b'111111111');
INSERT INTO t1_tc_25_atr_0002_it (target) VALUES (b'1');
SELECT 'TC-25-ATR-0002-IT' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_25_atr_0002_it' AND column_name='target' AND column_comment='test_comment';
SELECT 'TC-25-ATR-0002-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_atr_0002_it' AND column_name='target';

-- Test Case: TC-25-REG-0057-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=87014addffff column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0057_it, t2_tc_25_reg_0057_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0057_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0057_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0057_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0057_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0057_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0057_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0057_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0057_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0057_it MODIFY target BIT(32), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0057_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0057_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0057_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0057_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0057_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0057_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0057_it (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0057_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0057_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0057_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0057_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0057_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0057_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0057_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0057_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0057_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0057_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0057_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0057_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0057_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0057_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0057_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0057-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0057_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0057_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0057_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0057_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0057_it a JOIN t2_tc_25_reg_0057_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0057-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0057_it' AND column_name='target';

-- Test Case: TC-25-REG-0058-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=f12d9cc7ce4a column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0058_it, t2_tc_25_reg_0058_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0058_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t1_tc_25_reg_0058_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0058_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0058_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0058_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0058_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0058_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0058_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0058_it MODIFY target BIT(32), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0058_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0058_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0058_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0058_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0058_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0058_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0058_it (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0058_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t2_tc_25_reg_0058_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0058_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0058_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0058_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0058_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0058_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0058_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0058_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0058_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0058_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0058_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0058_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0058_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0058_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0058-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0058_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0058_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0058_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0058_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0058_it a JOIN t2_tc_25_reg_0058_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0058-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0058_it' AND column_name='target';

-- Test Case: TC-25-REG-0059-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=db8c52701ea9 column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0059_it, t2_tc_25_reg_0059_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0059_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t1_tc_25_reg_0059_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0059_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0059_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0059_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0059_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0059_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0059_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0059_it MODIFY target BIT(32), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0059_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0059_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0059_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0059_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0059_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0059_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0059_it (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0059_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t2_tc_25_reg_0059_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0059_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0059_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0059_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0059_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0059_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0059_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0059_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0059_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0059_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0059_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0059_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0059_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0059_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0059-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0059_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0059_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0059_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0059_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0059_it a JOIN t2_tc_25_reg_0059_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0059-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0059_it' AND column_name='target';

-- Test Case: TC-25-REG-0060-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: FAIL
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=FAIL build=SUCCESS assertions=2 neg_probes=0 alter_sha=96a3b3f6726f errno=[1659,1845,1846,3780] column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0060_it, t2_tc_25_reg_0060_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0060_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0060_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0060_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0060_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0060_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0060_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0060_it (target) VALUES (b'11111111');
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_25_reg_0060_it MODIFY target BIT(32), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0060_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0060_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0060_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0060_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0060_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0060_it (target) VALUES (b'1010');
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0060_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0060_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0060_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0060_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0060_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0060_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0060_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0060_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0060_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0060_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0060_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0060_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0060_it (target) VALUES (b'1010');
SELECT 'TC-25-REG-0060-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0060_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0060_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0060_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0060_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0060_it a JOIN t2_tc_25_reg_0060_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0060-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0060_it' AND column_name='target';

-- Test Case: TC-25-REG-0061-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=1743970eff8e column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0061_it, t2_tc_25_reg_0061_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0061_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0061_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0061_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0061_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0061_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0061_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0061_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0061_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0061_it MODIFY target BIT(32), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0061_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0061_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0061_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0061_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0061_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0061_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0061_it (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0061_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0061_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0061_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0061_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0061_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0061_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0061_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0061_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0061_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0061_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0061_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0061_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0061_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0061_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0061_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0061-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0061_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0061_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0061_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0061_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0061_it a JOIN t2_tc_25_reg_0061_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0061-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0061_it' AND column_name='target';

-- Test Case: TC-25-REG-0062-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=ceb76411b59e column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0062_it, t2_tc_25_reg_0062_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0062_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0062_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0062_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0062_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0062_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0062_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0062_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0062_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0062_it MODIFY target BIT(32), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0062_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0062_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0062_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0062_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0062_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0062_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0062_it (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0062_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0062_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0062_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0062_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0062_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0062_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0062_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0062_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0062_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0062_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0062_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0062_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0062_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0062_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0062_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0062-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0062_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0062_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0062_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0062_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0062_it a JOIN t2_tc_25_reg_0062_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0062-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0062_it' AND column_name='target';

-- Test Case: TC-25-REG-0063-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=d29fec71c8bd column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0063_it, t2_tc_25_reg_0063_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0063_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0063_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0063_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0063_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0063_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0063_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0063_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0063_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0063_it MODIFY target BIT(32), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0063_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0063_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0063_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0063_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0063_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0063_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0063_it (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0063_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0063_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0063_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0063_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0063_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0063_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0063_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0063_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0063_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0063_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0063_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0063_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0063_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0063_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0063_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0063-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0063_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0063_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0063_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0063_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0063_it a JOIN t2_tc_25_reg_0063_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0063-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0063_it' AND column_name='target';

-- Test Case: TC-25-REG-0064-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=5610c424c6da column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0064_it, t2_tc_25_reg_0064_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0064_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0064_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0064_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0064_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0064_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0064_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0064_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0064_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0064_it MODIFY target BIT(32), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0064_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0064_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0064_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0064_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0064_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0064_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0064_it (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0064_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0064_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0064_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0064_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0064_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0064_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0064_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0064_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0064_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0064_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0064_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0064_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0064_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0064_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0064_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0064-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0064_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0064_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0064_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0064_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0064_it a JOIN t2_tc_25_reg_0064_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0064-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0064_it' AND column_name='target';

-- Test Case: TC-25-REG-0065-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=70069f7117a2 column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0065_it, t2_tc_25_reg_0065_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0065_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0065_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0065_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0065_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0065_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0065_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0065_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0065_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0065_it MODIFY target BIT(32), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0065_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0065_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0065_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0065_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0065_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0065_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0065_it (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0065_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0065_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0065_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0065_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0065_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0065_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0065_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0065_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0065_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0065_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0065_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0065_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0065_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0065_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0065_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0065-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0065_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0065_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0065_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0065_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0065_it a JOIN t2_tc_25_reg_0065_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0065-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0065_it' AND column_name='target';

-- Test Case: TC-25-REG-0066-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=ad1cf6928656 column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0066_it, t2_tc_25_reg_0066_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0066_it (
  target BIT(16),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0066_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0066_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0066_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0066_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0066_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0066_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0066_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0066_it MODIFY target BIT(32), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0066_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0066_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0066_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0066_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0066_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0066_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0066_it (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0066_it (
  target BIT(32),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0066_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0066_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0066_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0066_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0066_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0066_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0066_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0066_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0066_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0066_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0066_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0066_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0066_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0066_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0066-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0066_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0066_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0066_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0066_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0066_it a JOIN t2_tc_25_reg_0066_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0066-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0066_it' AND column_name='target';

-- Test Case: TC-25-REG-0067-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=8584768eb766 column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0067_it, t2_tc_25_reg_0067_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0067_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BIT(16), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0067_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0067_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0067_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0067_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0067_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0067_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0067_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0067_it MODIFY target BIT(32), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0067_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0067_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0067_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0067_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0067_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0067_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0067_it (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0067_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BIT(32), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0067_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0067_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0067_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0067_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0067_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0067_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0067_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0067_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0067_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0067_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0067_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0067_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0067_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0067_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0067-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0067_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0067_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0067_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0067_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0067_it a JOIN t2_tc_25_reg_0067_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0067-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=4,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=4]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0067_it' AND column_name='target';

-- Test Case: TC-25-REG-0068-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=4cb9d8d18dec column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0068_it, t2_tc_25_reg_0068_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0068_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0068_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0068_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0068_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0068_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0068_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0068_it (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0068_it MODIFY target BIT(32) NOT NULL, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0068_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0068_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0068_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0068_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0068_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0068_it (target) VALUES (b'1010');
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0068_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0068_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0068_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0068_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0068_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0068_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0068_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0068_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0068_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0068_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0068_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0068_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0068_it (target) VALUES (b'1010');
SELECT 'TC-25-REG-0068-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0068_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0068_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0068_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0068_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0068_it a JOIN t2_tc_25_reg_0068_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0068-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0068_it' AND column_name='target';

-- Test Case: TC-25-REG-0069-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=89105753a37c column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0069_it, t2_tc_25_reg_0069_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0069_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0069_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0069_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0069_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0069_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0069_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0069_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0069_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0069_it MODIFY target BIT(32) DEFAULT b'0', ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0069_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0069_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0069_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0069_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0069_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0069_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0069_it (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0069_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0069_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0069_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0069_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0069_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0069_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0069_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0069_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0069_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0069_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0069_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0069_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0069_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0069_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0069_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0069-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0069_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0069_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0069_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0069_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0069_it a JOIN t2_tc_25_reg_0069_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0069-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0069_it' AND column_name='target';

-- Test Case: TC-25-REG-0070-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=5c4cb988b8de column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0070_it, t2_tc_25_reg_0070_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0070_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0070_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0070_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0070_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0070_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0070_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0070_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0070_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0070_it MODIFY target BIT(32) DEFAULT NULL, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0070_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0070_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0070_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0070_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0070_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0070_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0070_it (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0070_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0070_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0070_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0070_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0070_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0070_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0070_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0070_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0070_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0070_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0070_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0070_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0070_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0070_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0070_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0070-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0070_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0070_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0070_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0070_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0070_it a JOIN t2_tc_25_reg_0070_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0070-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0070_it' AND column_name='target';

-- Test Case: TC-25-REG-0071-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=2b48134f71ee column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0071_it, t2_tc_25_reg_0071_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0071_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0071_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0071_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0071_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0071_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0071_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0071_it (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0071_it MODIFY target BIT(32) NOT NULL DEFAULT b'0', ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0071_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0071_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0071_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0071_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0071_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0071_it (target) VALUES (b'1010');
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0071_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0071_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0071_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0071_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0071_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0071_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0071_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0071_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0071_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0071_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0071_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0071_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0071_it (target) VALUES (b'1010');
SELECT 'TC-25-REG-0071-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0071_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0071_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0071_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0071_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0071_it a JOIN t2_tc_25_reg_0071_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0071-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=NO has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0071_it' AND column_name='target';

-- Test Case: TC-25-REG-0072-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=4473fd9f7e24 column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0072_it, t2_tc_25_reg_0072_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0072_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0072_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0072_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0072_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0072_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0072_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0072_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0072_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0072_it MODIFY target BIT(32) INVISIBLE, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0072_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0072_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0072_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0072_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0072_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0072_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0072_it (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0072_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0072_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0072_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0072_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0072_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0072_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0072_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0072_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0072_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0072_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0072_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0072_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0072_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0072_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0072_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0072-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0072_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0072_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0072_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0072_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0072_it a JOIN t2_tc_25_reg_0072_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0072-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> 'INVISIBLE')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra=INVISIBLE pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0072_it' AND column_name='target';

-- Test Case: TC-25-REG-0073-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=82d91dab69bd column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0073_it, t2_tc_25_reg_0073_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0073_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0073_it MODIFY target BIT(32), ALGORITHM=instant;
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0073_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-25-REG-0073-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0073_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0073_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0073_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0073_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0073_it a JOIN t2_tc_25_reg_0073_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0073-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0073_it' AND column_name='target';

-- Test Case: TC-25-REG-0074-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=ba01af323408 column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0074_it, t2_tc_25_reg_0074_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0074_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0074_it (target) VALUES (b'0');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0074_it MODIFY target BIT(32), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0074_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0074_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0074_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0074_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0074_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0074_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0074_it (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0074_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0074_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0074_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0074_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0074_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0074_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0074_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0074_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0074_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0074-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0074_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0074_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0074_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0074_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0074_it a JOIN t2_tc_25_reg_0074_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0074-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0074_it' AND column_name='target';

-- Test Case: TC-25-REG-0075-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: BIT-03
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=ee1426a3b867 column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0075_it, t2_tc_25_reg_0075_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0075_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0075_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0075_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0075_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0075_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0075_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0075_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0075_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0075_it MODIFY target BIT(32), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0075_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0075_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0075_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0075_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0075_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0075_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0075_it (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0075_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0075_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0075_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0075_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0075_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0075_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0075_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0075_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0075_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0075_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0075_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0075_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0075_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0075_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0075_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0075-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0075_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0075_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0075_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0075_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0075_it a JOIN t2_tc_25_reg_0075_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0075-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0075_it' AND column_name='target';

-- Test Case: TC-25-REG-0076-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: BIT-03
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=7506b7ec64de column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0076_it, t2_tc_25_reg_0076_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0076_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0076_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0076_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0076_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0076_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0076_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0076_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0076_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0076_it MODIFY target BIT(32), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0076_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0076_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0076_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0076_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0076_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0076_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0076_it (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0076_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0076_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0076_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0076_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0076_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0076_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0076_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0076_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0076_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0076_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0076_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0076_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0076_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0076_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0076_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0076-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0076_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0076_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0076_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0076_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0076_it a JOIN t2_tc_25_reg_0076_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0076-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0076_it' AND column_name='target';

-- Test Case: TC-25-REG-0077-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=6019245aabca column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0077_it, t2_tc_25_reg_0077_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0077_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0077_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0077_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0077_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0077_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0077_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0077_it (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0077_it MODIFY target BIT(32), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0077_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0077_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0077_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0077_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0077_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0077_it (target) VALUES (b'1010');
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0077_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0077_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0077_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0077_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0077_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0077_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0077_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0077_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0077_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0077_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0077_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0077_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0077_it (target) VALUES (b'1010');
SELECT 'TC-25-REG-0077-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0077_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0077_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0077_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0077_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0077_it a JOIN t2_tc_25_reg_0077_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0077-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0077_it' AND column_name='target';

-- Test Case: TC-25-REG-0078-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=465d2b4650c3 column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0078_it, t2_tc_25_reg_0078_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0078_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0078_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0078_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0078_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0078_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0078_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0078_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0078_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0078_it MODIFY target BIT(32), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0078_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0078_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0078_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0078_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0078_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0078_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0078_it (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0078_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0078_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0078_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0078_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0078_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0078_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0078_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0078_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0078_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0078_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0078_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0078_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0078_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0078_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0078_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0078-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0078_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0078_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0078_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0078_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0078_it a JOIN t2_tc_25_reg_0078_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0078-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0078_it' AND column_name='target';

-- Test Case: TC-25-REG-0079-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=7c036ec3f639 column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0079_it, t2_tc_25_reg_0079_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0079_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0079_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0079_it MODIFY target BIT(32), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0079_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0079_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0079_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0079_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0079_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0079_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0079_it (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0079_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0079_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0079_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0079_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0079_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0079_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0079_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0079_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0079_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0079-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0079_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0079_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0079_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0079_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0079_it a JOIN t2_tc_25_reg_0079_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0079-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0079_it' AND column_name='target';

-- Test Case: TC-25-REG-0080-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=f1a20d7399ce column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0080_it, t2_tc_25_reg_0080_it;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_25_reg_0080_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0080_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0080_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0080_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0080_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0080_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0080_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0080_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0080_it MODIFY target BIT(32), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0080_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0080_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0080_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0080_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0080_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0080_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0080_it (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0080_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0080_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0080_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0080_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0080_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0080_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0080_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0080_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0080_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0080_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0080_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0080_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0080_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0080_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0080_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0080-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0080_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0080_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0080_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0080_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0080_it a JOIN t2_tc_25_reg_0080_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0080-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0080_it' AND column_name='target';

-- Test Case: TC-25-REG-0081-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=a2358739ed77 column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0081_it, t2_tc_25_reg_0081_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0081_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0081_it MODIFY target BIT(32) NOT NULL, ALGORITHM=instant;
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0081_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-25-REG-0081-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0081_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0081_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0081_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0081_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0081_it a JOIN t2_tc_25_reg_0081_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0081-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0081_it' AND column_name='target';

-- Test Case: TC-25-REG-0082-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: BIT-03
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=c4ce224e5a8b column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0082_it, t2_tc_25_reg_0082_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0082_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0082_it MODIFY target BIT(32), ALGORITHM=instant;
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0082_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-25-REG-0082-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0082_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0082_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0082_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0082_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0082_it a JOIN t2_tc_25_reg_0082_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0082-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0082_it' AND column_name='target';

-- Test Case: TC-25-REG-0083-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=e9517f5c03b6 column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0083_it, t2_tc_25_reg_0083_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0083_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0083_it MODIFY target BIT(32) NOT NULL DEFAULT b'0', ALGORITHM=instant;
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0083_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-25-REG-0083-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0083_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0083_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0083_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0083_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0083_it a JOIN t2_tc_25_reg_0083_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0083-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=NO has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0083_it' AND column_name='target';

-- Test Case: TC-25-REG-0084-IT
-- Type: BIT(16) -> BIT(32), Algorithm: instant, Expected: FAIL
-- Varied factor: KP-05
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=FAIL build=SUCCESS assertions=2 neg_probes=0 alter_sha=e802e5212a54 errno=[1659,1845,1846,3780] column_type=bit(16)
DROP TABLE IF EXISTS t1_tc_25_reg_0084_it, t2_tc_25_reg_0084_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0084_it (
  target BIT(16),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0084_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0084_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0084_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0084_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0084_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0084_it (target) VALUES (b'11111111');
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_25_reg_0084_it MODIFY target BIT(32), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0084_it (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0084_it (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0084_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0084_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0084_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_reg_0084_it (target) VALUES (b'1010');
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_25_reg_0084_it (
  target BIT(16),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0084_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0084_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0084_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0084_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0084_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0084_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0084_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0084_it (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_25_reg_0084_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0084_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0084_it (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_25_reg_0084_it (target) VALUES (b'1010');
SELECT 'TC-25-REG-0084-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0084_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0084_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0084_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0084_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0084_it a JOIN t2_tc_25_reg_0084_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0084-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0084_it' AND column_name='target';

-- Test Case: TC-25-ATR-0003-IT
-- Column attribute preservation: COMMENT
-- Type: BIT(16) -> BIT(32), Algorithm: instant
-- Transition ID: BIT-03
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=01fab534d4a8 column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_atr_0003_it, t2_tc_25_atr_0003_it;
CREATE TABLE t1_tc_25_atr_0003_it (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target BIT(16) COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB;
INSERT INTO t1_tc_25_atr_0003_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_atr_0003_it (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_25_atr_0003_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_atr_0003_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_atr_0003_it (target) VALUES (b'1010');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_atr_0003_it MODIFY target BIT(32) COMMENT 'test_comment', ALGORITHM=instant;
INSERT INTO t1_tc_25_atr_0003_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_atr_0003_it (target) VALUES (b'11111111111111111');
INSERT INTO t1_tc_25_atr_0003_it (target) VALUES (b'1');
SELECT 'TC-25-ATR-0003-IT' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_25_atr_0003_it' AND column_name='target' AND column_comment='test_comment';
SELECT 'TC-25-ATR-0003-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_atr_0003_it' AND column_name='target';

-- Test Case: TC-25-REG-0085-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=1863d319f43b column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0085_it, t2_tc_25_reg_0085_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0085_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0085_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0085_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0085_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0085_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0085_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0085_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0085_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0085_it MODIFY target BIT(64), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0085_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0085_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0085_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0085_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0085_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0085_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0085_it (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0085_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0085_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0085_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0085_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0085_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0085_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0085_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0085_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0085_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0085_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0085_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0085_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0085_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0085_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0085_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0085-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0085_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0085_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0085_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0085_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0085_it a JOIN t2_tc_25_reg_0085_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0085-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0085_it' AND column_name='target';

-- Test Case: TC-25-REG-0086-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=ce3a3e47bfde column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0086_it, t2_tc_25_reg_0086_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0086_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t1_tc_25_reg_0086_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0086_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0086_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0086_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0086_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0086_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0086_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0086_it MODIFY target BIT(64), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0086_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0086_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0086_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0086_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0086_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0086_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0086_it (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0086_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t2_tc_25_reg_0086_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0086_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0086_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0086_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0086_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0086_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0086_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0086_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0086_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0086_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0086_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0086_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0086_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0086_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0086-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0086_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0086_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0086_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0086_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0086_it a JOIN t2_tc_25_reg_0086_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0086-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0086_it' AND column_name='target';

-- Test Case: TC-25-REG-0087-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=3a233f4a7fda column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0087_it, t2_tc_25_reg_0087_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0087_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t1_tc_25_reg_0087_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0087_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0087_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0087_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0087_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0087_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0087_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0087_it MODIFY target BIT(64), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0087_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0087_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0087_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0087_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0087_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0087_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0087_it (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0087_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t2_tc_25_reg_0087_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0087_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0087_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0087_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0087_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0087_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0087_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0087_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0087_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0087_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0087_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0087_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0087_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0087_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0087-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0087_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0087_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0087_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0087_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0087_it a JOIN t2_tc_25_reg_0087_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0087-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0087_it' AND column_name='target';

-- Test Case: TC-25-REG-0088-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: FAIL
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=FAIL build=SUCCESS assertions=2 neg_probes=0 alter_sha=107160a5e704 errno=[1659,1845,1846,3780] column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0088_it, t2_tc_25_reg_0088_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0088_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0088_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0088_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0088_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0088_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0088_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0088_it (target) VALUES (b'11111111');
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_25_reg_0088_it MODIFY target BIT(64), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0088_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0088_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0088_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0088_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0088_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0088_it (target) VALUES (b'1010');
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0088_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0088_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0088_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0088_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0088_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0088_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0088_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0088_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0088_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0088_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0088_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0088_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0088_it (target) VALUES (b'1010');
SELECT 'TC-25-REG-0088-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0088_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0088_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0088_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0088_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0088_it a JOIN t2_tc_25_reg_0088_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0088-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0088_it' AND column_name='target';

-- Test Case: TC-25-REG-0089-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=ded9be75a865 column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0089_it, t2_tc_25_reg_0089_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0089_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0089_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0089_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0089_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0089_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0089_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0089_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0089_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0089_it MODIFY target BIT(64), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0089_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0089_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0089_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0089_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0089_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0089_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0089_it (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0089_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0089_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0089_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0089_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0089_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0089_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0089_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0089_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0089_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0089_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0089_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0089_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0089_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0089_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0089_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0089-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0089_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0089_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0089_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0089_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0089_it a JOIN t2_tc_25_reg_0089_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0089-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0089_it' AND column_name='target';

-- Test Case: TC-25-REG-0090-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=f29619bdeee3 column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0090_it, t2_tc_25_reg_0090_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0090_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0090_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0090_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0090_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0090_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0090_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0090_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0090_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0090_it MODIFY target BIT(64), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0090_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0090_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0090_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0090_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0090_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0090_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0090_it (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0090_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0090_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0090_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0090_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0090_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0090_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0090_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0090_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0090_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0090_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0090_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0090_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0090_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0090_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0090_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0090-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0090_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0090_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0090_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0090_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0090_it a JOIN t2_tc_25_reg_0090_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0090-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0090_it' AND column_name='target';

-- Test Case: TC-25-REG-0091-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=95696ad35724 column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0091_it, t2_tc_25_reg_0091_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0091_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0091_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0091_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0091_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0091_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0091_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0091_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0091_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0091_it MODIFY target BIT(64), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0091_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0091_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0091_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0091_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0091_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0091_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0091_it (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0091_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0091_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0091_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0091_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0091_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0091_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0091_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0091_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0091_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0091_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0091_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0091_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0091_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0091_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0091_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0091-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0091_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0091_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0091_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0091_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0091_it a JOIN t2_tc_25_reg_0091_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0091-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0091_it' AND column_name='target';

-- Test Case: TC-25-REG-0092-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=b7ddf7af61b7 column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0092_it, t2_tc_25_reg_0092_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0092_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0092_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0092_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0092_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0092_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0092_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0092_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0092_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0092_it MODIFY target BIT(64), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0092_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0092_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0092_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0092_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0092_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0092_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0092_it (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0092_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0092_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0092_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0092_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0092_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0092_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0092_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0092_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0092_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0092_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0092_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0092_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0092_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0092_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0092_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0092-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0092_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0092_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0092_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0092_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0092_it a JOIN t2_tc_25_reg_0092_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0092-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0092_it' AND column_name='target';

-- Test Case: TC-25-REG-0093-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=b374deef8039 column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0093_it, t2_tc_25_reg_0093_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0093_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0093_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0093_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0093_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0093_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0093_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0093_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0093_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0093_it MODIFY target BIT(64), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0093_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0093_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0093_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0093_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0093_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0093_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0093_it (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0093_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0093_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0093_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0093_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0093_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0093_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0093_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0093_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0093_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0093_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0093_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0093_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0093_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0093_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0093_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0093-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0093_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0093_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0093_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0093_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0093_it a JOIN t2_tc_25_reg_0093_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0093-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0093_it' AND column_name='target';

-- Test Case: TC-25-REG-0094-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=86a446e16ad0 column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0094_it, t2_tc_25_reg_0094_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0094_it (
  target BIT(32),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0094_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0094_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0094_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0094_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0094_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0094_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0094_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0094_it MODIFY target BIT(64), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0094_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0094_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0094_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0094_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0094_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0094_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0094_it (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0094_it (
  target BIT(64),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0094_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0094_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0094_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0094_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0094_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0094_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0094_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0094_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0094_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0094_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0094_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0094_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0094_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0094_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0094-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0094_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0094_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0094_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0094_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0094_it a JOIN t2_tc_25_reg_0094_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0094-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0094_it' AND column_name='target';

-- Test Case: TC-25-REG-0095-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=4678be06e641 column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0095_it, t2_tc_25_reg_0095_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0095_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BIT(32), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0095_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0095_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0095_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0095_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0095_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0095_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0095_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0095_it MODIFY target BIT(64), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0095_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0095_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0095_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0095_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0095_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0095_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0095_it (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0095_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BIT(64), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0095_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0095_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0095_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0095_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0095_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0095_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0095_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0095_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0095_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0095_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0095_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0095_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0095_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0095_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0095-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0095_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0095_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0095_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0095_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0095_it a JOIN t2_tc_25_reg_0095_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0095-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=4,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=4]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0095_it' AND column_name='target';

-- Test Case: TC-25-REG-0096-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=696b3f6d5b10 column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0096_it, t2_tc_25_reg_0096_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0096_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0096_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0096_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0096_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0096_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0096_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0096_it (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0096_it MODIFY target BIT(64) NOT NULL, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0096_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0096_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0096_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0096_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0096_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0096_it (target) VALUES (b'1010');
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0096_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0096_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0096_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0096_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0096_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0096_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0096_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0096_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0096_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0096_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0096_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0096_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0096_it (target) VALUES (b'1010');
SELECT 'TC-25-REG-0096-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0096_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0096_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0096_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0096_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0096_it a JOIN t2_tc_25_reg_0096_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0096-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0096_it' AND column_name='target';

-- Test Case: TC-25-REG-0097-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=59fbf205711b column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0097_it, t2_tc_25_reg_0097_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0097_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0097_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0097_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0097_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0097_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0097_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0097_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0097_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0097_it MODIFY target BIT(64) DEFAULT b'0', ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0097_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0097_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0097_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0097_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0097_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0097_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0097_it (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0097_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64) DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0097_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0097_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0097_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0097_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0097_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0097_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0097_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0097_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0097_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0097_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0097_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0097_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0097_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0097_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0097-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0097_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0097_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0097_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0097_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0097_it a JOIN t2_tc_25_reg_0097_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0097-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0097_it' AND column_name='target';

-- Test Case: TC-25-REG-0098-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=8ad21b09d910 column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0098_it, t2_tc_25_reg_0098_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0098_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0098_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0098_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0098_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0098_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0098_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0098_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0098_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0098_it MODIFY target BIT(64) DEFAULT NULL, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0098_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0098_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0098_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0098_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0098_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0098_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0098_it (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0098_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0098_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0098_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0098_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0098_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0098_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0098_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0098_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0098_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0098_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0098_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0098_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0098_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0098_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0098_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0098-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0098_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0098_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0098_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0098_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0098_it a JOIN t2_tc_25_reg_0098_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0098-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0098_it' AND column_name='target';

-- Test Case: TC-25-REG-0099-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=1bfd5f12b700 column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0099_it, t2_tc_25_reg_0099_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0099_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0099_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0099_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0099_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0099_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0099_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0099_it (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0099_it MODIFY target BIT(64) NOT NULL DEFAULT b'0', ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0099_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0099_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0099_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0099_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0099_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0099_it (target) VALUES (b'1010');
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0099_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0099_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0099_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0099_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0099_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0099_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0099_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0099_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0099_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0099_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0099_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0099_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0099_it (target) VALUES (b'1010');
SELECT 'TC-25-REG-0099-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0099_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0099_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0099_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0099_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0099_it a JOIN t2_tc_25_reg_0099_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0099-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=NO has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0099_it' AND column_name='target';

-- Test Case: TC-25-REG-0100-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=e45ae965107a column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0100_it, t2_tc_25_reg_0100_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0100_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0100_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0100_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0100_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0100_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0100_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0100_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0100_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0100_it MODIFY target BIT(64) INVISIBLE, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0100_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0100_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0100_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0100_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0100_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0100_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0100_it (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0100_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0100_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0100_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0100_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0100_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0100_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0100_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0100_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0100_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0100_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0100_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0100_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0100_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0100_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0100_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0100-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0100_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0100_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0100_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0100_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0100_it a JOIN t2_tc_25_reg_0100_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0100-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> 'INVISIBLE')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra=INVISIBLE pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0100_it' AND column_name='target';

-- Test Case: TC-25-REG-0101-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=2c08155371ca column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0101_it, t2_tc_25_reg_0101_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0101_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0101_it MODIFY target BIT(64), ALGORITHM=instant;
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0101_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-25-REG-0101-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0101_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0101_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0101_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0101_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0101_it a JOIN t2_tc_25_reg_0101_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0101-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0101_it' AND column_name='target';

-- Test Case: TC-25-REG-0102-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=22ed7d41ddd6 column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0102_it, t2_tc_25_reg_0102_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0102_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0102_it (target) VALUES (b'0');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0102_it MODIFY target BIT(64), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0102_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0102_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0102_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0102_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0102_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0102_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0102_it (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0102_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0102_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0102_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0102_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0102_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0102_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0102_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0102_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0102_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0102-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0102_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0102_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0102_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0102_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0102_it a JOIN t2_tc_25_reg_0102_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0102-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0102_it' AND column_name='target';

-- Test Case: TC-25-REG-0103-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: BIT-04
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=9cf2ee3f9dea column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0103_it, t2_tc_25_reg_0103_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0103_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0103_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0103_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0103_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0103_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0103_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0103_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0103_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0103_it MODIFY target BIT(64), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0103_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0103_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0103_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0103_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0103_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0103_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0103_it (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0103_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0103_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0103_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0103_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0103_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0103_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0103_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0103_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0103_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0103_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0103_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0103_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0103_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0103_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0103_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0103-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0103_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0103_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0103_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0103_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0103_it a JOIN t2_tc_25_reg_0103_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0103-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0103_it' AND column_name='target';

-- Test Case: TC-25-REG-0104-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: BIT-04
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=cd1bb7701890 column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0104_it, t2_tc_25_reg_0104_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0104_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0104_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0104_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0104_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0104_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0104_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0104_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0104_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0104_it MODIFY target BIT(64), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0104_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0104_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0104_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0104_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0104_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0104_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0104_it (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0104_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0104_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0104_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0104_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0104_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0104_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0104_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0104_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0104_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0104_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0104_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0104_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0104_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0104_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0104_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0104-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0104_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0104_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0104_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0104_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0104_it a JOIN t2_tc_25_reg_0104_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0104-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0104_it' AND column_name='target';

-- Test Case: TC-25-REG-0105-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=5dbc9b2dc417 column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0105_it, t2_tc_25_reg_0105_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0105_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0105_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0105_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0105_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0105_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0105_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0105_it (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0105_it MODIFY target BIT(64), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0105_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0105_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0105_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0105_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0105_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0105_it (target) VALUES (b'1010');
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0105_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0105_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0105_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0105_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0105_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0105_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0105_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0105_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0105_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0105_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0105_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0105_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0105_it (target) VALUES (b'1010');
SELECT 'TC-25-REG-0105-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0105_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0105_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0105_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0105_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0105_it a JOIN t2_tc_25_reg_0105_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0105-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0105_it' AND column_name='target';

-- Test Case: TC-25-REG-0106-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=be0ec0521202 column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0106_it, t2_tc_25_reg_0106_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0106_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0106_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0106_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0106_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0106_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0106_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0106_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0106_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0106_it MODIFY target BIT(64), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0106_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0106_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0106_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0106_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0106_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0106_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0106_it (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0106_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0106_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0106_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0106_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0106_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0106_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0106_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0106_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0106_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0106_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0106_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0106_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0106_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0106_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0106_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0106-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0106_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0106_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0106_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0106_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0106_it a JOIN t2_tc_25_reg_0106_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0106-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0106_it' AND column_name='target';

-- Test Case: TC-25-REG-0107-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=c300bf84ac6a column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0107_it, t2_tc_25_reg_0107_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0107_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0107_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0107_it MODIFY target BIT(64), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0107_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0107_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0107_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0107_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0107_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0107_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0107_it (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0107_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0107_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0107_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0107_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0107_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0107_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0107_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0107_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0107_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0107-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0107_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0107_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0107_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0107_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0107_it a JOIN t2_tc_25_reg_0107_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0107-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0107_it' AND column_name='target';

-- Test Case: TC-25-REG-0108-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=88d47a3126e7 column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0108_it, t2_tc_25_reg_0108_it;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_25_reg_0108_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0108_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0108_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0108_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0108_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0108_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0108_it (target) VALUES (b'11111111');
INSERT INTO t1_tc_25_reg_0108_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0108_it MODIFY target BIT(64), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0108_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0108_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0108_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0108_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0108_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0108_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0108_it (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0108_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0108_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0108_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0108_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0108_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0108_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0108_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0108_it (target) VALUES (NULL);
INSERT INTO t2_tc_25_reg_0108_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0108_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0108_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0108_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0108_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0108_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0108_it (target) VALUES (NULL);
SELECT 'TC-25-REG-0108-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0108_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0108_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0108_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0108_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0108_it a JOIN t2_tc_25_reg_0108_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0108-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0108_it' AND column_name='target';

-- Test Case: TC-25-REG-0109-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=ed04ee123fb4 column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0109_it, t2_tc_25_reg_0109_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0109_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0109_it MODIFY target BIT(64) NOT NULL, ALGORITHM=instant;
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0109_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-25-REG-0109-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0109_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0109_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0109_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0109_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0109_it a JOIN t2_tc_25_reg_0109_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0109-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0109_it' AND column_name='target';

-- Test Case: TC-25-REG-0110-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: BIT-04
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=b6c9792d2e31 column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0110_it, t2_tc_25_reg_0110_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0110_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0110_it MODIFY target BIT(64), ALGORITHM=instant;
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0110_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-25-REG-0110-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0110_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0110_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0110_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0110_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0110_it a JOIN t2_tc_25_reg_0110_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0110-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0110_it' AND column_name='target';

-- Test Case: TC-25-REG-0111-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=2 neg_probes=0 alter_sha=d70882649295 column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_reg_0111_it, t2_tc_25_reg_0111_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0111_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_reg_0111_it MODIFY target BIT(64) NOT NULL DEFAULT b'0', ALGORITHM=instant;
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_25_reg_0111_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-25-REG-0111-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0111_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0111_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0111_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0111_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0111_it a JOIN t2_tc_25_reg_0111_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0111-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=NO has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0111_it' AND column_name='target';

-- Test Case: TC-25-REG-0112-IT
-- Type: BIT(32) -> BIT(64), Algorithm: instant, Expected: FAIL
-- Varied factor: KP-05
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=FAIL build=SUCCESS assertions=2 neg_probes=0 alter_sha=3a505f1ebbfc errno=[1659,1845,1846,3780] column_type=bit(32)
DROP TABLE IF EXISTS t1_tc_25_reg_0112_it, t2_tc_25_reg_0112_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_25_reg_0112_it (
  target BIT(32),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_25_reg_0112_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0112_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0112_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0112_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0112_it (target) VALUES (b'1010');
INSERT INTO t1_tc_25_reg_0112_it (target) VALUES (b'11111111');
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_25_reg_0112_it MODIFY target BIT(64), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0112_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0112_it (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_25_reg_0112_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_reg_0112_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_reg_0112_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_reg_0112_it (target) VALUES (b'1010');
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_25_reg_0112_it (
  target BIT(32),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_25_reg_0112_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0112_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0112_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0112_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0112_it (target) VALUES (b'1010');
INSERT INTO t2_tc_25_reg_0112_it (target) VALUES (b'11111111');
INSERT INTO t2_tc_25_reg_0112_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0112_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0112_it (target) VALUES (b'1');
INSERT INTO t2_tc_25_reg_0112_it (target) VALUES (b'0');
INSERT INTO t2_tc_25_reg_0112_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_25_reg_0112_it (target) VALUES (b'1010');
SELECT 'TC-25-REG-0112-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_25_reg_0112_it
   WHERE id NOT IN (SELECT id FROM t2_tc_25_reg_0112_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_25_reg_0112_it
   WHERE id NOT IN (SELECT id FROM t1_tc_25_reg_0112_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_25_reg_0112_it a JOIN t2_tc_25_reg_0112_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-25-REG-0112-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_reg_0112_it' AND column_name='target';

-- Test Case: TC-25-ATR-0004-IT
-- Column attribute preservation: COMMENT
-- Type: BIT(32) -> BIT(64), Algorithm: instant
-- Transition ID: BIT-04
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=c5df967807f9 column_type=bit(64)
DROP TABLE IF EXISTS t1_tc_25_atr_0004_it, t2_tc_25_atr_0004_it;
CREATE TABLE t1_tc_25_atr_0004_it (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target BIT(32) COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB;
INSERT INTO t1_tc_25_atr_0004_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_atr_0004_it (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_25_atr_0004_it (target) VALUES (b'1');
INSERT INTO t1_tc_25_atr_0004_it (target) VALUES (b'0');
INSERT INTO t1_tc_25_atr_0004_it (target) VALUES (b'1010');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_25_atr_0004_it MODIFY target BIT(64) COMMENT 'test_comment', ALGORITHM=instant;
INSERT INTO t1_tc_25_atr_0004_it (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t1_tc_25_atr_0004_it (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t1_tc_25_atr_0004_it (target) VALUES (b'1');
SELECT 'TC-25-ATR-0004-IT' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_25_atr_0004_it' AND column_name='target' AND column_comment='test_comment';
SELECT 'TC-25-ATR-0004-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_25_atr_0004_it' AND column_name='target';

