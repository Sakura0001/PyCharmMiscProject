-- ============================================================
-- RDS MySQL DDL 秒级/在线修改列类型 测试套件 — 内网环境
-- 环境说明: 所有功能开关默认开启
-- 覆盖类型: BINARY + VARBINARY + DECIMAL + TEXT + BLOB + BIT
-- 覆盖算法: INSTANT + INPLACE (增强类型 INSTANT 预期成功: BINARY/VARBINARY/DECIMAL 已确认支持)
-- ============================================================
-- 本文件由 generate_test_sql.py 自动生成, 请勿手动修改
-- Suite-Revision: fe94a870b930   (生成器源码哈希; 时间戳见 results/generation_manifest.json)
-- 用例 ID 规则: TC-<文件号>-<作用域>-<序号>-<IT|IP>  —— 全局唯一
--   作用域 REG=普通表 OFAT/二元组, ATR=列属性保持, SPE=特殊模式,
--          FK=外键, PTK=分区(目标列是分区键), PNK=分区(目标列非分区键)
-- ============================================================

SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
SET SESSION innodb_lock_wait_timeout = 50;

-- File 16: BINARY INSTANT (预期成功)

-- Test Case: TC-16-REG-0001-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=fab24343e989 column_type=binary(20) neg_probe=6347e82ab978=167|1264|1265|1406 neg_probe=0b75f88fb4cf=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0001_it, t2_tc_16_reg_0001_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0001_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0001_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0001_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0001_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0001_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0001_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0001_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0001_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0001_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0001_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0001_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0001_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0001_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0001_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0001_it (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0001_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0001_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0001_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0001_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0001_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0001_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0001_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0001_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0001_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0001_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0001_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0001_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0001_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0001_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0001_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0001_it);
-- probe 1/1 -> t1_tc_16_reg_0001_it
INSERT INTO t1_tc_16_reg_0001_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0001_it
INSERT INTO t2_tc_16_reg_0001_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0001-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0001_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0001_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0001_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0001_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0001-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0001_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0001_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0001_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0001_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0001_it a JOIN t2_tc_16_reg_0001_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0001-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0001_it' AND column_name='target';

-- Test Case: TC-16-REG-0002-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=34850229ffcf column_type=binary(20) neg_probe=eb95e8423e02=167|1264|1265|1406 neg_probe=447bff486867=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0002_it, t2_tc_16_reg_0002_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0002_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t1_tc_16_reg_0002_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0002_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0002_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0002_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0002_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0002_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0002_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0002_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0002_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0002_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0002_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0002_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0002_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0002_it (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0002_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t2_tc_16_reg_0002_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0002_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0002_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0002_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0002_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0002_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0002_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0002_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0002_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0002_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0002_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0002_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0002_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0002_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0002_it);
-- probe 1/1 -> t1_tc_16_reg_0002_it
INSERT INTO t1_tc_16_reg_0002_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0002_it
INSERT INTO t2_tc_16_reg_0002_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0002-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0002_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0002_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0002_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0002_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0002-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0002_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0002_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0002_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0002_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0002_it a JOIN t2_tc_16_reg_0002_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0002-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0002_it' AND column_name='target';

-- Test Case: TC-16-REG-0003-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=1ea8a01835b6 column_type=binary(20) neg_probe=563d13209ddc=167|1264|1265|1406 neg_probe=f5f096c6a3c3=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0003_it, t2_tc_16_reg_0003_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0003_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t1_tc_16_reg_0003_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0003_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0003_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0003_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0003_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0003_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0003_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0003_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0003_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0003_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0003_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0003_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0003_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0003_it (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0003_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t2_tc_16_reg_0003_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0003_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0003_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0003_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0003_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0003_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0003_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0003_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0003_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0003_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0003_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0003_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0003_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0003_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0003_it);
-- probe 1/1 -> t1_tc_16_reg_0003_it
INSERT INTO t1_tc_16_reg_0003_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0003_it
INSERT INTO t2_tc_16_reg_0003_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0003-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0003_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0003_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0003_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0003_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0003-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0003_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0003_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0003_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0003_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0003_it a JOIN t2_tc_16_reg_0003_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0003-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0003_it' AND column_name='target';

-- Test Case: TC-16-REG-0004-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: FAIL
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=FAIL build=SUCCESS assertions=3 neg_probes=1 alter_sha=53c756c6ab2b errno=[1845,1846,1659,3780] column_type=binary(10) neg_probe=5289b5db5a78=167|1264|1265|1406 neg_probe=20a3f004aee6=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0004_it, t2_tc_16_reg_0004_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0004_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0004_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0004_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0004_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0004_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0004_it (target) VALUES ('');
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_16_reg_0004_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0004_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0004_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0004_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0004_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0004_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0004_it (target) VALUES ('');
-- Oracle table: BINARY(10)
CREATE TABLE t2_tc_16_reg_0004_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0004_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0004_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0004_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0004_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0004_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0004_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0004_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0004_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0004_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0004_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0004_it (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0004_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0004_it);
-- probe 1/1 -> t1_tc_16_reg_0004_it
INSERT INTO t1_tc_16_reg_0004_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0004_it
INSERT INTO t2_tc_16_reg_0004_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0004-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0004_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0004_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0004_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0004_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0004-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0004_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0004_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0004_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0004_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0004_it a JOIN t2_tc_16_reg_0004_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0004-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(10)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(10) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0004_it' AND column_name='target';

-- Test Case: TC-16-REG-0005-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=a733d87bc25d column_type=binary(20) neg_probe=ea6979fecfbd=167|1264|1265|1406 neg_probe=116fba5adda6=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0005_it, t2_tc_16_reg_0005_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0005_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0005_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0005_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0005_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0005_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0005_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0005_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0005_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0005_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0005_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0005_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0005_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0005_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0005_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0005_it (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0005_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0005_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0005_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0005_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0005_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0005_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0005_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0005_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0005_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0005_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0005_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0005_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0005_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0005_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0005_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0005_it);
-- probe 1/1 -> t1_tc_16_reg_0005_it
INSERT INTO t1_tc_16_reg_0005_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0005_it
INSERT INTO t2_tc_16_reg_0005_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0005-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0005_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0005_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0005_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0005_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0005-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0005_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0005_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0005_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0005_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0005_it a JOIN t2_tc_16_reg_0005_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0005-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0005_it' AND column_name='target';

-- Test Case: TC-16-REG-0006-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=aedaeed15301 column_type=binary(20) neg_probe=bd8d8d3eb314=167|1264|1265|1406 neg_probe=d2e9c1ff3a81=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0006_it, t2_tc_16_reg_0006_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0006_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0006_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0006_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0006_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0006_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0006_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0006_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0006_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0006_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0006_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0006_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0006_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0006_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0006_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0006_it (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0006_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0006_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0006_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0006_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0006_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0006_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0006_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0006_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0006_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0006_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0006_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0006_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0006_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0006_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0006_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0006_it);
-- probe 1/1 -> t1_tc_16_reg_0006_it
INSERT INTO t1_tc_16_reg_0006_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0006_it
INSERT INTO t2_tc_16_reg_0006_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0006-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0006_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0006_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0006_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0006_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0006-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0006_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0006_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0006_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0006_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0006_it a JOIN t2_tc_16_reg_0006_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0006-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0006_it' AND column_name='target';

-- Test Case: TC-16-REG-0007-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=70fd46375c91 column_type=binary(20) neg_probe=12957302324a=167|1264|1265|1406 neg_probe=48d72af72096=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0007_it, t2_tc_16_reg_0007_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0007_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0007_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0007_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0007_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0007_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0007_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0007_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0007_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0007_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0007_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0007_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0007_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0007_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0007_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0007_it (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0007_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0007_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0007_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0007_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0007_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0007_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0007_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0007_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0007_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0007_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0007_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0007_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0007_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0007_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0007_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0007_it);
-- probe 1/1 -> t1_tc_16_reg_0007_it
INSERT INTO t1_tc_16_reg_0007_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0007_it
INSERT INTO t2_tc_16_reg_0007_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0007-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0007_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0007_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0007_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0007_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0007-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0007_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0007_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0007_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0007_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0007_it a JOIN t2_tc_16_reg_0007_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0007-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0007_it' AND column_name='target';

-- Test Case: TC-16-REG-0008-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=132162bd3ae3 column_type=binary(20) neg_probe=f2d6af4e2dd4=167|1264|1265|1406 neg_probe=2e9166004ce4=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0008_it, t2_tc_16_reg_0008_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0008_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0008_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0008_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0008_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0008_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0008_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0008_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0008_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0008_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0008_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0008_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0008_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0008_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0008_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0008_it (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0008_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0008_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0008_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0008_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0008_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0008_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0008_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0008_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0008_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0008_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0008_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0008_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0008_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0008_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0008_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0008_it);
-- probe 1/1 -> t1_tc_16_reg_0008_it
INSERT INTO t1_tc_16_reg_0008_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0008_it
INSERT INTO t2_tc_16_reg_0008_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0008-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0008_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0008_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0008_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0008_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0008-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0008_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0008_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0008_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0008_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0008_it a JOIN t2_tc_16_reg_0008_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0008-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0008_it' AND column_name='target';

-- Test Case: TC-16-REG-0009-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=a4603625af73 column_type=binary(20) neg_probe=616282152e84=167|1264|1265|1406 neg_probe=a1e28ebce8f3=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0009_it, t2_tc_16_reg_0009_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0009_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0009_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0009_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0009_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0009_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0009_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0009_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0009_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0009_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0009_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0009_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0009_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0009_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0009_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0009_it (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0009_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0009_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0009_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0009_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0009_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0009_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0009_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0009_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0009_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0009_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0009_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0009_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0009_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0009_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0009_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0009_it);
-- probe 1/1 -> t1_tc_16_reg_0009_it
INSERT INTO t1_tc_16_reg_0009_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0009_it
INSERT INTO t2_tc_16_reg_0009_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0009-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0009_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0009_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0009_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0009_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0009-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0009_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0009_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0009_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0009_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0009_it a JOIN t2_tc_16_reg_0009_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0009-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0009_it' AND column_name='target';

-- Test Case: TC-16-REG-0010-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=040d7f8c6d7e column_type=binary(20) neg_probe=bad8d4f7f8d0=167|1264|1265|1406 neg_probe=dacd3b185135=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0010_it, t2_tc_16_reg_0010_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0010_it (
  target BINARY(10),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0010_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0010_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0010_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0010_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0010_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0010_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0010_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0010_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0010_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0010_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0010_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0010_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0010_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0010_it (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0010_it (
  target BINARY(20),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0010_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0010_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0010_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0010_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0010_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0010_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0010_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0010_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0010_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0010_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0010_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0010_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0010_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0010_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0010_it);
-- probe 1/1 -> t1_tc_16_reg_0010_it
INSERT INTO t1_tc_16_reg_0010_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0010_it
INSERT INTO t2_tc_16_reg_0010_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0010-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0010_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0010_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0010_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0010_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0010-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0010_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0010_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0010_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0010_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0010_it a JOIN t2_tc_16_reg_0010_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0010-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0010_it' AND column_name='target';

-- Test Case: TC-16-REG-0011-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=2b19c3ad45d3 column_type=binary(20) neg_probe=5724981121fe=167|1264|1265|1406 neg_probe=47f8a467a0f0=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0011_it, t2_tc_16_reg_0011_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0011_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BINARY(10), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0011_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0011_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0011_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0011_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0011_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0011_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0011_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0011_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0011_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0011_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0011_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0011_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0011_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0011_it (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0011_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BINARY(20), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0011_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0011_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0011_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0011_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0011_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0011_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0011_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0011_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0011_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0011_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0011_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0011_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0011_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0011_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0011_it);
-- probe 1/1 -> t1_tc_16_reg_0011_it
INSERT INTO t1_tc_16_reg_0011_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0011_it
INSERT INTO t2_tc_16_reg_0011_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0011-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0011_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0011_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0011_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0011_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0011-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0011_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0011_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0011_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0011_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0011_it a JOIN t2_tc_16_reg_0011_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0011-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=4,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=4]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0011_it' AND column_name='target';

-- Test Case: TC-16-REG-0012-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=d2986aaa78db column_type=binary(20) neg_probe=6325200c3b7a=167|1264|1265|1406 neg_probe=9335421c56c7=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0012_it, t2_tc_16_reg_0012_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0012_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0012_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0012_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0012_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0012_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0012_it (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0012_it MODIFY target BINARY(20) NOT NULL, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0012_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0012_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0012_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0012_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0012_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0012_it (target) VALUES ('');
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0012_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0012_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0012_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0012_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0012_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0012_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0012_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0012_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0012_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0012_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0012_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0012_it (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0012_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0012_it);
-- probe 1/1 -> t1_tc_16_reg_0012_it
INSERT INTO t1_tc_16_reg_0012_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0012_it
INSERT INTO t2_tc_16_reg_0012_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0012-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0012_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0012_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0012_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0012_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0012-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0012_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0012_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0012_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0012_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0012_it a JOIN t2_tc_16_reg_0012_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0012-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0012_it' AND column_name='target';

-- Test Case: TC-16-REG-0013-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=c1d1813a40bf column_type=binary(20) neg_probe=6b124a27a5bd=167|1264|1265|1406 neg_probe=94e4ae6e950a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0013_it, t2_tc_16_reg_0013_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0013_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10) DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0013_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0013_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0013_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0013_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0013_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0013_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0013_it MODIFY target BINARY(20) DEFAULT 0x00, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0013_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0013_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0013_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0013_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0013_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0013_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0013_it (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0013_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20) DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0013_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0013_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0013_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0013_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0013_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0013_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0013_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0013_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0013_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0013_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0013_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0013_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0013_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0013_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0013_it);
-- probe 1/1 -> t1_tc_16_reg_0013_it
INSERT INTO t1_tc_16_reg_0013_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0013_it
INSERT INTO t2_tc_16_reg_0013_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0013-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0013_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0013_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0013_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0013_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0013-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0013_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0013_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0013_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0013_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0013_it a JOIN t2_tc_16_reg_0013_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0013-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0013_it' AND column_name='target';

-- Test Case: TC-16-REG-0014-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=62904cfa100f column_type=binary(20) neg_probe=f6e412687080=167|1264|1265|1406 neg_probe=7b5a5b8c8d16=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0014_it, t2_tc_16_reg_0014_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0014_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0014_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0014_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0014_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0014_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0014_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0014_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0014_it MODIFY target BINARY(20) DEFAULT NULL, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0014_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0014_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0014_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0014_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0014_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0014_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0014_it (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0014_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0014_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0014_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0014_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0014_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0014_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0014_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0014_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0014_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0014_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0014_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0014_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0014_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0014_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0014_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0014_it);
-- probe 1/1 -> t1_tc_16_reg_0014_it
INSERT INTO t1_tc_16_reg_0014_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0014_it
INSERT INTO t2_tc_16_reg_0014_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0014-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0014_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0014_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0014_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0014_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0014-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0014_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0014_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0014_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0014_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0014_it a JOIN t2_tc_16_reg_0014_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0014-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0014_it' AND column_name='target';

-- Test Case: TC-16-REG-0015-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=81b71b51f120 column_type=binary(20) neg_probe=b3a7488fff94=167|1264|1265|1406 neg_probe=93b8b582a453=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0015_it, t2_tc_16_reg_0015_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0015_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0015_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0015_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0015_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0015_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0015_it (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0015_it MODIFY target BINARY(20) NOT NULL DEFAULT 0x00, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0015_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0015_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0015_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0015_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0015_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0015_it (target) VALUES ('');
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0015_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0015_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0015_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0015_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0015_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0015_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0015_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0015_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0015_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0015_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0015_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0015_it (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0015_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0015_it);
-- probe 1/1 -> t1_tc_16_reg_0015_it
INSERT INTO t1_tc_16_reg_0015_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0015_it
INSERT INTO t2_tc_16_reg_0015_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0015-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0015_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0015_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0015_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0015_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0015-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0015_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0015_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0015_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0015_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0015_it a JOIN t2_tc_16_reg_0015_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0015-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=NO has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0015_it' AND column_name='target';

-- Test Case: TC-16-REG-0016-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=5a50f59bfa47 column_type=binary(20) neg_probe=859059f42163=167|1264|1265|1406 neg_probe=73154b4d4e30=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0016_it, t2_tc_16_reg_0016_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0016_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0016_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0016_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0016_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0016_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0016_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0016_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0016_it MODIFY target BINARY(20) INVISIBLE, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0016_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0016_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0016_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0016_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0016_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0016_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0016_it (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0016_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0016_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0016_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0016_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0016_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0016_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0016_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0016_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0016_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0016_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0016_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0016_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0016_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0016_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0016_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0016_it);
-- probe 1/1 -> t1_tc_16_reg_0016_it
INSERT INTO t1_tc_16_reg_0016_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0016_it
INSERT INTO t2_tc_16_reg_0016_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0016-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0016_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0016_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0016_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0016_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0016-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0016_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0016_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0016_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0016_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0016_it a JOIN t2_tc_16_reg_0016_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0016-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> 'INVISIBLE')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra=INVISIBLE pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0016_it' AND column_name='target';

-- Test Case: TC-16-REG-0017-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=ea1786030503 column_type=binary(20) neg_probe=008bb01bd876=167|1264|1265|1406 neg_probe=1d6611dd3f79=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0017_it, t2_tc_16_reg_0017_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0017_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0017_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0017_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0017_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0017_it);
-- probe 1/1 -> t1_tc_16_reg_0017_it
INSERT INTO t1_tc_16_reg_0017_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0017_it
INSERT INTO t2_tc_16_reg_0017_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0017-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0017_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0017_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0017_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0017_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0017-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0017_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0017_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0017_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0017_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0017_it a JOIN t2_tc_16_reg_0017_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0017-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0017_it' AND column_name='target';

-- Test Case: TC-16-REG-0018-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=bbe9853ba6a5 column_type=binary(20) neg_probe=b62e4c2dbf30=167|1264|1265|1406 neg_probe=af85f332c517=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0018_it, t2_tc_16_reg_0018_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0018_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0018_it (target) VALUES (0x00000000000000000000);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0018_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0018_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0018_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0018_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0018_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0018_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0018_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0018_it (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0018_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0018_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0018_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0018_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0018_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0018_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0018_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0018_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0018_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0018_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0018_it);
-- probe 1/1 -> t1_tc_16_reg_0018_it
INSERT INTO t1_tc_16_reg_0018_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0018_it
INSERT INTO t2_tc_16_reg_0018_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0018-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0018_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0018_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0018_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0018_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0018-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0018_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0018_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0018_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0018_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0018_it a JOIN t2_tc_16_reg_0018_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0018-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0018_it' AND column_name='target';

-- Test Case: TC-16-REG-0019-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: BIN-01
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=db3c9927bcf8 column_type=binary(20) neg_probe=4e6dd5d997c2=167|1264|1265|1406 neg_probe=b0bee3c32fda=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0019_it, t2_tc_16_reg_0019_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0019_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0019_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0019_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0019_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0019_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0019_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0019_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0019_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0019_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0019_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0019_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0019_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0019_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0019_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0019_it (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0019_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0019_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0019_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0019_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0019_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0019_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0019_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0019_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0019_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0019_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0019_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0019_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0019_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0019_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0019_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0019_it);
-- probe 1/1 -> t1_tc_16_reg_0019_it
INSERT INTO t1_tc_16_reg_0019_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0019_it
INSERT INTO t2_tc_16_reg_0019_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0019-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0019_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0019_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0019_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0019_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0019-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0019_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0019_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0019_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0019_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0019_it a JOIN t2_tc_16_reg_0019_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0019-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0019_it' AND column_name='target';

-- Test Case: TC-16-REG-0020-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: BIN-01
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=58745ab52adf column_type=binary(20) neg_probe=a1af3a883438=167|1264|1265|1406 neg_probe=f36f6443b279=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0020_it, t2_tc_16_reg_0020_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0020_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0020_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0020_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0020_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0020_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0020_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0020_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0020_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0020_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0020_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0020_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0020_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0020_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0020_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0020_it (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0020_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0020_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0020_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0020_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0020_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0020_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0020_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0020_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0020_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0020_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0020_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0020_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0020_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0020_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0020_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0020_it);
-- probe 1/1 -> t1_tc_16_reg_0020_it
INSERT INTO t1_tc_16_reg_0020_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0020_it
INSERT INTO t2_tc_16_reg_0020_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0020-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0020_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0020_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0020_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0020_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0020-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0020_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0020_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0020_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0020_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0020_it a JOIN t2_tc_16_reg_0020_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0020-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0020_it' AND column_name='target';

-- Test Case: TC-16-REG-0021-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=ee8c344e88e5 column_type=binary(20) neg_probe=91357422a2f2=167|1264|1265|1406 neg_probe=741b223d3f7c=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0021_it, t2_tc_16_reg_0021_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0021_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0021_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0021_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0021_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0021_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0021_it (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0021_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0021_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0021_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0021_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0021_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0021_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0021_it (target) VALUES ('');
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0021_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0021_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0021_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0021_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0021_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0021_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0021_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0021_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0021_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0021_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0021_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0021_it (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0021_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0021_it);
-- probe 1/1 -> t1_tc_16_reg_0021_it
INSERT INTO t1_tc_16_reg_0021_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0021_it
INSERT INTO t2_tc_16_reg_0021_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0021-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0021_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0021_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0021_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0021_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0021-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0021_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0021_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0021_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0021_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0021_it a JOIN t2_tc_16_reg_0021_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0021-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0021_it' AND column_name='target';

-- Test Case: TC-16-REG-0022-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=341c26de667e column_type=binary(20) neg_probe=67884f2554a3=167|1264|1265|1406 neg_probe=b50434384d50=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0022_it, t2_tc_16_reg_0022_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0022_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0022_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0022_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0022_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0022_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0022_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0022_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0022_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0022_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0022_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0022_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0022_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0022_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0022_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0022_it (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0022_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0022_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0022_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0022_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0022_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0022_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0022_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0022_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0022_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0022_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0022_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0022_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0022_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0022_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0022_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0022_it);
-- probe 1/1 -> t1_tc_16_reg_0022_it
INSERT INTO t1_tc_16_reg_0022_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0022_it
INSERT INTO t2_tc_16_reg_0022_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0022-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0022_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0022_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0022_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0022_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0022-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0022_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0022_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0022_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0022_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0022_it a JOIN t2_tc_16_reg_0022_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0022-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0022_it' AND column_name='target';

-- Test Case: TC-16-REG-0023-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=aebec71e0533 column_type=binary(20) neg_probe=273c1405ebe5=167|1264|1265|1406 neg_probe=5777d55b94a6=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0023_it, t2_tc_16_reg_0023_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0023_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0023_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0023_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0023_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0023_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0023_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0023_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0023_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0023_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0023_it (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0023_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0023_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0023_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0023_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0023_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0023_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0023_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0023_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0023_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0023_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0023_it);
-- probe 1/1 -> t1_tc_16_reg_0023_it
INSERT INTO t1_tc_16_reg_0023_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0023_it
INSERT INTO t2_tc_16_reg_0023_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0023-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0023_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0023_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0023_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0023_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0023-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0023_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0023_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0023_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0023_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0023_it a JOIN t2_tc_16_reg_0023_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0023-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0023_it' AND column_name='target';

-- Test Case: TC-16-REG-0024-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=6cfbd79f1c42 column_type=binary(20) neg_probe=7e1822ee2b0b=ACCEPTED neg_probe=2e4d7a8d6e96=ACCEPTED
DROP TABLE IF EXISTS t1_tc_16_reg_0024_it, t2_tc_16_reg_0024_it;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_16_reg_0024_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0024_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0024_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0024_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0024_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0024_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0024_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0024_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0024_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0024_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0024_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0024_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0024_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0024_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0024_it (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0024_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0024_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0024_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0024_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0024_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0024_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0024_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0024_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0024_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0024_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0024_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0024_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0024_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0024_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0024_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0024_it);
-- probe 1/1 -> t1_tc_16_reg_0024_it
INSERT INTO t1_tc_16_reg_0024_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0024_it
INSERT INTO t2_tc_16_reg_0024_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0024-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0024_it) - @neg_before_t1 = (SELECT COUNT(*) FROM t2_tc_16_reg_0024_it) - @neg_before_t2,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0024_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0024_it) - @neg_before_t2,' expect=t1_added = t2_added (非 STRICT: 截断行为必须与对照表一致) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0024-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0024_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0024_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0024_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0024_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0024_it a JOIN t2_tc_16_reg_0024_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0024-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0024_it' AND column_name='target';

-- Test Case: TC-16-REG-0025-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=3e7946680fa0 column_type=binary(20) neg_probe=412741e6f9f4=167|1264|1265|1406 neg_probe=f51a8de3f3bc=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0025_it, t2_tc_16_reg_0025_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0025_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0025_it MODIFY target BINARY(20) NOT NULL, ALGORITHM=instant;
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0025_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0025_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0025_it);
-- probe 1/1 -> t1_tc_16_reg_0025_it
INSERT INTO t1_tc_16_reg_0025_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0025_it
INSERT INTO t2_tc_16_reg_0025_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0025-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0025_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0025_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0025_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0025_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0025-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0025_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0025_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0025_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0025_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0025_it a JOIN t2_tc_16_reg_0025_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0025-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0025_it' AND column_name='target';

-- Test Case: TC-16-REG-0026-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: BIN-01
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=5a760141405e column_type=binary(20) neg_probe=f25a10504fa9=167|1264|1265|1406 neg_probe=48c6dd1b82bd=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0026_it, t2_tc_16_reg_0026_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0026_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0026_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0026_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0026_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0026_it);
-- probe 1/1 -> t1_tc_16_reg_0026_it
INSERT INTO t1_tc_16_reg_0026_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0026_it
INSERT INTO t2_tc_16_reg_0026_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0026-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0026_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0026_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0026_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0026_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0026-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0026_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0026_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0026_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0026_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0026_it a JOIN t2_tc_16_reg_0026_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0026-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0026_it' AND column_name='target';

-- Test Case: TC-16-REG-0027-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=b55436c427d9 column_type=binary(20) neg_probe=a2c173708094=167|1264|1265|1406 neg_probe=cfaa71fcca74=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0027_it, t2_tc_16_reg_0027_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0027_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0027_it MODIFY target BINARY(20) NOT NULL DEFAULT 0x00, ALGORITHM=instant;
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_16_reg_0027_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0027_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0027_it);
-- probe 1/1 -> t1_tc_16_reg_0027_it
INSERT INTO t1_tc_16_reg_0027_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0027_it
INSERT INTO t2_tc_16_reg_0027_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0027-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0027_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0027_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0027_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0027_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0027-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0027_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0027_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0027_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0027_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0027_it a JOIN t2_tc_16_reg_0027_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0027-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=NO has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0027_it' AND column_name='target';

-- Test Case: TC-16-REG-0028-IT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant, Expected: FAIL
-- Varied factor: KP-05
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=FAIL build=SUCCESS assertions=3 neg_probes=1 alter_sha=a41afc16d937 errno=[1845,1846,1659,3780] column_type=binary(10) neg_probe=054a179dd39f=167|1264|1265|1406 neg_probe=15e6168dcdc7=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0028_it, t2_tc_16_reg_0028_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0028_it (
  target BINARY(10),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0028_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0028_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0028_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_reg_0028_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_reg_0028_it (target) VALUES ('');
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_16_reg_0028_it MODIFY target BINARY(20), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0028_it (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0028_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0028_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0028_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_reg_0028_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0028_it (target) VALUES ('');
-- Oracle table: BINARY(10)
CREATE TABLE t2_tc_16_reg_0028_it (
  target BINARY(10),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0028_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0028_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0028_it (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_16_reg_0028_it (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_16_reg_0028_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0028_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0028_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0028_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0028_it (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_16_reg_0028_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0028_it (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0028_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0028_it);
-- probe 1/1 -> t1_tc_16_reg_0028_it
INSERT INTO t1_tc_16_reg_0028_it (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0028_it
INSERT INTO t2_tc_16_reg_0028_it (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0028-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0028_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0028_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0028_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0028_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0028-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0028_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0028_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0028_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0028_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0028_it a JOIN t2_tc_16_reg_0028_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0028-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(10)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(10) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0028_it' AND column_name='target';

-- Test Case: TC-16-ATR-0001-IT
-- Column attribute preservation: COMMENT
-- Type: BINARY(10) -> BINARY(20), Algorithm: instant
-- Transition ID: BIN-01
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=b856a5f45eba column_type=binary(20)
DROP TABLE IF EXISTS t1_tc_16_atr_0001_it, t2_tc_16_atr_0001_it;
CREATE TABLE t1_tc_16_atr_0001_it (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target BINARY(10) COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB;
INSERT INTO t1_tc_16_atr_0001_it (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_16_atr_0001_it (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_16_atr_0001_it (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_16_atr_0001_it (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_16_atr_0001_it (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_atr_0001_it MODIFY target BINARY(20) COMMENT 'test_comment', ALGORITHM=instant;
INSERT INTO t1_tc_16_atr_0001_it (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_atr_0001_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_atr_0001_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
SELECT 'TC-16-ATR-0001-IT' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_16_atr_0001_it' AND column_name='target' AND column_comment='test_comment';
SELECT 'TC-16-ATR-0001-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_atr_0001_it' AND column_name='target';

-- Test Case: TC-16-REG-0029-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=4f82f1ab64ac column_type=binary(80) neg_probe=5e841a363feb=167|1264|1265|1406 neg_probe=ea8fd900c37e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0029_it, t2_tc_16_reg_0029_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0029_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0029_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0029_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0029_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0029_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0029_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0029_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0029_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0029_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0029_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0029_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0029_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0029_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0029_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0029_it (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0029_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0029_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0029_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0029_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0029_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0029_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0029_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0029_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0029_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0029_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0029_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0029_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0029_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0029_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0029_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0029_it);
-- probe 1/1 -> t1_tc_16_reg_0029_it
INSERT INTO t1_tc_16_reg_0029_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0029_it
INSERT INTO t2_tc_16_reg_0029_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0029-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0029_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0029_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0029_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0029_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0029-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0029_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0029_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0029_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0029_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0029_it a JOIN t2_tc_16_reg_0029_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0029-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0029_it' AND column_name='target';

-- Test Case: TC-16-REG-0030-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=0705cfb1ce15 column_type=binary(80) neg_probe=82afd426dc39=167|1264|1265|1406 neg_probe=b2b2c89370e9=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0030_it, t2_tc_16_reg_0030_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0030_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t1_tc_16_reg_0030_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0030_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0030_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0030_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0030_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0030_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0030_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0030_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0030_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0030_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0030_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0030_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0030_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0030_it (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0030_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t2_tc_16_reg_0030_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0030_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0030_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0030_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0030_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0030_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0030_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0030_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0030_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0030_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0030_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0030_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0030_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0030_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0030_it);
-- probe 1/1 -> t1_tc_16_reg_0030_it
INSERT INTO t1_tc_16_reg_0030_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0030_it
INSERT INTO t2_tc_16_reg_0030_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0030-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0030_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0030_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0030_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0030_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0030-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0030_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0030_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0030_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0030_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0030_it a JOIN t2_tc_16_reg_0030_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0030-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0030_it' AND column_name='target';

-- Test Case: TC-16-REG-0031-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=908c41d3481d column_type=binary(80) neg_probe=90aea58dfa97=167|1264|1265|1406 neg_probe=96bcbb949024=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0031_it, t2_tc_16_reg_0031_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0031_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t1_tc_16_reg_0031_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0031_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0031_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0031_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0031_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0031_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0031_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0031_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0031_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0031_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0031_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0031_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0031_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0031_it (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0031_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t2_tc_16_reg_0031_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0031_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0031_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0031_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0031_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0031_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0031_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0031_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0031_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0031_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0031_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0031_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0031_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0031_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0031_it);
-- probe 1/1 -> t1_tc_16_reg_0031_it
INSERT INTO t1_tc_16_reg_0031_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0031_it
INSERT INTO t2_tc_16_reg_0031_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0031-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0031_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0031_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0031_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0031_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0031-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0031_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0031_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0031_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0031_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0031_it a JOIN t2_tc_16_reg_0031_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0031-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0031_it' AND column_name='target';

-- Test Case: TC-16-REG-0032-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: FAIL
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=FAIL build=SUCCESS assertions=3 neg_probes=1 alter_sha=ec88aca17ea4 errno=[1845,1846,1659,3780] column_type=binary(40) neg_probe=cc4d29929835=167|1264|1265|1406 neg_probe=464cbf3af612=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0032_it, t2_tc_16_reg_0032_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0032_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0032_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0032_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0032_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0032_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0032_it (target) VALUES ('');
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_16_reg_0032_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0032_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0032_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0032_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0032_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0032_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0032_it (target) VALUES ('');
-- Oracle table: BINARY(40)
CREATE TABLE t2_tc_16_reg_0032_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0032_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0032_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0032_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0032_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0032_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0032_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0032_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0032_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0032_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0032_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0032_it (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0032_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0032_it);
-- probe 1/1 -> t1_tc_16_reg_0032_it
INSERT INTO t1_tc_16_reg_0032_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0032_it
INSERT INTO t2_tc_16_reg_0032_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0032-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0032_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0032_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0032_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0032_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0032-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0032_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0032_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0032_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0032_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0032_it a JOIN t2_tc_16_reg_0032_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0032-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(40)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(40) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0032_it' AND column_name='target';

-- Test Case: TC-16-REG-0033-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=e187ece6c894 column_type=binary(80) neg_probe=6948bafcbcce=167|1264|1265|1406 neg_probe=d19e210bc328=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0033_it, t2_tc_16_reg_0033_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0033_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0033_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0033_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0033_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0033_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0033_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0033_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0033_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0033_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0033_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0033_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0033_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0033_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0033_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0033_it (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0033_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0033_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0033_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0033_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0033_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0033_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0033_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0033_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0033_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0033_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0033_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0033_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0033_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0033_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0033_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0033_it);
-- probe 1/1 -> t1_tc_16_reg_0033_it
INSERT INTO t1_tc_16_reg_0033_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0033_it
INSERT INTO t2_tc_16_reg_0033_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0033-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0033_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0033_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0033_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0033_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0033-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0033_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0033_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0033_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0033_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0033_it a JOIN t2_tc_16_reg_0033_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0033-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0033_it' AND column_name='target';

-- Test Case: TC-16-REG-0034-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=8c5a7df23bc7 column_type=binary(80) neg_probe=eba5b86d1e7f=167|1264|1265|1406 neg_probe=80fb56064b1a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0034_it, t2_tc_16_reg_0034_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0034_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0034_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0034_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0034_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0034_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0034_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0034_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0034_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0034_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0034_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0034_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0034_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0034_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0034_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0034_it (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0034_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0034_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0034_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0034_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0034_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0034_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0034_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0034_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0034_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0034_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0034_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0034_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0034_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0034_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0034_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0034_it);
-- probe 1/1 -> t1_tc_16_reg_0034_it
INSERT INTO t1_tc_16_reg_0034_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0034_it
INSERT INTO t2_tc_16_reg_0034_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0034-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0034_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0034_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0034_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0034_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0034-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0034_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0034_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0034_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0034_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0034_it a JOIN t2_tc_16_reg_0034_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0034-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0034_it' AND column_name='target';

-- Test Case: TC-16-REG-0035-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=c27df82b969f column_type=binary(80) neg_probe=6d09cb677dcf=167|1264|1265|1406 neg_probe=c3663e8681c4=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0035_it, t2_tc_16_reg_0035_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0035_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0035_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0035_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0035_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0035_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0035_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0035_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0035_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0035_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0035_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0035_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0035_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0035_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0035_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0035_it (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0035_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0035_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0035_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0035_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0035_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0035_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0035_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0035_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0035_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0035_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0035_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0035_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0035_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0035_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0035_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0035_it);
-- probe 1/1 -> t1_tc_16_reg_0035_it
INSERT INTO t1_tc_16_reg_0035_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0035_it
INSERT INTO t2_tc_16_reg_0035_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0035-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0035_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0035_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0035_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0035_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0035-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0035_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0035_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0035_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0035_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0035_it a JOIN t2_tc_16_reg_0035_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0035-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0035_it' AND column_name='target';

-- Test Case: TC-16-REG-0036-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=c26ee9516300 column_type=binary(80) neg_probe=112d8e51a530=167|1264|1265|1406 neg_probe=bd35571d9664=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0036_it, t2_tc_16_reg_0036_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0036_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0036_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0036_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0036_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0036_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0036_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0036_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0036_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0036_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0036_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0036_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0036_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0036_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0036_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0036_it (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0036_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0036_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0036_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0036_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0036_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0036_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0036_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0036_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0036_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0036_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0036_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0036_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0036_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0036_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0036_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0036_it);
-- probe 1/1 -> t1_tc_16_reg_0036_it
INSERT INTO t1_tc_16_reg_0036_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0036_it
INSERT INTO t2_tc_16_reg_0036_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0036-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0036_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0036_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0036_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0036_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0036-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0036_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0036_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0036_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0036_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0036_it a JOIN t2_tc_16_reg_0036_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0036-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0036_it' AND column_name='target';

-- Test Case: TC-16-REG-0037-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=3351a37121e4 column_type=binary(80) neg_probe=cebe1e43724d=167|1264|1265|1406 neg_probe=3a4d80cb008c=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0037_it, t2_tc_16_reg_0037_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0037_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0037_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0037_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0037_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0037_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0037_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0037_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0037_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0037_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0037_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0037_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0037_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0037_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0037_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0037_it (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0037_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0037_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0037_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0037_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0037_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0037_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0037_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0037_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0037_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0037_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0037_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0037_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0037_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0037_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0037_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0037_it);
-- probe 1/1 -> t1_tc_16_reg_0037_it
INSERT INTO t1_tc_16_reg_0037_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0037_it
INSERT INTO t2_tc_16_reg_0037_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0037-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0037_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0037_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0037_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0037_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0037-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0037_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0037_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0037_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0037_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0037_it a JOIN t2_tc_16_reg_0037_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0037-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0037_it' AND column_name='target';

-- Test Case: TC-16-REG-0038-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=d0db6335d7c9 column_type=binary(80) neg_probe=b1695c83a52e=167|1264|1265|1406 neg_probe=70fbf2c9dc01=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0038_it, t2_tc_16_reg_0038_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0038_it (
  target BINARY(40),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0038_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0038_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0038_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0038_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0038_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0038_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0038_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0038_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0038_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0038_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0038_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0038_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0038_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0038_it (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0038_it (
  target BINARY(80),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0038_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0038_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0038_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0038_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0038_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0038_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0038_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0038_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0038_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0038_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0038_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0038_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0038_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0038_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0038_it);
-- probe 1/1 -> t1_tc_16_reg_0038_it
INSERT INTO t1_tc_16_reg_0038_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0038_it
INSERT INTO t2_tc_16_reg_0038_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0038-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0038_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0038_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0038_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0038_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0038-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0038_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0038_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0038_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0038_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0038_it a JOIN t2_tc_16_reg_0038_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0038-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0038_it' AND column_name='target';

-- Test Case: TC-16-REG-0039-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=786b5ed1d0a8 column_type=binary(80) neg_probe=194ad97b689c=167|1264|1265|1406 neg_probe=783a4cf26434=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0039_it, t2_tc_16_reg_0039_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0039_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BINARY(40), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0039_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0039_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0039_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0039_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0039_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0039_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0039_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0039_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0039_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0039_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0039_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0039_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0039_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0039_it (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0039_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BINARY(80), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0039_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0039_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0039_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0039_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0039_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0039_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0039_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0039_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0039_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0039_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0039_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0039_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0039_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0039_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0039_it);
-- probe 1/1 -> t1_tc_16_reg_0039_it
INSERT INTO t1_tc_16_reg_0039_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0039_it
INSERT INTO t2_tc_16_reg_0039_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0039-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0039_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0039_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0039_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0039_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0039-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0039_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0039_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0039_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0039_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0039_it a JOIN t2_tc_16_reg_0039_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0039-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=4,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=4]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0039_it' AND column_name='target';

-- Test Case: TC-16-REG-0040-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=4b193ca7f6ad column_type=binary(80) neg_probe=ea60424c70af=167|1264|1265|1406 neg_probe=cec0e6222587=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0040_it, t2_tc_16_reg_0040_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0040_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0040_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0040_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0040_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0040_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0040_it (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0040_it MODIFY target BINARY(80) NOT NULL, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0040_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0040_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0040_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0040_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0040_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0040_it (target) VALUES ('');
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0040_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0040_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0040_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0040_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0040_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0040_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0040_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0040_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0040_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0040_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0040_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0040_it (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0040_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0040_it);
-- probe 1/1 -> t1_tc_16_reg_0040_it
INSERT INTO t1_tc_16_reg_0040_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0040_it
INSERT INTO t2_tc_16_reg_0040_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0040-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0040_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0040_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0040_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0040_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0040-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0040_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0040_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0040_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0040_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0040_it a JOIN t2_tc_16_reg_0040_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0040-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0040_it' AND column_name='target';

-- Test Case: TC-16-REG-0041-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=1c72314ae997 column_type=binary(80) neg_probe=04283306e7d0=167|1264|1265|1406 neg_probe=8d3aace74648=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0041_it, t2_tc_16_reg_0041_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0041_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40) DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0041_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0041_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0041_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0041_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0041_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0041_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0041_it MODIFY target BINARY(80) DEFAULT 0x00, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0041_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0041_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0041_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0041_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0041_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0041_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0041_it (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0041_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80) DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0041_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0041_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0041_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0041_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0041_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0041_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0041_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0041_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0041_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0041_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0041_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0041_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0041_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0041_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0041_it);
-- probe 1/1 -> t1_tc_16_reg_0041_it
INSERT INTO t1_tc_16_reg_0041_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0041_it
INSERT INTO t2_tc_16_reg_0041_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0041-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0041_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0041_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0041_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0041_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0041-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0041_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0041_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0041_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0041_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0041_it a JOIN t2_tc_16_reg_0041_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0041-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0041_it' AND column_name='target';

-- Test Case: TC-16-REG-0042-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=15748698ced7 column_type=binary(80) neg_probe=99e150b918e9=167|1264|1265|1406 neg_probe=b36f9208e51a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0042_it, t2_tc_16_reg_0042_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0042_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0042_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0042_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0042_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0042_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0042_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0042_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0042_it MODIFY target BINARY(80) DEFAULT NULL, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0042_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0042_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0042_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0042_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0042_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0042_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0042_it (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0042_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0042_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0042_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0042_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0042_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0042_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0042_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0042_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0042_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0042_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0042_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0042_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0042_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0042_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0042_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0042_it);
-- probe 1/1 -> t1_tc_16_reg_0042_it
INSERT INTO t1_tc_16_reg_0042_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0042_it
INSERT INTO t2_tc_16_reg_0042_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0042-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0042_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0042_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0042_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0042_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0042-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0042_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0042_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0042_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0042_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0042_it a JOIN t2_tc_16_reg_0042_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0042-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0042_it' AND column_name='target';

-- Test Case: TC-16-REG-0043-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=26ec062cd000 column_type=binary(80) neg_probe=5ec6ad381700=167|1264|1265|1406 neg_probe=bcb3c3300cf4=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0043_it, t2_tc_16_reg_0043_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0043_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0043_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0043_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0043_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0043_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0043_it (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0043_it MODIFY target BINARY(80) NOT NULL DEFAULT 0x00, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0043_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0043_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0043_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0043_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0043_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0043_it (target) VALUES ('');
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0043_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0043_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0043_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0043_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0043_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0043_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0043_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0043_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0043_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0043_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0043_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0043_it (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0043_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0043_it);
-- probe 1/1 -> t1_tc_16_reg_0043_it
INSERT INTO t1_tc_16_reg_0043_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0043_it
INSERT INTO t2_tc_16_reg_0043_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0043-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0043_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0043_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0043_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0043_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0043-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0043_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0043_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0043_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0043_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0043_it a JOIN t2_tc_16_reg_0043_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0043-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=NO has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0043_it' AND column_name='target';

-- Test Case: TC-16-REG-0044-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=caca1ed26120 column_type=binary(80) neg_probe=3b6fb2938dcc=167|1264|1265|1406 neg_probe=e84a8bb45278=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0044_it, t2_tc_16_reg_0044_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0044_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0044_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0044_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0044_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0044_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0044_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0044_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0044_it MODIFY target BINARY(80) INVISIBLE, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0044_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0044_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0044_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0044_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0044_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0044_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0044_it (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0044_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0044_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0044_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0044_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0044_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0044_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0044_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0044_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0044_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0044_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0044_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0044_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0044_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0044_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0044_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0044_it);
-- probe 1/1 -> t1_tc_16_reg_0044_it
INSERT INTO t1_tc_16_reg_0044_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0044_it
INSERT INTO t2_tc_16_reg_0044_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0044-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0044_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0044_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0044_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0044_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0044-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0044_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0044_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0044_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0044_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0044_it a JOIN t2_tc_16_reg_0044_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0044-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> 'INVISIBLE')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra=INVISIBLE pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0044_it' AND column_name='target';

-- Test Case: TC-16-REG-0045-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=3984aa102d20 column_type=binary(80) neg_probe=645b180870f0=167|1264|1265|1406 neg_probe=639a75d43140=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0045_it, t2_tc_16_reg_0045_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0045_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0045_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0045_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0045_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0045_it);
-- probe 1/1 -> t1_tc_16_reg_0045_it
INSERT INTO t1_tc_16_reg_0045_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0045_it
INSERT INTO t2_tc_16_reg_0045_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0045-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0045_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0045_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0045_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0045_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0045-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0045_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0045_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0045_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0045_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0045_it a JOIN t2_tc_16_reg_0045_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0045-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0045_it' AND column_name='target';

-- Test Case: TC-16-REG-0046-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=94c3b25a027c column_type=binary(80) neg_probe=91df3993f647=167|1264|1265|1406 neg_probe=abc8e4e42c27=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0046_it, t2_tc_16_reg_0046_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0046_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0046_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0046_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0046_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0046_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0046_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0046_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0046_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0046_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0046_it (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0046_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0046_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0046_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0046_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0046_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0046_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0046_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0046_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0046_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0046_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0046_it);
-- probe 1/1 -> t1_tc_16_reg_0046_it
INSERT INTO t1_tc_16_reg_0046_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0046_it
INSERT INTO t2_tc_16_reg_0046_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0046-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0046_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0046_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0046_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0046_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0046-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0046_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0046_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0046_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0046_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0046_it a JOIN t2_tc_16_reg_0046_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0046-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0046_it' AND column_name='target';

-- Test Case: TC-16-REG-0047-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: BIN-02
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=adbf4d2d36d7 column_type=binary(80) neg_probe=a721ba05190a=167|1264|1265|1406 neg_probe=fefdf9196f3d=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0047_it, t2_tc_16_reg_0047_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0047_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0047_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0047_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0047_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0047_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0047_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0047_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0047_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0047_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0047_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0047_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0047_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0047_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0047_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0047_it (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0047_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0047_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0047_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0047_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0047_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0047_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0047_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0047_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0047_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0047_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0047_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0047_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0047_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0047_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0047_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0047_it);
-- probe 1/1 -> t1_tc_16_reg_0047_it
INSERT INTO t1_tc_16_reg_0047_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0047_it
INSERT INTO t2_tc_16_reg_0047_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0047-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0047_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0047_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0047_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0047_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0047-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0047_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0047_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0047_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0047_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0047_it a JOIN t2_tc_16_reg_0047_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0047-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0047_it' AND column_name='target';

-- Test Case: TC-16-REG-0048-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: BIN-02
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=2cb378948228 column_type=binary(80) neg_probe=b15def687a26=167|1264|1265|1406 neg_probe=d7c95e54e040=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0048_it, t2_tc_16_reg_0048_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0048_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0048_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0048_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0048_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0048_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0048_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0048_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0048_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0048_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0048_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0048_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0048_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0048_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0048_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0048_it (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0048_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0048_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0048_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0048_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0048_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0048_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0048_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0048_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0048_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0048_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0048_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0048_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0048_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0048_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0048_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0048_it);
-- probe 1/1 -> t1_tc_16_reg_0048_it
INSERT INTO t1_tc_16_reg_0048_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0048_it
INSERT INTO t2_tc_16_reg_0048_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0048-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0048_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0048_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0048_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0048_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0048-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0048_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0048_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0048_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0048_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0048_it a JOIN t2_tc_16_reg_0048_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0048-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0048_it' AND column_name='target';

-- Test Case: TC-16-REG-0049-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=36c544a5ae2f column_type=binary(80) neg_probe=d3c74a463fe2=167|1264|1265|1406 neg_probe=eb3ecf64068e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0049_it, t2_tc_16_reg_0049_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0049_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0049_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0049_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0049_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0049_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0049_it (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0049_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0049_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0049_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0049_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0049_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0049_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0049_it (target) VALUES ('');
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0049_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0049_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0049_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0049_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0049_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0049_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0049_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0049_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0049_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0049_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0049_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0049_it (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0049_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0049_it);
-- probe 1/1 -> t1_tc_16_reg_0049_it
INSERT INTO t1_tc_16_reg_0049_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0049_it
INSERT INTO t2_tc_16_reg_0049_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0049-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0049_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0049_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0049_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0049_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0049-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0049_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0049_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0049_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0049_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0049_it a JOIN t2_tc_16_reg_0049_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0049-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0049_it' AND column_name='target';

-- Test Case: TC-16-REG-0050-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=f9964eab6453 column_type=binary(80) neg_probe=309ceaa6c81a=167|1264|1265|1406 neg_probe=0702a20e52ae=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0050_it, t2_tc_16_reg_0050_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0050_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0050_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0050_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0050_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0050_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0050_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0050_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0050_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0050_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0050_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0050_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0050_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0050_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0050_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0050_it (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0050_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0050_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0050_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0050_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0050_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0050_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0050_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0050_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0050_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0050_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0050_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0050_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0050_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0050_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0050_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0050_it);
-- probe 1/1 -> t1_tc_16_reg_0050_it
INSERT INTO t1_tc_16_reg_0050_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0050_it
INSERT INTO t2_tc_16_reg_0050_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0050-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0050_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0050_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0050_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0050_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0050-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0050_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0050_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0050_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0050_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0050_it a JOIN t2_tc_16_reg_0050_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0050-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0050_it' AND column_name='target';

-- Test Case: TC-16-REG-0051-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=09f10e1cb34e column_type=binary(80) neg_probe=58c64b904892=167|1264|1265|1406 neg_probe=369add2bd61a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0051_it, t2_tc_16_reg_0051_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0051_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0051_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0051_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0051_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0051_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0051_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0051_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0051_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0051_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0051_it (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0051_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0051_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0051_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0051_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0051_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0051_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0051_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0051_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0051_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0051_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0051_it);
-- probe 1/1 -> t1_tc_16_reg_0051_it
INSERT INTO t1_tc_16_reg_0051_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0051_it
INSERT INTO t2_tc_16_reg_0051_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0051-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0051_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0051_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0051_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0051_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0051-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0051_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0051_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0051_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0051_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0051_it a JOIN t2_tc_16_reg_0051_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0051-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0051_it' AND column_name='target';

-- Test Case: TC-16-REG-0052-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=d271d0e11682 column_type=binary(80) neg_probe=63e901dd037e=ACCEPTED neg_probe=6f47891a7e14=ACCEPTED
DROP TABLE IF EXISTS t1_tc_16_reg_0052_it, t2_tc_16_reg_0052_it;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_16_reg_0052_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0052_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0052_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0052_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0052_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0052_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0052_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0052_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0052_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0052_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0052_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0052_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0052_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0052_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0052_it (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0052_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0052_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0052_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0052_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0052_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0052_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0052_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0052_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0052_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0052_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0052_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0052_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0052_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0052_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0052_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0052_it);
-- probe 1/1 -> t1_tc_16_reg_0052_it
INSERT INTO t1_tc_16_reg_0052_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0052_it
INSERT INTO t2_tc_16_reg_0052_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0052-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0052_it) - @neg_before_t1 = (SELECT COUNT(*) FROM t2_tc_16_reg_0052_it) - @neg_before_t2,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0052_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0052_it) - @neg_before_t2,' expect=t1_added = t2_added (非 STRICT: 截断行为必须与对照表一致) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0052-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0052_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0052_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0052_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0052_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0052_it a JOIN t2_tc_16_reg_0052_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0052-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0052_it' AND column_name='target';

-- Test Case: TC-16-REG-0053-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=a9316a0cc431 column_type=binary(80) neg_probe=5eb89b23ceb2=167|1264|1265|1406 neg_probe=bea8c9c6829c=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0053_it, t2_tc_16_reg_0053_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0053_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0053_it MODIFY target BINARY(80) NOT NULL, ALGORITHM=instant;
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0053_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0053_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0053_it);
-- probe 1/1 -> t1_tc_16_reg_0053_it
INSERT INTO t1_tc_16_reg_0053_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0053_it
INSERT INTO t2_tc_16_reg_0053_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0053-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0053_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0053_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0053_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0053_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0053-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0053_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0053_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0053_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0053_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0053_it a JOIN t2_tc_16_reg_0053_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0053-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0053_it' AND column_name='target';

-- Test Case: TC-16-REG-0054-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: BIN-02
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=574ef5d24cf2 column_type=binary(80) neg_probe=c4c68cf1f772=167|1264|1265|1406 neg_probe=4df1e626d1ed=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0054_it, t2_tc_16_reg_0054_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0054_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0054_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0054_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0054_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0054_it);
-- probe 1/1 -> t1_tc_16_reg_0054_it
INSERT INTO t1_tc_16_reg_0054_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0054_it
INSERT INTO t2_tc_16_reg_0054_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0054-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0054_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0054_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0054_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0054_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0054-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0054_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0054_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0054_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0054_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0054_it a JOIN t2_tc_16_reg_0054_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0054-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0054_it' AND column_name='target';

-- Test Case: TC-16-REG-0055-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=26122b6607be column_type=binary(80) neg_probe=6f8650608769=167|1264|1265|1406 neg_probe=5f670daee7d9=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0055_it, t2_tc_16_reg_0055_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0055_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0055_it MODIFY target BINARY(80) NOT NULL DEFAULT 0x00, ALGORITHM=instant;
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_16_reg_0055_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0055_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0055_it);
-- probe 1/1 -> t1_tc_16_reg_0055_it
INSERT INTO t1_tc_16_reg_0055_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0055_it
INSERT INTO t2_tc_16_reg_0055_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0055-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0055_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0055_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0055_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0055_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0055-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0055_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0055_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0055_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0055_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0055_it a JOIN t2_tc_16_reg_0055_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0055-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=NO has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0055_it' AND column_name='target';

-- Test Case: TC-16-REG-0056-IT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant, Expected: FAIL
-- Varied factor: KP-05
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=FAIL build=SUCCESS assertions=3 neg_probes=1 alter_sha=2e502291f21e errno=[1845,1846,1659,3780] column_type=binary(40) neg_probe=51d894c56d0f=167|1264|1265|1406 neg_probe=2900d8f99c62=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0056_it, t2_tc_16_reg_0056_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0056_it (
  target BINARY(40),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0056_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0056_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0056_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0056_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0056_it (target) VALUES ('');
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_16_reg_0056_it MODIFY target BINARY(80), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0056_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0056_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0056_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_16_reg_0056_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0056_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0056_it (target) VALUES ('');
-- Oracle table: BINARY(40)
CREATE TABLE t2_tc_16_reg_0056_it (
  target BINARY(40),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0056_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0056_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0056_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0056_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0056_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0056_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0056_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0056_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_16_reg_0056_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0056_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0056_it (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0056_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0056_it);
-- probe 1/1 -> t1_tc_16_reg_0056_it
INSERT INTO t1_tc_16_reg_0056_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0056_it
INSERT INTO t2_tc_16_reg_0056_it (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0056-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0056_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0056_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0056_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0056_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0056-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0056_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0056_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0056_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0056_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0056_it a JOIN t2_tc_16_reg_0056_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0056-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(40)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(40) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0056_it' AND column_name='target';

-- Test Case: TC-16-ATR-0002-IT
-- Column attribute preservation: COMMENT
-- Type: BINARY(40) -> BINARY(80), Algorithm: instant
-- Transition ID: BIN-02
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=589b5ac25117 column_type=binary(80)
DROP TABLE IF EXISTS t1_tc_16_atr_0002_it, t2_tc_16_atr_0002_it;
CREATE TABLE t1_tc_16_atr_0002_it (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target BINARY(40) COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB;
INSERT INTO t1_tc_16_atr_0002_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_atr_0002_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_atr_0002_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_atr_0002_it (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_atr_0002_it (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_atr_0002_it MODIFY target BINARY(80) COMMENT 'test_comment', ALGORITHM=instant;
INSERT INTO t1_tc_16_atr_0002_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_atr_0002_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_atr_0002_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
SELECT 'TC-16-ATR-0002-IT' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_16_atr_0002_it' AND column_name='target' AND column_comment='test_comment';
SELECT 'TC-16-ATR-0002-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_atr_0002_it' AND column_name='target';

-- Test Case: TC-16-REG-0057-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=ef684c9c7c14 column_type=binary(255) neg_probe=86ba225d334f=167|1264|1265|1406 neg_probe=cd270b022c5e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0057_it, t2_tc_16_reg_0057_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0057_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0057_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0057_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0057_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0057_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0057_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0057_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0057_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0057_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0057_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0057_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0057_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0057_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0057_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0057_it (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0057_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0057_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0057_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0057_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0057_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0057_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0057_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0057_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0057_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0057_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0057_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0057_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0057_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0057_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0057_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0057_it);
-- probe 1/1 -> t1_tc_16_reg_0057_it
INSERT INTO t1_tc_16_reg_0057_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0057_it
INSERT INTO t2_tc_16_reg_0057_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0057-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0057_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0057_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0057_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0057_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0057-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0057_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0057_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0057_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0057_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0057_it a JOIN t2_tc_16_reg_0057_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0057-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0057_it' AND column_name='target';

-- Test Case: TC-16-REG-0058-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=f81728da6c9b column_type=binary(255) neg_probe=f786abb77fca=167|1264|1265|1406 neg_probe=df7962e70b4e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0058_it, t2_tc_16_reg_0058_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0058_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t1_tc_16_reg_0058_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0058_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0058_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0058_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0058_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0058_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0058_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0058_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0058_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0058_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0058_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0058_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0058_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0058_it (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0058_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t2_tc_16_reg_0058_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0058_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0058_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0058_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0058_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0058_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0058_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0058_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0058_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0058_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0058_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0058_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0058_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0058_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0058_it);
-- probe 1/1 -> t1_tc_16_reg_0058_it
INSERT INTO t1_tc_16_reg_0058_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0058_it
INSERT INTO t2_tc_16_reg_0058_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0058-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0058_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0058_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0058_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0058_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0058-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0058_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0058_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0058_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0058_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0058_it a JOIN t2_tc_16_reg_0058_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0058-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0058_it' AND column_name='target';

-- Test Case: TC-16-REG-0059-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=b0e801bb4ec0 column_type=binary(255) neg_probe=6b60d40eb7b6=167|1264|1265|1406 neg_probe=5d96d7129694=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0059_it, t2_tc_16_reg_0059_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0059_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t1_tc_16_reg_0059_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0059_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0059_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0059_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0059_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0059_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0059_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0059_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0059_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0059_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0059_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0059_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0059_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0059_it (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0059_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t2_tc_16_reg_0059_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0059_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0059_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0059_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0059_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0059_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0059_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0059_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0059_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0059_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0059_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0059_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0059_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0059_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0059_it);
-- probe 1/1 -> t1_tc_16_reg_0059_it
INSERT INTO t1_tc_16_reg_0059_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0059_it
INSERT INTO t2_tc_16_reg_0059_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0059-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0059_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0059_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0059_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0059_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0059-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0059_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0059_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0059_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0059_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0059_it a JOIN t2_tc_16_reg_0059_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0059-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0059_it' AND column_name='target';

-- Test Case: TC-16-REG-0060-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: FAIL
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=FAIL build=SUCCESS assertions=3 neg_probes=1 alter_sha=6dae5cfee339 errno=[1845,1846,1659,3780] column_type=binary(254) neg_probe=0543229c206b=167|1264|1265|1406 neg_probe=3ef4fb1e418e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0060_it, t2_tc_16_reg_0060_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0060_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0060_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0060_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0060_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0060_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0060_it (target) VALUES ('');
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_16_reg_0060_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0060_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0060_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0060_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0060_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0060_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0060_it (target) VALUES ('');
-- Oracle table: BINARY(254)
CREATE TABLE t2_tc_16_reg_0060_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0060_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0060_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0060_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0060_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0060_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0060_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0060_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0060_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0060_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0060_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0060_it (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0060_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0060_it);
-- probe 1/1 -> t1_tc_16_reg_0060_it
INSERT INTO t1_tc_16_reg_0060_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0060_it
INSERT INTO t2_tc_16_reg_0060_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0060-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0060_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0060_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0060_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0060_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0060-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0060_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0060_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0060_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0060_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0060_it a JOIN t2_tc_16_reg_0060_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0060-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(254)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(254) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0060_it' AND column_name='target';

-- Test Case: TC-16-REG-0061-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=e9efabac80c6 column_type=binary(255) neg_probe=18705563d1bd=167|1264|1265|1406 neg_probe=dcf4ba4a440c=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0061_it, t2_tc_16_reg_0061_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0061_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0061_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0061_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0061_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0061_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0061_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0061_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0061_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0061_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0061_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0061_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0061_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0061_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0061_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0061_it (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0061_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0061_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0061_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0061_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0061_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0061_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0061_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0061_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0061_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0061_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0061_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0061_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0061_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0061_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0061_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0061_it);
-- probe 1/1 -> t1_tc_16_reg_0061_it
INSERT INTO t1_tc_16_reg_0061_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0061_it
INSERT INTO t2_tc_16_reg_0061_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0061-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0061_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0061_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0061_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0061_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0061-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0061_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0061_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0061_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0061_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0061_it a JOIN t2_tc_16_reg_0061_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0061-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0061_it' AND column_name='target';

-- Test Case: TC-16-REG-0062-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=6c379b07b30e column_type=binary(255) neg_probe=da278b18db37=167|1264|1265|1406 neg_probe=642a40ad5254=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0062_it, t2_tc_16_reg_0062_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0062_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0062_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0062_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0062_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0062_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0062_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0062_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0062_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0062_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0062_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0062_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0062_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0062_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0062_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0062_it (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0062_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0062_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0062_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0062_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0062_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0062_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0062_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0062_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0062_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0062_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0062_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0062_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0062_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0062_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0062_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0062_it);
-- probe 1/1 -> t1_tc_16_reg_0062_it
INSERT INTO t1_tc_16_reg_0062_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0062_it
INSERT INTO t2_tc_16_reg_0062_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0062-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0062_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0062_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0062_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0062_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0062-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0062_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0062_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0062_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0062_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0062_it a JOIN t2_tc_16_reg_0062_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0062-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0062_it' AND column_name='target';

-- Test Case: TC-16-REG-0063-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=deeaae9d160c column_type=binary(255) neg_probe=546c155dcdb2=167|1264|1265|1406 neg_probe=b59fe52a7d76=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0063_it, t2_tc_16_reg_0063_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0063_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0063_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0063_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0063_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0063_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0063_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0063_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0063_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0063_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0063_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0063_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0063_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0063_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0063_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0063_it (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0063_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0063_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0063_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0063_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0063_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0063_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0063_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0063_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0063_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0063_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0063_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0063_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0063_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0063_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0063_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0063_it);
-- probe 1/1 -> t1_tc_16_reg_0063_it
INSERT INTO t1_tc_16_reg_0063_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0063_it
INSERT INTO t2_tc_16_reg_0063_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0063-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0063_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0063_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0063_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0063_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0063-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0063_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0063_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0063_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0063_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0063_it a JOIN t2_tc_16_reg_0063_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0063-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0063_it' AND column_name='target';

-- Test Case: TC-16-REG-0064-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=173a9154cb03 column_type=binary(255) neg_probe=316d4d61256f=167|1264|1265|1406 neg_probe=1612bc71160e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0064_it, t2_tc_16_reg_0064_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0064_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0064_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0064_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0064_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0064_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0064_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0064_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0064_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0064_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0064_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0064_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0064_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0064_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0064_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0064_it (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0064_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0064_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0064_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0064_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0064_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0064_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0064_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0064_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0064_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0064_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0064_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0064_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0064_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0064_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0064_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0064_it);
-- probe 1/1 -> t1_tc_16_reg_0064_it
INSERT INTO t1_tc_16_reg_0064_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0064_it
INSERT INTO t2_tc_16_reg_0064_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0064-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0064_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0064_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0064_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0064_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0064-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0064_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0064_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0064_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0064_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0064_it a JOIN t2_tc_16_reg_0064_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0064-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0064_it' AND column_name='target';

-- Test Case: TC-16-REG-0065-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=a3d459c3dde1 column_type=binary(255) neg_probe=09b1da121cc4=167|1264|1265|1406 neg_probe=707580b84144=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0065_it, t2_tc_16_reg_0065_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0065_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0065_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0065_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0065_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0065_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0065_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0065_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0065_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0065_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0065_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0065_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0065_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0065_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0065_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0065_it (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0065_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0065_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0065_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0065_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0065_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0065_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0065_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0065_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0065_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0065_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0065_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0065_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0065_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0065_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0065_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0065_it);
-- probe 1/1 -> t1_tc_16_reg_0065_it
INSERT INTO t1_tc_16_reg_0065_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0065_it
INSERT INTO t2_tc_16_reg_0065_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0065-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0065_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0065_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0065_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0065_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0065-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0065_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0065_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0065_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0065_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0065_it a JOIN t2_tc_16_reg_0065_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0065-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0065_it' AND column_name='target';

-- Test Case: TC-16-REG-0066-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=415bdd8d1b17 column_type=binary(255) neg_probe=a729f2007dc1=167|1264|1265|1406 neg_probe=d3105bf59d3d=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0066_it, t2_tc_16_reg_0066_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0066_it (
  target BINARY(254),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0066_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0066_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0066_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0066_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0066_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0066_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0066_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0066_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0066_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0066_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0066_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0066_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0066_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0066_it (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0066_it (
  target BINARY(255),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0066_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0066_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0066_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0066_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0066_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0066_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0066_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0066_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0066_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0066_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0066_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0066_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0066_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0066_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0066_it);
-- probe 1/1 -> t1_tc_16_reg_0066_it
INSERT INTO t1_tc_16_reg_0066_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0066_it
INSERT INTO t2_tc_16_reg_0066_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0066-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0066_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0066_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0066_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0066_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0066-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0066_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0066_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0066_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0066_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0066_it a JOIN t2_tc_16_reg_0066_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0066-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0066_it' AND column_name='target';

-- Test Case: TC-16-REG-0067-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=b40b25e296ca column_type=binary(255) neg_probe=b7320bf6ccf4=167|1264|1265|1406 neg_probe=e4516b983329=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0067_it, t2_tc_16_reg_0067_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0067_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BINARY(254), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0067_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0067_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0067_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0067_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0067_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0067_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0067_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0067_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0067_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0067_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0067_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0067_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0067_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0067_it (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0067_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BINARY(255), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0067_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0067_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0067_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0067_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0067_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0067_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0067_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0067_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0067_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0067_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0067_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0067_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0067_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0067_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0067_it);
-- probe 1/1 -> t1_tc_16_reg_0067_it
INSERT INTO t1_tc_16_reg_0067_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0067_it
INSERT INTO t2_tc_16_reg_0067_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0067-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0067_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0067_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0067_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0067_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0067-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0067_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0067_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0067_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0067_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0067_it a JOIN t2_tc_16_reg_0067_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0067-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=4,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=4]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0067_it' AND column_name='target';

-- Test Case: TC-16-REG-0068-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=68041c5cec5d column_type=binary(255) neg_probe=9590c9cd2ffe=167|1264|1265|1406 neg_probe=086cd5cd7b4b=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0068_it, t2_tc_16_reg_0068_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0068_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0068_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0068_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0068_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0068_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0068_it (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0068_it MODIFY target BINARY(255) NOT NULL, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0068_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0068_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0068_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0068_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0068_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0068_it (target) VALUES ('');
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0068_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0068_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0068_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0068_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0068_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0068_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0068_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0068_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0068_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0068_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0068_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0068_it (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0068_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0068_it);
-- probe 1/1 -> t1_tc_16_reg_0068_it
INSERT INTO t1_tc_16_reg_0068_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0068_it
INSERT INTO t2_tc_16_reg_0068_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0068-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0068_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0068_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0068_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0068_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0068-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0068_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0068_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0068_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0068_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0068_it a JOIN t2_tc_16_reg_0068_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0068-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0068_it' AND column_name='target';

-- Test Case: TC-16-REG-0069-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=59f4117bf405 column_type=binary(255) neg_probe=c941deb12d9d=167|1264|1265|1406 neg_probe=6b3168c03927=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0069_it, t2_tc_16_reg_0069_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0069_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254) DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0069_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0069_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0069_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0069_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0069_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0069_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0069_it MODIFY target BINARY(255) DEFAULT 0x00, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0069_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0069_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0069_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0069_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0069_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0069_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0069_it (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0069_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255) DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0069_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0069_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0069_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0069_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0069_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0069_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0069_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0069_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0069_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0069_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0069_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0069_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0069_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0069_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0069_it);
-- probe 1/1 -> t1_tc_16_reg_0069_it
INSERT INTO t1_tc_16_reg_0069_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0069_it
INSERT INTO t2_tc_16_reg_0069_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0069-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0069_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0069_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0069_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0069_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0069-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0069_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0069_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0069_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0069_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0069_it a JOIN t2_tc_16_reg_0069_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0069-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0069_it' AND column_name='target';

-- Test Case: TC-16-REG-0070-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=5743fba3fe91 column_type=binary(255) neg_probe=9b603e1243c1=167|1264|1265|1406 neg_probe=7774eb3346ee=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0070_it, t2_tc_16_reg_0070_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0070_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0070_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0070_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0070_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0070_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0070_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0070_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0070_it MODIFY target BINARY(255) DEFAULT NULL, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0070_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0070_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0070_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0070_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0070_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0070_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0070_it (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0070_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0070_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0070_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0070_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0070_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0070_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0070_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0070_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0070_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0070_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0070_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0070_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0070_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0070_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0070_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0070_it);
-- probe 1/1 -> t1_tc_16_reg_0070_it
INSERT INTO t1_tc_16_reg_0070_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0070_it
INSERT INTO t2_tc_16_reg_0070_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0070-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0070_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0070_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0070_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0070_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0070-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0070_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0070_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0070_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0070_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0070_it a JOIN t2_tc_16_reg_0070_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0070-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0070_it' AND column_name='target';

-- Test Case: TC-16-REG-0071-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=70ab2e33123a column_type=binary(255) neg_probe=071b29733751=167|1264|1265|1406 neg_probe=c1beb914b468=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0071_it, t2_tc_16_reg_0071_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0071_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0071_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0071_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0071_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0071_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0071_it (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0071_it MODIFY target BINARY(255) NOT NULL DEFAULT 0x00, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0071_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0071_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0071_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0071_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0071_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0071_it (target) VALUES ('');
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0071_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0071_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0071_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0071_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0071_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0071_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0071_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0071_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0071_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0071_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0071_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0071_it (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0071_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0071_it);
-- probe 1/1 -> t1_tc_16_reg_0071_it
INSERT INTO t1_tc_16_reg_0071_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0071_it
INSERT INTO t2_tc_16_reg_0071_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0071-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0071_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0071_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0071_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0071_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0071-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0071_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0071_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0071_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0071_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0071_it a JOIN t2_tc_16_reg_0071_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0071-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=NO has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0071_it' AND column_name='target';

-- Test Case: TC-16-REG-0072-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=cb22b76ba18a column_type=binary(255) neg_probe=767c59f06835=167|1264|1265|1406 neg_probe=c8eb4f277b27=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0072_it, t2_tc_16_reg_0072_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0072_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0072_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0072_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0072_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0072_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0072_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0072_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0072_it MODIFY target BINARY(255) INVISIBLE, ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0072_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0072_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0072_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0072_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0072_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0072_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0072_it (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0072_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0072_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0072_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0072_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0072_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0072_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0072_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0072_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0072_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0072_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0072_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0072_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0072_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0072_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0072_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0072_it);
-- probe 1/1 -> t1_tc_16_reg_0072_it
INSERT INTO t1_tc_16_reg_0072_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0072_it
INSERT INTO t2_tc_16_reg_0072_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0072-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0072_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0072_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0072_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0072_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0072-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0072_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0072_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0072_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0072_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0072_it a JOIN t2_tc_16_reg_0072_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0072-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> 'INVISIBLE')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra=INVISIBLE pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0072_it' AND column_name='target';

-- Test Case: TC-16-REG-0073-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=491a5fde1620 column_type=binary(255) neg_probe=640098058716=167|1264|1265|1406 neg_probe=2cce87f4392b=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0073_it, t2_tc_16_reg_0073_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0073_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0073_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0073_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0073_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0073_it);
-- probe 1/1 -> t1_tc_16_reg_0073_it
INSERT INTO t1_tc_16_reg_0073_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0073_it
INSERT INTO t2_tc_16_reg_0073_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0073-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0073_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0073_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0073_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0073_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0073-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0073_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0073_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0073_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0073_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0073_it a JOIN t2_tc_16_reg_0073_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0073-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0073_it' AND column_name='target';

-- Test Case: TC-16-REG-0074-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=40410bdfa573 column_type=binary(255) neg_probe=7638c878f77b=167|1264|1265|1406 neg_probe=133c803f043e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0074_it, t2_tc_16_reg_0074_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0074_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0074_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0074_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0074_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0074_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0074_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0074_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0074_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0074_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0074_it (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0074_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0074_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0074_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0074_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0074_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0074_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0074_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0074_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0074_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0074_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0074_it);
-- probe 1/1 -> t1_tc_16_reg_0074_it
INSERT INTO t1_tc_16_reg_0074_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0074_it
INSERT INTO t2_tc_16_reg_0074_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0074-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0074_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0074_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0074_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0074_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0074-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0074_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0074_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0074_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0074_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0074_it a JOIN t2_tc_16_reg_0074_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0074-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0074_it' AND column_name='target';

-- Test Case: TC-16-REG-0075-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: BIN-03
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=41e8ff04f02b column_type=binary(255) neg_probe=09db7dda0d89=167|1264|1265|1406 neg_probe=cc7334fc0c6e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0075_it, t2_tc_16_reg_0075_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0075_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0075_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0075_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0075_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0075_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0075_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0075_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0075_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0075_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0075_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0075_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0075_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0075_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0075_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0075_it (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0075_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0075_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0075_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0075_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0075_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0075_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0075_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0075_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0075_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0075_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0075_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0075_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0075_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0075_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0075_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0075_it);
-- probe 1/1 -> t1_tc_16_reg_0075_it
INSERT INTO t1_tc_16_reg_0075_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0075_it
INSERT INTO t2_tc_16_reg_0075_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0075-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0075_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0075_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0075_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0075_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0075-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0075_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0075_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0075_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0075_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0075_it a JOIN t2_tc_16_reg_0075_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0075-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0075_it' AND column_name='target';

-- Test Case: TC-16-REG-0076-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: BIN-03
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=6d0f56926836 column_type=binary(255) neg_probe=5aaa528b85dd=167|1264|1265|1406 neg_probe=1e687b6d98ea=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0076_it, t2_tc_16_reg_0076_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0076_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0076_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0076_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0076_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0076_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0076_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0076_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0076_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0076_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0076_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0076_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0076_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0076_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0076_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0076_it (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0076_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0076_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0076_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0076_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0076_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0076_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0076_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0076_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0076_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0076_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0076_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0076_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0076_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0076_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0076_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0076_it);
-- probe 1/1 -> t1_tc_16_reg_0076_it
INSERT INTO t1_tc_16_reg_0076_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0076_it
INSERT INTO t2_tc_16_reg_0076_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0076-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0076_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0076_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0076_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0076_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0076-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0076_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0076_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0076_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0076_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0076_it a JOIN t2_tc_16_reg_0076_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0076-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0076_it' AND column_name='target';

-- Test Case: TC-16-REG-0077-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=b49338db4ba6 column_type=binary(255) neg_probe=782e21f1958c=167|1264|1265|1406 neg_probe=b503dd134128=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0077_it, t2_tc_16_reg_0077_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0077_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0077_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0077_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0077_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0077_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0077_it (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0077_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0077_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0077_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0077_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0077_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0077_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0077_it (target) VALUES ('');
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0077_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0077_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0077_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0077_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0077_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0077_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0077_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0077_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0077_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0077_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0077_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0077_it (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0077_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0077_it);
-- probe 1/1 -> t1_tc_16_reg_0077_it
INSERT INTO t1_tc_16_reg_0077_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0077_it
INSERT INTO t2_tc_16_reg_0077_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0077-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0077_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0077_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0077_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0077_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0077-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0077_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0077_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0077_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0077_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0077_it a JOIN t2_tc_16_reg_0077_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0077-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0077_it' AND column_name='target';

-- Test Case: TC-16-REG-0078-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=15a0da898fe6 column_type=binary(255) neg_probe=ed63ce616fdb=167|1264|1265|1406 neg_probe=495c746f97c6=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0078_it, t2_tc_16_reg_0078_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0078_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0078_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0078_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0078_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0078_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0078_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0078_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0078_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0078_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0078_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0078_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0078_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0078_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0078_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0078_it (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0078_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0078_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0078_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0078_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0078_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0078_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0078_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0078_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0078_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0078_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0078_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0078_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0078_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0078_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0078_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0078_it);
-- probe 1/1 -> t1_tc_16_reg_0078_it
INSERT INTO t1_tc_16_reg_0078_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0078_it
INSERT INTO t2_tc_16_reg_0078_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0078-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0078_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0078_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0078_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0078_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0078-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0078_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0078_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0078_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0078_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0078_it a JOIN t2_tc_16_reg_0078_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0078-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0078_it' AND column_name='target';

-- Test Case: TC-16-REG-0079-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=afec94c0601e column_type=binary(255) neg_probe=7d039e88e5ac=167|1264|1265|1406 neg_probe=efa9e5519c70=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0079_it, t2_tc_16_reg_0079_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0079_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0079_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0079_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0079_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0079_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0079_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0079_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0079_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0079_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0079_it (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0079_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0079_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0079_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0079_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0079_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0079_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0079_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0079_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0079_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0079_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0079_it);
-- probe 1/1 -> t1_tc_16_reg_0079_it
INSERT INTO t1_tc_16_reg_0079_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0079_it
INSERT INTO t2_tc_16_reg_0079_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0079-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0079_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0079_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0079_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0079_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0079-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0079_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0079_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0079_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0079_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0079_it a JOIN t2_tc_16_reg_0079_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0079-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0079_it' AND column_name='target';

-- Test Case: TC-16-REG-0080-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=ee2050b26e02 column_type=binary(255) neg_probe=b261b0306259=ACCEPTED neg_probe=f43c4f248820=ACCEPTED
DROP TABLE IF EXISTS t1_tc_16_reg_0080_it, t2_tc_16_reg_0080_it;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_16_reg_0080_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0080_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0080_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0080_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0080_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0080_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0080_it (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0080_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0080_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0080_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0080_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0080_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0080_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0080_it (target) VALUES ('');
INSERT INTO t1_tc_16_reg_0080_it (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0080_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0080_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0080_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0080_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0080_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0080_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0080_it (target) VALUES (NULL);
INSERT INTO t2_tc_16_reg_0080_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0080_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0080_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0080_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0080_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0080_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0080_it (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0080_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0080_it);
-- probe 1/1 -> t1_tc_16_reg_0080_it
INSERT INTO t1_tc_16_reg_0080_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0080_it
INSERT INTO t2_tc_16_reg_0080_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0080-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0080_it) - @neg_before_t1 = (SELECT COUNT(*) FROM t2_tc_16_reg_0080_it) - @neg_before_t2,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0080_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0080_it) - @neg_before_t2,' expect=t1_added = t2_added (非 STRICT: 截断行为必须与对照表一致) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0080-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0080_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0080_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0080_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0080_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0080_it a JOIN t2_tc_16_reg_0080_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0080-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0080_it' AND column_name='target';

-- Test Case: TC-16-REG-0081-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=b2a4fc26c31f column_type=binary(255) neg_probe=fa3629192dd6=167|1264|1265|1406 neg_probe=ed933c2acf35=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0081_it, t2_tc_16_reg_0081_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0081_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0081_it MODIFY target BINARY(255) NOT NULL, ALGORITHM=instant;
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0081_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0081_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0081_it);
-- probe 1/1 -> t1_tc_16_reg_0081_it
INSERT INTO t1_tc_16_reg_0081_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0081_it
INSERT INTO t2_tc_16_reg_0081_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0081-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0081_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0081_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0081_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0081_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0081-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0081_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0081_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0081_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0081_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0081_it a JOIN t2_tc_16_reg_0081_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0081-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0081_it' AND column_name='target';

-- Test Case: TC-16-REG-0082-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: BIN-03
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=016d0de6ee3e column_type=binary(255) neg_probe=86351e288c7b=167|1264|1265|1406 neg_probe=9812846bcccd=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0082_it, t2_tc_16_reg_0082_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0082_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0082_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0082_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0082_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0082_it);
-- probe 1/1 -> t1_tc_16_reg_0082_it
INSERT INTO t1_tc_16_reg_0082_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0082_it
INSERT INTO t2_tc_16_reg_0082_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0082-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0082_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0082_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0082_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0082_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0082-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0082_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0082_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0082_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0082_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0082_it a JOIN t2_tc_16_reg_0082_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0082-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0082_it' AND column_name='target';

-- Test Case: TC-16-REG-0083-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=d0ddfc4bd540 column_type=binary(255) neg_probe=b1a17124bb05=167|1264|1265|1406 neg_probe=45a9bce197a9=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0083_it, t2_tc_16_reg_0083_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0083_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_reg_0083_it MODIFY target BINARY(255) NOT NULL DEFAULT 0x00, ALGORITHM=instant;
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_16_reg_0083_it (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0083_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0083_it);
-- probe 1/1 -> t1_tc_16_reg_0083_it
INSERT INTO t1_tc_16_reg_0083_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0083_it
INSERT INTO t2_tc_16_reg_0083_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0083-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0083_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0083_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0083_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0083_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0083-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0083_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0083_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0083_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0083_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0083_it a JOIN t2_tc_16_reg_0083_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0083-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=NO has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0083_it' AND column_name='target';

-- Test Case: TC-16-REG-0084-IT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant, Expected: FAIL
-- Varied factor: KP-05
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=FAIL build=SUCCESS assertions=3 neg_probes=1 alter_sha=71054a2c4e69 errno=[1845,1846,1659,3780] column_type=binary(254) neg_probe=ca74b1f4d0cc=167|1264|1265|1406 neg_probe=872dcb4e2801=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_16_reg_0084_it, t2_tc_16_reg_0084_it;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_16_reg_0084_it (
  target BINARY(254),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_16_reg_0084_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0084_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0084_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0084_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_reg_0084_it (target) VALUES ('');
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_16_reg_0084_it MODIFY target BINARY(255), ALGORITHM=instant;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0084_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0084_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_16_reg_0084_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_16_reg_0084_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_reg_0084_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_reg_0084_it (target) VALUES ('');
-- Oracle table: BINARY(254)
CREATE TABLE t2_tc_16_reg_0084_it (
  target BINARY(254),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_16_reg_0084_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0084_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0084_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0084_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_16_reg_0084_it (target) VALUES ('');
INSERT INTO t2_tc_16_reg_0084_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0084_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0084_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_16_reg_0084_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_16_reg_0084_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_16_reg_0084_it (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_16_reg_0084_it);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_16_reg_0084_it);
-- probe 1/1 -> t1_tc_16_reg_0084_it
INSERT INTO t1_tc_16_reg_0084_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_16_reg_0084_it
INSERT INTO t2_tc_16_reg_0084_it (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-16-REG-0084-IT#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_16_reg_0084_it) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_16_reg_0084_it) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_16_reg_0084_it) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_16_reg_0084_it) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-16-REG-0084-IT' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_16_reg_0084_it
   WHERE id NOT IN (SELECT id FROM t2_tc_16_reg_0084_it)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_16_reg_0084_it
   WHERE id NOT IN (SELECT id FROM t1_tc_16_reg_0084_it)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_16_reg_0084_it a JOIN t2_tc_16_reg_0084_it b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-16-REG-0084-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(254)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(254) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_reg_0084_it' AND column_name='target';

-- Test Case: TC-16-ATR-0003-IT
-- Column attribute preservation: COMMENT
-- Type: BINARY(254) -> BINARY(255), Algorithm: instant
-- Transition ID: BIN-03
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=ab63df6d592c column_type=binary(255)
DROP TABLE IF EXISTS t1_tc_16_atr_0003_it, t2_tc_16_atr_0003_it;
CREATE TABLE t1_tc_16_atr_0003_it (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target BINARY(254) COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB;
INSERT INTO t1_tc_16_atr_0003_it (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_atr_0003_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_atr_0003_it (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_atr_0003_it (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_16_atr_0003_it (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_16_atr_0003_it MODIFY target BINARY(255) COMMENT 'test_comment', ALGORITHM=instant;
INSERT INTO t1_tc_16_atr_0003_it (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_16_atr_0003_it (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_16_atr_0003_it (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
SELECT 'TC-16-ATR-0003-IT' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_16_atr_0003_it' AND column_name='target' AND column_comment='test_comment';
SELECT 'TC-16-ATR-0003-IT#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_16_atr_0003_it' AND column_name='target';

