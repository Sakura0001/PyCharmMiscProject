-- ============================================================
-- RDS MySQL DDL 秒级/在线修改列类型 测试套件 — 内网环境
-- 环境说明: 所有功能开关默认开启
-- 覆盖类型: BINARY + VARBINARY + DECIMAL + TEXT + BLOB + BIT
-- 覆盖算法: INSTANT + INPLACE (增强类型 INSTANT 预期成功: BINARY/VARBINARY/DECIMAL 已确认支持)
-- ============================================================
-- 本文件由 generate_test_sql.py 自动生成, 请勿手动修改
-- Suite-Revision: 77acedf440f2   (生成器源码哈希; 时间戳见 results/generation_manifest.json)
-- 用例 ID 规则: TC-<文件号>-<作用域>-<序号>-<IT|IP>  —— 全局唯一
--   作用域 REG=普通表 OFAT/二元组, ATR=列属性保持, SPE=特殊模式,
--          FK=外键, PTK=分区(目标列是分区键), PNK=分区(目标列非分区键)
-- ============================================================

SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
SET SESSION innodb_lock_wait_timeout = 50;

-- File 26: BIT INPLACE

-- Test Case: TC-26-REG-0001-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0001_ip, t2_tc_26_reg_0001_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0001_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0001_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0001_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0001_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0001_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0001_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0001_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0001_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0001_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0001_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0001_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0001_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0001_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0001_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0001_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0001_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0001_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0001_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0001_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0001_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0001_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0001_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0001_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0001_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0001_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0001_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0001_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0001-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0001_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0001_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0001_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0001_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0001_ip a JOIN t2_tc_26_reg_0001_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0002-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0002_ip, t2_tc_26_reg_0002_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0002_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t1_tc_26_reg_0002_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0002_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0002_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0002_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0002_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0002_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0002_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0002_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0002_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0002_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0002_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0002_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0002_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0002_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t2_tc_26_reg_0002_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0002_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0002_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0002_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0002_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0002_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0002_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0002_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0002_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0002_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0002_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0002_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0002-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0002_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0002_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0002_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0002_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0002_ip a JOIN t2_tc_26_reg_0002_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0003-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0003_ip, t2_tc_26_reg_0003_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0003_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t1_tc_26_reg_0003_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0003_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0003_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0003_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0003_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0003_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0003_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0003_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0003_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0003_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0003_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0003_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0003_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0003_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t2_tc_26_reg_0003_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0003_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0003_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0003_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0003_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0003_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0003_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0003_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0003_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0003_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0003_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0003_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0003-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0003_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0003_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0003_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0003_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0003_ip a JOIN t2_tc_26_reg_0003_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0004-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0004_ip, t2_tc_26_reg_0004_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0004_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0004_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0004_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0004_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0004_ip (target) VALUES (b'0');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0004_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0004_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0004_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0004_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0004_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0004_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0004_ip (target) VALUES (b'1010');
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0004_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0004_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0004_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0004_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0004_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0004_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0004_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0004_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0004_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0004_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0004_ip (target) VALUES (b'1010');
SELECT 'TC-26-REG-0004-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0004_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0004_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0004_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0004_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0004_ip a JOIN t2_tc_26_reg_0004_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0005-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0005_ip, t2_tc_26_reg_0005_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0005_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0005_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0005_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0005_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0005_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0005_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0005_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0005_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0005_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0005_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0005_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0005_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0005_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0005_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0005_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0005_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0005_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0005_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0005_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0005_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0005_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0005_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0005_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0005_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0005_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0005_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0005_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0005-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0005_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0005_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0005_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0005_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0005_ip a JOIN t2_tc_26_reg_0005_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0006-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0006_ip, t2_tc_26_reg_0006_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0006_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0006_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0006_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0006_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0006_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0006_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0006_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0006_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0006_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0006_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0006_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0006_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0006_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0006_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0006_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0006_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0006_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0006_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0006_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0006_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0006_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0006_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0006_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0006_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0006_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0006_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0006_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0006-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0006_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0006_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0006_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0006_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0006_ip a JOIN t2_tc_26_reg_0006_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0007-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0007_ip, t2_tc_26_reg_0007_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0007_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0007_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0007_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0007_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0007_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0007_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0007_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0007_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0007_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0007_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0007_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0007_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0007_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0007_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0007_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0007_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0007_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0007_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0007_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0007_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0007_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0007_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0007_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0007_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0007_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0007_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0007_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0007-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0007_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0007_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0007_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0007_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0007_ip a JOIN t2_tc_26_reg_0007_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0008-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0008_ip, t2_tc_26_reg_0008_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0008_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0008_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0008_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0008_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0008_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0008_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0008_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0008_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0008_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0008_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0008_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0008_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0008_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0008_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0008_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0008_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0008_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0008_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0008_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0008_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0008_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0008_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0008_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0008_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0008_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0008_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0008_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0008-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0008_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0008_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0008_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0008_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0008_ip a JOIN t2_tc_26_reg_0008_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0009-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0009_ip, t2_tc_26_reg_0009_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0009_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0009_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0009_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0009_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0009_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0009_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0009_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0009_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0009_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0009_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0009_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0009_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0009_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0009_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0009_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0009_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0009_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0009_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0009_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0009_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0009_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0009_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0009_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0009_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0009_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0009_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0009_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0009-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0009_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0009_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0009_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0009_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0009_ip a JOIN t2_tc_26_reg_0009_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0010-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
DROP TABLE IF EXISTS t1_tc_26_reg_0010_ip, t2_tc_26_reg_0010_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0010_ip (
  target BIT(1),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0010_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0010_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0010_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0010_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0010_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0010_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0010_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0010_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0010_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0010_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0010_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0010_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0010_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0010_ip (
  target BIT(8),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0010_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0010_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0010_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0010_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0010_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0010_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0010_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0010_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0010_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0010_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0010_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0010_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0010-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0010_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0010_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0010_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0010_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0010_ip a JOIN t2_tc_26_reg_0010_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0011-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
DROP TABLE IF EXISTS t1_tc_26_reg_0011_ip, t2_tc_26_reg_0011_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0011_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BIT(1), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0011_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0011_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0011_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0011_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0011_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0011_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0011_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0011_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0011_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0011_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0011_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0011_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0011_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0011_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BIT(8), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0011_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0011_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0011_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0011_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0011_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0011_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0011_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0011_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0011_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0011_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0011_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0011_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0011-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0011_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0011_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0011_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0011_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0011_ip a JOIN t2_tc_26_reg_0011_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0012-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0012_ip, t2_tc_26_reg_0012_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0012_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0012_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0012_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0012_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0012_ip (target) VALUES (b'0');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0012_ip MODIFY target BIT(8) NOT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0012_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0012_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0012_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0012_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0012_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0012_ip (target) VALUES (b'1010');
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0012_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0012_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0012_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0012_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0012_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0012_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0012_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0012_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0012_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0012_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0012_ip (target) VALUES (b'1010');
SELECT 'TC-26-REG-0012-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0012_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0012_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0012_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0012_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0012_ip a JOIN t2_tc_26_reg_0012_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0013-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0013_ip, t2_tc_26_reg_0013_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0013_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1) DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0013_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0013_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0013_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0013_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0013_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0013_ip MODIFY target BIT(8) DEFAULT b'0', ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0013_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0013_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0013_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0013_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0013_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0013_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0013_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0013_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0013_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0013_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0013_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0013_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0013_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0013_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0013_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0013_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0013_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0013_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0013_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0013_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0013-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0013_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0013_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0013_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0013_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0013_ip a JOIN t2_tc_26_reg_0013_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0014-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0014_ip, t2_tc_26_reg_0014_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0014_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0014_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0014_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0014_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0014_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0014_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0014_ip MODIFY target BIT(8) DEFAULT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0014_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0014_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0014_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0014_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0014_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0014_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0014_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0014_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0014_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0014_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0014_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0014_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0014_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0014_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0014_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0014_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0014_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0014_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0014_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0014_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0014-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0014_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0014_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0014_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0014_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0014_ip a JOIN t2_tc_26_reg_0014_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0015-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0015_ip, t2_tc_26_reg_0015_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0015_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0015_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0015_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0015_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0015_ip (target) VALUES (b'0');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0015_ip MODIFY target BIT(8) NOT NULL DEFAULT b'0', ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0015_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0015_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0015_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0015_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0015_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0015_ip (target) VALUES (b'1010');
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0015_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0015_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0015_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0015_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0015_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0015_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0015_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0015_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0015_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0015_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0015_ip (target) VALUES (b'1010');
SELECT 'TC-26-REG-0015-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0015_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0015_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0015_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0015_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0015_ip a JOIN t2_tc_26_reg_0015_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0016-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0016_ip, t2_tc_26_reg_0016_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0016_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0016_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0016_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0016_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0016_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0016_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0016_ip MODIFY target BIT(8) INVISIBLE, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0016_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0016_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0016_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0016_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0016_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0016_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0016_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0016_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0016_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0016_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0016_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0016_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0016_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0016_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0016_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0016_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0016_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0016_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0016_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0016_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0016-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0016_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0016_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0016_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0016_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0016_ip a JOIN t2_tc_26_reg_0016_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0017-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0017_ip, t2_tc_26_reg_0017_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0017_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0017_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0017_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-26-REG-0017-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0017_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0017_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0017_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0017_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0017_ip a JOIN t2_tc_26_reg_0017_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0018-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0018_ip, t2_tc_26_reg_0018_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0018_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0018_ip (target) VALUES (b'0');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0018_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0018_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0018_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0018_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0018_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0018_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0018_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0018_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0018_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0018_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0018_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0018_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0018_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0018_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0018_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0018_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0018_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0018-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0018_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0018_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0018_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0018_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0018_ip a JOIN t2_tc_26_reg_0018_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0019-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: BIT-01
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0019_ip, t2_tc_26_reg_0019_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0019_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0019_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0019_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0019_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0019_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0019_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0019_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0019_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0019_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0019_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0019_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0019_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0019_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0019_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0019_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0019_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0019_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0019_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0019_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0019_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0019_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0019_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0019_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0019_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0019_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0019_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0019_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0019-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0019_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0019_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0019_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0019_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0019_ip a JOIN t2_tc_26_reg_0019_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0020-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: BIT-01
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0020_ip, t2_tc_26_reg_0020_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0020_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0020_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0020_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0020_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0020_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0020_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0020_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0020_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0020_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0020_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0020_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0020_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0020_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0020_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0020_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0020_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0020_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0020_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0020_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0020_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0020_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0020_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0020_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0020_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0020_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0020_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0020_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0020-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0020_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0020_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0020_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0020_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0020_ip a JOIN t2_tc_26_reg_0020_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0021-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0021_ip, t2_tc_26_reg_0021_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0021_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0021_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0021_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0021_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0021_ip (target) VALUES (b'0');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0021_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0021_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0021_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0021_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0021_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0021_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0021_ip (target) VALUES (b'1010');
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0021_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0021_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0021_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0021_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0021_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0021_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0021_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0021_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0021_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0021_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0021_ip (target) VALUES (b'1010');
SELECT 'TC-26-REG-0021-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0021_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0021_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0021_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0021_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0021_ip a JOIN t2_tc_26_reg_0021_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0022-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0022_ip, t2_tc_26_reg_0022_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0022_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0022_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0022_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0022_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0022_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0022_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0022_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0022_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0022_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0022_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0022_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0022_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0022_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0022_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0022_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0022_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0022_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0022_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0022_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0022_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0022_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0022_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0022_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0022_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0022_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0022_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0022_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0022-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0022_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0022_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0022_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0022_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0022_ip a JOIN t2_tc_26_reg_0022_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0023-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0023_ip, t2_tc_26_reg_0023_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0023_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0023_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0023_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0023_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0023_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0023_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0023_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0023_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0023_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0023_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0023_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0023_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0023_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0023_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0023_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0023_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0023_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0023_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0023_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0023-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0023_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0023_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0023_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0023_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0023_ip a JOIN t2_tc_26_reg_0023_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0024-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=SECONDARY_INDEX
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=SECONDARY_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0024_ip, t2_tc_26_reg_0024_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0024_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0024_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0024_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0024_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0024_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0024_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0024_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0024_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0024_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0024_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0024_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0024_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0024_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0024_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0024_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0024_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0024_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0024_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0024_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0024_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0024_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0024_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0024_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0024_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0024_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0024_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0024_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0024-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0024_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0024_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0024_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0024_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0024_ip a JOIN t2_tc_26_reg_0024_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0025-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=UNIQUE_INDEX
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0025_ip, t2_tc_26_reg_0025_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0025_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0025_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0025_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0025_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0025_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0025_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0025_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0025_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0025_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0025_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0025_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0025_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0025_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0025_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0025_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0025_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0025_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0025_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0025_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0025_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0025_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0025_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0025_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0025_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0025_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0025_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0025_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0025-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0025_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0025_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0025_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0025_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0025_ip a JOIN t2_tc_26_reg_0025_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0026-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=FOREIGN_KEY
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=FOREIGN_KEY, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0026_ip, t2_tc_26_reg_0026_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0026_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0026_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0026_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0026_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0026_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0026_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0026_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0026_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0026_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0026_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0026_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0026_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0026_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0026_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0026_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0026_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0026_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0026_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0026_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0026_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0026_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0026_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0026_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0026_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0026_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0026_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0026_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0026-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0026_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0026_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0026_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0026_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0026_ip a JOIN t2_tc_26_reg_0026_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0027-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=CHECK
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=CHECK, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0027_ip, t2_tc_26_reg_0027_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0027_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0027_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0027_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0027_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0027_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0027_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0027_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0027_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0027_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0027_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0027_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0027_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0027_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0027_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0027_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0027_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0027_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0027_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0027_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0027_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0027_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0027_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0027_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0027_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0027_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0027_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0027_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0027-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0027_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0027_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0027_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0027_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0027_ip a JOIN t2_tc_26_reg_0027_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0028-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0028_ip, t2_tc_26_reg_0028_ip;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_26_reg_0028_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0028_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0028_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0028_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0028_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0028_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0028_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0028_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0028_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0028_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0028_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0028_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0028_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0028_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0028_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0028_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0028_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0028_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0028_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0028_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0028_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0028_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0028_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0028_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0028_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0028_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0028_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0028-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0028_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0028_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0028_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0028_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0028_ip a JOIN t2_tc_26_reg_0028_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0029-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0029_ip, t2_tc_26_reg_0029_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0029_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0029_ip MODIFY target BIT(8) NOT NULL, ALGORITHM=inplace;
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0029_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-26-REG-0029-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0029_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0029_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0029_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0029_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0029_ip a JOIN t2_tc_26_reg_0029_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0030-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-02
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0030_ip, t2_tc_26_reg_0030_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0030_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0030_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0030_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0030_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0030_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0030_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0030_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0030_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0030_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0030_ip (target) VALUES (NULL);
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0030_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0030_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0030_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0030_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0030_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0030_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0030_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0030_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0030_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0030-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0030_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0030_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0030_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0030_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0030_ip a JOIN t2_tc_26_reg_0030_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0031-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: BIT-01
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0031_ip, t2_tc_26_reg_0031_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0031_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0031_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0031_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-26-REG-0031-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0031_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0031_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0031_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0031_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0031_ip a JOIN t2_tc_26_reg_0031_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0032-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0032_ip, t2_tc_26_reg_0032_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0032_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(1) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0032_ip MODIFY target BIT(8) NOT NULL DEFAULT b'0', ALGORITHM=inplace;
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0032_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-26-REG-0032-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0032_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0032_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0032_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0032_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0032_ip a JOIN t2_tc_26_reg_0032_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0033-IP
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-05
-- Transition ID: BIT-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
DROP TABLE IF EXISTS t1_tc_26_reg_0033_ip, t2_tc_26_reg_0033_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0033_ip (
  target BIT(1),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0033_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0033_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0033_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0033_ip (target) VALUES (b'0');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0033_ip MODIFY target BIT(8), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0033_ip (target) VALUES (b'11111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0033_ip (target) VALUES (b'11');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0033_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0033_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0033_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0033_ip (target) VALUES (b'1010');
-- Oracle table: BIT(8)
CREATE TABLE t2_tc_26_reg_0033_ip (
  target BIT(8),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0033_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0033_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0033_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0033_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0033_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0033_ip (target) VALUES (b'11');
INSERT INTO t2_tc_26_reg_0033_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0033_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0033_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0033_ip (target) VALUES (b'1010');
SELECT 'TC-26-REG-0033-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0033_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0033_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0033_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0033_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0033_ip a JOIN t2_tc_26_reg_0033_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-ATR-0001-IP
-- Column attribute preservation: COMMENT
-- Type: BIT(1) -> BIT(8), Algorithm: inplace
DROP TABLE IF EXISTS t1_tc_26_atr_0001_ip, t2_tc_26_atr_0001_ip;
CREATE TABLE t1_tc_26_atr_0001_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target BIT(1) COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB;
INSERT INTO t1_tc_26_atr_0001_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_atr_0001_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_atr_0001_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_atr_0001_ip (target) VALUES (b'0');
ALTER TABLE t1_tc_26_atr_0001_ip MODIFY target BIT(8) COMMENT 'test_comment', ALGORITHM=inplace;
INSERT INTO t1_tc_26_atr_0001_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_atr_0001_ip (target) VALUES (b'11');
INSERT INTO t1_tc_26_atr_0001_ip (target) VALUES (b'1');
SELECT 'TC-26-ATR-0001-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_26_atr_0001_ip' AND column_name='target' AND column_comment='test_comment';

-- Test Case: TC-26-REG-0034-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0034_ip, t2_tc_26_reg_0034_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0034_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0034_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0034_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0034_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0034_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0034_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0034_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0034_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0034_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0034_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0034_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0034_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0034_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0034_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0034_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0034_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0034_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0034_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0034_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0034_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0034_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0034_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0034_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0034_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0034_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0034_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0034_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0034_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0034_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0034_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0034_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0034-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0034_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0034_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0034_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0034_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0034_ip a JOIN t2_tc_26_reg_0034_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0035-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0035_ip, t2_tc_26_reg_0035_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0035_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t1_tc_26_reg_0035_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0035_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0035_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0035_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0035_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0035_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0035_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0035_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0035_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0035_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0035_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0035_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0035_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0035_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0035_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0035_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t2_tc_26_reg_0035_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0035_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0035_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0035_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0035_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0035_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0035_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0035_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0035_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0035_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0035_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0035_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0035_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0035_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0035-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0035_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0035_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0035_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0035_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0035_ip a JOIN t2_tc_26_reg_0035_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0036-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0036_ip, t2_tc_26_reg_0036_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0036_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t1_tc_26_reg_0036_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0036_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0036_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0036_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0036_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0036_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0036_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0036_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0036_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0036_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0036_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0036_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0036_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0036_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0036_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0036_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t2_tc_26_reg_0036_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0036_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0036_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0036_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0036_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0036_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0036_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0036_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0036_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0036_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0036_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0036_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0036_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0036_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0036-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0036_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0036_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0036_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0036_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0036_ip a JOIN t2_tc_26_reg_0036_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0037-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0037_ip, t2_tc_26_reg_0037_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0037_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0037_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0037_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0037_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0037_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0037_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0037_ip (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0037_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0037_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0037_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0037_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0037_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0037_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0037_ip (target) VALUES (b'1010');
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0037_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0037_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0037_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0037_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0037_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0037_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0037_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0037_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0037_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0037_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0037_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0037_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0037_ip (target) VALUES (b'1010');
SELECT 'TC-26-REG-0037-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0037_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0037_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0037_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0037_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0037_ip a JOIN t2_tc_26_reg_0037_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0038-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0038_ip, t2_tc_26_reg_0038_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0038_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0038_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0038_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0038_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0038_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0038_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0038_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0038_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0038_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0038_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0038_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0038_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0038_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0038_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0038_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0038_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0038_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0038_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0038_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0038_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0038_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0038_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0038_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0038_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0038_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0038_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0038_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0038_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0038_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0038_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0038_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0038-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0038_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0038_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0038_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0038_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0038_ip a JOIN t2_tc_26_reg_0038_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0039-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0039_ip, t2_tc_26_reg_0039_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0039_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0039_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0039_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0039_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0039_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0039_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0039_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0039_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0039_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0039_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0039_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0039_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0039_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0039_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0039_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0039_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0039_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0039_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0039_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0039_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0039_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0039_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0039_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0039_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0039_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0039_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0039_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0039_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0039_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0039_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0039_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0039-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0039_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0039_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0039_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0039_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0039_ip a JOIN t2_tc_26_reg_0039_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0040-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0040_ip, t2_tc_26_reg_0040_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0040_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0040_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0040_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0040_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0040_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0040_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0040_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0040_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0040_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0040_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0040_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0040_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0040_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0040_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0040_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0040_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0040_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0040_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0040_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0040_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0040_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0040_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0040_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0040_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0040_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0040_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0040_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0040_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0040_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0040_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0040_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0040-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0040_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0040_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0040_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0040_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0040_ip a JOIN t2_tc_26_reg_0040_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0041-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0041_ip, t2_tc_26_reg_0041_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0041_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0041_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0041_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0041_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0041_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0041_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0041_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0041_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0041_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0041_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0041_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0041_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0041_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0041_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0041_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0041_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0041_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0041_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0041_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0041_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0041_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0041_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0041_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0041_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0041_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0041_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0041_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0041_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0041_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0041_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0041_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0041-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0041_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0041_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0041_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0041_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0041_ip a JOIN t2_tc_26_reg_0041_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0042-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0042_ip, t2_tc_26_reg_0042_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0042_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0042_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0042_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0042_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0042_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0042_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0042_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0042_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0042_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0042_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0042_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0042_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0042_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0042_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0042_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0042_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0042_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0042_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0042_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0042_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0042_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0042_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0042_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0042_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0042_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0042_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0042_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0042_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0042_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0042_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0042_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0042-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0042_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0042_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0042_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0042_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0042_ip a JOIN t2_tc_26_reg_0042_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0043-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
DROP TABLE IF EXISTS t1_tc_26_reg_0043_ip, t2_tc_26_reg_0043_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0043_ip (
  target BIT(8),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0043_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0043_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0043_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0043_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0043_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0043_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0043_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0043_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0043_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0043_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0043_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0043_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0043_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0043_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0043_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0043_ip (
  target BIT(16),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0043_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0043_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0043_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0043_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0043_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0043_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0043_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0043_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0043_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0043_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0043_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0043_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0043_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0043_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0043-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0043_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0043_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0043_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0043_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0043_ip a JOIN t2_tc_26_reg_0043_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0044-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
DROP TABLE IF EXISTS t1_tc_26_reg_0044_ip, t2_tc_26_reg_0044_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0044_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BIT(8), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0044_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0044_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0044_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0044_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0044_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0044_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0044_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0044_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0044_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0044_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0044_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0044_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0044_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0044_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0044_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0044_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BIT(16), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0044_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0044_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0044_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0044_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0044_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0044_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0044_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0044_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0044_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0044_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0044_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0044_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0044_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0044_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0044-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0044_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0044_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0044_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0044_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0044_ip a JOIN t2_tc_26_reg_0044_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0045-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0045_ip, t2_tc_26_reg_0045_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0045_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0045_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0045_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0045_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0045_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0045_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0045_ip (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0045_ip MODIFY target BIT(16) NOT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0045_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0045_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0045_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0045_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0045_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0045_ip (target) VALUES (b'1010');
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0045_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0045_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0045_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0045_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0045_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0045_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0045_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0045_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0045_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0045_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0045_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0045_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0045_ip (target) VALUES (b'1010');
SELECT 'TC-26-REG-0045-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0045_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0045_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0045_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0045_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0045_ip a JOIN t2_tc_26_reg_0045_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0046-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0046_ip, t2_tc_26_reg_0046_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0046_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0046_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0046_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0046_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0046_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0046_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0046_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0046_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0046_ip MODIFY target BIT(16) DEFAULT b'0', ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0046_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0046_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0046_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0046_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0046_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0046_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0046_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0046_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0046_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0046_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0046_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0046_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0046_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0046_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0046_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0046_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0046_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0046_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0046_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0046_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0046_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0046_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0046-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0046_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0046_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0046_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0046_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0046_ip a JOIN t2_tc_26_reg_0046_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0047-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0047_ip, t2_tc_26_reg_0047_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0047_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0047_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0047_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0047_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0047_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0047_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0047_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0047_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0047_ip MODIFY target BIT(16) DEFAULT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0047_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0047_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0047_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0047_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0047_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0047_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0047_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0047_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0047_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0047_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0047_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0047_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0047_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0047_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0047_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0047_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0047_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0047_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0047_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0047_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0047_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0047_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0047-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0047_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0047_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0047_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0047_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0047_ip a JOIN t2_tc_26_reg_0047_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0048-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0048_ip, t2_tc_26_reg_0048_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0048_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0048_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0048_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0048_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0048_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0048_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0048_ip (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0048_ip MODIFY target BIT(16) NOT NULL DEFAULT b'0', ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0048_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0048_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0048_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0048_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0048_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0048_ip (target) VALUES (b'1010');
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0048_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0048_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0048_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0048_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0048_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0048_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0048_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0048_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0048_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0048_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0048_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0048_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0048_ip (target) VALUES (b'1010');
SELECT 'TC-26-REG-0048-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0048_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0048_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0048_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0048_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0048_ip a JOIN t2_tc_26_reg_0048_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0049-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0049_ip, t2_tc_26_reg_0049_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0049_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0049_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0049_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0049_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0049_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0049_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0049_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0049_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0049_ip MODIFY target BIT(16) INVISIBLE, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0049_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0049_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0049_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0049_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0049_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0049_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0049_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0049_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0049_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0049_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0049_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0049_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0049_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0049_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0049_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0049_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0049_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0049_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0049_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0049_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0049_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0049_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0049-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0049_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0049_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0049_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0049_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0049_ip a JOIN t2_tc_26_reg_0049_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0050-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0050_ip, t2_tc_26_reg_0050_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0050_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0050_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0050_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-26-REG-0050-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0050_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0050_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0050_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0050_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0050_ip a JOIN t2_tc_26_reg_0050_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0051-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0051_ip, t2_tc_26_reg_0051_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0051_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0051_ip (target) VALUES (b'0');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0051_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0051_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0051_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0051_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0051_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0051_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0051_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0051_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0051_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0051_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0051_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0051_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0051_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0051_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0051_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0051_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0051_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0051-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0051_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0051_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0051_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0051_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0051_ip a JOIN t2_tc_26_reg_0051_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0052-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: BIT-02
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0052_ip, t2_tc_26_reg_0052_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0052_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0052_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0052_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0052_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0052_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0052_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0052_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0052_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0052_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0052_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0052_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0052_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0052_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0052_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0052_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0052_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0052_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0052_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0052_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0052_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0052_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0052_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0052_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0052_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0052_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0052_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0052_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0052_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0052_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0052_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0052_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0052-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0052_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0052_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0052_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0052_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0052_ip a JOIN t2_tc_26_reg_0052_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0053-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: BIT-02
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0053_ip, t2_tc_26_reg_0053_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0053_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0053_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0053_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0053_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0053_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0053_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0053_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0053_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0053_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0053_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0053_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0053_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0053_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0053_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0053_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0053_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0053_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0053_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0053_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0053_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0053_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0053_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0053_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0053_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0053_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0053_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0053_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0053_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0053_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0053_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0053_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0053-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0053_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0053_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0053_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0053_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0053_ip a JOIN t2_tc_26_reg_0053_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0054-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0054_ip, t2_tc_26_reg_0054_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0054_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0054_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0054_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0054_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0054_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0054_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0054_ip (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0054_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0054_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0054_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0054_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0054_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0054_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0054_ip (target) VALUES (b'1010');
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0054_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0054_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0054_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0054_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0054_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0054_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0054_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0054_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0054_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0054_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0054_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0054_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0054_ip (target) VALUES (b'1010');
SELECT 'TC-26-REG-0054-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0054_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0054_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0054_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0054_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0054_ip a JOIN t2_tc_26_reg_0054_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0055-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0055_ip, t2_tc_26_reg_0055_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0055_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0055_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0055_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0055_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0055_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0055_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0055_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0055_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0055_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0055_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0055_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0055_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0055_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0055_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0055_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0055_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0055_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0055_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0055_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0055_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0055_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0055_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0055_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0055_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0055_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0055_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0055_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0055_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0055_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0055_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0055_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0055-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0055_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0055_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0055_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0055_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0055_ip a JOIN t2_tc_26_reg_0055_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0056-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0056_ip, t2_tc_26_reg_0056_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0056_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0056_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0056_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0056_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0056_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0056_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0056_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0056_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0056_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0056_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0056_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0056_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0056_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0056_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0056_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0056_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0056_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0056_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0056_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0056-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0056_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0056_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0056_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0056_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0056_ip a JOIN t2_tc_26_reg_0056_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0057-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=SECONDARY_INDEX
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=SECONDARY_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0057_ip, t2_tc_26_reg_0057_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0057_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0057_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0057_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0057_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0057_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0057_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0057_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0057_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0057_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0057_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0057_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0057_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0057_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0057_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0057_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0057_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0057_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0057_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0057_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0057_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0057_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0057_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0057_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0057_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0057_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0057_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0057_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0057_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0057_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0057_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0057_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0057-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0057_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0057_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0057_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0057_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0057_ip a JOIN t2_tc_26_reg_0057_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0058-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=UNIQUE_INDEX
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0058_ip, t2_tc_26_reg_0058_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0058_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0058_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0058_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0058_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0058_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0058_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0058_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0058_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0058_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0058_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0058_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0058_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0058_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0058_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0058_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0058_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0058_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0058_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0058_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0058_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0058_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0058_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0058_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0058_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0058_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0058_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0058_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0058_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0058_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0058_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0058_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0058-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0058_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0058_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0058_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0058_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0058_ip a JOIN t2_tc_26_reg_0058_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0059-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=FOREIGN_KEY
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=FOREIGN_KEY, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0059_ip, t2_tc_26_reg_0059_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0059_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0059_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0059_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0059_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0059_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0059_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0059_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0059_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0059_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0059_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0059_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0059_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0059_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0059_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0059_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0059_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0059_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0059_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0059_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0059_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0059_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0059_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0059_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0059_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0059_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0059_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0059_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0059_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0059_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0059_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0059_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0059-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0059_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0059_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0059_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0059_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0059_ip a JOIN t2_tc_26_reg_0059_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0060-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=CHECK
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=CHECK, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0060_ip, t2_tc_26_reg_0060_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0060_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0060_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0060_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0060_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0060_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0060_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0060_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0060_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0060_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0060_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0060_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0060_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0060_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0060_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0060_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0060_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0060_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0060_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0060_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0060_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0060_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0060_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0060_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0060_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0060_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0060_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0060_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0060_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0060_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0060_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0060_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0060-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0060_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0060_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0060_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0060_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0060_ip a JOIN t2_tc_26_reg_0060_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0061-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0061_ip, t2_tc_26_reg_0061_ip;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_26_reg_0061_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0061_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0061_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0061_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0061_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0061_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0061_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0061_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0061_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0061_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0061_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0061_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0061_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0061_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0061_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0061_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0061_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0061_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0061_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0061_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0061_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0061_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0061_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0061_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0061_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0061_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0061_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0061_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0061_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0061_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0061_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0061-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0061_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0061_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0061_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0061_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0061_ip a JOIN t2_tc_26_reg_0061_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0062-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0062_ip, t2_tc_26_reg_0062_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0062_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0062_ip MODIFY target BIT(16) NOT NULL, ALGORITHM=inplace;
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0062_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-26-REG-0062-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0062_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0062_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0062_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0062_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0062_ip a JOIN t2_tc_26_reg_0062_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0063-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-02
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0063_ip, t2_tc_26_reg_0063_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0063_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0063_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0063_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0063_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0063_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0063_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0063_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0063_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0063_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0063_ip (target) VALUES (NULL);
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0063_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0063_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0063_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0063_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0063_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0063_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0063_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0063_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0063_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0063-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0063_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0063_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0063_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0063_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0063_ip a JOIN t2_tc_26_reg_0063_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0064-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: BIT-02
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0064_ip, t2_tc_26_reg_0064_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0064_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0064_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0064_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-26-REG-0064-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0064_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0064_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0064_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0064_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0064_ip a JOIN t2_tc_26_reg_0064_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0065-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0065_ip, t2_tc_26_reg_0065_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0065_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(8) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0065_ip MODIFY target BIT(16) NOT NULL DEFAULT b'0', ALGORITHM=inplace;
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0065_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-26-REG-0065-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0065_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0065_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0065_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0065_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0065_ip a JOIN t2_tc_26_reg_0065_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0066-IP
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-05
-- Transition ID: BIT-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
DROP TABLE IF EXISTS t1_tc_26_reg_0066_ip, t2_tc_26_reg_0066_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0066_ip (
  target BIT(8),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0066_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0066_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0066_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0066_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0066_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0066_ip (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0066_ip MODIFY target BIT(16), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0066_ip (target) VALUES (b'1111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0066_ip (target) VALUES (b'111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0066_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0066_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0066_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0066_ip (target) VALUES (b'1010');
-- Oracle table: BIT(16)
CREATE TABLE t2_tc_26_reg_0066_ip (
  target BIT(16),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0066_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0066_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0066_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0066_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0066_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0066_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0066_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0066_ip (target) VALUES (b'111111111');
INSERT INTO t2_tc_26_reg_0066_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0066_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0066_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0066_ip (target) VALUES (b'1010');
SELECT 'TC-26-REG-0066-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0066_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0066_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0066_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0066_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0066_ip a JOIN t2_tc_26_reg_0066_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-ATR-0002-IP
-- Column attribute preservation: COMMENT
-- Type: BIT(8) -> BIT(16), Algorithm: inplace
DROP TABLE IF EXISTS t1_tc_26_atr_0002_ip, t2_tc_26_atr_0002_ip;
CREATE TABLE t1_tc_26_atr_0002_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target BIT(8) COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB;
INSERT INTO t1_tc_26_atr_0002_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_atr_0002_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_atr_0002_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_atr_0002_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_atr_0002_ip (target) VALUES (b'1010');
ALTER TABLE t1_tc_26_atr_0002_ip MODIFY target BIT(16) COMMENT 'test_comment', ALGORITHM=inplace;
INSERT INTO t1_tc_26_atr_0002_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_atr_0002_ip (target) VALUES (b'111111111');
INSERT INTO t1_tc_26_atr_0002_ip (target) VALUES (b'1');
SELECT 'TC-26-ATR-0002-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_26_atr_0002_ip' AND column_name='target' AND column_comment='test_comment';

-- Test Case: TC-26-REG-0067-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0067_ip, t2_tc_26_reg_0067_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0067_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0067_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0067_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0067_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0067_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0067_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0067_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0067_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0067_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0067_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0067_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0067_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0067_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0067_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0067_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0067_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0067_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0067_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0067_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0067_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0067_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0067_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0067_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0067_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0067_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0067_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0067_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0067_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0067_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0067_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0067_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0067-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0067_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0067_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0067_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0067_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0067_ip a JOIN t2_tc_26_reg_0067_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0068-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0068_ip, t2_tc_26_reg_0068_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0068_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t1_tc_26_reg_0068_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0068_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0068_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0068_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0068_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0068_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0068_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0068_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0068_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0068_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0068_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0068_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0068_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0068_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0068_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0068_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t2_tc_26_reg_0068_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0068_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0068_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0068_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0068_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0068_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0068_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0068_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0068_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0068_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0068_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0068_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0068_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0068_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0068-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0068_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0068_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0068_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0068_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0068_ip a JOIN t2_tc_26_reg_0068_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0069-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0069_ip, t2_tc_26_reg_0069_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0069_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t1_tc_26_reg_0069_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0069_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0069_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0069_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0069_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0069_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0069_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0069_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0069_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0069_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0069_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0069_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0069_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0069_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0069_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0069_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t2_tc_26_reg_0069_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0069_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0069_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0069_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0069_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0069_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0069_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0069_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0069_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0069_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0069_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0069_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0069_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0069_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0069-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0069_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0069_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0069_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0069_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0069_ip a JOIN t2_tc_26_reg_0069_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0070-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0070_ip, t2_tc_26_reg_0070_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0070_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0070_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0070_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0070_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0070_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0070_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0070_ip (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0070_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0070_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0070_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0070_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0070_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0070_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0070_ip (target) VALUES (b'1010');
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0070_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0070_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0070_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0070_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0070_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0070_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0070_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0070_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0070_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0070_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0070_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0070_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0070_ip (target) VALUES (b'1010');
SELECT 'TC-26-REG-0070-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0070_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0070_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0070_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0070_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0070_ip a JOIN t2_tc_26_reg_0070_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0071-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0071_ip, t2_tc_26_reg_0071_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0071_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0071_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0071_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0071_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0071_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0071_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0071_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0071_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0071_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0071_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0071_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0071_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0071_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0071_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0071_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0071_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0071_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0071_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0071_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0071_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0071_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0071_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0071_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0071_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0071_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0071_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0071_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0071_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0071_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0071_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0071_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0071-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0071_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0071_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0071_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0071_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0071_ip a JOIN t2_tc_26_reg_0071_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0072-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0072_ip, t2_tc_26_reg_0072_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0072_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0072_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0072_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0072_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0072_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0072_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0072_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0072_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0072_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0072_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0072_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0072_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0072_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0072_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0072_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0072_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0072_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0072_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0072_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0072_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0072_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0072_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0072_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0072_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0072_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0072_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0072_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0072_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0072_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0072_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0072_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0072-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0072_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0072_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0072_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0072_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0072_ip a JOIN t2_tc_26_reg_0072_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0073-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0073_ip, t2_tc_26_reg_0073_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0073_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0073_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0073_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0073_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0073_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0073_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0073_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0073_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0073_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0073_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0073_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0073_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0073_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0073_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0073_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0073_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0073_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0073_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0073_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0073_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0073_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0073_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0073_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0073_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0073_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0073_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0073_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0073_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0073_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0073_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0073_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0073-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0073_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0073_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0073_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0073_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0073_ip a JOIN t2_tc_26_reg_0073_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0074-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0074_ip, t2_tc_26_reg_0074_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0074_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0074_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0074_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0074_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0074_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0074_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0074_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0074_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0074_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0074_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0074_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0074_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0074_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0074_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0074_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0074_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0074_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0074_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0074_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0074_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0074_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0074_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0074_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0074_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0074_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0074_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0074_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0074_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0074_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0074_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0074_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0074-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0074_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0074_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0074_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0074_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0074_ip a JOIN t2_tc_26_reg_0074_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0075-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0075_ip, t2_tc_26_reg_0075_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0075_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0075_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0075_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0075_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0075_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0075_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0075_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0075_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0075_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0075_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0075_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0075_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0075_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0075_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0075_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0075_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0075_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0075_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0075_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0075_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0075_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0075_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0075_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0075_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0075_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0075_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0075_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0075_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0075_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0075_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0075_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0075-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0075_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0075_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0075_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0075_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0075_ip a JOIN t2_tc_26_reg_0075_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0076-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
DROP TABLE IF EXISTS t1_tc_26_reg_0076_ip, t2_tc_26_reg_0076_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0076_ip (
  target BIT(16),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0076_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0076_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0076_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0076_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0076_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0076_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0076_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0076_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0076_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0076_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0076_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0076_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0076_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0076_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0076_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0076_ip (
  target BIT(32),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0076_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0076_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0076_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0076_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0076_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0076_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0076_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0076_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0076_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0076_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0076_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0076_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0076_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0076_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0076-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0076_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0076_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0076_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0076_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0076_ip a JOIN t2_tc_26_reg_0076_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0077-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
DROP TABLE IF EXISTS t1_tc_26_reg_0077_ip, t2_tc_26_reg_0077_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0077_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BIT(16), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0077_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0077_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0077_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0077_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0077_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0077_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0077_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0077_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0077_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0077_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0077_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0077_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0077_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0077_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0077_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0077_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BIT(32), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0077_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0077_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0077_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0077_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0077_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0077_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0077_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0077_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0077_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0077_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0077_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0077_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0077_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0077_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0077-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0077_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0077_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0077_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0077_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0077_ip a JOIN t2_tc_26_reg_0077_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0078-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0078_ip, t2_tc_26_reg_0078_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0078_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0078_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0078_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0078_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0078_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0078_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0078_ip (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0078_ip MODIFY target BIT(32) NOT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0078_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0078_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0078_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0078_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0078_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0078_ip (target) VALUES (b'1010');
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0078_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0078_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0078_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0078_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0078_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0078_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0078_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0078_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0078_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0078_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0078_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0078_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0078_ip (target) VALUES (b'1010');
SELECT 'TC-26-REG-0078-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0078_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0078_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0078_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0078_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0078_ip a JOIN t2_tc_26_reg_0078_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0079-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0079_ip, t2_tc_26_reg_0079_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0079_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0079_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0079_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0079_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0079_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0079_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0079_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0079_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0079_ip MODIFY target BIT(32) DEFAULT b'0', ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0079_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0079_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0079_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0079_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0079_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0079_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0079_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0079_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0079_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0079_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0079_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0079_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0079_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0079_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0079_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0079_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0079_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0079_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0079_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0079_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0079_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0079_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0079-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0079_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0079_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0079_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0079_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0079_ip a JOIN t2_tc_26_reg_0079_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0080-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0080_ip, t2_tc_26_reg_0080_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0080_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0080_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0080_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0080_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0080_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0080_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0080_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0080_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0080_ip MODIFY target BIT(32) DEFAULT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0080_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0080_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0080_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0080_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0080_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0080_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0080_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0080_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0080_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0080_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0080_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0080_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0080_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0080_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0080_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0080_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0080_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0080_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0080_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0080_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0080_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0080_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0080-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0080_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0080_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0080_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0080_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0080_ip a JOIN t2_tc_26_reg_0080_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0081-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0081_ip, t2_tc_26_reg_0081_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0081_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0081_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0081_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0081_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0081_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0081_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0081_ip (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0081_ip MODIFY target BIT(32) NOT NULL DEFAULT b'0', ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0081_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0081_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0081_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0081_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0081_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0081_ip (target) VALUES (b'1010');
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0081_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0081_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0081_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0081_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0081_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0081_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0081_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0081_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0081_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0081_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0081_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0081_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0081_ip (target) VALUES (b'1010');
SELECT 'TC-26-REG-0081-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0081_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0081_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0081_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0081_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0081_ip a JOIN t2_tc_26_reg_0081_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0082-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0082_ip, t2_tc_26_reg_0082_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0082_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0082_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0082_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0082_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0082_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0082_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0082_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0082_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0082_ip MODIFY target BIT(32) INVISIBLE, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0082_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0082_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0082_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0082_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0082_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0082_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0082_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0082_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0082_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0082_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0082_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0082_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0082_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0082_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0082_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0082_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0082_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0082_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0082_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0082_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0082_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0082_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0082-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0082_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0082_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0082_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0082_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0082_ip a JOIN t2_tc_26_reg_0082_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0083-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0083_ip, t2_tc_26_reg_0083_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0083_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0083_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0083_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-26-REG-0083-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0083_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0083_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0083_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0083_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0083_ip a JOIN t2_tc_26_reg_0083_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0084-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0084_ip, t2_tc_26_reg_0084_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0084_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0084_ip (target) VALUES (b'0');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0084_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0084_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0084_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0084_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0084_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0084_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0084_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0084_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0084_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0084_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0084_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0084_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0084_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0084_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0084_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0084_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0084_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0084-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0084_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0084_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0084_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0084_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0084_ip a JOIN t2_tc_26_reg_0084_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0085-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: BIT-03
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0085_ip, t2_tc_26_reg_0085_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0085_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0085_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0085_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0085_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0085_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0085_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0085_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0085_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0085_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0085_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0085_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0085_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0085_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0085_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0085_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0085_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0085_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0085_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0085_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0085_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0085_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0085_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0085_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0085_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0085_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0085_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0085_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0085_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0085_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0085_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0085_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0085-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0085_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0085_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0085_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0085_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0085_ip a JOIN t2_tc_26_reg_0085_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0086-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: BIT-03
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0086_ip, t2_tc_26_reg_0086_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0086_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0086_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0086_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0086_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0086_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0086_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0086_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0086_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0086_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0086_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0086_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0086_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0086_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0086_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0086_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0086_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0086_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0086_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0086_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0086_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0086_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0086_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0086_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0086_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0086_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0086_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0086_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0086_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0086_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0086_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0086_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0086-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0086_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0086_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0086_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0086_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0086_ip a JOIN t2_tc_26_reg_0086_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0087-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0087_ip, t2_tc_26_reg_0087_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0087_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0087_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0087_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0087_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0087_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0087_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0087_ip (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0087_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0087_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0087_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0087_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0087_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0087_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0087_ip (target) VALUES (b'1010');
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0087_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0087_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0087_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0087_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0087_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0087_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0087_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0087_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0087_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0087_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0087_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0087_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0087_ip (target) VALUES (b'1010');
SELECT 'TC-26-REG-0087-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0087_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0087_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0087_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0087_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0087_ip a JOIN t2_tc_26_reg_0087_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0088-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0088_ip, t2_tc_26_reg_0088_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0088_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0088_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0088_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0088_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0088_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0088_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0088_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0088_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0088_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0088_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0088_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0088_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0088_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0088_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0088_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0088_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0088_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0088_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0088_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0088_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0088_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0088_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0088_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0088_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0088_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0088_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0088_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0088_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0088_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0088_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0088_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0088-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0088_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0088_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0088_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0088_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0088_ip a JOIN t2_tc_26_reg_0088_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0089-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0089_ip, t2_tc_26_reg_0089_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0089_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0089_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0089_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0089_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0089_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0089_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0089_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0089_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0089_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0089_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0089_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0089_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0089_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0089_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0089_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0089_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0089_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0089_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0089_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0089-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0089_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0089_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0089_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0089_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0089_ip a JOIN t2_tc_26_reg_0089_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0090-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=SECONDARY_INDEX
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=SECONDARY_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0090_ip, t2_tc_26_reg_0090_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0090_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0090_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0090_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0090_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0090_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0090_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0090_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0090_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0090_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0090_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0090_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0090_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0090_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0090_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0090_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0090_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0090_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0090_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0090_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0090_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0090_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0090_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0090_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0090_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0090_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0090_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0090_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0090_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0090_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0090_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0090_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0090-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0090_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0090_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0090_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0090_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0090_ip a JOIN t2_tc_26_reg_0090_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0091-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=UNIQUE_INDEX
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0091_ip, t2_tc_26_reg_0091_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0091_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0091_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0091_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0091_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0091_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0091_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0091_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0091_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0091_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0091_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0091_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0091_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0091_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0091_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0091_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0091_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0091_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0091_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0091_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0091_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0091_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0091_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0091_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0091_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0091_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0091_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0091_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0091_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0091_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0091_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0091_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0091-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0091_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0091_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0091_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0091_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0091_ip a JOIN t2_tc_26_reg_0091_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0092-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=FOREIGN_KEY
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=FOREIGN_KEY, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0092_ip, t2_tc_26_reg_0092_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0092_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0092_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0092_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0092_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0092_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0092_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0092_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0092_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0092_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0092_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0092_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0092_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0092_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0092_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0092_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0092_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0092_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0092_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0092_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0092_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0092_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0092_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0092_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0092_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0092_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0092_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0092_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0092_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0092_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0092_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0092_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0092-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0092_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0092_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0092_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0092_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0092_ip a JOIN t2_tc_26_reg_0092_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0093-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=CHECK
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=CHECK, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0093_ip, t2_tc_26_reg_0093_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0093_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0093_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0093_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0093_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0093_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0093_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0093_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0093_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0093_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0093_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0093_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0093_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0093_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0093_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0093_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0093_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0093_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0093_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0093_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0093_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0093_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0093_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0093_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0093_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0093_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0093_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0093_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0093_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0093_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0093_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0093_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0093-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0093_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0093_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0093_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0093_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0093_ip a JOIN t2_tc_26_reg_0093_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0094-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0094_ip, t2_tc_26_reg_0094_ip;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_26_reg_0094_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0094_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0094_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0094_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0094_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0094_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0094_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0094_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0094_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0094_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0094_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0094_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0094_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0094_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0094_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0094_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0094_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0094_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0094_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0094_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0094_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0094_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0094_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0094_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0094_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0094_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0094_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0094_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0094_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0094_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0094_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0094-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0094_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0094_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0094_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0094_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0094_ip a JOIN t2_tc_26_reg_0094_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0095-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0095_ip, t2_tc_26_reg_0095_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0095_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0095_ip MODIFY target BIT(32) NOT NULL, ALGORITHM=inplace;
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0095_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-26-REG-0095-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0095_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0095_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0095_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0095_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0095_ip a JOIN t2_tc_26_reg_0095_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0096-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-02
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0096_ip, t2_tc_26_reg_0096_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0096_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0096_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0096_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0096_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0096_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0096_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0096_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0096_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0096_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0096_ip (target) VALUES (NULL);
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0096_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0096_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0096_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0096_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0096_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0096_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0096_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0096_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0096_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0096-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0096_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0096_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0096_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0096_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0096_ip a JOIN t2_tc_26_reg_0096_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0097-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: BIT-03
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0097_ip, t2_tc_26_reg_0097_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0097_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0097_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0097_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-26-REG-0097-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0097_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0097_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0097_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0097_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0097_ip a JOIN t2_tc_26_reg_0097_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0098-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0098_ip, t2_tc_26_reg_0098_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0098_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(16) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0098_ip MODIFY target BIT(32) NOT NULL DEFAULT b'0', ALGORITHM=inplace;
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0098_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-26-REG-0098-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0098_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0098_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0098_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0098_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0098_ip a JOIN t2_tc_26_reg_0098_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0099-IP
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-05
-- Transition ID: BIT-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
DROP TABLE IF EXISTS t1_tc_26_reg_0099_ip, t2_tc_26_reg_0099_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0099_ip (
  target BIT(16),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0099_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0099_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0099_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0099_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0099_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0099_ip (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0099_ip MODIFY target BIT(32), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0099_ip (target) VALUES (b'11111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0099_ip (target) VALUES (b'11111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0099_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0099_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0099_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_reg_0099_ip (target) VALUES (b'1010');
-- Oracle table: BIT(32)
CREATE TABLE t2_tc_26_reg_0099_ip (
  target BIT(32),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0099_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0099_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0099_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0099_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0099_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0099_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0099_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0099_ip (target) VALUES (b'11111111111111111');
INSERT INTO t2_tc_26_reg_0099_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0099_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0099_ip (target) VALUES (b'1111111111111111');
INSERT INTO t2_tc_26_reg_0099_ip (target) VALUES (b'1010');
SELECT 'TC-26-REG-0099-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0099_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0099_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0099_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0099_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0099_ip a JOIN t2_tc_26_reg_0099_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-ATR-0003-IP
-- Column attribute preservation: COMMENT
-- Type: BIT(16) -> BIT(32), Algorithm: inplace
DROP TABLE IF EXISTS t1_tc_26_atr_0003_ip, t2_tc_26_atr_0003_ip;
CREATE TABLE t1_tc_26_atr_0003_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target BIT(16) COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB;
INSERT INTO t1_tc_26_atr_0003_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_atr_0003_ip (target) VALUES (b'1111111111111111');
INSERT INTO t1_tc_26_atr_0003_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_atr_0003_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_atr_0003_ip (target) VALUES (b'1010');
ALTER TABLE t1_tc_26_atr_0003_ip MODIFY target BIT(32) COMMENT 'test_comment', ALGORITHM=inplace;
INSERT INTO t1_tc_26_atr_0003_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_atr_0003_ip (target) VALUES (b'11111111111111111');
INSERT INTO t1_tc_26_atr_0003_ip (target) VALUES (b'1');
SELECT 'TC-26-ATR-0003-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_26_atr_0003_ip' AND column_name='target' AND column_comment='test_comment';

-- Test Case: TC-26-REG-0100-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0100_ip, t2_tc_26_reg_0100_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0100_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0100_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0100_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0100_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0100_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0100_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0100_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0100_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0100_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0100_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0100_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0100_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0100_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0100_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0100_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0100_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0100_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0100_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0100_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0100_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0100_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0100_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0100_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0100_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0100_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0100_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0100_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0100_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0100_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0100_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0100_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0100-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0100_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0100_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0100_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0100_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0100_ip a JOIN t2_tc_26_reg_0100_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0101-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0101_ip, t2_tc_26_reg_0101_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0101_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t1_tc_26_reg_0101_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0101_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0101_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0101_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0101_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0101_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0101_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0101_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0101_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0101_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0101_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0101_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0101_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0101_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0101_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0101_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t2_tc_26_reg_0101_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0101_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0101_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0101_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0101_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0101_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0101_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0101_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0101_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0101_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0101_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0101_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0101_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0101_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0101-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0101_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0101_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0101_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0101_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0101_ip a JOIN t2_tc_26_reg_0101_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0102-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0102_ip, t2_tc_26_reg_0102_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0102_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t1_tc_26_reg_0102_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0102_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0102_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0102_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0102_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0102_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0102_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0102_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0102_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0102_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0102_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0102_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0102_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0102_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0102_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0102_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t2_tc_26_reg_0102_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0102_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0102_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0102_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0102_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0102_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0102_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0102_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0102_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0102_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0102_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0102_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0102_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0102_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0102-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0102_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0102_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0102_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0102_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0102_ip a JOIN t2_tc_26_reg_0102_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0103-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0103_ip, t2_tc_26_reg_0103_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0103_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0103_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0103_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0103_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0103_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0103_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0103_ip (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0103_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0103_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0103_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0103_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0103_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0103_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0103_ip (target) VALUES (b'1010');
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0103_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0103_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0103_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0103_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0103_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0103_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0103_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0103_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0103_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0103_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0103_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0103_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0103_ip (target) VALUES (b'1010');
SELECT 'TC-26-REG-0103-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0103_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0103_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0103_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0103_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0103_ip a JOIN t2_tc_26_reg_0103_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0104-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0104_ip, t2_tc_26_reg_0104_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0104_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0104_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0104_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0104_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0104_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0104_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0104_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0104_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0104_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0104_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0104_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0104_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0104_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0104_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0104_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0104_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0104_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0104_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0104_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0104_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0104_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0104_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0104_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0104_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0104_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0104_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0104_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0104_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0104_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0104_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0104_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0104-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0104_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0104_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0104_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0104_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0104_ip a JOIN t2_tc_26_reg_0104_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0105-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0105_ip, t2_tc_26_reg_0105_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0105_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0105_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0105_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0105_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0105_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0105_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0105_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0105_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0105_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0105_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0105_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0105_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0105_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0105_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0105_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0105_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0105_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0105_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0105_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0105_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0105_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0105_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0105_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0105_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0105_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0105_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0105_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0105_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0105_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0105_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0105_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0105-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0105_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0105_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0105_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0105_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0105_ip a JOIN t2_tc_26_reg_0105_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0106-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0106_ip, t2_tc_26_reg_0106_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0106_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0106_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0106_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0106_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0106_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0106_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0106_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0106_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0106_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0106_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0106_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0106_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0106_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0106_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0106_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0106_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0106_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0106_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0106_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0106_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0106_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0106_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0106_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0106_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0106_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0106_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0106_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0106_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0106_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0106_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0106_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0106-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0106_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0106_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0106_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0106_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0106_ip a JOIN t2_tc_26_reg_0106_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0107-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0107_ip, t2_tc_26_reg_0107_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0107_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0107_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0107_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0107_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0107_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0107_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0107_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0107_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0107_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0107_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0107_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0107_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0107_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0107_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0107_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0107_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0107_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0107_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0107_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0107_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0107_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0107_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0107_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0107_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0107_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0107_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0107_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0107_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0107_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0107_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0107_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0107-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0107_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0107_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0107_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0107_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0107_ip a JOIN t2_tc_26_reg_0107_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0108-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0108_ip, t2_tc_26_reg_0108_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0108_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0108_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0108_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0108_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0108_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0108_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0108_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0108_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0108_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0108_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0108_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0108_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0108_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0108_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0108_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0108_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0108_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0108_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0108_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0108_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0108_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0108_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0108_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0108_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0108_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0108_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0108_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0108_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0108_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0108_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0108_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0108-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0108_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0108_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0108_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0108_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0108_ip a JOIN t2_tc_26_reg_0108_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0109-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
DROP TABLE IF EXISTS t1_tc_26_reg_0109_ip, t2_tc_26_reg_0109_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0109_ip (
  target BIT(32),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0109_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0109_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0109_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0109_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0109_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0109_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0109_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0109_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0109_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0109_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0109_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0109_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0109_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0109_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0109_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0109_ip (
  target BIT(64),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0109_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0109_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0109_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0109_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0109_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0109_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0109_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0109_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0109_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0109_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0109_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0109_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0109_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0109_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0109-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0109_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0109_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0109_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0109_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0109_ip a JOIN t2_tc_26_reg_0109_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0110-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
DROP TABLE IF EXISTS t1_tc_26_reg_0110_ip, t2_tc_26_reg_0110_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0110_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BIT(32), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0110_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0110_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0110_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0110_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0110_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0110_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0110_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0110_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0110_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0110_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0110_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0110_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0110_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0110_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0110_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0110_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BIT(64), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0110_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0110_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0110_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0110_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0110_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0110_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0110_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0110_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0110_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0110_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0110_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0110_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0110_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0110_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0110-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0110_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0110_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0110_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0110_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0110_ip a JOIN t2_tc_26_reg_0110_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0111-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0111_ip, t2_tc_26_reg_0111_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0111_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0111_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0111_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0111_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0111_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0111_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0111_ip (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0111_ip MODIFY target BIT(64) NOT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0111_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0111_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0111_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0111_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0111_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0111_ip (target) VALUES (b'1010');
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0111_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0111_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0111_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0111_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0111_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0111_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0111_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0111_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0111_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0111_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0111_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0111_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0111_ip (target) VALUES (b'1010');
SELECT 'TC-26-REG-0111-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0111_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0111_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0111_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0111_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0111_ip a JOIN t2_tc_26_reg_0111_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0112-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0112_ip, t2_tc_26_reg_0112_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0112_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0112_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0112_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0112_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0112_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0112_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0112_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0112_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0112_ip MODIFY target BIT(64) DEFAULT b'0', ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0112_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0112_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0112_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0112_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0112_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0112_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0112_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0112_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64) DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0112_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0112_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0112_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0112_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0112_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0112_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0112_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0112_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0112_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0112_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0112_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0112_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0112_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0112_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0112-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0112_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0112_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0112_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0112_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0112_ip a JOIN t2_tc_26_reg_0112_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0113-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0113_ip, t2_tc_26_reg_0113_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0113_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0113_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0113_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0113_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0113_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0113_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0113_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0113_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0113_ip MODIFY target BIT(64) DEFAULT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0113_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0113_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0113_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0113_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0113_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0113_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0113_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0113_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0113_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0113_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0113_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0113_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0113_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0113_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0113_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0113_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0113_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0113_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0113_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0113_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0113_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0113_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0113-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0113_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0113_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0113_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0113_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0113_ip a JOIN t2_tc_26_reg_0113_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0114-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0114_ip, t2_tc_26_reg_0114_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0114_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0114_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0114_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0114_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0114_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0114_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0114_ip (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0114_ip MODIFY target BIT(64) NOT NULL DEFAULT b'0', ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0114_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0114_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0114_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0114_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0114_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0114_ip (target) VALUES (b'1010');
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0114_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0114_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0114_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0114_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0114_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0114_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0114_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0114_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0114_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0114_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0114_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0114_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0114_ip (target) VALUES (b'1010');
SELECT 'TC-26-REG-0114-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0114_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0114_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0114_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0114_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0114_ip a JOIN t2_tc_26_reg_0114_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0115-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0115_ip, t2_tc_26_reg_0115_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0115_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0115_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0115_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0115_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0115_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0115_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0115_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0115_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0115_ip MODIFY target BIT(64) INVISIBLE, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0115_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0115_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0115_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0115_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0115_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0115_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0115_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0115_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0115_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0115_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0115_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0115_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0115_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0115_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0115_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0115_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0115_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0115_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0115_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0115_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0115_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0115_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0115-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0115_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0115_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0115_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0115_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0115_ip a JOIN t2_tc_26_reg_0115_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0116-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0116_ip, t2_tc_26_reg_0116_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0116_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0116_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0116_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-26-REG-0116-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0116_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0116_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0116_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0116_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0116_ip a JOIN t2_tc_26_reg_0116_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0117-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0117_ip, t2_tc_26_reg_0117_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0117_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0117_ip (target) VALUES (b'0');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0117_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0117_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0117_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0117_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0117_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0117_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0117_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0117_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0117_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0117_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0117_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0117_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0117_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0117_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0117_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0117_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0117_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0117-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0117_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0117_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0117_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0117_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0117_ip a JOIN t2_tc_26_reg_0117_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0118-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: BIT-04
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0118_ip, t2_tc_26_reg_0118_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0118_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0118_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0118_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0118_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0118_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0118_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0118_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0118_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0118_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0118_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0118_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0118_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0118_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0118_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0118_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0118_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0118_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0118_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0118_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0118_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0118_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0118_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0118_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0118_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0118_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0118_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0118_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0118_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0118_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0118_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0118_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0118-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0118_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0118_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0118_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0118_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0118_ip a JOIN t2_tc_26_reg_0118_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0119-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: BIT-04
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0119_ip, t2_tc_26_reg_0119_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0119_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0119_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0119_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0119_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0119_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0119_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0119_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0119_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0119_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0119_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0119_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0119_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0119_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0119_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0119_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0119_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0119_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0119_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0119_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0119_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0119_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0119_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0119_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0119_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0119_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0119_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0119_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0119_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0119_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0119_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0119_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0119-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0119_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0119_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0119_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0119_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0119_ip a JOIN t2_tc_26_reg_0119_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0120-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0120_ip, t2_tc_26_reg_0120_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0120_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0120_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0120_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0120_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0120_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0120_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0120_ip (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0120_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0120_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0120_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0120_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0120_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0120_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0120_ip (target) VALUES (b'1010');
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0120_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0120_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0120_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0120_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0120_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0120_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0120_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0120_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0120_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0120_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0120_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0120_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0120_ip (target) VALUES (b'1010');
SELECT 'TC-26-REG-0120-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0120_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0120_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0120_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0120_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0120_ip a JOIN t2_tc_26_reg_0120_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0121-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0121_ip, t2_tc_26_reg_0121_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0121_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0121_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0121_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0121_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0121_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0121_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0121_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0121_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0121_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0121_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0121_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0121_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0121_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0121_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0121_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0121_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0121_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0121_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0121_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0121_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0121_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0121_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0121_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0121_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0121_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0121_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0121_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0121_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0121_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0121_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0121_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0121-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0121_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0121_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0121_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0121_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0121_ip a JOIN t2_tc_26_reg_0121_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0122-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0122_ip, t2_tc_26_reg_0122_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0122_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0122_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0122_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0122_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0122_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0122_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0122_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0122_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0122_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0122_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0122_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0122_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0122_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0122_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0122_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0122_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0122_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0122_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0122_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0122-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0122_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0122_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0122_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0122_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0122_ip a JOIN t2_tc_26_reg_0122_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0123-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=SECONDARY_INDEX
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=SECONDARY_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0123_ip, t2_tc_26_reg_0123_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0123_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0123_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0123_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0123_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0123_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0123_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0123_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0123_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0123_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0123_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0123_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0123_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0123_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0123_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0123_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0123_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0123_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0123_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0123_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0123_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0123_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0123_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0123_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0123_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0123_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0123_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0123_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0123_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0123_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0123_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0123_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0123-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0123_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0123_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0123_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0123_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0123_ip a JOIN t2_tc_26_reg_0123_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0124-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=UNIQUE_INDEX
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0124_ip, t2_tc_26_reg_0124_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0124_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0124_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0124_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0124_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0124_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0124_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0124_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0124_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0124_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0124_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0124_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0124_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0124_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0124_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0124_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0124_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0124_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0124_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0124_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0124_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0124_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0124_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0124_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0124_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0124_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0124_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0124_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0124_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0124_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0124_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0124_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0124-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0124_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0124_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0124_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0124_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0124_ip a JOIN t2_tc_26_reg_0124_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0125-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=FOREIGN_KEY
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=FOREIGN_KEY, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0125_ip, t2_tc_26_reg_0125_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0125_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0125_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0125_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0125_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0125_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0125_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0125_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0125_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0125_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0125_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0125_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0125_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0125_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0125_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0125_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0125_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0125_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0125_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0125_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0125_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0125_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0125_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0125_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0125_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0125_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0125_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0125_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0125_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0125_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0125_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0125_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0125-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0125_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0125_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0125_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0125_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0125_ip a JOIN t2_tc_26_reg_0125_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0126-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=CHECK
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=CHECK, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0126_ip, t2_tc_26_reg_0126_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0126_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0126_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0126_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0126_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0126_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0126_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0126_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0126_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0126_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0126_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0126_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0126_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0126_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0126_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0126_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0126_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0126_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0126_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0126_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0126_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0126_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0126_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0126_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0126_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0126_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0126_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0126_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0126_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0126_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0126_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0126_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0126-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0126_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0126_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0126_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0126_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0126_ip a JOIN t2_tc_26_reg_0126_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0127-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0127_ip, t2_tc_26_reg_0127_ip;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_26_reg_0127_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0127_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0127_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0127_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0127_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0127_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0127_ip (target) VALUES (b'11111111');
INSERT INTO t1_tc_26_reg_0127_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0127_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0127_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0127_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0127_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0127_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0127_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0127_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0127_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0127_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0127_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0127_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0127_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0127_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0127_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0127_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0127_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0127_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0127_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0127_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0127_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0127_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0127_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0127_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0127-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0127_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0127_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0127_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0127_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0127_ip a JOIN t2_tc_26_reg_0127_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0128-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0128_ip, t2_tc_26_reg_0128_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0128_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0128_ip MODIFY target BIT(64) NOT NULL, ALGORITHM=inplace;
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0128_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-26-REG-0128-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0128_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0128_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0128_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0128_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0128_ip a JOIN t2_tc_26_reg_0128_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0129-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-02
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0129_ip, t2_tc_26_reg_0129_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0129_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0129_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0129_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0129_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0129_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0129_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0129_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0129_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0129_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0129_ip (target) VALUES (NULL);
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0129_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0129_ip (target) VALUES (NULL);
INSERT INTO t2_tc_26_reg_0129_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0129_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0129_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0129_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0129_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0129_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0129_ip (target) VALUES (NULL);
SELECT 'TC-26-REG-0129-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0129_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0129_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0129_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0129_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0129_ip a JOIN t2_tc_26_reg_0129_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0130-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: BIT-04
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0130_ip, t2_tc_26_reg_0130_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0130_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0130_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0130_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-26-REG-0130-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0130_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0130_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0130_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0130_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0130_ip a JOIN t2_tc_26_reg_0130_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0131-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
DROP TABLE IF EXISTS t1_tc_26_reg_0131_ip, t2_tc_26_reg_0131_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0131_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(32) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0131_ip MODIFY target BIT(64) NOT NULL DEFAULT b'0', ALGORITHM=inplace;
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0131_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BIT(64) NOT NULL DEFAULT b'0',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
SELECT 'TC-26-REG-0131-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0131_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0131_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0131_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0131_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0131_ip a JOIN t2_tc_26_reg_0131_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-REG-0132-IP
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-05
-- Transition ID: BIT-04
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
DROP TABLE IF EXISTS t1_tc_26_reg_0132_ip, t2_tc_26_reg_0132_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_26_reg_0132_ip (
  target BIT(32),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_26_reg_0132_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0132_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0132_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0132_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0132_ip (target) VALUES (b'1010');
INSERT INTO t1_tc_26_reg_0132_ip (target) VALUES (b'11111111');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_26_reg_0132_ip MODIFY target BIT(64), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0132_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0132_ip (target) VALUES (b'111111111111111111111111111111111');
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_26_reg_0132_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_reg_0132_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_reg_0132_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_reg_0132_ip (target) VALUES (b'1010');
-- Oracle table: BIT(64)
CREATE TABLE t2_tc_26_reg_0132_ip (
  target BIT(64),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_26_reg_0132_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0132_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0132_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0132_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0132_ip (target) VALUES (b'1010');
INSERT INTO t2_tc_26_reg_0132_ip (target) VALUES (b'11111111');
INSERT INTO t2_tc_26_reg_0132_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0132_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0132_ip (target) VALUES (b'1');
INSERT INTO t2_tc_26_reg_0132_ip (target) VALUES (b'0');
INSERT INTO t2_tc_26_reg_0132_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t2_tc_26_reg_0132_ip (target) VALUES (b'1010');
SELECT 'TC-26-REG-0132-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_26_reg_0132_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_26_reg_0132_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_26_reg_0132_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_26_reg_0132_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_26_reg_0132_ip a JOIN t2_tc_26_reg_0132_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;

-- Test Case: TC-26-ATR-0004-IP
-- Column attribute preservation: COMMENT
-- Type: BIT(32) -> BIT(64), Algorithm: inplace
DROP TABLE IF EXISTS t1_tc_26_atr_0004_ip, t2_tc_26_atr_0004_ip;
CREATE TABLE t1_tc_26_atr_0004_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target BIT(32) COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB;
INSERT INTO t1_tc_26_atr_0004_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_atr_0004_ip (target) VALUES (b'11111111111111111111111111111111');
INSERT INTO t1_tc_26_atr_0004_ip (target) VALUES (b'1');
INSERT INTO t1_tc_26_atr_0004_ip (target) VALUES (b'0');
INSERT INTO t1_tc_26_atr_0004_ip (target) VALUES (b'1010');
ALTER TABLE t1_tc_26_atr_0004_ip MODIFY target BIT(64) COMMENT 'test_comment', ALGORITHM=inplace;
INSERT INTO t1_tc_26_atr_0004_ip (target) VALUES (b'1111111111111111111111111111111111111111111111111111111111111111');
INSERT INTO t1_tc_26_atr_0004_ip (target) VALUES (b'111111111111111111111111111111111');
INSERT INTO t1_tc_26_atr_0004_ip (target) VALUES (b'1');
SELECT 'TC-26-ATR-0004-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_26_atr_0004_ip' AND column_name='target' AND column_comment='test_comment';

