-- ============================================================
-- RDS MySQL DDL 秒级/在线修改列类型 测试套件 — 内网环境
-- 环境说明: 所有功能开关默认开启
-- 覆盖类型: BINARY + VARBINARY + DECIMAL + TEXT + BLOB + BIT
-- 覆盖算法: INSTANT + INPLACE (增强类型 INSTANT 预期成功: BINARY/VARBINARY/DECIMAL 已确认支持)
-- ============================================================
-- 本文件由 generate_test_sql.py 自动生成, 请勿手动修改
-- Suite-Revision: 8d806086fd8b   (生成器源码哈希; 时间戳见 results/generation_manifest.json)
-- 用例 ID 规则: TC-<文件号>-<作用域>-<序号>-<IT|IP>  —— 全局唯一
--   作用域 REG=普通表 OFAT/二元组, ATR=列属性保持, SPE=特殊模式,
--          FK=外键, PTK=分区(目标列是分区键), PNK=分区(目标列非分区键)
-- ============================================================

SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
SET SESSION innodb_lock_wait_timeout = 50;

-- File 15: BINARY INPLACE

-- Test Case: TC-15-REG-0001-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=2f4bef57be02 column_type=binary(20) neg_probe=64cf4ef8407b=167|1264|1265|1406 neg_probe=59ecef63605a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0001_ip, t2_tc_15_reg_0001_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0001_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0001_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0001_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0001_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0001_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0001_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0001_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0001_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0001_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0001_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0001_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0001_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0001_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0001_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0001_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0001_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0001_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0001_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0001_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0001_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0001_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0001_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0001_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0001_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0001_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0001_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0001_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0001_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0001_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0001_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0001_ip);
-- probe 1/1 -> t1_tc_15_reg_0001_ip
INSERT INTO t1_tc_15_reg_0001_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0001_ip
INSERT INTO t2_tc_15_reg_0001_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0001-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0001_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0001_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0001_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0001_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0001-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0001_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0001_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0001_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0001_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0001_ip a JOIN t2_tc_15_reg_0001_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0001-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0001_ip' AND column_name='target';

-- Test Case: TC-15-REG-0002-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=980731f4ba70 column_type=binary(20) neg_probe=fad56cbd9311=167|1264|1265|1406 neg_probe=3e39f69e9eb9=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0002_ip, t2_tc_15_reg_0002_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0002_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t1_tc_15_reg_0002_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0002_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0002_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0002_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0002_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0002_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0002_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0002_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0002_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0002_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0002_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0002_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0002_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0002_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0002_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t2_tc_15_reg_0002_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0002_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0002_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0002_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0002_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0002_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0002_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0002_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0002_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0002_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0002_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0002_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0002_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0002_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0002_ip);
-- probe 1/1 -> t1_tc_15_reg_0002_ip
INSERT INTO t1_tc_15_reg_0002_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0002_ip
INSERT INTO t2_tc_15_reg_0002_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0002-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0002_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0002_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0002_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0002_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0002-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0002_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0002_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0002_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0002_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0002_ip a JOIN t2_tc_15_reg_0002_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0002-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0002_ip' AND column_name='target';

-- Test Case: TC-15-REG-0003-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=206ae9413e0d column_type=binary(20) neg_probe=b623ccda85ba=167|1264|1265|1406 neg_probe=5580ab54ae86=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0003_ip, t2_tc_15_reg_0003_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0003_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t1_tc_15_reg_0003_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0003_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0003_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0003_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0003_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0003_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0003_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0003_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0003_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0003_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0003_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0003_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0003_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0003_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0003_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t2_tc_15_reg_0003_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0003_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0003_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0003_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0003_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0003_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0003_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0003_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0003_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0003_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0003_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0003_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0003_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0003_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0003_ip);
-- probe 1/1 -> t1_tc_15_reg_0003_ip
INSERT INTO t1_tc_15_reg_0003_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0003_ip
INSERT INTO t2_tc_15_reg_0003_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0003-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0003_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0003_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0003_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0003_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0003-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0003_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0003_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0003_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0003_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0003_ip a JOIN t2_tc_15_reg_0003_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0003-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0003_ip' AND column_name='target';

-- Test Case: TC-15-REG-0004-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=3b624ea40f4c column_type=binary(20) neg_probe=3b0572919395=167|1264|1265|1406 neg_probe=2e7fbfd76c89=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0004_ip, t2_tc_15_reg_0004_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0004_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0004_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0004_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0004_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0004_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0004_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0004_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0004_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0004_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0004_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0004_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0004_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0004_ip (target) VALUES ('');
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0004_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0004_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0004_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0004_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0004_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0004_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0004_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0004_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0004_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0004_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0004_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0004_ip (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0004_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0004_ip);
-- probe 1/1 -> t1_tc_15_reg_0004_ip
INSERT INTO t1_tc_15_reg_0004_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0004_ip
INSERT INTO t2_tc_15_reg_0004_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0004-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0004_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0004_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0004_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0004_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0004-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0004_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0004_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0004_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0004_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0004_ip a JOIN t2_tc_15_reg_0004_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0004-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0004_ip' AND column_name='target';

-- Test Case: TC-15-REG-0005-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=d0f5ccfc74dc column_type=binary(20) neg_probe=86b8fccb6649=167|1264|1265|1406 neg_probe=4b4610fc0cbb=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0005_ip, t2_tc_15_reg_0005_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0005_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0005_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0005_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0005_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0005_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0005_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0005_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0005_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0005_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0005_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0005_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0005_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0005_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0005_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0005_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0005_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0005_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0005_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0005_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0005_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0005_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0005_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0005_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0005_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0005_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0005_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0005_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0005_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0005_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0005_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0005_ip);
-- probe 1/1 -> t1_tc_15_reg_0005_ip
INSERT INTO t1_tc_15_reg_0005_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0005_ip
INSERT INTO t2_tc_15_reg_0005_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0005-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0005_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0005_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0005_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0005_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0005-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0005_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0005_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0005_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0005_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0005_ip a JOIN t2_tc_15_reg_0005_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0005-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0005_ip' AND column_name='target';

-- Test Case: TC-15-REG-0006-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=33e97f803809 column_type=binary(20) neg_probe=8f82922632bc=167|1264|1265|1406 neg_probe=7d920e215104=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0006_ip, t2_tc_15_reg_0006_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0006_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0006_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0006_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0006_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0006_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0006_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0006_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0006_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0006_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0006_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0006_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0006_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0006_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0006_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0006_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0006_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0006_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0006_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0006_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0006_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0006_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0006_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0006_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0006_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0006_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0006_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0006_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0006_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0006_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0006_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0006_ip);
-- probe 1/1 -> t1_tc_15_reg_0006_ip
INSERT INTO t1_tc_15_reg_0006_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0006_ip
INSERT INTO t2_tc_15_reg_0006_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0006-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0006_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0006_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0006_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0006_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0006-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0006_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0006_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0006_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0006_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0006_ip a JOIN t2_tc_15_reg_0006_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0006-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0006_ip' AND column_name='target';

-- Test Case: TC-15-REG-0007-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=6601792314ca column_type=binary(20) neg_probe=ef435ff7ed14=167|1264|1265|1406 neg_probe=5355863f3156=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0007_ip, t2_tc_15_reg_0007_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0007_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0007_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0007_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0007_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0007_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0007_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0007_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0007_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0007_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0007_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0007_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0007_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0007_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0007_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0007_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0007_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0007_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0007_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0007_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0007_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0007_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0007_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0007_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0007_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0007_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0007_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0007_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0007_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0007_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0007_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0007_ip);
-- probe 1/1 -> t1_tc_15_reg_0007_ip
INSERT INTO t1_tc_15_reg_0007_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0007_ip
INSERT INTO t2_tc_15_reg_0007_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0007-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0007_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0007_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0007_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0007_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0007-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0007_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0007_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0007_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0007_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0007_ip a JOIN t2_tc_15_reg_0007_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0007-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0007_ip' AND column_name='target';

-- Test Case: TC-15-REG-0008-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=52dfb6fde246 column_type=binary(20) neg_probe=a5b2b54e8583=167|1264|1265|1406 neg_probe=80f522e41d80=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0008_ip, t2_tc_15_reg_0008_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0008_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0008_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0008_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0008_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0008_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0008_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0008_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0008_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0008_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0008_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0008_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0008_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0008_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0008_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0008_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0008_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0008_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0008_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0008_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0008_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0008_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0008_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0008_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0008_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0008_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0008_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0008_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0008_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0008_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0008_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0008_ip);
-- probe 1/1 -> t1_tc_15_reg_0008_ip
INSERT INTO t1_tc_15_reg_0008_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0008_ip
INSERT INTO t2_tc_15_reg_0008_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0008-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0008_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0008_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0008_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0008_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0008-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0008_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0008_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0008_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0008_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0008_ip a JOIN t2_tc_15_reg_0008_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0008-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0008_ip' AND column_name='target';

-- Test Case: TC-15-REG-0009-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=8ef0d4dd7fcf column_type=binary(20) neg_probe=5ab5959ba47c=167|1264|1265|1406 neg_probe=13743bb30dd4=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0009_ip, t2_tc_15_reg_0009_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0009_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0009_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0009_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0009_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0009_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0009_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0009_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0009_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0009_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0009_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0009_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0009_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0009_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0009_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0009_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0009_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0009_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0009_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0009_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0009_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0009_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0009_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0009_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0009_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0009_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0009_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0009_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0009_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0009_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0009_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0009_ip);
-- probe 1/1 -> t1_tc_15_reg_0009_ip
INSERT INTO t1_tc_15_reg_0009_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0009_ip
INSERT INTO t2_tc_15_reg_0009_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0009-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0009_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0009_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0009_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0009_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0009-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0009_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0009_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0009_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0009_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0009_ip a JOIN t2_tc_15_reg_0009_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0009-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0009_ip' AND column_name='target';

-- Test Case: TC-15-REG-0010-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=aff4be779bce column_type=binary(20) neg_probe=30736cd742c6=167|1264|1265|1406 neg_probe=e117e2de38f9=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0010_ip, t2_tc_15_reg_0010_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0010_ip (
  target BINARY(10),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0010_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0010_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0010_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0010_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0010_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0010_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0010_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0010_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0010_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0010_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0010_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0010_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0010_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0010_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0010_ip (
  target BINARY(20),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0010_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0010_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0010_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0010_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0010_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0010_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0010_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0010_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0010_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0010_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0010_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0010_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0010_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0010_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0010_ip);
-- probe 1/1 -> t1_tc_15_reg_0010_ip
INSERT INTO t1_tc_15_reg_0010_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0010_ip
INSERT INTO t2_tc_15_reg_0010_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0010-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0010_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0010_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0010_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0010_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0010-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0010_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0010_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0010_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0010_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0010_ip a JOIN t2_tc_15_reg_0010_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0010-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0010_ip' AND column_name='target';

-- Test Case: TC-15-REG-0011-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=21e66cd18c0b column_type=binary(20) neg_probe=6325ac1cfa9c=167|1264|1265|1406 neg_probe=00abacd51b56=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0011_ip, t2_tc_15_reg_0011_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0011_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BINARY(10), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0011_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0011_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0011_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0011_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0011_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0011_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0011_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0011_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0011_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0011_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0011_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0011_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0011_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0011_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0011_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BINARY(20), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0011_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0011_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0011_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0011_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0011_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0011_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0011_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0011_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0011_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0011_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0011_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0011_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0011_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0011_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0011_ip);
-- probe 1/1 -> t1_tc_15_reg_0011_ip
INSERT INTO t1_tc_15_reg_0011_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0011_ip
INSERT INTO t2_tc_15_reg_0011_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0011-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0011_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0011_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0011_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0011_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0011-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0011_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0011_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0011_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0011_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0011_ip a JOIN t2_tc_15_reg_0011_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0011-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=4,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=4]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0011_ip' AND column_name='target';

-- Test Case: TC-15-REG-0012-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=99cb2722aa2c column_type=binary(20) neg_probe=1210ff274059=167|1264|1265|1406 neg_probe=540cd873ba23=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0012_ip, t2_tc_15_reg_0012_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0012_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0012_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0012_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0012_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0012_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0012_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0012_ip MODIFY target BINARY(20) NOT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0012_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0012_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0012_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0012_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0012_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0012_ip (target) VALUES ('');
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0012_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0012_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0012_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0012_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0012_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0012_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0012_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0012_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0012_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0012_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0012_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0012_ip (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0012_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0012_ip);
-- probe 1/1 -> t1_tc_15_reg_0012_ip
INSERT INTO t1_tc_15_reg_0012_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0012_ip
INSERT INTO t2_tc_15_reg_0012_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0012-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0012_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0012_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0012_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0012_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0012-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0012_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0012_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0012_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0012_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0012_ip a JOIN t2_tc_15_reg_0012_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0012-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0012_ip' AND column_name='target';

-- Test Case: TC-15-REG-0013-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=95ce9b35e788 column_type=binary(20) neg_probe=1ce01ea18b56=167|1264|1265|1406 neg_probe=b37c8a880199=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0013_ip, t2_tc_15_reg_0013_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0013_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10) DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0013_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0013_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0013_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0013_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0013_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0013_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0013_ip MODIFY target BINARY(20) DEFAULT 0x00, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0013_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0013_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0013_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0013_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0013_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0013_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0013_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0013_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20) DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0013_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0013_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0013_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0013_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0013_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0013_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0013_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0013_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0013_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0013_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0013_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0013_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0013_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0013_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0013_ip);
-- probe 1/1 -> t1_tc_15_reg_0013_ip
INSERT INTO t1_tc_15_reg_0013_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0013_ip
INSERT INTO t2_tc_15_reg_0013_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0013-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0013_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0013_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0013_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0013_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0013-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0013_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0013_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0013_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0013_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0013_ip a JOIN t2_tc_15_reg_0013_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0013-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0013_ip' AND column_name='target';

-- Test Case: TC-15-REG-0014-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=9436fb666e74 column_type=binary(20) neg_probe=2d9cf23a7cc0=167|1264|1265|1406 neg_probe=4ba2917168b4=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0014_ip, t2_tc_15_reg_0014_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0014_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0014_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0014_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0014_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0014_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0014_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0014_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0014_ip MODIFY target BINARY(20) DEFAULT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0014_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0014_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0014_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0014_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0014_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0014_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0014_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0014_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0014_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0014_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0014_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0014_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0014_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0014_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0014_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0014_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0014_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0014_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0014_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0014_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0014_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0014_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0014_ip);
-- probe 1/1 -> t1_tc_15_reg_0014_ip
INSERT INTO t1_tc_15_reg_0014_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0014_ip
INSERT INTO t2_tc_15_reg_0014_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0014-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0014_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0014_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0014_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0014_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0014-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0014_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0014_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0014_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0014_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0014_ip a JOIN t2_tc_15_reg_0014_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0014-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0014_ip' AND column_name='target';

-- Test Case: TC-15-REG-0015-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=37702055dc62 column_type=binary(20) neg_probe=72d9a92f0937=167|1264|1265|1406 neg_probe=79544d89d43b=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0015_ip, t2_tc_15_reg_0015_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0015_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0015_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0015_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0015_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0015_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0015_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0015_ip MODIFY target BINARY(20) NOT NULL DEFAULT 0x00, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0015_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0015_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0015_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0015_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0015_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0015_ip (target) VALUES ('');
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0015_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0015_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0015_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0015_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0015_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0015_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0015_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0015_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0015_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0015_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0015_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0015_ip (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0015_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0015_ip);
-- probe 1/1 -> t1_tc_15_reg_0015_ip
INSERT INTO t1_tc_15_reg_0015_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0015_ip
INSERT INTO t2_tc_15_reg_0015_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0015-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0015_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0015_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0015_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0015_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0015-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0015_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0015_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0015_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0015_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0015_ip a JOIN t2_tc_15_reg_0015_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0015-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=NO has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0015_ip' AND column_name='target';

-- Test Case: TC-15-REG-0016-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=961534c1e3f0 column_type=binary(20) neg_probe=320a17e2af67=167|1264|1265|1406 neg_probe=b7b24eafbe7a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0016_ip, t2_tc_15_reg_0016_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0016_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0016_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0016_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0016_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0016_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0016_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0016_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0016_ip MODIFY target BINARY(20) INVISIBLE, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0016_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0016_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0016_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0016_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0016_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0016_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0016_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0016_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0016_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0016_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0016_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0016_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0016_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0016_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0016_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0016_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0016_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0016_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0016_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0016_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0016_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0016_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0016_ip);
-- probe 1/1 -> t1_tc_15_reg_0016_ip
INSERT INTO t1_tc_15_reg_0016_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0016_ip
INSERT INTO t2_tc_15_reg_0016_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0016-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0016_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0016_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0016_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0016_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0016-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0016_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0016_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0016_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0016_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0016_ip a JOIN t2_tc_15_reg_0016_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0016-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> 'INVISIBLE')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra=INVISIBLE pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0016_ip' AND column_name='target';

-- Test Case: TC-15-REG-0017-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=15e0dd6a5256 column_type=binary(20) neg_probe=20e01c0afab9=167|1264|1265|1406 neg_probe=c71503f66ac2=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0017_ip, t2_tc_15_reg_0017_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0017_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0017_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0017_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0017_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0017_ip);
-- probe 1/1 -> t1_tc_15_reg_0017_ip
INSERT INTO t1_tc_15_reg_0017_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0017_ip
INSERT INTO t2_tc_15_reg_0017_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0017-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0017_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0017_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0017_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0017_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0017-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0017_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0017_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0017_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0017_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0017_ip a JOIN t2_tc_15_reg_0017_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0017-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0017_ip' AND column_name='target';

-- Test Case: TC-15-REG-0018-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=feaa9ed3d137 column_type=binary(20) neg_probe=e805dfc03b6f=167|1264|1265|1406 neg_probe=bf27b99f209d=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0018_ip, t2_tc_15_reg_0018_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0018_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0018_ip (target) VALUES (0x00000000000000000000);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0018_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0018_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0018_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0018_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0018_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0018_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0018_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0018_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0018_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0018_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0018_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0018_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0018_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0018_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0018_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0018_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0018_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0018_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0018_ip);
-- probe 1/1 -> t1_tc_15_reg_0018_ip
INSERT INTO t1_tc_15_reg_0018_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0018_ip
INSERT INTO t2_tc_15_reg_0018_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0018-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0018_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0018_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0018_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0018_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0018-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0018_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0018_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0018_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0018_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0018_ip a JOIN t2_tc_15_reg_0018_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0018-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0018_ip' AND column_name='target';

-- Test Case: TC-15-REG-0019-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: BIN-01
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=edd84c728e2f column_type=binary(20) neg_probe=06283f57bd77=167|1264|1265|1406 neg_probe=88709ddc6d75=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0019_ip, t2_tc_15_reg_0019_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0019_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0019_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0019_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0019_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0019_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0019_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0019_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0019_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0019_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0019_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0019_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0019_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0019_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0019_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0019_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0019_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0019_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0019_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0019_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0019_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0019_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0019_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0019_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0019_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0019_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0019_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0019_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0019_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0019_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0019_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0019_ip);
-- probe 1/1 -> t1_tc_15_reg_0019_ip
INSERT INTO t1_tc_15_reg_0019_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0019_ip
INSERT INTO t2_tc_15_reg_0019_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0019-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0019_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0019_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0019_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0019_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0019-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0019_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0019_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0019_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0019_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0019_ip a JOIN t2_tc_15_reg_0019_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0019-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0019_ip' AND column_name='target';

-- Test Case: TC-15-REG-0020-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: BIN-01
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=760295526e4a column_type=binary(20) neg_probe=a44b67e23fad=167|1264|1265|1406 neg_probe=e8f2350505de=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0020_ip, t2_tc_15_reg_0020_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0020_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0020_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0020_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0020_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0020_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0020_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0020_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0020_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0020_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0020_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0020_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0020_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0020_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0020_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0020_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0020_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0020_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0020_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0020_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0020_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0020_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0020_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0020_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0020_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0020_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0020_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0020_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0020_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0020_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0020_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0020_ip);
-- probe 1/1 -> t1_tc_15_reg_0020_ip
INSERT INTO t1_tc_15_reg_0020_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0020_ip
INSERT INTO t2_tc_15_reg_0020_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0020-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0020_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0020_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0020_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0020_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0020-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0020_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0020_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0020_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0020_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0020_ip a JOIN t2_tc_15_reg_0020_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0020-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0020_ip' AND column_name='target';

-- Test Case: TC-15-REG-0021-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=5832c3249822 column_type=binary(20) neg_probe=ff6ec2438df1=167|1264|1265|1406 neg_probe=b4d42e1725b7=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0021_ip, t2_tc_15_reg_0021_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0021_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0021_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0021_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0021_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0021_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0021_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0021_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0021_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0021_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0021_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0021_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0021_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0021_ip (target) VALUES ('');
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0021_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0021_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0021_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0021_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0021_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0021_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0021_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0021_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0021_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0021_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0021_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0021_ip (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0021_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0021_ip);
-- probe 1/1 -> t1_tc_15_reg_0021_ip
INSERT INTO t1_tc_15_reg_0021_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0021_ip
INSERT INTO t2_tc_15_reg_0021_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0021-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0021_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0021_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0021_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0021_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0021-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0021_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0021_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0021_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0021_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0021_ip a JOIN t2_tc_15_reg_0021_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0021-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0021_ip' AND column_name='target';

-- Test Case: TC-15-REG-0022-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=a31da6ec461e column_type=binary(20) neg_probe=dd09c8a697ac=167|1264|1265|1406 neg_probe=d5567932a698=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0022_ip, t2_tc_15_reg_0022_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0022_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0022_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0022_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0022_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0022_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0022_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0022_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0022_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0022_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0022_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0022_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0022_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0022_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0022_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0022_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0022_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0022_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0022_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0022_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0022_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0022_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0022_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0022_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0022_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0022_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0022_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0022_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0022_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0022_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0022_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0022_ip);
-- probe 1/1 -> t1_tc_15_reg_0022_ip
INSERT INTO t1_tc_15_reg_0022_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0022_ip
INSERT INTO t2_tc_15_reg_0022_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0022-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0022_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0022_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0022_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0022_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0022-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0022_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0022_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0022_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0022_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0022_ip a JOIN t2_tc_15_reg_0022_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0022-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0022_ip' AND column_name='target';

-- Test Case: TC-15-REG-0023-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=097e9adc0086 column_type=binary(20) neg_probe=2654de48c378=167|1264|1265|1406 neg_probe=5f5f8a9459b6=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0023_ip, t2_tc_15_reg_0023_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0023_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0023_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0023_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0023_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0023_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0023_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0023_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0023_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0023_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0023_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0023_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0023_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0023_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0023_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0023_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0023_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0023_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0023_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0023_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0023_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0023_ip);
-- probe 1/1 -> t1_tc_15_reg_0023_ip
INSERT INTO t1_tc_15_reg_0023_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0023_ip
INSERT INTO t2_tc_15_reg_0023_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0023-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0023_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0023_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0023_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0023_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0023-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0023_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0023_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0023_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0023_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0023_ip a JOIN t2_tc_15_reg_0023_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0023-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0023_ip' AND column_name='target';

-- Test Case: TC-15-REG-0024-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=SECONDARY_INDEX
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=SECONDARY_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=6621da5c8d1a column_type=binary(20) neg_probe=cf232457f000=167|1264|1265|1406 neg_probe=34ad59c746ca=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0024_ip, t2_tc_15_reg_0024_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0024_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0024_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0024_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0024_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0024_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0024_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0024_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0024_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0024_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0024_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0024_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0024_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0024_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0024_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0024_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0024_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0024_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0024_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0024_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0024_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0024_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0024_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0024_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0024_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0024_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0024_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0024_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0024_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0024_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0024_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0024_ip);
-- probe 1/1 -> t1_tc_15_reg_0024_ip
INSERT INTO t1_tc_15_reg_0024_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0024_ip
INSERT INTO t2_tc_15_reg_0024_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0024-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0024_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0024_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0024_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0024_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0024-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0024_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0024_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0024_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0024_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0024_ip a JOIN t2_tc_15_reg_0024_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0024-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0024_ip' AND column_name='target';

-- Test Case: TC-15-REG-0025-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=UNIQUE_INDEX
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=0fcb7c7509f2 column_type=binary(20) neg_probe=c84a2864f403=167|1264|1265|1406 neg_probe=30edde601886=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0025_ip, t2_tc_15_reg_0025_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0025_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0025_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0025_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0025_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0025_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0025_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0025_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0025_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0025_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0025_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0025_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0025_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0025_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0025_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0025_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0025_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0025_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0025_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0025_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0025_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0025_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0025_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0025_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0025_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0025_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0025_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0025_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0025_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0025_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0025_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0025_ip);
-- probe 1/1 -> t1_tc_15_reg_0025_ip
INSERT INTO t1_tc_15_reg_0025_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0025_ip
INSERT INTO t2_tc_15_reg_0025_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0025-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0025_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0025_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0025_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0025_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0025-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0025_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0025_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0025_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0025_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0025_ip a JOIN t2_tc_15_reg_0025_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0025-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0025_ip' AND column_name='target';

-- Test Case: TC-15-REG-0026-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=FOREIGN_KEY
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=FOREIGN_KEY, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=5e0c44fc14bf column_type=binary(20) neg_probe=3fd2176e07d6=167|1264|1265|1406 neg_probe=27366ad0a39a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0026_ip, t2_tc_15_reg_0026_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0026_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0026_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0026_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0026_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0026_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0026_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0026_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0026_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0026_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0026_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0026_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0026_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0026_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0026_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0026_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0026_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0026_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0026_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0026_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0026_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0026_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0026_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0026_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0026_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0026_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0026_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0026_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0026_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0026_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0026_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0026_ip);
-- probe 1/1 -> t1_tc_15_reg_0026_ip
INSERT INTO t1_tc_15_reg_0026_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0026_ip
INSERT INTO t2_tc_15_reg_0026_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0026-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0026_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0026_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0026_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0026_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0026-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0026_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0026_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0026_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0026_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0026_ip a JOIN t2_tc_15_reg_0026_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0026-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0026_ip' AND column_name='target';

-- Test Case: TC-15-REG-0027-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: FAIL
-- Varied factor: dependencies=CHECK
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=CHECK, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=FAIL build=SUCCESS assertions=3 neg_probes=1 alter_sha=8ac85f85a833 errno=[1659,1845,1846,3780] column_type=binary(10) neg_probe=9e6043757bc7=167|1264|1265|1406 neg_probe=4f6b4c30710a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0027_ip, t2_tc_15_reg_0027_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0027_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0027_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0027_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0027_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0027_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0027_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0027_ip (target) VALUES (NULL);
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_15_reg_0027_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0027_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0027_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0027_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0027_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0027_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0027_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0027_ip (target) VALUES (NULL);
-- Oracle table: BINARY(10)
CREATE TABLE t2_tc_15_reg_0027_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0027_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0027_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0027_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0027_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0027_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0027_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0027_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0027_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0027_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0027_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0027_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0027_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0027_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0027_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0027_ip);
-- probe 1/1 -> t1_tc_15_reg_0027_ip
INSERT INTO t1_tc_15_reg_0027_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0027_ip
INSERT INTO t2_tc_15_reg_0027_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0027-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0027_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0027_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0027_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0027_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0027-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0027_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0027_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0027_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0027_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0027_ip a JOIN t2_tc_15_reg_0027_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0027-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(10)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(10) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0027_ip' AND column_name='target';

-- Test Case: TC-15-REG-0028-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=8a93e69a4585 column_type=binary(20) neg_probe=19e35eee9da9=ACCEPTED neg_probe=70e17f3edb07=ACCEPTED
DROP TABLE IF EXISTS t1_tc_15_reg_0028_ip, t2_tc_15_reg_0028_ip;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_15_reg_0028_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0028_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0028_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0028_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0028_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0028_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0028_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0028_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0028_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0028_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0028_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0028_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0028_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0028_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0028_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0028_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0028_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0028_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0028_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0028_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0028_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0028_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0028_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0028_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0028_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0028_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0028_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0028_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0028_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0028_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0028_ip);
-- probe 1/1 -> t1_tc_15_reg_0028_ip
INSERT INTO t1_tc_15_reg_0028_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0028_ip
INSERT INTO t2_tc_15_reg_0028_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0028-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0028_ip) - @neg_before_t1 = (SELECT COUNT(*) FROM t2_tc_15_reg_0028_ip) - @neg_before_t2,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0028_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0028_ip) - @neg_before_t2,' expect=t1_added = t2_added (非 STRICT: 截断行为必须与对照表一致) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0028-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0028_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0028_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0028_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0028_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0028_ip a JOIN t2_tc_15_reg_0028_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0028-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0028_ip' AND column_name='target';

-- Test Case: TC-15-REG-0029-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=b3bc3264973d column_type=binary(20) neg_probe=e9fec7391d59=167|1264|1265|1406 neg_probe=3c86a13b5918=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0029_ip, t2_tc_15_reg_0029_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0029_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0029_ip MODIFY target BINARY(20) NOT NULL, ALGORITHM=inplace;
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0029_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0029_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0029_ip);
-- probe 1/1 -> t1_tc_15_reg_0029_ip
INSERT INTO t1_tc_15_reg_0029_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0029_ip
INSERT INTO t2_tc_15_reg_0029_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0029-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0029_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0029_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0029_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0029_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0029-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0029_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0029_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0029_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0029_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0029_ip a JOIN t2_tc_15_reg_0029_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0029-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0029_ip' AND column_name='target';

-- Test Case: TC-15-REG-0030-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-02
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=00eaf74493cc column_type=binary(20) neg_probe=6f74cf3fdc5a=167|1264|1265|1406 neg_probe=ed844cd42caf=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0030_ip, t2_tc_15_reg_0030_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0030_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0030_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0030_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0030_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0030_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0030_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0030_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0030_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0030_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0030_ip (target) VALUES (NULL);
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0030_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0030_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0030_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0030_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0030_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0030_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0030_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0030_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0030_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0030_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0030_ip);
-- probe 1/1 -> t1_tc_15_reg_0030_ip
INSERT INTO t1_tc_15_reg_0030_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0030_ip
INSERT INTO t2_tc_15_reg_0030_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0030-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0030_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0030_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0030_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0030_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0030-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0030_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0030_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0030_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0030_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0030_ip a JOIN t2_tc_15_reg_0030_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0030-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0030_ip' AND column_name='target';

-- Test Case: TC-15-REG-0031-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: BIN-01
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=45006c3dbe35 column_type=binary(20) neg_probe=7e622d1604ff=167|1264|1265|1406 neg_probe=6b9dc9a922a7=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0031_ip, t2_tc_15_reg_0031_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0031_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0031_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0031_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0031_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0031_ip);
-- probe 1/1 -> t1_tc_15_reg_0031_ip
INSERT INTO t1_tc_15_reg_0031_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0031_ip
INSERT INTO t2_tc_15_reg_0031_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0031-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0031_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0031_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0031_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0031_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0031-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0031_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0031_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0031_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0031_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0031_ip a JOIN t2_tc_15_reg_0031_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0031-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0031_ip' AND column_name='target';

-- Test Case: TC-15-REG-0032-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=fb3b6db7c72d column_type=binary(20) neg_probe=0a74a63689fd=167|1264|1265|1406 neg_probe=124b6d07e0ad=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0032_ip, t2_tc_15_reg_0032_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0032_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(10) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0032_ip MODIFY target BINARY(20) NOT NULL DEFAULT 0x00, ALGORITHM=inplace;
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0032_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(20) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0032_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0032_ip);
-- probe 1/1 -> t1_tc_15_reg_0032_ip
INSERT INTO t1_tc_15_reg_0032_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0032_ip
INSERT INTO t2_tc_15_reg_0032_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0032-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0032_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0032_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0032_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0032_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0032-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0032_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0032_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0032_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0032_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0032_ip a JOIN t2_tc_15_reg_0032_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0032-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=NO has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0032_ip' AND column_name='target';

-- Test Case: TC-15-REG-0033-IP
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-05
-- Transition ID: BIN-01
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=1b55dae8ac36 column_type=binary(20) neg_probe=48a57aade44d=167|1264|1265|1406 neg_probe=61e8cb9d7e04=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0033_ip, t2_tc_15_reg_0033_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0033_ip (
  target BINARY(10),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0033_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0033_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0033_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_reg_0033_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_reg_0033_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0033_ip MODIFY target BINARY(20), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0033_ip (target) VALUES (0x0000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0033_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0033_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0033_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_reg_0033_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0033_ip (target) VALUES ('');
-- Oracle table: BINARY(20)
CREATE TABLE t2_tc_15_reg_0033_ip (
  target BINARY(20),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0033_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0033_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0033_ip (target) VALUES (0x000000000000000000);
INSERT INTO t2_tc_15_reg_0033_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t2_tc_15_reg_0033_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0033_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0033_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0033_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0033_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t2_tc_15_reg_0033_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0033_ip (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0033_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0033_ip);
-- probe 1/1 -> t1_tc_15_reg_0033_ip
INSERT INTO t1_tc_15_reg_0033_ip (target) VALUES (0x414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0033_ip
INSERT INTO t2_tc_15_reg_0033_ip (target) VALUES (0x414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0033-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0033_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0033_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0033_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0033_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0033-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0033_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0033_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0033_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0033_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0033_ip a JOIN t2_tc_15_reg_0033_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0033-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0033_ip' AND column_name='target';

-- Test Case: TC-15-ATR-0001-IP
-- Column attribute preservation: COMMENT
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace
-- Transition ID: BIN-01
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=37e43627ff10 column_type=binary(20)
DROP TABLE IF EXISTS t1_tc_15_atr_0001_ip, t2_tc_15_atr_0001_ip;
CREATE TABLE t1_tc_15_atr_0001_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target BINARY(10) COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB;
INSERT INTO t1_tc_15_atr_0001_ip (target) VALUES (0x00000000000000000000);
INSERT INTO t1_tc_15_atr_0001_ip (target) VALUES (0xffffffffffffffffffff);
INSERT INTO t1_tc_15_atr_0001_ip (target) VALUES (0x000000000000000000);
INSERT INTO t1_tc_15_atr_0001_ip (target) VALUES (0x41424142414241424142);
INSERT INTO t1_tc_15_atr_0001_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_atr_0001_ip MODIFY target BINARY(20) COMMENT 'test_comment', ALGORITHM=inplace;
INSERT INTO t1_tc_15_atr_0001_ip (target) VALUES (0x0000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_atr_0001_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_atr_0001_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d4d);
SELECT 'TC-15-ATR-0001-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_15_atr_0001_ip' AND column_name='target' AND column_comment='test_comment';
SELECT 'TC-15-ATR-0001-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_atr_0001_ip' AND column_name='target';

-- Test Case: TC-15-REG-0034-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=c2dde0dd76f6 column_type=binary(80) neg_probe=e33fa1cc29e8=167|1264|1265|1406 neg_probe=d4fecb8871ba=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0034_ip, t2_tc_15_reg_0034_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0034_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0034_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0034_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0034_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0034_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0034_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0034_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0034_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0034_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0034_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0034_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0034_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0034_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0034_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0034_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0034_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0034_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0034_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0034_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0034_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0034_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0034_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0034_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0034_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0034_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0034_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0034_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0034_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0034_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0034_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0034_ip);
-- probe 1/1 -> t1_tc_15_reg_0034_ip
INSERT INTO t1_tc_15_reg_0034_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0034_ip
INSERT INTO t2_tc_15_reg_0034_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0034-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0034_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0034_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0034_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0034_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0034-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0034_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0034_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0034_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0034_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0034_ip a JOIN t2_tc_15_reg_0034_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0034-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0034_ip' AND column_name='target';

-- Test Case: TC-15-REG-0035-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=59f06cff9ae5 column_type=binary(80) neg_probe=0897ebd2b080=167|1264|1265|1406 neg_probe=54f3bfc7839b=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0035_ip, t2_tc_15_reg_0035_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0035_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t1_tc_15_reg_0035_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0035_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0035_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0035_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0035_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0035_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0035_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0035_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0035_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0035_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0035_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0035_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0035_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0035_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0035_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t2_tc_15_reg_0035_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0035_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0035_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0035_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0035_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0035_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0035_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0035_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0035_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0035_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0035_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0035_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0035_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0035_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0035_ip);
-- probe 1/1 -> t1_tc_15_reg_0035_ip
INSERT INTO t1_tc_15_reg_0035_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0035_ip
INSERT INTO t2_tc_15_reg_0035_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0035-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0035_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0035_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0035_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0035_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0035-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0035_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0035_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0035_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0035_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0035_ip a JOIN t2_tc_15_reg_0035_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0035-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0035_ip' AND column_name='target';

-- Test Case: TC-15-REG-0036-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=5124fbf4c5a7 column_type=binary(80) neg_probe=a627b479559f=167|1264|1265|1406 neg_probe=b8aa259b5972=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0036_ip, t2_tc_15_reg_0036_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0036_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t1_tc_15_reg_0036_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0036_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0036_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0036_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0036_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0036_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0036_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0036_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0036_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0036_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0036_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0036_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0036_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0036_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0036_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t2_tc_15_reg_0036_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0036_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0036_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0036_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0036_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0036_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0036_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0036_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0036_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0036_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0036_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0036_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0036_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0036_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0036_ip);
-- probe 1/1 -> t1_tc_15_reg_0036_ip
INSERT INTO t1_tc_15_reg_0036_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0036_ip
INSERT INTO t2_tc_15_reg_0036_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0036-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0036_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0036_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0036_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0036_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0036-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0036_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0036_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0036_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0036_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0036_ip a JOIN t2_tc_15_reg_0036_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0036-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0036_ip' AND column_name='target';

-- Test Case: TC-15-REG-0037-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=4af23c90aa05 column_type=binary(80) neg_probe=a92927d5483d=167|1264|1265|1406 neg_probe=2a9877e409ab=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0037_ip, t2_tc_15_reg_0037_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0037_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0037_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0037_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0037_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0037_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0037_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0037_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0037_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0037_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0037_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0037_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0037_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0037_ip (target) VALUES ('');
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0037_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0037_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0037_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0037_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0037_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0037_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0037_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0037_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0037_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0037_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0037_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0037_ip (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0037_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0037_ip);
-- probe 1/1 -> t1_tc_15_reg_0037_ip
INSERT INTO t1_tc_15_reg_0037_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0037_ip
INSERT INTO t2_tc_15_reg_0037_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0037-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0037_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0037_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0037_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0037_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0037-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0037_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0037_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0037_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0037_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0037_ip a JOIN t2_tc_15_reg_0037_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0037-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0037_ip' AND column_name='target';

-- Test Case: TC-15-REG-0038-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=db51a4036038 column_type=binary(80) neg_probe=196f85a23055=167|1264|1265|1406 neg_probe=396d3087c315=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0038_ip, t2_tc_15_reg_0038_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0038_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0038_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0038_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0038_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0038_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0038_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0038_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0038_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0038_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0038_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0038_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0038_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0038_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0038_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0038_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0038_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0038_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0038_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0038_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0038_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0038_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0038_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0038_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0038_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0038_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0038_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0038_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0038_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0038_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0038_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0038_ip);
-- probe 1/1 -> t1_tc_15_reg_0038_ip
INSERT INTO t1_tc_15_reg_0038_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0038_ip
INSERT INTO t2_tc_15_reg_0038_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0038-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0038_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0038_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0038_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0038_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0038-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0038_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0038_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0038_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0038_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0038_ip a JOIN t2_tc_15_reg_0038_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0038-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0038_ip' AND column_name='target';

-- Test Case: TC-15-REG-0039-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=58b4ecc772e1 column_type=binary(80) neg_probe=e2d964d7c430=167|1264|1265|1406 neg_probe=351db59ba244=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0039_ip, t2_tc_15_reg_0039_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0039_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0039_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0039_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0039_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0039_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0039_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0039_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0039_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0039_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0039_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0039_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0039_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0039_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0039_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0039_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0039_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0039_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0039_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0039_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0039_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0039_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0039_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0039_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0039_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0039_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0039_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0039_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0039_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0039_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0039_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0039_ip);
-- probe 1/1 -> t1_tc_15_reg_0039_ip
INSERT INTO t1_tc_15_reg_0039_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0039_ip
INSERT INTO t2_tc_15_reg_0039_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0039-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0039_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0039_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0039_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0039_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0039-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0039_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0039_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0039_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0039_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0039_ip a JOIN t2_tc_15_reg_0039_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0039-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0039_ip' AND column_name='target';

-- Test Case: TC-15-REG-0040-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=641f21b2d25e column_type=binary(80) neg_probe=3d3d7266f5bc=167|1264|1265|1406 neg_probe=934c52338db5=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0040_ip, t2_tc_15_reg_0040_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0040_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0040_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0040_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0040_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0040_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0040_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0040_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0040_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0040_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0040_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0040_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0040_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0040_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0040_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0040_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0040_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0040_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0040_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0040_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0040_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0040_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0040_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0040_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0040_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0040_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0040_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0040_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0040_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0040_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0040_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0040_ip);
-- probe 1/1 -> t1_tc_15_reg_0040_ip
INSERT INTO t1_tc_15_reg_0040_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0040_ip
INSERT INTO t2_tc_15_reg_0040_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0040-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0040_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0040_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0040_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0040_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0040-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0040_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0040_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0040_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0040_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0040_ip a JOIN t2_tc_15_reg_0040_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0040-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0040_ip' AND column_name='target';

-- Test Case: TC-15-REG-0041-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=1e12e16552cf column_type=binary(80) neg_probe=6d3cfdc8f73d=167|1264|1265|1406 neg_probe=b2be6fc9c6d5=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0041_ip, t2_tc_15_reg_0041_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0041_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0041_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0041_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0041_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0041_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0041_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0041_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0041_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0041_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0041_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0041_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0041_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0041_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0041_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0041_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0041_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0041_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0041_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0041_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0041_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0041_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0041_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0041_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0041_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0041_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0041_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0041_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0041_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0041_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0041_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0041_ip);
-- probe 1/1 -> t1_tc_15_reg_0041_ip
INSERT INTO t1_tc_15_reg_0041_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0041_ip
INSERT INTO t2_tc_15_reg_0041_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0041-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0041_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0041_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0041_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0041_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0041-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0041_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0041_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0041_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0041_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0041_ip a JOIN t2_tc_15_reg_0041_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0041-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0041_ip' AND column_name='target';

-- Test Case: TC-15-REG-0042-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=a6080f00393a column_type=binary(80) neg_probe=5661bfbbc11e=167|1264|1265|1406 neg_probe=572ea8f4e4c0=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0042_ip, t2_tc_15_reg_0042_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0042_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0042_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0042_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0042_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0042_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0042_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0042_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0042_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0042_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0042_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0042_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0042_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0042_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0042_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0042_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0042_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0042_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0042_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0042_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0042_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0042_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0042_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0042_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0042_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0042_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0042_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0042_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0042_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0042_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0042_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0042_ip);
-- probe 1/1 -> t1_tc_15_reg_0042_ip
INSERT INTO t1_tc_15_reg_0042_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0042_ip
INSERT INTO t2_tc_15_reg_0042_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0042-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0042_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0042_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0042_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0042_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0042-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0042_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0042_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0042_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0042_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0042_ip a JOIN t2_tc_15_reg_0042_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0042-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0042_ip' AND column_name='target';

-- Test Case: TC-15-REG-0043-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=ad164365d695 column_type=binary(80) neg_probe=beaccdc4336d=167|1264|1265|1406 neg_probe=a6f6991b6618=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0043_ip, t2_tc_15_reg_0043_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0043_ip (
  target BINARY(40),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0043_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0043_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0043_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0043_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0043_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0043_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0043_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0043_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0043_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0043_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0043_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0043_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0043_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0043_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0043_ip (
  target BINARY(80),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0043_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0043_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0043_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0043_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0043_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0043_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0043_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0043_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0043_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0043_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0043_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0043_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0043_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0043_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0043_ip);
-- probe 1/1 -> t1_tc_15_reg_0043_ip
INSERT INTO t1_tc_15_reg_0043_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0043_ip
INSERT INTO t2_tc_15_reg_0043_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0043-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0043_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0043_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0043_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0043_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0043-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0043_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0043_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0043_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0043_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0043_ip a JOIN t2_tc_15_reg_0043_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0043-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0043_ip' AND column_name='target';

-- Test Case: TC-15-REG-0044-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=78b5c59c70e3 column_type=binary(80) neg_probe=3481e169d505=167|1264|1265|1406 neg_probe=f5e13f93d9b6=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0044_ip, t2_tc_15_reg_0044_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0044_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BINARY(40), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0044_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0044_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0044_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0044_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0044_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0044_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0044_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0044_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0044_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0044_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0044_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0044_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0044_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0044_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0044_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BINARY(80), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0044_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0044_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0044_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0044_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0044_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0044_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0044_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0044_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0044_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0044_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0044_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0044_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0044_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0044_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0044_ip);
-- probe 1/1 -> t1_tc_15_reg_0044_ip
INSERT INTO t1_tc_15_reg_0044_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0044_ip
INSERT INTO t2_tc_15_reg_0044_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0044-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0044_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0044_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0044_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0044_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0044-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0044_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0044_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0044_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0044_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0044_ip a JOIN t2_tc_15_reg_0044_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0044-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=4,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=4]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0044_ip' AND column_name='target';

-- Test Case: TC-15-REG-0045-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=389043478571 column_type=binary(80) neg_probe=92bbcd6d0ed3=167|1264|1265|1406 neg_probe=59b316c93f92=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0045_ip, t2_tc_15_reg_0045_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0045_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0045_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0045_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0045_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0045_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0045_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0045_ip MODIFY target BINARY(80) NOT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0045_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0045_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0045_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0045_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0045_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0045_ip (target) VALUES ('');
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0045_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0045_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0045_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0045_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0045_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0045_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0045_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0045_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0045_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0045_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0045_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0045_ip (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0045_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0045_ip);
-- probe 1/1 -> t1_tc_15_reg_0045_ip
INSERT INTO t1_tc_15_reg_0045_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0045_ip
INSERT INTO t2_tc_15_reg_0045_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0045-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0045_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0045_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0045_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0045_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0045-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0045_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0045_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0045_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0045_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0045_ip a JOIN t2_tc_15_reg_0045_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0045-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0045_ip' AND column_name='target';

-- Test Case: TC-15-REG-0046-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=f88a51ff48b5 column_type=binary(80) neg_probe=0b35418bdb13=167|1264|1265|1406 neg_probe=a700fa524484=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0046_ip, t2_tc_15_reg_0046_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0046_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40) DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0046_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0046_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0046_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0046_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0046_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0046_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0046_ip MODIFY target BINARY(80) DEFAULT 0x00, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0046_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0046_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0046_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0046_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0046_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0046_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0046_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0046_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80) DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0046_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0046_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0046_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0046_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0046_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0046_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0046_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0046_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0046_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0046_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0046_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0046_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0046_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0046_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0046_ip);
-- probe 1/1 -> t1_tc_15_reg_0046_ip
INSERT INTO t1_tc_15_reg_0046_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0046_ip
INSERT INTO t2_tc_15_reg_0046_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0046-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0046_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0046_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0046_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0046_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0046-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0046_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0046_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0046_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0046_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0046_ip a JOIN t2_tc_15_reg_0046_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0046-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0046_ip' AND column_name='target';

-- Test Case: TC-15-REG-0047-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=ec5a1a48e2eb column_type=binary(80) neg_probe=51f553cad06e=167|1264|1265|1406 neg_probe=b07d4c036a2f=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0047_ip, t2_tc_15_reg_0047_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0047_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0047_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0047_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0047_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0047_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0047_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0047_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0047_ip MODIFY target BINARY(80) DEFAULT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0047_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0047_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0047_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0047_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0047_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0047_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0047_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0047_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0047_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0047_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0047_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0047_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0047_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0047_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0047_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0047_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0047_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0047_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0047_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0047_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0047_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0047_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0047_ip);
-- probe 1/1 -> t1_tc_15_reg_0047_ip
INSERT INTO t1_tc_15_reg_0047_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0047_ip
INSERT INTO t2_tc_15_reg_0047_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0047-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0047_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0047_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0047_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0047_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0047-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0047_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0047_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0047_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0047_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0047_ip a JOIN t2_tc_15_reg_0047_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0047-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0047_ip' AND column_name='target';

-- Test Case: TC-15-REG-0048-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=e2e29f601242 column_type=binary(80) neg_probe=6c9b71c1d51c=167|1264|1265|1406 neg_probe=42379947f8a3=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0048_ip, t2_tc_15_reg_0048_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0048_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0048_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0048_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0048_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0048_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0048_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0048_ip MODIFY target BINARY(80) NOT NULL DEFAULT 0x00, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0048_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0048_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0048_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0048_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0048_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0048_ip (target) VALUES ('');
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0048_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0048_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0048_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0048_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0048_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0048_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0048_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0048_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0048_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0048_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0048_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0048_ip (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0048_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0048_ip);
-- probe 1/1 -> t1_tc_15_reg_0048_ip
INSERT INTO t1_tc_15_reg_0048_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0048_ip
INSERT INTO t2_tc_15_reg_0048_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0048-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0048_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0048_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0048_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0048_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0048-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0048_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0048_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0048_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0048_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0048_ip a JOIN t2_tc_15_reg_0048_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0048-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=NO has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0048_ip' AND column_name='target';

-- Test Case: TC-15-REG-0049-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=d95060fcb0ac column_type=binary(80) neg_probe=9d2cab370c08=167|1264|1265|1406 neg_probe=11c7607b4bf9=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0049_ip, t2_tc_15_reg_0049_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0049_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0049_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0049_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0049_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0049_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0049_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0049_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0049_ip MODIFY target BINARY(80) INVISIBLE, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0049_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0049_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0049_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0049_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0049_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0049_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0049_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0049_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0049_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0049_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0049_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0049_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0049_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0049_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0049_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0049_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0049_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0049_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0049_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0049_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0049_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0049_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0049_ip);
-- probe 1/1 -> t1_tc_15_reg_0049_ip
INSERT INTO t1_tc_15_reg_0049_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0049_ip
INSERT INTO t2_tc_15_reg_0049_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0049-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0049_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0049_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0049_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0049_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0049-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0049_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0049_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0049_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0049_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0049_ip a JOIN t2_tc_15_reg_0049_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0049-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> 'INVISIBLE')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra=INVISIBLE pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0049_ip' AND column_name='target';

-- Test Case: TC-15-REG-0050-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=4b12b85fc215 column_type=binary(80) neg_probe=2ab75fa121ee=167|1264|1265|1406 neg_probe=3fb95ccf4f00=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0050_ip, t2_tc_15_reg_0050_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0050_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0050_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0050_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0050_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0050_ip);
-- probe 1/1 -> t1_tc_15_reg_0050_ip
INSERT INTO t1_tc_15_reg_0050_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0050_ip
INSERT INTO t2_tc_15_reg_0050_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0050-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0050_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0050_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0050_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0050_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0050-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0050_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0050_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0050_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0050_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0050_ip a JOIN t2_tc_15_reg_0050_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0050-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0050_ip' AND column_name='target';

-- Test Case: TC-15-REG-0051-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=799b9496be55 column_type=binary(80) neg_probe=8b725934f576=167|1264|1265|1406 neg_probe=9c7432dc223f=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0051_ip, t2_tc_15_reg_0051_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0051_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0051_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0051_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0051_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0051_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0051_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0051_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0051_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0051_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0051_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0051_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0051_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0051_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0051_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0051_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0051_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0051_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0051_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0051_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0051_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0051_ip);
-- probe 1/1 -> t1_tc_15_reg_0051_ip
INSERT INTO t1_tc_15_reg_0051_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0051_ip
INSERT INTO t2_tc_15_reg_0051_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0051-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0051_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0051_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0051_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0051_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0051-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0051_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0051_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0051_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0051_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0051_ip a JOIN t2_tc_15_reg_0051_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0051-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0051_ip' AND column_name='target';

-- Test Case: TC-15-REG-0052-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: BIN-02
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=a13a25bccb94 column_type=binary(80) neg_probe=659164214a63=167|1264|1265|1406 neg_probe=06d9615ff4bd=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0052_ip, t2_tc_15_reg_0052_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0052_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0052_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0052_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0052_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0052_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0052_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0052_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0052_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0052_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0052_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0052_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0052_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0052_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0052_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0052_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0052_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0052_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0052_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0052_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0052_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0052_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0052_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0052_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0052_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0052_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0052_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0052_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0052_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0052_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0052_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0052_ip);
-- probe 1/1 -> t1_tc_15_reg_0052_ip
INSERT INTO t1_tc_15_reg_0052_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0052_ip
INSERT INTO t2_tc_15_reg_0052_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0052-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0052_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0052_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0052_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0052_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0052-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0052_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0052_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0052_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0052_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0052_ip a JOIN t2_tc_15_reg_0052_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0052-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0052_ip' AND column_name='target';

-- Test Case: TC-15-REG-0053-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: BIN-02
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=ae676c18921d column_type=binary(80) neg_probe=e913d21edcbb=167|1264|1265|1406 neg_probe=5b06a6a05a5e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0053_ip, t2_tc_15_reg_0053_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0053_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0053_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0053_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0053_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0053_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0053_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0053_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0053_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0053_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0053_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0053_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0053_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0053_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0053_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0053_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0053_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0053_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0053_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0053_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0053_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0053_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0053_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0053_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0053_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0053_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0053_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0053_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0053_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0053_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0053_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0053_ip);
-- probe 1/1 -> t1_tc_15_reg_0053_ip
INSERT INTO t1_tc_15_reg_0053_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0053_ip
INSERT INTO t2_tc_15_reg_0053_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0053-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0053_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0053_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0053_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0053_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0053-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0053_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0053_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0053_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0053_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0053_ip a JOIN t2_tc_15_reg_0053_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0053-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0053_ip' AND column_name='target';

-- Test Case: TC-15-REG-0054-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=a37a62c36006 column_type=binary(80) neg_probe=88bf510d08ab=167|1264|1265|1406 neg_probe=2ce75dfcf0a1=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0054_ip, t2_tc_15_reg_0054_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0054_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0054_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0054_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0054_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0054_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0054_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0054_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0054_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0054_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0054_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0054_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0054_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0054_ip (target) VALUES ('');
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0054_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0054_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0054_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0054_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0054_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0054_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0054_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0054_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0054_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0054_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0054_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0054_ip (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0054_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0054_ip);
-- probe 1/1 -> t1_tc_15_reg_0054_ip
INSERT INTO t1_tc_15_reg_0054_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0054_ip
INSERT INTO t2_tc_15_reg_0054_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0054-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0054_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0054_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0054_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0054_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0054-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0054_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0054_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0054_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0054_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0054_ip a JOIN t2_tc_15_reg_0054_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0054-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0054_ip' AND column_name='target';

-- Test Case: TC-15-REG-0055-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=4f1fbb4b7c04 column_type=binary(80) neg_probe=20863d304099=167|1264|1265|1406 neg_probe=94a60ec447e6=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0055_ip, t2_tc_15_reg_0055_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0055_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0055_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0055_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0055_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0055_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0055_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0055_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0055_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0055_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0055_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0055_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0055_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0055_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0055_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0055_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0055_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0055_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0055_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0055_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0055_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0055_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0055_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0055_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0055_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0055_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0055_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0055_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0055_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0055_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0055_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0055_ip);
-- probe 1/1 -> t1_tc_15_reg_0055_ip
INSERT INTO t1_tc_15_reg_0055_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0055_ip
INSERT INTO t2_tc_15_reg_0055_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0055-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0055_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0055_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0055_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0055_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0055-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0055_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0055_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0055_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0055_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0055_ip a JOIN t2_tc_15_reg_0055_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0055-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0055_ip' AND column_name='target';

-- Test Case: TC-15-REG-0056-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=7504206ce82f column_type=binary(80) neg_probe=153ade8ea9e4=167|1264|1265|1406 neg_probe=19197aaa1bdd=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0056_ip, t2_tc_15_reg_0056_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0056_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0056_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0056_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0056_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0056_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0056_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0056_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0056_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0056_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0056_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0056_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0056_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0056_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0056_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0056_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0056_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0056_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0056_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0056_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0056_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0056_ip);
-- probe 1/1 -> t1_tc_15_reg_0056_ip
INSERT INTO t1_tc_15_reg_0056_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0056_ip
INSERT INTO t2_tc_15_reg_0056_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0056-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0056_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0056_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0056_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0056_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0056-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0056_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0056_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0056_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0056_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0056_ip a JOIN t2_tc_15_reg_0056_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0056-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0056_ip' AND column_name='target';

-- Test Case: TC-15-REG-0057-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=SECONDARY_INDEX
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=SECONDARY_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=c7e70238a891 column_type=binary(80) neg_probe=33ab77017979=167|1264|1265|1406 neg_probe=418d471190c0=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0057_ip, t2_tc_15_reg_0057_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0057_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0057_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0057_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0057_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0057_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0057_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0057_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0057_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0057_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0057_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0057_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0057_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0057_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0057_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0057_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0057_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0057_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0057_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0057_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0057_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0057_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0057_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0057_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0057_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0057_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0057_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0057_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0057_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0057_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0057_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0057_ip);
-- probe 1/1 -> t1_tc_15_reg_0057_ip
INSERT INTO t1_tc_15_reg_0057_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0057_ip
INSERT INTO t2_tc_15_reg_0057_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0057-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0057_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0057_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0057_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0057_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0057-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0057_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0057_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0057_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0057_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0057_ip a JOIN t2_tc_15_reg_0057_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0057-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0057_ip' AND column_name='target';

-- Test Case: TC-15-REG-0058-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=UNIQUE_INDEX
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=b0403b07588a column_type=binary(80) neg_probe=3e4141e7f2d5=167|1264|1265|1406 neg_probe=3839d8f0791e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0058_ip, t2_tc_15_reg_0058_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0058_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0058_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0058_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0058_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0058_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0058_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0058_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0058_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0058_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0058_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0058_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0058_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0058_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0058_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0058_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0058_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0058_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0058_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0058_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0058_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0058_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0058_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0058_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0058_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0058_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0058_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0058_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0058_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0058_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0058_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0058_ip);
-- probe 1/1 -> t1_tc_15_reg_0058_ip
INSERT INTO t1_tc_15_reg_0058_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0058_ip
INSERT INTO t2_tc_15_reg_0058_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0058-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0058_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0058_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0058_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0058_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0058-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0058_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0058_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0058_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0058_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0058_ip a JOIN t2_tc_15_reg_0058_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0058-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0058_ip' AND column_name='target';

-- Test Case: TC-15-REG-0059-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=FOREIGN_KEY
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=FOREIGN_KEY, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=fd0b4d914a95 column_type=binary(80) neg_probe=d6bf099a646d=167|1264|1265|1406 neg_probe=f01b5d64761f=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0059_ip, t2_tc_15_reg_0059_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0059_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0059_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0059_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0059_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0059_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0059_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0059_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0059_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0059_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0059_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0059_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0059_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0059_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0059_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0059_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0059_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0059_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0059_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0059_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0059_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0059_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0059_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0059_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0059_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0059_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0059_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0059_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0059_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0059_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0059_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0059_ip);
-- probe 1/1 -> t1_tc_15_reg_0059_ip
INSERT INTO t1_tc_15_reg_0059_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0059_ip
INSERT INTO t2_tc_15_reg_0059_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0059-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0059_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0059_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0059_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0059_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0059-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0059_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0059_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0059_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0059_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0059_ip a JOIN t2_tc_15_reg_0059_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0059-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0059_ip' AND column_name='target';

-- Test Case: TC-15-REG-0060-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: FAIL
-- Varied factor: dependencies=CHECK
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=CHECK, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=FAIL build=SUCCESS assertions=3 neg_probes=1 alter_sha=c3a30abb7f47 errno=[1659,1845,1846,3780] column_type=binary(40) neg_probe=97868b1bcdbc=167|1264|1265|1406 neg_probe=cfad8cca1fe4=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0060_ip, t2_tc_15_reg_0060_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0060_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0060_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0060_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0060_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0060_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0060_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0060_ip (target) VALUES (NULL);
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_15_reg_0060_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0060_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0060_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0060_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0060_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0060_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0060_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0060_ip (target) VALUES (NULL);
-- Oracle table: BINARY(40)
CREATE TABLE t2_tc_15_reg_0060_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0060_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0060_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0060_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0060_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0060_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0060_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0060_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0060_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0060_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0060_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0060_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0060_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0060_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0060_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0060_ip);
-- probe 1/1 -> t1_tc_15_reg_0060_ip
INSERT INTO t1_tc_15_reg_0060_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0060_ip
INSERT INTO t2_tc_15_reg_0060_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0060-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0060_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0060_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0060_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0060_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0060-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0060_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0060_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0060_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0060_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0060_ip a JOIN t2_tc_15_reg_0060_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0060-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(40)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(40) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0060_ip' AND column_name='target';

-- Test Case: TC-15-REG-0061-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=7686af867faa column_type=binary(80) neg_probe=80ca85c18a16=ACCEPTED neg_probe=a0b8bbb47cd0=ACCEPTED
DROP TABLE IF EXISTS t1_tc_15_reg_0061_ip, t2_tc_15_reg_0061_ip;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_15_reg_0061_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0061_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0061_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0061_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0061_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0061_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0061_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0061_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0061_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0061_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0061_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0061_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0061_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0061_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0061_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0061_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0061_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0061_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0061_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0061_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0061_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0061_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0061_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0061_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0061_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0061_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0061_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0061_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0061_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0061_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0061_ip);
-- probe 1/1 -> t1_tc_15_reg_0061_ip
INSERT INTO t1_tc_15_reg_0061_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0061_ip
INSERT INTO t2_tc_15_reg_0061_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0061-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0061_ip) - @neg_before_t1 = (SELECT COUNT(*) FROM t2_tc_15_reg_0061_ip) - @neg_before_t2,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0061_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0061_ip) - @neg_before_t2,' expect=t1_added = t2_added (非 STRICT: 截断行为必须与对照表一致) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0061-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0061_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0061_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0061_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0061_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0061_ip a JOIN t2_tc_15_reg_0061_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0061-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0061_ip' AND column_name='target';

-- Test Case: TC-15-REG-0062-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=34b4f6ae3557 column_type=binary(80) neg_probe=c88f6c39ef60=167|1264|1265|1406 neg_probe=723803b30ee6=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0062_ip, t2_tc_15_reg_0062_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0062_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0062_ip MODIFY target BINARY(80) NOT NULL, ALGORITHM=inplace;
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0062_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0062_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0062_ip);
-- probe 1/1 -> t1_tc_15_reg_0062_ip
INSERT INTO t1_tc_15_reg_0062_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0062_ip
INSERT INTO t2_tc_15_reg_0062_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0062-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0062_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0062_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0062_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0062_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0062-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0062_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0062_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0062_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0062_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0062_ip a JOIN t2_tc_15_reg_0062_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0062-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0062_ip' AND column_name='target';

-- Test Case: TC-15-REG-0063-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-02
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=66254cdacbf4 column_type=binary(80) neg_probe=09534123645f=167|1264|1265|1406 neg_probe=c9eaaf70c7c4=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0063_ip, t2_tc_15_reg_0063_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0063_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0063_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0063_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0063_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0063_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0063_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0063_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0063_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0063_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0063_ip (target) VALUES (NULL);
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0063_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0063_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0063_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0063_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0063_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0063_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0063_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0063_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0063_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0063_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0063_ip);
-- probe 1/1 -> t1_tc_15_reg_0063_ip
INSERT INTO t1_tc_15_reg_0063_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0063_ip
INSERT INTO t2_tc_15_reg_0063_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0063-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0063_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0063_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0063_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0063_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0063-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0063_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0063_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0063_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0063_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0063_ip a JOIN t2_tc_15_reg_0063_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0063-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0063_ip' AND column_name='target';

-- Test Case: TC-15-REG-0064-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: BIN-02
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=e3b9b2545d6c column_type=binary(80) neg_probe=2ce5feeb323b=167|1264|1265|1406 neg_probe=a78586f62602=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0064_ip, t2_tc_15_reg_0064_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0064_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0064_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0064_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0064_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0064_ip);
-- probe 1/1 -> t1_tc_15_reg_0064_ip
INSERT INTO t1_tc_15_reg_0064_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0064_ip
INSERT INTO t2_tc_15_reg_0064_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0064-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0064_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0064_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0064_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0064_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0064-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0064_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0064_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0064_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0064_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0064_ip a JOIN t2_tc_15_reg_0064_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0064-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0064_ip' AND column_name='target';

-- Test Case: TC-15-REG-0065-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=1cd274170238 column_type=binary(80) neg_probe=d85ee5c1bb91=167|1264|1265|1406 neg_probe=3891510b7f4a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0065_ip, t2_tc_15_reg_0065_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0065_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(40) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0065_ip MODIFY target BINARY(80) NOT NULL DEFAULT 0x00, ALGORITHM=inplace;
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0065_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(80) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0065_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0065_ip);
-- probe 1/1 -> t1_tc_15_reg_0065_ip
INSERT INTO t1_tc_15_reg_0065_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0065_ip
INSERT INTO t2_tc_15_reg_0065_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0065-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0065_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0065_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0065_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0065_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0065-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0065_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0065_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0065_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0065_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0065_ip a JOIN t2_tc_15_reg_0065_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0065-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=NO has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0065_ip' AND column_name='target';

-- Test Case: TC-15-REG-0066-IP
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-05
-- Transition ID: BIN-02
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=f099672df518 column_type=binary(80) neg_probe=b252785867eb=167|1264|1265|1406 neg_probe=8383f64216a8=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0066_ip, t2_tc_15_reg_0066_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0066_ip (
  target BINARY(40),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0066_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0066_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0066_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0066_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0066_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0066_ip MODIFY target BINARY(80), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0066_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0066_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0066_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t1_tc_15_reg_0066_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0066_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0066_ip (target) VALUES ('');
-- Oracle table: BINARY(80)
CREATE TABLE t2_tc_15_reg_0066_ip (
  target BINARY(80),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0066_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0066_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0066_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0066_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0066_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0066_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0066_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0066_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
INSERT INTO t2_tc_15_reg_0066_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0066_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0066_ip (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0066_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0066_ip);
-- probe 1/1 -> t1_tc_15_reg_0066_ip
INSERT INTO t1_tc_15_reg_0066_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0066_ip
INSERT INTO t2_tc_15_reg_0066_ip (target) VALUES (0x414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0066-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0066_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0066_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0066_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0066_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0066-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0066_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0066_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0066_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0066_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0066_ip a JOIN t2_tc_15_reg_0066_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0066-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0066_ip' AND column_name='target';

-- Test Case: TC-15-ATR-0002-IP
-- Column attribute preservation: COMMENT
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace
-- Transition ID: BIN-02
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=6bd825327ceb column_type=binary(80)
DROP TABLE IF EXISTS t1_tc_15_atr_0002_ip, t2_tc_15_atr_0002_ip;
CREATE TABLE t1_tc_15_atr_0002_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target BINARY(40) COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB;
INSERT INTO t1_tc_15_atr_0002_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_atr_0002_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_atr_0002_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_atr_0002_ip (target) VALUES (0x41424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_atr_0002_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_atr_0002_ip MODIFY target BINARY(80) COMMENT 'test_comment', ALGORITHM=inplace;
INSERT INTO t1_tc_15_atr_0002_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_atr_0002_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_atr_0002_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4d);
SELECT 'TC-15-ATR-0002-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_15_atr_0002_ip' AND column_name='target' AND column_comment='test_comment';
SELECT 'TC-15-ATR-0002-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_atr_0002_ip' AND column_name='target';

-- Test Case: TC-15-REG-0067-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: BASELINE
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=bc6e6e4d731e column_type=binary(255) neg_probe=4c1ecb84fbb3=167|1264|1265|1406 neg_probe=b8527cd53524=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0067_ip, t2_tc_15_reg_0067_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0067_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0067_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0067_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0067_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0067_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0067_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0067_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0067_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0067_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0067_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0067_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0067_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0067_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0067_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0067_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0067_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0067_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0067_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0067_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0067_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0067_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0067_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0067_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0067_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0067_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0067_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0067_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0067_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0067_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0067_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0067_ip);
-- probe 1/1 -> t1_tc_15_reg_0067_ip
INSERT INTO t1_tc_15_reg_0067_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0067_ip
INSERT INTO t2_tc_15_reg_0067_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0067-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0067_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0067_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0067_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0067_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0067-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0067_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0067_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0067_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0067_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0067_ip a JOIN t2_tc_15_reg_0067_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0067-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0067_ip' AND column_name='target';

-- Test Case: TC-15-REG-0068-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=COMPACT
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=COMPACT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=3ed699daa6b0 column_type=binary(255) neg_probe=d8239e1d4c43=167|1264|1265|1406 neg_probe=2970557edc7b=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0068_ip, t2_tc_15_reg_0068_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0068_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t1_tc_15_reg_0068_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0068_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0068_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0068_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0068_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0068_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0068_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0068_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0068_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0068_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0068_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0068_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0068_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0068_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0068_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=COMPACT;
INSERT INTO t2_tc_15_reg_0068_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0068_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0068_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0068_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0068_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0068_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0068_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0068_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0068_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0068_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0068_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0068_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0068_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0068_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0068_ip);
-- probe 1/1 -> t1_tc_15_reg_0068_ip
INSERT INTO t1_tc_15_reg_0068_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0068_ip
INSERT INTO t2_tc_15_reg_0068_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0068-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0068_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0068_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0068_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0068_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0068-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0068_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0068_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0068_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0068_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0068_ip a JOIN t2_tc_15_reg_0068_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0068-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0068_ip' AND column_name='target';

-- Test Case: TC-15-REG-0069-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: row_format=REDUNDANT
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=REDUNDANT, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=9961115d9a73 column_type=binary(255) neg_probe=ded4b91073d8=167|1264|1265|1406 neg_probe=0cf0af842669=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0069_ip, t2_tc_15_reg_0069_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0069_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t1_tc_15_reg_0069_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0069_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0069_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0069_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0069_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0069_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0069_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0069_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0069_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0069_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0069_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0069_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0069_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0069_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0069_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=REDUNDANT;
INSERT INTO t2_tc_15_reg_0069_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0069_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0069_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0069_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0069_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0069_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0069_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0069_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0069_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0069_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0069_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0069_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0069_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0069_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0069_ip);
-- probe 1/1 -> t1_tc_15_reg_0069_ip
INSERT INTO t1_tc_15_reg_0069_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0069_ip
INSERT INTO t2_tc_15_reg_0069_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0069-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0069_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0069_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0069_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0069_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0069-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0069_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0069_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0069_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0069_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0069_ip a JOIN t2_tc_15_reg_0069_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0069-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0069_ip' AND column_name='target';

-- Test Case: TC-15-REG-0070-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=COMPOSITE_PK
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=629f66caa2d4 column_type=binary(255) neg_probe=18c70d435065=167|1264|1265|1406 neg_probe=0306f07392fc=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0070_ip, t2_tc_15_reg_0070_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0070_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0070_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0070_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0070_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0070_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0070_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0070_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0070_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0070_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0070_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0070_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0070_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0070_ip (target) VALUES ('');
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0070_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0070_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0070_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0070_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0070_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0070_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0070_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0070_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0070_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0070_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0070_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0070_ip (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0070_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0070_ip);
-- probe 1/1 -> t1_tc_15_reg_0070_ip
INSERT INTO t1_tc_15_reg_0070_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0070_ip
INSERT INTO t2_tc_15_reg_0070_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0070-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0070_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0070_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0070_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0070_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0070-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0070_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0070_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0070_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0070_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0070_ip a JOIN t2_tc_15_reg_0070_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0070-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0070_ip' AND column_name='target';

-- Test Case: TC-15-REG-0071-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: primary_key=NO_EXPLICIT_PK
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=NO_EXPLICIT_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=07c6375e4e4c column_type=binary(255) neg_probe=c1a6014b894f=167|1264|1265|1406 neg_probe=d8dbbcd4bfce=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0071_ip, t2_tc_15_reg_0071_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0071_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0071_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0071_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0071_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0071_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0071_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0071_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0071_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0071_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0071_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0071_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0071_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0071_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0071_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0071_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0071_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', INDEX idx_id (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0071_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0071_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0071_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0071_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0071_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0071_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0071_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0071_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0071_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0071_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0071_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0071_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0071_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0071_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0071_ip);
-- probe 1/1 -> t1_tc_15_reg_0071_ip
INSERT INTO t1_tc_15_reg_0071_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0071_ip
INSERT INTO t2_tc_15_reg_0071_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0071-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0071_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0071_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0071_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0071_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0071-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0071_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0071_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0071_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0071_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0071_ip a JOIN t2_tc_15_reg_0071_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0071-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0071_ip' AND column_name='target';

-- Test Case: TC-15-REG-0072-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=NONE
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=NONE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=362f8dd7c95c column_type=binary(255) neg_probe=c36ca3642444=167|1264|1265|1406 neg_probe=4c894ef1c85c=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0072_ip, t2_tc_15_reg_0072_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0072_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0072_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0072_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0072_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0072_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0072_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0072_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0072_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0072_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0072_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0072_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0072_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0072_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0072_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0072_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0072_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0072_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0072_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0072_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0072_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0072_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0072_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0072_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0072_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0072_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0072_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0072_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0072_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0072_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0072_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0072_ip);
-- probe 1/1 -> t1_tc_15_reg_0072_ip
INSERT INTO t1_tc_15_reg_0072_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0072_ip
INSERT INTO t2_tc_15_reg_0072_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0072-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0072_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0072_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0072_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0072_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0072-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0072_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0072_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0072_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0072_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0072_ip a JOIN t2_tc_15_reg_0072_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0072-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0072_ip' AND column_name='target';

-- Test Case: TC-15-REG-0073-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=MULTIPLE_SECONDARY
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=MULTIPLE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=6634edf6cee8 column_type=binary(255) neg_probe=a8bfa404d5bf=167|1264|1265|1406 neg_probe=91eb17801492=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0073_ip, t2_tc_15_reg_0073_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0073_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0073_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0073_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0073_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0073_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0073_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0073_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0073_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0073_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0073_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0073_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0073_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0073_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0073_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0073_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0073_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_pad2 (pad2)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0073_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0073_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0073_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0073_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0073_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0073_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0073_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0073_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0073_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0073_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0073_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0073_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0073_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0073_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0073_ip);
-- probe 1/1 -> t1_tc_15_reg_0073_ip
INSERT INTO t1_tc_15_reg_0073_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0073_ip
INSERT INTO t2_tc_15_reg_0073_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0073-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0073_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0073_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0073_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0073_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0073-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0073_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0073_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0073_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0073_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0073_ip a JOIN t2_tc_15_reg_0073_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0073-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0073_ip' AND column_name='target';

-- Test Case: TC-15-REG-0074-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=UNIQUE
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=UNIQUE, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=51cfc3a830b5 column_type=binary(255) neg_probe=e5866823d71f=167|1264|1265|1406 neg_probe=62361f14bb99=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0074_ip, t2_tc_15_reg_0074_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0074_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0074_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0074_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0074_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0074_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0074_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0074_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0074_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0074_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0074_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0074_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0074_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0074_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0074_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0074_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0074_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), UNIQUE INDEX uq_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0074_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0074_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0074_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0074_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0074_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0074_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0074_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0074_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0074_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0074_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0074_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0074_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0074_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0074_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0074_ip);
-- probe 1/1 -> t1_tc_15_reg_0074_ip
INSERT INTO t1_tc_15_reg_0074_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0074_ip
INSERT INTO t2_tc_15_reg_0074_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0074-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0074_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0074_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0074_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0074_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0074-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0074_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0074_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0074_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0074_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0074_ip a JOIN t2_tc_15_reg_0074_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0074-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0074_ip' AND column_name='target';

-- Test Case: TC-15-REG-0075-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: non_target_index=COMPOSITE_PREFIX
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=COMPOSITE_PREFIX, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=140b7fcb9d12 column_type=binary(255) neg_probe=7542594a8ec0=167|1264|1265|1406 neg_probe=af857097165e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0075_ip, t2_tc_15_reg_0075_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0075_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0075_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0075_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0075_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0075_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0075_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0075_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0075_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0075_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0075_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0075_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0075_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0075_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0075_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0075_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0075_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_composite (pad1(10), pad2(10))
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0075_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0075_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0075_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0075_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0075_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0075_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0075_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0075_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0075_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0075_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0075_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0075_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0075_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0075_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0075_ip);
-- probe 1/1 -> t1_tc_15_reg_0075_ip
INSERT INTO t1_tc_15_reg_0075_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0075_ip
INSERT INTO t2_tc_15_reg_0075_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0075-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0075_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0075_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0075_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0075_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0075-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0075_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0075_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0075_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0075_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0075_ip a JOIN t2_tc_15_reg_0075_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0075-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0075_ip' AND column_name='target';

-- Test Case: TC-15-REG-0076-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=FIRST
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=b3300c4536b3 column_type=binary(255) neg_probe=73a095a97802=167|1264|1265|1406 neg_probe=40381dbd2857=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0076_ip, t2_tc_15_reg_0076_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0076_ip (
  target BINARY(254),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0076_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0076_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0076_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0076_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0076_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0076_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0076_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0076_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0076_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0076_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0076_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0076_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0076_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0076_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0076_ip (
  target BINARY(255),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0076_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0076_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0076_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0076_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0076_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0076_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0076_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0076_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0076_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0076_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0076_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0076_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0076_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0076_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0076_ip);
-- probe 1/1 -> t1_tc_15_reg_0076_ip
INSERT INTO t1_tc_15_reg_0076_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0076_ip
INSERT INTO t2_tc_15_reg_0076_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0076-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0076_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0076_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0076_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0076_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0076-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0076_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0076_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0076_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0076_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0076_ip a JOIN t2_tc_15_reg_0076_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0076-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0076_ip' AND column_name='target';

-- Test Case: TC-15-REG-0077-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_position=LAST
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=LAST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=2b709de85142 column_type=binary(255) neg_probe=31fca4dd16a2=167|1264|1265|1406 neg_probe=9337a190895a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0077_ip, t2_tc_15_reg_0077_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0077_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BINARY(254), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0077_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0077_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0077_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0077_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0077_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0077_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0077_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0077_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0077_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0077_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0077_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0077_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0077_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0077_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0077_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2',
  target BINARY(255), PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0077_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0077_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0077_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0077_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0077_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0077_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0077_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0077_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0077_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0077_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0077_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0077_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0077_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0077_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0077_ip);
-- probe 1/1 -> t1_tc_15_reg_0077_ip
INSERT INTO t1_tc_15_reg_0077_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0077_ip
INSERT INTO t2_tc_15_reg_0077_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0077-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0077_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0077_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0077_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0077_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0077-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0077_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0077_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0077_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0077_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0077_ip a JOIN t2_tc_15_reg_0077_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0077-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=4,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=4]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0077_ip' AND column_name='target';

-- Test Case: TC-15-REG-0078-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_NO_DEFAULT
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=65784c339fdc column_type=binary(255) neg_probe=5e62862c5842=167|1264|1265|1406 neg_probe=2dd32c68c473=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0078_ip, t2_tc_15_reg_0078_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0078_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0078_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0078_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0078_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0078_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0078_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0078_ip MODIFY target BINARY(255) NOT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0078_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0078_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0078_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0078_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0078_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0078_ip (target) VALUES ('');
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0078_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0078_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0078_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0078_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0078_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0078_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0078_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0078_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0078_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0078_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0078_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0078_ip (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0078_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0078_ip);
-- probe 1/1 -> t1_tc_15_reg_0078_ip
INSERT INTO t1_tc_15_reg_0078_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0078_ip
INSERT INTO t2_tc_15_reg_0078_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0078-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0078_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0078_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0078_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0078_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0078-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0078_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0078_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0078_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0078_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0078_ip a JOIN t2_tc_15_reg_0078_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0078-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0078_ip' AND column_name='target';

-- Test Case: TC-15-REG-0079-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=CONSTANT_DEFAULT
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=CONSTANT_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=a3c7c699e44b column_type=binary(255) neg_probe=6b280fbb8418=167|1264|1265|1406 neg_probe=0b19514d636a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0079_ip, t2_tc_15_reg_0079_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0079_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254) DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0079_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0079_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0079_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0079_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0079_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0079_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0079_ip MODIFY target BINARY(255) DEFAULT 0x00, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0079_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0079_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0079_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0079_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0079_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0079_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0079_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0079_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255) DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0079_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0079_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0079_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0079_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0079_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0079_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0079_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0079_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0079_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0079_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0079_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0079_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0079_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0079_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0079_ip);
-- probe 1/1 -> t1_tc_15_reg_0079_ip
INSERT INTO t1_tc_15_reg_0079_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0079_ip
INSERT INTO t2_tc_15_reg_0079_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0079-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0079_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0079_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0079_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0079_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0079-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0079_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0079_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0079_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0079_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0079_ip a JOIN t2_tc_15_reg_0079_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0079-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0079_ip' AND column_name='target';

-- Test Case: TC-15-REG-0080-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NULL_DEFAULT
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=5be9eead2b90 column_type=binary(255) neg_probe=acd4a70afc6e=167|1264|1265|1406 neg_probe=c9602ca5b8d5=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0080_ip, t2_tc_15_reg_0080_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0080_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0080_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0080_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0080_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0080_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0080_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0080_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0080_ip MODIFY target BINARY(255) DEFAULT NULL, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0080_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0080_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0080_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0080_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0080_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0080_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0080_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0080_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255) DEFAULT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0080_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0080_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0080_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0080_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0080_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0080_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0080_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0080_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0080_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0080_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0080_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0080_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0080_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0080_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0080_ip);
-- probe 1/1 -> t1_tc_15_reg_0080_ip
INSERT INTO t1_tc_15_reg_0080_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0080_ip
INSERT INTO t2_tc_15_reg_0080_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0080-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0080_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0080_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0080_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0080_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0080-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0080_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0080_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0080_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0080_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0080_ip a JOIN t2_tc_15_reg_0080_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0080-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0080_ip' AND column_name='target';

-- Test Case: TC-15-REG-0081-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=NOT_NULL_DEFAULT
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=46d64865a25c column_type=binary(255) neg_probe=b0e744313d5e=167|1264|1265|1406 neg_probe=d0be03794044=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0081_ip, t2_tc_15_reg_0081_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0081_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0081_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0081_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0081_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0081_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0081_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0081_ip MODIFY target BINARY(255) NOT NULL DEFAULT 0x00, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0081_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0081_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0081_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0081_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0081_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0081_ip (target) VALUES ('');
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0081_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0081_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0081_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0081_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0081_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0081_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0081_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0081_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0081_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0081_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0081_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0081_ip (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0081_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0081_ip);
-- probe 1/1 -> t1_tc_15_reg_0081_ip
INSERT INTO t1_tc_15_reg_0081_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0081_ip
INSERT INTO t2_tc_15_reg_0081_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0081-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0081_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0081_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0081_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0081_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0081-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0081_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0081_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0081_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0081_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0081_ip a JOIN t2_tc_15_reg_0081_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0081-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=NO has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0081_ip' AND column_name='target';

-- Test Case: TC-15-REG-0082-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: target_attributes=INVISIBLE
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=INVISIBLE, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=5fb160fe7ced column_type=binary(255) neg_probe=ed376e0e7987=167|1264|1265|1406 neg_probe=be3a85497e05=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0082_ip, t2_tc_15_reg_0082_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0082_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0082_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0082_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0082_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0082_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0082_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0082_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0082_ip MODIFY target BINARY(255) INVISIBLE, ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0082_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0082_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0082_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0082_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0082_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0082_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0082_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0082_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255) INVISIBLE,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0082_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0082_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0082_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0082_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0082_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0082_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0082_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0082_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0082_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0082_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0082_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0082_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0082_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0082_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0082_ip);
-- probe 1/1 -> t1_tc_15_reg_0082_ip
INSERT INTO t1_tc_15_reg_0082_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0082_ip
INSERT INTO t2_tc_15_reg_0082_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0082-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0082_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0082_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0082_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0082_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0082-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0082_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0082_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0082_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0082_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0082_ip a JOIN t2_tc_15_reg_0082_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0082-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> 'INVISIBLE')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra=INVISIBLE pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0082_ip' AND column_name='target';

-- Test Case: TC-15-REG-0083-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S0
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=e7d654631b25 column_type=binary(255) neg_probe=d4dbb68aa08f=167|1264|1265|1406 neg_probe=4ce9ee5120b3=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0083_ip, t2_tc_15_reg_0083_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0083_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0083_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0083_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0083_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0083_ip);
-- probe 1/1 -> t1_tc_15_reg_0083_ip
INSERT INTO t1_tc_15_reg_0083_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0083_ip
INSERT INTO t2_tc_15_reg_0083_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0083-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0083_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0083_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0083_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0083_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0083-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0083_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0083_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0083_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0083_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0083_ip a JOIN t2_tc_15_reg_0083_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0083-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0083_ip' AND column_name='target';

-- Test Case: TC-15-REG-0084-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_scale=S1
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S1, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=b9297a9fa121 column_type=binary(255) neg_probe=20c1296a862c=167|1264|1265|1406 neg_probe=06ec6db5aa78=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0084_ip, t2_tc_15_reg_0084_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0084_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0084_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0084_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0084_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0084_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0084_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0084_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0084_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0084_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0084_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0084_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0084_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0084_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0084_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0084_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0084_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0084_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0084_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0084_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0084_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0084_ip);
-- probe 1/1 -> t1_tc_15_reg_0084_ip
INSERT INTO t1_tc_15_reg_0084_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0084_ip
INSERT INTO t2_tc_15_reg_0084_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0084-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0084_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0084_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0084_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0084_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0084-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0084_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0084_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0084_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0084_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0084_ip a JOIN t2_tc_15_reg_0084_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0084-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0084_ip' AND column_name='target';

-- Test Case: TC-15-REG-0085-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=UNIFORM
-- Transition ID: BIN-03
-- Factors: data_distribution=UNIFORM, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=b2eba8b1431f column_type=binary(255) neg_probe=8e4c9e00249c=167|1264|1265|1406 neg_probe=a264e4e54f87=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0085_ip, t2_tc_15_reg_0085_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0085_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0085_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0085_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0085_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0085_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0085_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0085_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0085_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0085_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0085_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0085_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0085_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0085_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0085_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0085_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0085_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0085_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0085_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0085_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0085_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0085_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0085_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0085_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0085_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0085_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0085_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0085_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0085_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0085_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0085_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0085_ip);
-- probe 1/1 -> t1_tc_15_reg_0085_ip
INSERT INTO t1_tc_15_reg_0085_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0085_ip
INSERT INTO t2_tc_15_reg_0085_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0085-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0085_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0085_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0085_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0085_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0085-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0085_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0085_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0085_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0085_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0085_ip a JOIN t2_tc_15_reg_0085_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0085-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0085_ip' AND column_name='target';

-- Test Case: TC-15-REG-0086-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: data_distribution=MONOTONIC
-- Transition ID: BIN-03
-- Factors: data_distribution=MONOTONIC, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=59545671b23f column_type=binary(255) neg_probe=8cf6815457e5=167|1264|1265|1406 neg_probe=634ee45e2bff=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0086_ip, t2_tc_15_reg_0086_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0086_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0086_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0086_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0086_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0086_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0086_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0086_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0086_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0086_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0086_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0086_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0086_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0086_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0086_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0086_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0086_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0086_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0086_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0086_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0086_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0086_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0086_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0086_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0086_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0086_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0086_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0086_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0086_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0086_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0086_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0086_ip);
-- probe 1/1 -> t1_tc_15_reg_0086_ip
INSERT INTO t1_tc_15_reg_0086_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0086_ip
INSERT INTO t2_tc_15_reg_0086_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0086-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0086_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0086_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0086_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0086_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0086-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0086_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0086_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0086_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0086_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0086_ip a JOIN t2_tc_15_reg_0086_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0086-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0086_ip' AND column_name='target';

-- Test Case: TC-15-REG-0087-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ZERO
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ZERO, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=ce8fd1c0aeae column_type=binary(255) neg_probe=ab76043f97d9=167|1264|1265|1406 neg_probe=1f3500917c7a=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0087_ip, t2_tc_15_reg_0087_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0087_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0087_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0087_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0087_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0087_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0087_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0087_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0087_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0087_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0087_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0087_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0087_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0087_ip (target) VALUES ('');
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0087_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0087_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0087_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0087_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0087_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0087_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0087_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0087_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0087_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0087_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0087_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0087_ip (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0087_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0087_ip);
-- probe 1/1 -> t1_tc_15_reg_0087_ip
INSERT INTO t1_tc_15_reg_0087_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0087_ip
INSERT INTO t2_tc_15_reg_0087_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0087-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0087_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0087_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0087_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0087_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0087-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0087_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0087_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0087_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0087_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0087_ip a JOIN t2_tc_15_reg_0087_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0087-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0087_ip' AND column_name='target';

-- Test Case: TC-15-REG-0088-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=SINGLE
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=SINGLE, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=71c9a1145ca8 column_type=binary(255) neg_probe=d004571b1b0a=167|1264|1265|1406 neg_probe=deb120d27667=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0088_ip, t2_tc_15_reg_0088_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0088_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0088_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0088_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0088_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0088_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0088_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0088_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0088_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0088_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0088_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0088_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0088_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0088_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0088_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0088_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0088_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0088_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0088_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0088_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0088_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0088_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0088_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0088_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0088_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0088_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0088_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0088_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0088_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0088_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0088_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0088_ip);
-- probe 1/1 -> t1_tc_15_reg_0088_ip
INSERT INTO t1_tc_15_reg_0088_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0088_ip
INSERT INTO t2_tc_15_reg_0088_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0088-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0088_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0088_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0088_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0088_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0088-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0088_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0088_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0088_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0088_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0088_ip a JOIN t2_tc_15_reg_0088_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0088-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0088_ip' AND column_name='target';

-- Test Case: TC-15-REG-0089-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: null_ratio=ALL
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=388d93ab0e97 column_type=binary(255) neg_probe=9a4a93fde4ee=167|1264|1265|1406 neg_probe=35dfafefb2e0=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0089_ip, t2_tc_15_reg_0089_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0089_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0089_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0089_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0089_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0089_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0089_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0089_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0089_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0089_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0089_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0089_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0089_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0089_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0089_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0089_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0089_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0089_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0089_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0089_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0089_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0089_ip);
-- probe 1/1 -> t1_tc_15_reg_0089_ip
INSERT INTO t1_tc_15_reg_0089_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0089_ip
INSERT INTO t2_tc_15_reg_0089_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0089-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0089_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0089_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0089_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0089_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0089-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0089_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0089_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0089_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0089_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0089_ip a JOIN t2_tc_15_reg_0089_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0089-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0089_ip' AND column_name='target';

-- Test Case: TC-15-REG-0090-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=SECONDARY_INDEX
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=SECONDARY_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=0379d78d4da9 column_type=binary(255) neg_probe=07cf87e2bd5d=167|1264|1265|1406 neg_probe=fb894201b6a8=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0090_ip, t2_tc_15_reg_0090_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0090_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0090_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0090_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0090_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0090_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0090_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0090_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0090_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0090_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0090_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0090_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0090_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0090_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0090_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0090_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0090_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), INDEX idx_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0090_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0090_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0090_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0090_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0090_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0090_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0090_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0090_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0090_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0090_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0090_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0090_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0090_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0090_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0090_ip);
-- probe 1/1 -> t1_tc_15_reg_0090_ip
INSERT INTO t1_tc_15_reg_0090_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0090_ip
INSERT INTO t2_tc_15_reg_0090_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0090-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0090_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0090_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0090_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0090_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0090-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0090_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0090_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0090_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0090_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0090_ip a JOIN t2_tc_15_reg_0090_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0090-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0090_ip' AND column_name='target';

-- Test Case: TC-15-REG-0091-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=UNIQUE_INDEX
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=aea09e0ca3aa column_type=binary(255) neg_probe=2aa1aef33be1=167|1264|1265|1406 neg_probe=90340bcad43e=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0091_ip, t2_tc_15_reg_0091_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0091_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0091_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0091_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0091_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0091_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0091_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0091_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0091_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0091_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0091_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0091_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0091_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0091_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0091_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0091_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0091_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0091_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0091_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0091_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0091_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0091_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0091_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0091_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0091_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0091_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0091_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0091_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0091_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0091_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0091_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0091_ip);
-- probe 1/1 -> t1_tc_15_reg_0091_ip
INSERT INTO t1_tc_15_reg_0091_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0091_ip
INSERT INTO t2_tc_15_reg_0091_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0091-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0091_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0091_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0091_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0091_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0091-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0091_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0091_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0091_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0091_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0091_ip a JOIN t2_tc_15_reg_0091_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0091-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0091_ip' AND column_name='target';

-- Test Case: TC-15-REG-0092-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: dependencies=FOREIGN_KEY
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=FOREIGN_KEY, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=06700ea387cc column_type=binary(255) neg_probe=06b0438f2241=167|1264|1265|1406 neg_probe=073d97ca2617=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0092_ip, t2_tc_15_reg_0092_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0092_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0092_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0092_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0092_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0092_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0092_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0092_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0092_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0092_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0092_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0092_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0092_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0092_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0092_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0092_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0092_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0092_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0092_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0092_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0092_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0092_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0092_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0092_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0092_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0092_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0092_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0092_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0092_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0092_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0092_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0092_ip);
-- probe 1/1 -> t1_tc_15_reg_0092_ip
INSERT INTO t1_tc_15_reg_0092_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0092_ip
INSERT INTO t2_tc_15_reg_0092_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0092-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0092_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0092_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0092_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0092_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0092-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0092_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0092_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0092_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0092_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0092_ip a JOIN t2_tc_15_reg_0092_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0092-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0092_ip' AND column_name='target';

-- Test Case: TC-15-REG-0093-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: FAIL
-- Varied factor: dependencies=CHECK
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=CHECK, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=FAIL build=SUCCESS assertions=3 neg_probes=1 alter_sha=83f8b0d18fab errno=[1659,1845,1846,3780] column_type=binary(254) neg_probe=61f71bbfb33f=167|1264|1265|1406 neg_probe=a860edc5cb02=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0093_ip, t2_tc_15_reg_0093_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0093_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0093_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0093_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0093_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0093_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0093_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0093_ip (target) VALUES (NULL);
-- Expected: ALTER FAILS (table keeps old type)
ALTER TABLE t1_tc_15_reg_0093_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0093_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0093_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0093_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0093_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0093_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0093_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0093_ip (target) VALUES (NULL);
-- Oracle table: BINARY(254)
CREATE TABLE t2_tc_15_reg_0093_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), CHECK (target IS NOT NULL OR 1=1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0093_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0093_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0093_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0093_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0093_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0093_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0093_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0093_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0093_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0093_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0093_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0093_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0093_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0093_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0093_ip);
-- probe 1/1 -> t1_tc_15_reg_0093_ip
INSERT INTO t1_tc_15_reg_0093_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0093_ip
INSERT INTO t2_tc_15_reg_0093_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0093-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0093_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0093_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0093_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0093_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0093-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0093_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0093_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0093_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0093_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0093_ip a JOIN t2_tc_15_reg_0093_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0093-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(254)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(254) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0093_ip' AND column_name='target';

-- Test Case: TC-15-REG-0094-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: sql_mode=NON_STRICT
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=NON_STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=73054be89714 column_type=binary(255) neg_probe=b0d44c5a93bd=ACCEPTED neg_probe=33c1a315cc32=ACCEPTED
DROP TABLE IF EXISTS t1_tc_15_reg_0094_ip, t2_tc_15_reg_0094_ip;
SET SESSION sql_mode = '';
CREATE TABLE t1_tc_15_reg_0094_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0094_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0094_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0094_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0094_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0094_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0094_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0094_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0094_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0094_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0094_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0094_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0094_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0094_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0094_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0094_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0094_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0094_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0094_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0094_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0094_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0094_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0094_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0094_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0094_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0094_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0094_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0094_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0094_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0094_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0094_ip);
-- probe 1/1 -> t1_tc_15_reg_0094_ip
INSERT INTO t1_tc_15_reg_0094_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0094_ip
INSERT INTO t2_tc_15_reg_0094_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0094-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0094_ip) - @neg_before_t1 = (SELECT COUNT(*) FROM t2_tc_15_reg_0094_ip) - @neg_before_t2,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0094_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0094_ip) - @neg_before_t2,' expect=t1_added = t2_added (非 STRICT: 截断行为必须与对照表一致) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0094-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0094_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0094_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0094_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0094_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0094_ip a JOIN t2_tc_15_reg_0094_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0094-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0094_ip' AND column_name='target';

-- Test Case: TC-15-REG-0095-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-01
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=a1383e7dbeaa column_type=binary(255) neg_probe=6aad5c3ae4da=167|1264|1265|1406 neg_probe=291161968518=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0095_ip, t2_tc_15_reg_0095_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0095_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0095_ip MODIFY target BINARY(255) NOT NULL, ALGORITHM=inplace;
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0095_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255) NOT NULL,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0095_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0095_ip);
-- probe 1/1 -> t1_tc_15_reg_0095_ip
INSERT INTO t1_tc_15_reg_0095_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0095_ip
INSERT INTO t2_tc_15_reg_0095_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0095-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0095_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0095_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0095_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0095_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0095-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0095_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0095_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0095_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0095_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0095_ip a JOIN t2_tc_15_reg_0095_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0095-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0095_ip' AND column_name='target';

-- Test Case: TC-15-REG-0096-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-02
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=UNIQUE_INDEX, non_target_index=ONE_SECONDARY, null_ratio=ALL, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=360831312852 column_type=binary(255) neg_probe=fb06478a245e=167|1264|1265|1406 neg_probe=3f26937630fb=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0096_ip, t2_tc_15_reg_0096_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0096_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0096_ip (target) VALUES (NULL);
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0096_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0096_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0096_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0096_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0096_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0096_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0096_ip (target) VALUES ('');
INSERT INTO t1_tc_15_reg_0096_ip (target) VALUES (NULL);
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0096_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1), UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0096_ip (target) VALUES (NULL);
INSERT INTO t2_tc_15_reg_0096_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0096_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0096_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0096_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0096_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0096_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0096_ip (target) VALUES (NULL);
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0096_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0096_ip);
-- probe 1/1 -> t1_tc_15_reg_0096_ip
INSERT INTO t1_tc_15_reg_0096_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0096_ip
INSERT INTO t2_tc_15_reg_0096_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0096-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0096_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0096_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0096_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0096_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0096-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0096_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0096_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0096_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0096_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0096_ip a JOIN t2_tc_15_reg_0096_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0096-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0096_ip' AND column_name='target';

-- Test Case: TC-15-REG-0097-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-03
-- Transition ID: BIN-03
-- Factors: data_distribution=UNIFORM, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=be2543ff3257 column_type=binary(255) neg_probe=10355e40cd55=167|1264|1265|1406 neg_probe=ba5e15338ca0=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0097_ip, t2_tc_15_reg_0097_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0097_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0097_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0097_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255),
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0097_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0097_ip);
-- probe 1/1 -> t1_tc_15_reg_0097_ip
INSERT INTO t1_tc_15_reg_0097_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0097_ip
INSERT INTO t2_tc_15_reg_0097_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0097-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0097_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0097_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0097_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0097_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0097-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0097_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0097_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0097_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0097_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0097_ip a JOIN t2_tc_15_reg_0097_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0097-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0097_ip' AND column_name='target';

-- Test Case: TC-15-REG-0098-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-04
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S0, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=CLUSTERED, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NOT_NULL_DEFAULT, target_position=MIDDLE
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=88e7e607277b column_type=binary(255) neg_probe=bd07d500dc4e=167|1264|1265|1406 neg_probe=fc63158a3704=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0098_ip, t2_tc_15_reg_0098_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0098_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(254) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0098_ip MODIFY target BINARY(255) NOT NULL DEFAULT 0x00, ALGORITHM=inplace;
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0098_ip (
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  target BINARY(255) NOT NULL DEFAULT 0x00,
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0098_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0098_ip);
-- probe 1/1 -> t1_tc_15_reg_0098_ip
INSERT INTO t1_tc_15_reg_0098_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0098_ip
INSERT INTO t2_tc_15_reg_0098_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0098-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0098_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0098_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0098_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0098_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0098-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0098_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0098_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0098_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0098_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0098_ip a JOIN t2_tc_15_reg_0098_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0098-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 1)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=3,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=NO has_default=1 charset=NULL collation=NULL extra= pos=3]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0098_ip' AND column_name='target';

-- Test Case: TC-15-REG-0099-IP
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Varied factor: KP-05
-- Transition ID: BIN-03
-- Factors: data_distribution=TYPE_BOUNDARIES, data_scale=S100, dependencies=NONE, non_target_index=ONE_SECONDARY, null_ratio=TEN_PERCENT, primary_key=COMPOSITE_PK, row_format=DYNAMIC, sql_mode=STRICT, target_attributes=NULL_NO_DEFAULT, target_position=FIRST
-- @expect alter=SUCCESS build=SUCCESS assertions=3 neg_probes=1 alter_sha=4d448abb58fb column_type=binary(255) neg_probe=addeaa5c454f=167|1264|1265|1406 neg_probe=0d3effaf11f5=167|1264|1265|1406
DROP TABLE IF EXISTS t1_tc_15_reg_0099_ip, t2_tc_15_reg_0099_ip;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_15_reg_0099_ip (
  target BINARY(254),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t1_tc_15_reg_0099_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0099_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0099_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0099_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_reg_0099_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_reg_0099_ip MODIFY target BINARY(255), ALGORITHM=inplace;
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0099_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0099_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
-- Insert new-range value (may fail if ALTER failed)
INSERT INTO t1_tc_15_reg_0099_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t1_tc_15_reg_0099_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_reg_0099_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_reg_0099_ip (target) VALUES ('');
-- Oracle table: BINARY(255)
CREATE TABLE t2_tc_15_reg_0099_ip (
  target BINARY(255),
  id INT NOT NULL AUTO_INCREMENT,
  pad1 VARCHAR(20) DEFAULT 'pad1',
  pad2 VARCHAR(20) DEFAULT 'pad2', PRIMARY KEY (id, target), INDEX idx_pad1 (pad1)
) ENGINE=InnoDB ROW_FORMAT=DYNAMIC;
INSERT INTO t2_tc_15_reg_0099_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0099_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0099_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0099_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t2_tc_15_reg_0099_ip (target) VALUES ('');
INSERT INTO t2_tc_15_reg_0099_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0099_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0099_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
INSERT INTO t2_tc_15_reg_0099_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t2_tc_15_reg_0099_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t2_tc_15_reg_0099_ip (target) VALUES ('');
-- Negative probes: 超出新类型上限的值（STRICT 必须拒绝 / 非 STRICT 必须与对照表一致）
SET @neg_before_t1 = (SELECT COUNT(*) FROM t1_tc_15_reg_0099_ip);
SET @neg_before_t2 = (SELECT COUNT(*) FROM t2_tc_15_reg_0099_ip);
-- probe 1/1 -> t1_tc_15_reg_0099_ip
INSERT INTO t1_tc_15_reg_0099_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
-- probe 1/1 -> t2_tc_15_reg_0099_ip
INSERT INTO t2_tc_15_reg_0099_ip (target) VALUES (0x41414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141414141);
SELECT 'TC-15-REG-0099-IP#NEG_REJECTED' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_15_reg_0099_ip) - @neg_before_t1 = 0 AND (SELECT COUNT(*) FROM t2_tc_15_reg_0099_ip) - @neg_before_t2 = 0,'PASS','FAIL') AS result,
       CONCAT('t1_added=',(SELECT COUNT(*) FROM t1_tc_15_reg_0099_ip) - @neg_before_t1,' t2_added=',(SELECT COUNT(*) FROM t2_tc_15_reg_0099_ip) - @neg_before_t2,' expect=0 (STRICT: 超限值必须被拒绝) sql_mode=',@@session.sql_mode) AS mismatch;
SELECT 'TC-15-REG-0099-IP' AS test_id,
       IF(COUNT(*)=0,'PASS','FAIL') AS result,
       IF(COUNT(*)=0,'',GROUP_CONCAT(CONCAT(src,':id=',id) SEPARATOR '; ')) AS mismatch
FROM (
  SELECT 't1_extra' AS src, id FROM t1_tc_15_reg_0099_ip
   WHERE id NOT IN (SELECT id FROM t2_tc_15_reg_0099_ip)
  UNION ALL
  SELECT 't2_extra' AS src, id FROM t2_tc_15_reg_0099_ip
   WHERE id NOT IN (SELECT id FROM t1_tc_15_reg_0099_ip)
  UNION ALL
  SELECT 'data_mismatch' AS src, a.id FROM t1_tc_15_reg_0099_ip a JOIN t2_tc_15_reg_0099_ip b ON a.id = b.id
   WHERE NOT (a.id <=> b.id AND a.pad1 <=> b.pad1 AND a.target <=> b.target AND a.pad2 <=> b.pad2)
) AS mismatches;
SELECT 'TC-15-REG-0099-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='NO'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=1,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=NO has_default=0 charset=NULL collation=NULL extra= pos=1]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_reg_0099_ip' AND column_name='target';

-- Test Case: TC-15-ATR-0003-IP
-- Column attribute preservation: COMMENT
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace
-- Transition ID: BIN-03
-- @expect alter=SUCCESS build=SUCCESS assertions=2 alter_sha=fd1424e75cdc column_type=binary(255)
DROP TABLE IF EXISTS t1_tc_15_atr_0003_ip, t2_tc_15_atr_0003_ip;
CREATE TABLE t1_tc_15_atr_0003_ip (
  id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
  target BINARY(254) COMMENT 'test_comment',
  pad VARCHAR(20) DEFAULT 'pad'
) ENGINE=InnoDB;
INSERT INTO t1_tc_15_atr_0003_ip (target) VALUES (0x0000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_atr_0003_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_atr_0003_ip (target) VALUES (0x00000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_atr_0003_ip (target) VALUES (0x4142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142414241424142);
INSERT INTO t1_tc_15_atr_0003_ip (target) VALUES ('');
-- Expected: ALTER SUCCESS
ALTER TABLE t1_tc_15_atr_0003_ip MODIFY target BINARY(255) COMMENT 'test_comment', ALGORITHM=inplace;
INSERT INTO t1_tc_15_atr_0003_ip (target) VALUES (0x000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);
INSERT INTO t1_tc_15_atr_0003_ip (target) VALUES (0xffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffffff);
INSERT INTO t1_tc_15_atr_0003_ip (target) VALUES (0x4d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d49584d4958);
SELECT 'TC-15-ATR-0003-IP' AS test_id, IF(COUNT(*)>0,'PASS','FAIL') AS result FROM information_schema.columns WHERE table_schema=DATABASE() AND table_name='t1_tc_15_atr_0003_ip' AND column_name='target' AND column_comment='test_comment';
SELECT 'TC-15-ATR-0003-IP#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              ' want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_15_atr_0003_ip' AND column_name='target';

