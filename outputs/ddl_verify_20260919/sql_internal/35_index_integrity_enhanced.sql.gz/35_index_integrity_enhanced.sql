-- ============================================================
-- RDS MySQL DDL 秒级/在线修改列类型 测试套件 — 内网环境
-- 环境说明: 所有功能开关默认开启
-- 覆盖类型: BINARY + VARBINARY + DECIMAL + TEXT + BLOB + BIT
-- 覆盖算法: INSTANT + INPLACE (增强类型 INSTANT 预期成功: BINARY/VARBINARY/DECIMAL 已确认支持)
-- ============================================================
-- 本文件由 generate_test_sql.py 自动生成, 请勿手动修改
-- Suite-Revision: 1186b16f779b   (生成器源码哈希; 时间戳见 results/generation_manifest.json)
-- 用例 ID 规则: TC-<文件号>-<作用域>-<序号>-<IT|IP>  —— 全局唯一
--   作用域 REG=普通表 OFAT/二元组, ATR=列属性保持, SPE=特殊模式,
--          FK=外键, PTK=分区(目标列是分区键), PNK=分区(目标列非分区键)
-- ============================================================

SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
SET SESSION innodb_lock_wait_timeout = 50;

-- File 35: 索引与约束完整性复验 (SECONDARY / UNIQUE)

-- Test Case: TC-35-IDX-0001-XX
-- Index integrity: SECONDARY index on target
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: BIN-01
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=8f2b17714714 column_type=binary(20) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0001_xx, t2_tc_35_idx_0001_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0001_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BINARY(10),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'0000000000000000');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'0000000000000001');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'0000000000000002');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'0000000000000003');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'0000000000000004');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'0000000000000005');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'0000000000000006');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'0000000000000007');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'0000000000000008');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'0000000000000009');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'000000000000000A');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'000000000000000B');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'000000000000000C');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'000000000000000D');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'000000000000000E');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'000000000000000F');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'0000000000000010');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'0000000000000011');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'0000000000000012');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'0000000000000013');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'0000000000000014');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'0000000000000015');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'0000000000000016');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'0000000000000017');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'0000000000000018');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'0000000000000019');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'000000000000001A');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'000000000000001B');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'000000000000001C');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'000000000000001D');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'000000000000001E');
INSERT INTO t1_tc_35_idx_0001_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t1_tc_35_idx_0001_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0001_xx MODIFY target BINARY(20), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0001_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BINARY(20),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'0000000000000000');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'0000000000000001');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'0000000000000002');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'0000000000000003');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'0000000000000004');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'0000000000000005');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'0000000000000006');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'0000000000000007');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'0000000000000008');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'0000000000000009');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'000000000000000A');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'000000000000000B');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'000000000000000C');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'000000000000000D');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'000000000000000E');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'000000000000000F');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'0000000000000010');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'0000000000000011');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'0000000000000012');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'0000000000000013');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'0000000000000014');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'0000000000000015');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'0000000000000016');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'0000000000000017');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'0000000000000018');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'0000000000000019');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'000000000000001A');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'000000000000001B');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'000000000000001C');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'000000000000001D');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'000000000000001E');
INSERT INTO t2_tc_35_idx_0001_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t2_tc_35_idx_0001_xx;
SELECT 'TC-35-IDX-0001-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0001_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0001_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0001-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0001_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0001_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0001_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0001_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0001-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0001_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0001_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0001-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0001_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0001_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0001_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0001_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0001-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0001_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0002-XX
-- Index integrity: UNIQUE index on target
-- Type: BINARY(10) -> BINARY(20), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: BIN-01
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=4e30de7cd0ef column_type=binary(20) index_kind=UNIQUE neg_probe=e0165f4168b5=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0002_xx, t2_tc_35_idx_0002_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0002_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BINARY(10),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000000');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000001');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000002');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000003');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000004');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000005');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000006');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000007');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000008');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000009');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'000000000000000A');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'000000000000000B');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'000000000000000C');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'000000000000000D');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'000000000000000E');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'000000000000000F');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000010');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000011');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000012');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000013');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000014');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000015');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000016');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000017');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000018');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000019');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'000000000000001A');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'000000000000001B');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'000000000000001C');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'000000000000001D');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'000000000000001E');
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t1_tc_35_idx_0002_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0002_xx MODIFY target BINARY(20), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0002_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BINARY(20),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'0000000000000000');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'0000000000000001');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'0000000000000002');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'0000000000000003');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'0000000000000004');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'0000000000000005');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'0000000000000006');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'0000000000000007');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'0000000000000008');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'0000000000000009');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'000000000000000A');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'000000000000000B');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'000000000000000C');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'000000000000000D');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'000000000000000E');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'000000000000000F');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'0000000000000010');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'0000000000000011');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'0000000000000012');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'0000000000000013');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'0000000000000014');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'0000000000000015');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'0000000000000016');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'0000000000000017');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'0000000000000018');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'0000000000000019');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'000000000000001A');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'000000000000001B');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'000000000000001C');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'000000000000001D');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'000000000000001E');
INSERT INTO t2_tc_35_idx_0002_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t2_tc_35_idx_0002_xx;
SELECT 'TC-35-IDX-0002-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0002_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0002_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0002-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0002_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0002_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0002_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0002_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0002-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0002_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0002_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0002-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0002_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0002_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0002_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0002_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0002-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(20)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=binary(20) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0002_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0002_xx (target) VALUES (X'0000000000000000');

-- Test Case: TC-35-IDX-0003-XX
-- Index integrity: SECONDARY index on target
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: BIN-02
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=5529af7db707 column_type=binary(80) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0003_xx, t2_tc_35_idx_0003_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0003_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BINARY(40),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'0000000000000000');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'0000000000000001');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'0000000000000002');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'0000000000000003');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'0000000000000004');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'0000000000000005');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'0000000000000006');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'0000000000000007');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'0000000000000008');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'0000000000000009');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'000000000000000A');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'000000000000000B');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'000000000000000C');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'000000000000000D');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'000000000000000E');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'000000000000000F');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'0000000000000010');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'0000000000000011');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'0000000000000012');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'0000000000000013');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'0000000000000014');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'0000000000000015');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'0000000000000016');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'0000000000000017');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'0000000000000018');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'0000000000000019');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'000000000000001A');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'000000000000001B');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'000000000000001C');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'000000000000001D');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'000000000000001E');
INSERT INTO t1_tc_35_idx_0003_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t1_tc_35_idx_0003_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0003_xx MODIFY target BINARY(80), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0003_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BINARY(80),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'0000000000000000');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'0000000000000001');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'0000000000000002');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'0000000000000003');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'0000000000000004');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'0000000000000005');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'0000000000000006');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'0000000000000007');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'0000000000000008');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'0000000000000009');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'000000000000000A');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'000000000000000B');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'000000000000000C');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'000000000000000D');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'000000000000000E');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'000000000000000F');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'0000000000000010');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'0000000000000011');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'0000000000000012');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'0000000000000013');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'0000000000000014');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'0000000000000015');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'0000000000000016');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'0000000000000017');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'0000000000000018');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'0000000000000019');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'000000000000001A');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'000000000000001B');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'000000000000001C');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'000000000000001D');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'000000000000001E');
INSERT INTO t2_tc_35_idx_0003_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t2_tc_35_idx_0003_xx;
SELECT 'TC-35-IDX-0003-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0003_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0003_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0003-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0003_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0003_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0003_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0003_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0003-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0003_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0003_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0003-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0003_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0003_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0003_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0003_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0003-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0003_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0004-XX
-- Index integrity: UNIQUE index on target
-- Type: BINARY(40) -> BINARY(80), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: BIN-02
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=d49d0ec465d6 column_type=binary(80) index_kind=UNIQUE neg_probe=c8c23a0e5719=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0004_xx, t2_tc_35_idx_0004_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0004_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BINARY(40),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000000');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000001');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000002');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000003');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000004');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000005');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000006');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000007');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000008');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000009');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'000000000000000A');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'000000000000000B');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'000000000000000C');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'000000000000000D');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'000000000000000E');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'000000000000000F');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000010');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000011');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000012');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000013');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000014');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000015');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000016');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000017');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000018');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000019');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'000000000000001A');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'000000000000001B');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'000000000000001C');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'000000000000001D');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'000000000000001E');
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t1_tc_35_idx_0004_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0004_xx MODIFY target BINARY(80), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0004_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BINARY(80),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'0000000000000000');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'0000000000000001');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'0000000000000002');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'0000000000000003');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'0000000000000004');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'0000000000000005');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'0000000000000006');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'0000000000000007');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'0000000000000008');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'0000000000000009');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'000000000000000A');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'000000000000000B');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'000000000000000C');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'000000000000000D');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'000000000000000E');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'000000000000000F');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'0000000000000010');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'0000000000000011');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'0000000000000012');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'0000000000000013');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'0000000000000014');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'0000000000000015');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'0000000000000016');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'0000000000000017');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'0000000000000018');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'0000000000000019');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'000000000000001A');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'000000000000001B');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'000000000000001C');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'000000000000001D');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'000000000000001E');
INSERT INTO t2_tc_35_idx_0004_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t2_tc_35_idx_0004_xx;
SELECT 'TC-35-IDX-0004-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0004_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0004_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0004-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0004_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0004_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0004_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0004_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0004-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0004_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0004_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0004-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0004_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0004_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0004_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0004_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0004-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(80)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=binary(80) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0004_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0004_xx (target) VALUES (X'0000000000000000');

-- Test Case: TC-35-IDX-0005-XX
-- Index integrity: SECONDARY index on target
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: BIN-03
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=be4b159a2256 column_type=binary(255) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0005_xx, t2_tc_35_idx_0005_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0005_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BINARY(254),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'0000000000000000');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'0000000000000001');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'0000000000000002');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'0000000000000003');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'0000000000000004');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'0000000000000005');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'0000000000000006');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'0000000000000007');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'0000000000000008');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'0000000000000009');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'000000000000000A');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'000000000000000B');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'000000000000000C');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'000000000000000D');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'000000000000000E');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'000000000000000F');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'0000000000000010');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'0000000000000011');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'0000000000000012');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'0000000000000013');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'0000000000000014');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'0000000000000015');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'0000000000000016');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'0000000000000017');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'0000000000000018');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'0000000000000019');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'000000000000001A');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'000000000000001B');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'000000000000001C');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'000000000000001D');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'000000000000001E');
INSERT INTO t1_tc_35_idx_0005_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t1_tc_35_idx_0005_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0005_xx MODIFY target BINARY(255), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0005_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BINARY(255),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'0000000000000000');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'0000000000000001');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'0000000000000002');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'0000000000000003');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'0000000000000004');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'0000000000000005');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'0000000000000006');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'0000000000000007');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'0000000000000008');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'0000000000000009');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'000000000000000A');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'000000000000000B');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'000000000000000C');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'000000000000000D');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'000000000000000E');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'000000000000000F');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'0000000000000010');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'0000000000000011');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'0000000000000012');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'0000000000000013');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'0000000000000014');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'0000000000000015');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'0000000000000016');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'0000000000000017');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'0000000000000018');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'0000000000000019');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'000000000000001A');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'000000000000001B');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'000000000000001C');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'000000000000001D');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'000000000000001E');
INSERT INTO t2_tc_35_idx_0005_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t2_tc_35_idx_0005_xx;
SELECT 'TC-35-IDX-0005-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0005_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0005_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0005-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0005_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0005_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0005_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0005_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0005-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0005_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0005_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0005-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0005_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0005_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0005_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0005_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0005-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0005_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0006-XX
-- Index integrity: UNIQUE index on target
-- Type: BINARY(254) -> BINARY(255), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: BIN-03
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=6e5fe31d7267 column_type=binary(255) index_kind=UNIQUE neg_probe=c3359380aa06=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0006_xx, t2_tc_35_idx_0006_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0006_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BINARY(254),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000000');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000001');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000002');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000003');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000004');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000005');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000006');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000007');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000008');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000009');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'000000000000000A');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'000000000000000B');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'000000000000000C');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'000000000000000D');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'000000000000000E');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'000000000000000F');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000010');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000011');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000012');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000013');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000014');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000015');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000016');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000017');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000018');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000019');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'000000000000001A');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'000000000000001B');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'000000000000001C');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'000000000000001D');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'000000000000001E');
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t1_tc_35_idx_0006_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0006_xx MODIFY target BINARY(255), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0006_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BINARY(255),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'0000000000000000');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'0000000000000001');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'0000000000000002');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'0000000000000003');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'0000000000000004');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'0000000000000005');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'0000000000000006');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'0000000000000007');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'0000000000000008');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'0000000000000009');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'000000000000000A');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'000000000000000B');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'000000000000000C');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'000000000000000D');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'000000000000000E');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'000000000000000F');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'0000000000000010');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'0000000000000011');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'0000000000000012');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'0000000000000013');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'0000000000000014');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'0000000000000015');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'0000000000000016');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'0000000000000017');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'0000000000000018');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'0000000000000019');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'000000000000001A');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'000000000000001B');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'000000000000001C');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'000000000000001D');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'000000000000001E');
INSERT INTO t2_tc_35_idx_0006_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t2_tc_35_idx_0006_xx;
SELECT 'TC-35-IDX-0006-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0006_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0006_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0006-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0006_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0006_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0006_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0006_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0006-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0006_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0006_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0006-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0006_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0006_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0006_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0006_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0006-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='binary(255)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=binary(255) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0006_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0006_xx (target) VALUES (X'0000000000000000');

-- Test Case: TC-35-IDX-0007-XX
-- Index integrity: SECONDARY index on target
-- Type: VARBINARY(20) -> VARBINARY(40), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VBIN-01
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=267113f99414 column_type=varbinary(40) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0007_xx, t2_tc_35_idx_0007_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0007_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARBINARY(20),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'0000000000000000');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'0000000000000001');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'0000000000000002');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'0000000000000003');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'0000000000000004');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'0000000000000005');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'0000000000000006');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'0000000000000007');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'0000000000000008');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'0000000000000009');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'000000000000000A');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'000000000000000B');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'000000000000000C');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'000000000000000D');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'000000000000000E');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'000000000000000F');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'0000000000000010');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'0000000000000011');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'0000000000000012');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'0000000000000013');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'0000000000000014');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'0000000000000015');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'0000000000000016');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'0000000000000017');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'0000000000000018');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'0000000000000019');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'000000000000001A');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'000000000000001B');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'000000000000001C');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'000000000000001D');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'000000000000001E');
INSERT INTO t1_tc_35_idx_0007_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t1_tc_35_idx_0007_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0007_xx MODIFY target VARBINARY(40), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0007_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARBINARY(40),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'0000000000000000');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'0000000000000001');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'0000000000000002');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'0000000000000003');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'0000000000000004');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'0000000000000005');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'0000000000000006');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'0000000000000007');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'0000000000000008');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'0000000000000009');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'000000000000000A');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'000000000000000B');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'000000000000000C');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'000000000000000D');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'000000000000000E');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'000000000000000F');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'0000000000000010');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'0000000000000011');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'0000000000000012');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'0000000000000013');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'0000000000000014');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'0000000000000015');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'0000000000000016');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'0000000000000017');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'0000000000000018');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'0000000000000019');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'000000000000001A');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'000000000000001B');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'000000000000001C');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'000000000000001D');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'000000000000001E');
INSERT INTO t2_tc_35_idx_0007_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t2_tc_35_idx_0007_xx;
SELECT 'TC-35-IDX-0007-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0007_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0007_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0007-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0007_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0007_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0007_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0007_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0007-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0007_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0007_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0007-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0007_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0007_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0007_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0007_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0007-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varbinary(40)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varbinary(40) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0007_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0008-XX
-- Index integrity: UNIQUE index on target
-- Type: VARBINARY(20) -> VARBINARY(40), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VBIN-01
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=4d4803575417 column_type=varbinary(40) index_kind=UNIQUE neg_probe=1a560ce597d7=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0008_xx, t2_tc_35_idx_0008_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0008_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARBINARY(20),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000000');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000001');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000002');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000003');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000004');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000005');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000006');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000007');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000008');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000009');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'000000000000000A');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'000000000000000B');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'000000000000000C');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'000000000000000D');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'000000000000000E');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'000000000000000F');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000010');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000011');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000012');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000013');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000014');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000015');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000016');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000017');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000018');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000019');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'000000000000001A');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'000000000000001B');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'000000000000001C');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'000000000000001D');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'000000000000001E');
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t1_tc_35_idx_0008_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0008_xx MODIFY target VARBINARY(40), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0008_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARBINARY(40),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'0000000000000000');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'0000000000000001');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'0000000000000002');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'0000000000000003');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'0000000000000004');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'0000000000000005');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'0000000000000006');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'0000000000000007');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'0000000000000008');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'0000000000000009');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'000000000000000A');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'000000000000000B');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'000000000000000C');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'000000000000000D');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'000000000000000E');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'000000000000000F');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'0000000000000010');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'0000000000000011');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'0000000000000012');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'0000000000000013');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'0000000000000014');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'0000000000000015');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'0000000000000016');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'0000000000000017');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'0000000000000018');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'0000000000000019');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'000000000000001A');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'000000000000001B');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'000000000000001C');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'000000000000001D');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'000000000000001E');
INSERT INTO t2_tc_35_idx_0008_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t2_tc_35_idx_0008_xx;
SELECT 'TC-35-IDX-0008-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0008_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0008_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0008-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0008_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0008_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0008_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0008_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0008-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0008_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0008_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0008-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0008_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0008_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0008_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0008_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0008-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varbinary(40)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varbinary(40) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0008_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0008_xx (target) VALUES (X'0000000000000000');

-- Test Case: TC-35-IDX-0009-XX
-- Index integrity: SECONDARY index on target
-- Type: VARBINARY(100) -> VARBINARY(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VBIN-02
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=76f4e04e55f7 column_type=varbinary(200) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0009_xx, t2_tc_35_idx_0009_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0009_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARBINARY(100),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'0000000000000000');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'0000000000000001');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'0000000000000002');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'0000000000000003');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'0000000000000004');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'0000000000000005');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'0000000000000006');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'0000000000000007');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'0000000000000008');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'0000000000000009');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'000000000000000A');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'000000000000000B');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'000000000000000C');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'000000000000000D');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'000000000000000E');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'000000000000000F');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'0000000000000010');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'0000000000000011');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'0000000000000012');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'0000000000000013');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'0000000000000014');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'0000000000000015');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'0000000000000016');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'0000000000000017');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'0000000000000018');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'0000000000000019');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'000000000000001A');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'000000000000001B');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'000000000000001C');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'000000000000001D');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'000000000000001E');
INSERT INTO t1_tc_35_idx_0009_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t1_tc_35_idx_0009_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0009_xx MODIFY target VARBINARY(200), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0009_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARBINARY(200),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'0000000000000000');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'0000000000000001');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'0000000000000002');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'0000000000000003');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'0000000000000004');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'0000000000000005');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'0000000000000006');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'0000000000000007');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'0000000000000008');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'0000000000000009');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'000000000000000A');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'000000000000000B');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'000000000000000C');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'000000000000000D');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'000000000000000E');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'000000000000000F');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'0000000000000010');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'0000000000000011');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'0000000000000012');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'0000000000000013');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'0000000000000014');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'0000000000000015');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'0000000000000016');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'0000000000000017');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'0000000000000018');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'0000000000000019');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'000000000000001A');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'000000000000001B');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'000000000000001C');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'000000000000001D');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'000000000000001E');
INSERT INTO t2_tc_35_idx_0009_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t2_tc_35_idx_0009_xx;
SELECT 'TC-35-IDX-0009-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0009_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0009_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0009-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0009_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0009_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0009_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0009_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0009-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0009_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0009_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0009-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0009_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0009_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0009_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0009_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0009-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varbinary(200)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varbinary(200) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0009_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0010-XX
-- Index integrity: UNIQUE index on target
-- Type: VARBINARY(100) -> VARBINARY(200), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VBIN-02
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=326309c37b60 column_type=varbinary(200) index_kind=UNIQUE neg_probe=8987b466173b=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0010_xx, t2_tc_35_idx_0010_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0010_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARBINARY(100),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000000');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000001');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000002');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000003');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000004');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000005');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000006');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000007');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000008');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000009');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'000000000000000A');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'000000000000000B');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'000000000000000C');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'000000000000000D');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'000000000000000E');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'000000000000000F');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000010');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000011');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000012');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000013');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000014');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000015');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000016');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000017');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000018');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000019');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'000000000000001A');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'000000000000001B');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'000000000000001C');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'000000000000001D');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'000000000000001E');
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t1_tc_35_idx_0010_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0010_xx MODIFY target VARBINARY(200), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0010_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARBINARY(200),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'0000000000000000');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'0000000000000001');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'0000000000000002');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'0000000000000003');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'0000000000000004');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'0000000000000005');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'0000000000000006');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'0000000000000007');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'0000000000000008');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'0000000000000009');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'000000000000000A');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'000000000000000B');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'000000000000000C');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'000000000000000D');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'000000000000000E');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'000000000000000F');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'0000000000000010');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'0000000000000011');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'0000000000000012');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'0000000000000013');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'0000000000000014');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'0000000000000015');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'0000000000000016');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'0000000000000017');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'0000000000000018');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'0000000000000019');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'000000000000001A');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'000000000000001B');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'000000000000001C');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'000000000000001D');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'000000000000001E');
INSERT INTO t2_tc_35_idx_0010_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t2_tc_35_idx_0010_xx;
SELECT 'TC-35-IDX-0010-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0010_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0010_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0010-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0010_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0010_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0010_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0010_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0010-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0010_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0010_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0010-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0010_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0010_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0010_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0010_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0010-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varbinary(200)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varbinary(200) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0010_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0010_xx (target) VALUES (X'0000000000000000');

-- Test Case: TC-35-IDX-0011-XX
-- Index integrity: SECONDARY index on target
-- Type: VARBINARY(65527) -> VARBINARY(65528), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VBIN-03
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=1e9701938105 column_type=varbinary(65528) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0011_xx, t2_tc_35_idx_0011_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0011_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARBINARY(65527),
  PRIMARY KEY (id),
  INDEX idx_target (target(64))
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'0000000000000000');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'0000000000000001');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'0000000000000002');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'0000000000000003');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'0000000000000004');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'0000000000000005');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'0000000000000006');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'0000000000000007');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'0000000000000008');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'0000000000000009');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'000000000000000A');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'000000000000000B');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'000000000000000C');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'000000000000000D');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'000000000000000E');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'000000000000000F');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'0000000000000010');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'0000000000000011');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'0000000000000012');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'0000000000000013');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'0000000000000014');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'0000000000000015');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'0000000000000016');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'0000000000000017');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'0000000000000018');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'0000000000000019');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'000000000000001A');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'000000000000001B');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'000000000000001C');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'000000000000001D');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'000000000000001E');
INSERT INTO t1_tc_35_idx_0011_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t1_tc_35_idx_0011_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0011_xx MODIFY target VARBINARY(65528), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0011_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARBINARY(65528),
  PRIMARY KEY (id),
  INDEX idx_target (target(64))
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'0000000000000000');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'0000000000000001');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'0000000000000002');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'0000000000000003');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'0000000000000004');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'0000000000000005');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'0000000000000006');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'0000000000000007');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'0000000000000008');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'0000000000000009');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'000000000000000A');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'000000000000000B');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'000000000000000C');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'000000000000000D');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'000000000000000E');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'000000000000000F');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'0000000000000010');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'0000000000000011');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'0000000000000012');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'0000000000000013');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'0000000000000014');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'0000000000000015');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'0000000000000016');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'0000000000000017');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'0000000000000018');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'0000000000000019');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'000000000000001A');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'000000000000001B');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'000000000000001C');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'000000000000001D');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'000000000000001E');
INSERT INTO t2_tc_35_idx_0011_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t2_tc_35_idx_0011_xx;
SELECT 'TC-35-IDX-0011-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0011_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0011_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0011-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0011_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0011_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0011_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0011_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0011-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0011_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0011_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0011-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0011_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0011_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0011_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0011_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0011-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varbinary(65528)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varbinary(65528) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0011_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0012-XX
-- Index integrity: UNIQUE index on target
-- Type: VARBINARY(65527) -> VARBINARY(65528), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: VBIN-03
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=fbfde1b13dea column_type=varbinary(65528) index_kind=UNIQUE neg_probe=9103f6d6e3a3=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0012_xx, t2_tc_35_idx_0012_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0012_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARBINARY(65527),
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target(64))
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000000');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000001');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000002');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000003');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000004');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000005');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000006');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000007');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000008');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000009');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'000000000000000A');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'000000000000000B');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'000000000000000C');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'000000000000000D');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'000000000000000E');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'000000000000000F');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000010');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000011');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000012');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000013');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000014');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000015');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000016');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000017');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000018');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000019');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'000000000000001A');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'000000000000001B');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'000000000000001C');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'000000000000001D');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'000000000000001E');
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t1_tc_35_idx_0012_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0012_xx MODIFY target VARBINARY(65528), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0012_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target VARBINARY(65528),
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target(64))
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'0000000000000000');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'0000000000000001');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'0000000000000002');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'0000000000000003');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'0000000000000004');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'0000000000000005');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'0000000000000006');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'0000000000000007');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'0000000000000008');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'0000000000000009');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'000000000000000A');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'000000000000000B');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'000000000000000C');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'000000000000000D');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'000000000000000E');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'000000000000000F');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'0000000000000010');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'0000000000000011');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'0000000000000012');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'0000000000000013');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'0000000000000014');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'0000000000000015');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'0000000000000016');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'0000000000000017');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'0000000000000018');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'0000000000000019');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'000000000000001A');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'000000000000001B');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'000000000000001C');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'000000000000001D');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'000000000000001E');
INSERT INTO t2_tc_35_idx_0012_xx (target) VALUES (X'000000000000001F');
ANALYZE TABLE t2_tc_35_idx_0012_xx;
SELECT 'TC-35-IDX-0012-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0012_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0012_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0012-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0012_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0012_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0012_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0012_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0012-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0012_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0012_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0012-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0012_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0012_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0012_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0012_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0012-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='varbinary(65528)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=varbinary(65528) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0012_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0012_xx (target) VALUES (X'0000000000000000');

-- Test Case: TC-35-IDX-0013-XX
-- Index integrity: SECONDARY index on target
-- Type: DECIMAL(10,2) -> DECIMAL(12,2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-01
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=0d13a1534633 column_type=decimal(12,2) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0013_xx, t2_tc_35_idx_0013_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0013_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(10,2),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.00);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.01);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.02);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.03);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.04);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.05);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.06);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.07);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.08);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.09);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.10);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.11);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.12);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.13);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.14);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.15);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.16);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.17);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.18);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.19);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.20);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.21);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.22);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.23);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.24);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.25);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.26);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.27);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.28);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.29);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.30);
INSERT INTO t1_tc_35_idx_0013_xx (target) VALUES (0.31);
ANALYZE TABLE t1_tc_35_idx_0013_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0013_xx MODIFY target DECIMAL(12,2), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0013_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(12,2),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.00);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.01);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.02);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.03);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.04);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.05);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.06);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.07);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.08);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.09);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.10);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.11);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.12);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.13);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.14);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.15);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.16);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.17);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.18);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.19);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.20);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.21);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.22);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.23);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.24);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.25);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.26);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.27);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.28);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.29);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.30);
INSERT INTO t2_tc_35_idx_0013_xx (target) VALUES (0.31);
ANALYZE TABLE t2_tc_35_idx_0013_xx;
SELECT 'TC-35-IDX-0013-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0013_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0013_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0013-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0013_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0013_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0013_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0013_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0013-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0013_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0013_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0013-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0013_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0013_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0013_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0013_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0013-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(12,2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(12,2) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0013_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0014-XX
-- Index integrity: UNIQUE index on target
-- Type: DECIMAL(10,2) -> DECIMAL(12,2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-01
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=4cec7bb13819 column_type=decimal(12,2) index_kind=UNIQUE neg_probe=f4d4de8456c6=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0014_xx, t2_tc_35_idx_0014_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0014_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(10,2),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.00);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.01);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.02);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.03);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.04);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.05);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.06);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.07);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.08);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.09);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.10);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.11);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.12);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.13);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.14);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.15);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.16);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.17);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.18);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.19);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.20);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.21);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.22);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.23);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.24);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.25);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.26);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.27);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.28);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.29);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.30);
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.31);
ANALYZE TABLE t1_tc_35_idx_0014_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0014_xx MODIFY target DECIMAL(12,2), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0014_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(12,2),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.00);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.01);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.02);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.03);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.04);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.05);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.06);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.07);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.08);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.09);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.10);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.11);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.12);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.13);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.14);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.15);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.16);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.17);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.18);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.19);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.20);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.21);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.22);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.23);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.24);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.25);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.26);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.27);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.28);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.29);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.30);
INSERT INTO t2_tc_35_idx_0014_xx (target) VALUES (0.31);
ANALYZE TABLE t2_tc_35_idx_0014_xx;
SELECT 'TC-35-IDX-0014-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0014_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0014_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0014-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0014_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0014_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0014_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0014_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0014-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0014_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0014_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0014-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0014_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0014_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0014_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0014_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0014-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(12,2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(12,2) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0014_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0014_xx (target) VALUES (0.00);

-- Test Case: TC-35-IDX-0015-XX
-- Index integrity: SECONDARY index on target
-- Type: DECIMAL(1,0) -> DECIMAL(2,0), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-02
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=39c2ff119c82 column_type=decimal(2,0) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0015_xx, t2_tc_35_idx_0015_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0015_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(1,0),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0015_xx (target) VALUES (0);
INSERT INTO t1_tc_35_idx_0015_xx (target) VALUES (1);
INSERT INTO t1_tc_35_idx_0015_xx (target) VALUES (2);
INSERT INTO t1_tc_35_idx_0015_xx (target) VALUES (3);
INSERT INTO t1_tc_35_idx_0015_xx (target) VALUES (4);
INSERT INTO t1_tc_35_idx_0015_xx (target) VALUES (5);
INSERT INTO t1_tc_35_idx_0015_xx (target) VALUES (6);
INSERT INTO t1_tc_35_idx_0015_xx (target) VALUES (7);
INSERT INTO t1_tc_35_idx_0015_xx (target) VALUES (8);
INSERT INTO t1_tc_35_idx_0015_xx (target) VALUES (9);
ANALYZE TABLE t1_tc_35_idx_0015_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0015_xx MODIFY target DECIMAL(2,0), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0015_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(2,0),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0015_xx (target) VALUES (0);
INSERT INTO t2_tc_35_idx_0015_xx (target) VALUES (1);
INSERT INTO t2_tc_35_idx_0015_xx (target) VALUES (2);
INSERT INTO t2_tc_35_idx_0015_xx (target) VALUES (3);
INSERT INTO t2_tc_35_idx_0015_xx (target) VALUES (4);
INSERT INTO t2_tc_35_idx_0015_xx (target) VALUES (5);
INSERT INTO t2_tc_35_idx_0015_xx (target) VALUES (6);
INSERT INTO t2_tc_35_idx_0015_xx (target) VALUES (7);
INSERT INTO t2_tc_35_idx_0015_xx (target) VALUES (8);
INSERT INTO t2_tc_35_idx_0015_xx (target) VALUES (9);
ANALYZE TABLE t2_tc_35_idx_0015_xx;
SELECT 'TC-35-IDX-0015-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0015_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0015_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0015-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0015_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0015_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0015_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0015_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0015-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0015_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0015_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0015-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0015_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0015_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0015_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0015_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0015-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(2,0)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(2,0) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0015_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0016-XX
-- Index integrity: UNIQUE index on target
-- Type: DECIMAL(1,0) -> DECIMAL(2,0), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-02
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=79c7ff946f28 column_type=decimal(2,0) index_kind=UNIQUE neg_probe=4f0f32a84ff5=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0016_xx, t2_tc_35_idx_0016_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0016_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(1,0),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0016_xx (target) VALUES (0);
INSERT INTO t1_tc_35_idx_0016_xx (target) VALUES (1);
INSERT INTO t1_tc_35_idx_0016_xx (target) VALUES (2);
INSERT INTO t1_tc_35_idx_0016_xx (target) VALUES (3);
INSERT INTO t1_tc_35_idx_0016_xx (target) VALUES (4);
INSERT INTO t1_tc_35_idx_0016_xx (target) VALUES (5);
INSERT INTO t1_tc_35_idx_0016_xx (target) VALUES (6);
INSERT INTO t1_tc_35_idx_0016_xx (target) VALUES (7);
INSERT INTO t1_tc_35_idx_0016_xx (target) VALUES (8);
INSERT INTO t1_tc_35_idx_0016_xx (target) VALUES (9);
ANALYZE TABLE t1_tc_35_idx_0016_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0016_xx MODIFY target DECIMAL(2,0), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0016_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(2,0),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0016_xx (target) VALUES (0);
INSERT INTO t2_tc_35_idx_0016_xx (target) VALUES (1);
INSERT INTO t2_tc_35_idx_0016_xx (target) VALUES (2);
INSERT INTO t2_tc_35_idx_0016_xx (target) VALUES (3);
INSERT INTO t2_tc_35_idx_0016_xx (target) VALUES (4);
INSERT INTO t2_tc_35_idx_0016_xx (target) VALUES (5);
INSERT INTO t2_tc_35_idx_0016_xx (target) VALUES (6);
INSERT INTO t2_tc_35_idx_0016_xx (target) VALUES (7);
INSERT INTO t2_tc_35_idx_0016_xx (target) VALUES (8);
INSERT INTO t2_tc_35_idx_0016_xx (target) VALUES (9);
ANALYZE TABLE t2_tc_35_idx_0016_xx;
SELECT 'TC-35-IDX-0016-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0016_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0016_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0016-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0016_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0016_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0016_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0016_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0016-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0016_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0016_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0016-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0016_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0016_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0016_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0016_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0016-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(2,0)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(2,0) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0016_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0016_xx (target) VALUES (0);

-- Test Case: TC-35-IDX-0017-XX
-- Index integrity: SECONDARY index on target
-- Type: DECIMAL(1,1) -> DECIMAL(2,1), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-03
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=0da2ebc04d0c column_type=decimal(2,1) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0017_xx, t2_tc_35_idx_0017_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0017_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(1,1),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0017_xx (target) VALUES (0.0);
INSERT INTO t1_tc_35_idx_0017_xx (target) VALUES (0.1);
INSERT INTO t1_tc_35_idx_0017_xx (target) VALUES (0.2);
INSERT INTO t1_tc_35_idx_0017_xx (target) VALUES (0.3);
INSERT INTO t1_tc_35_idx_0017_xx (target) VALUES (0.4);
INSERT INTO t1_tc_35_idx_0017_xx (target) VALUES (0.5);
INSERT INTO t1_tc_35_idx_0017_xx (target) VALUES (0.6);
INSERT INTO t1_tc_35_idx_0017_xx (target) VALUES (0.7);
INSERT INTO t1_tc_35_idx_0017_xx (target) VALUES (0.8);
INSERT INTO t1_tc_35_idx_0017_xx (target) VALUES (0.9);
ANALYZE TABLE t1_tc_35_idx_0017_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0017_xx MODIFY target DECIMAL(2,1), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0017_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(2,1),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0017_xx (target) VALUES (0.0);
INSERT INTO t2_tc_35_idx_0017_xx (target) VALUES (0.1);
INSERT INTO t2_tc_35_idx_0017_xx (target) VALUES (0.2);
INSERT INTO t2_tc_35_idx_0017_xx (target) VALUES (0.3);
INSERT INTO t2_tc_35_idx_0017_xx (target) VALUES (0.4);
INSERT INTO t2_tc_35_idx_0017_xx (target) VALUES (0.5);
INSERT INTO t2_tc_35_idx_0017_xx (target) VALUES (0.6);
INSERT INTO t2_tc_35_idx_0017_xx (target) VALUES (0.7);
INSERT INTO t2_tc_35_idx_0017_xx (target) VALUES (0.8);
INSERT INTO t2_tc_35_idx_0017_xx (target) VALUES (0.9);
ANALYZE TABLE t2_tc_35_idx_0017_xx;
SELECT 'TC-35-IDX-0017-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0017_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0017_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0017-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0017_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0017_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0017_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0017_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0017-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0017_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0017_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0017-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0017_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0017_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0017_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0017_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0017-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(2,1)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(2,1) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0017_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0018-XX
-- Index integrity: UNIQUE index on target
-- Type: DECIMAL(1,1) -> DECIMAL(2,1), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-03
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=688263e46e28 column_type=decimal(2,1) index_kind=UNIQUE neg_probe=65824c2dce73=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0018_xx, t2_tc_35_idx_0018_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0018_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(1,1),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0018_xx (target) VALUES (0.0);
INSERT INTO t1_tc_35_idx_0018_xx (target) VALUES (0.1);
INSERT INTO t1_tc_35_idx_0018_xx (target) VALUES (0.2);
INSERT INTO t1_tc_35_idx_0018_xx (target) VALUES (0.3);
INSERT INTO t1_tc_35_idx_0018_xx (target) VALUES (0.4);
INSERT INTO t1_tc_35_idx_0018_xx (target) VALUES (0.5);
INSERT INTO t1_tc_35_idx_0018_xx (target) VALUES (0.6);
INSERT INTO t1_tc_35_idx_0018_xx (target) VALUES (0.7);
INSERT INTO t1_tc_35_idx_0018_xx (target) VALUES (0.8);
INSERT INTO t1_tc_35_idx_0018_xx (target) VALUES (0.9);
ANALYZE TABLE t1_tc_35_idx_0018_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0018_xx MODIFY target DECIMAL(2,1), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0018_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(2,1),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0018_xx (target) VALUES (0.0);
INSERT INTO t2_tc_35_idx_0018_xx (target) VALUES (0.1);
INSERT INTO t2_tc_35_idx_0018_xx (target) VALUES (0.2);
INSERT INTO t2_tc_35_idx_0018_xx (target) VALUES (0.3);
INSERT INTO t2_tc_35_idx_0018_xx (target) VALUES (0.4);
INSERT INTO t2_tc_35_idx_0018_xx (target) VALUES (0.5);
INSERT INTO t2_tc_35_idx_0018_xx (target) VALUES (0.6);
INSERT INTO t2_tc_35_idx_0018_xx (target) VALUES (0.7);
INSERT INTO t2_tc_35_idx_0018_xx (target) VALUES (0.8);
INSERT INTO t2_tc_35_idx_0018_xx (target) VALUES (0.9);
ANALYZE TABLE t2_tc_35_idx_0018_xx;
SELECT 'TC-35-IDX-0018-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0018_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0018_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0018-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0018_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0018_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0018_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0018_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0018-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0018_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0018_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0018-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0018_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0018_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0018_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0018_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0018-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(2,1)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(2,1) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0018_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0018_xx (target) VALUES (0.0);

-- Test Case: TC-35-IDX-0019-XX
-- Index integrity: SECONDARY index on target
-- Type: DECIMAL(64,30) -> DECIMAL(65,30), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-04
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=04fa98b0c354 column_type=decimal(65,30) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0019_xx, t2_tc_35_idx_0019_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0019_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(64,30),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000000);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000001);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000002);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000003);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000004);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000005);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000006);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000007);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000008);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000009);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000010);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000011);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000012);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000013);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000014);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000015);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000016);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000017);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000018);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000019);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000020);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000021);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000022);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000023);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000024);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000025);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000026);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000027);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000028);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000029);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000030);
INSERT INTO t1_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000031);
ANALYZE TABLE t1_tc_35_idx_0019_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0019_xx MODIFY target DECIMAL(65,30), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0019_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(65,30),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000000);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000001);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000002);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000003);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000004);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000005);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000006);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000007);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000008);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000009);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000010);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000011);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000012);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000013);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000014);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000015);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000016);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000017);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000018);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000019);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000020);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000021);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000022);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000023);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000024);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000025);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000026);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000027);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000028);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000029);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000030);
INSERT INTO t2_tc_35_idx_0019_xx (target) VALUES (0.000000000000000000000000000031);
ANALYZE TABLE t2_tc_35_idx_0019_xx;
SELECT 'TC-35-IDX-0019-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0019_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0019_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0019-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0019_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0019_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0019_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0019_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0019-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0019_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0019_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0019-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0019_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0019_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0019_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0019_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0019-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(65,30)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(65,30) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0019_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0020-XX
-- Index integrity: UNIQUE index on target
-- Type: DECIMAL(64,30) -> DECIMAL(65,30), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-04
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=32c38ff3686f column_type=decimal(65,30) index_kind=UNIQUE neg_probe=85e83a3db03b=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0020_xx, t2_tc_35_idx_0020_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0020_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(64,30),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000000);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000001);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000002);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000003);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000004);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000005);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000006);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000007);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000008);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000009);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000010);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000011);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000012);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000013);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000014);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000015);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000016);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000017);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000018);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000019);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000020);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000021);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000022);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000023);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000024);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000025);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000026);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000027);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000028);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000029);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000030);
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000031);
ANALYZE TABLE t1_tc_35_idx_0020_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0020_xx MODIFY target DECIMAL(65,30), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0020_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(65,30),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000000);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000001);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000002);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000003);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000004);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000005);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000006);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000007);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000008);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000009);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000010);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000011);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000012);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000013);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000014);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000015);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000016);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000017);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000018);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000019);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000020);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000021);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000022);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000023);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000024);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000025);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000026);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000027);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000028);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000029);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000030);
INSERT INTO t2_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000031);
ANALYZE TABLE t2_tc_35_idx_0020_xx;
SELECT 'TC-35-IDX-0020-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0020_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0020_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0020-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0020_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0020_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0020_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0020_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0020-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0020_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0020_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0020-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0020_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0020_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0020_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0020_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0020-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(65,30)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(65,30) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0020_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0020_xx (target) VALUES (0.000000000000000000000000000000);

-- Test Case: TC-35-IDX-0021-XX
-- Index integrity: SECONDARY index on target
-- Type: DECIMAL(18,0) -> DECIMAL(20,0), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-05
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=0ae96394445d column_type=decimal(20,0) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0021_xx, t2_tc_35_idx_0021_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0021_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(18,0),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (0);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (1);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (2);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (3);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (4);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (5);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (6);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (7);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (8);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (9);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (10);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (11);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (12);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (13);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (14);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (15);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (16);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (17);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (18);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (19);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (20);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (21);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (22);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (23);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (24);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (25);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (26);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (27);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (28);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (29);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (30);
INSERT INTO t1_tc_35_idx_0021_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_35_idx_0021_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0021_xx MODIFY target DECIMAL(20,0), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0021_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(20,0),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (0);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (1);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (2);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (3);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (4);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (5);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (6);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (7);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (8);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (9);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (10);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (11);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (12);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (13);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (14);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (15);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (16);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (17);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (18);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (19);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (20);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (21);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (22);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (23);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (24);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (25);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (26);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (27);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (28);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (29);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (30);
INSERT INTO t2_tc_35_idx_0021_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_35_idx_0021_xx;
SELECT 'TC-35-IDX-0021-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0021_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0021_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0021-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0021_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0021_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0021_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0021_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0021-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0021_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0021_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0021-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0021_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0021_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0021_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0021_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0021-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(20,0)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(20,0) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0021_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0022-XX
-- Index integrity: UNIQUE index on target
-- Type: DECIMAL(18,0) -> DECIMAL(20,0), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-05
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=cb8bcc9f62ec column_type=decimal(20,0) index_kind=UNIQUE neg_probe=1bad5c6b76fb=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0022_xx, t2_tc_35_idx_0022_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0022_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(18,0),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (0);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (1);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (2);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (3);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (4);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (5);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (6);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (7);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (8);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (9);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (10);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (11);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (12);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (13);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (14);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (15);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (16);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (17);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (18);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (19);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (20);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (21);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (22);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (23);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (24);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (25);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (26);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (27);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (28);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (29);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (30);
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_35_idx_0022_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0022_xx MODIFY target DECIMAL(20,0), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0022_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(20,0),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (0);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (1);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (2);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (3);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (4);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (5);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (6);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (7);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (8);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (9);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (10);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (11);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (12);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (13);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (14);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (15);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (16);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (17);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (18);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (19);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (20);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (21);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (22);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (23);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (24);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (25);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (26);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (27);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (28);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (29);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (30);
INSERT INTO t2_tc_35_idx_0022_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_35_idx_0022_xx;
SELECT 'TC-35-IDX-0022-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0022_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0022_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0022-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0022_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0022_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0022_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0022_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0022-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0022_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0022_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0022-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0022_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0022_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0022_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0022_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0022-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(20,0)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(20,0) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0022_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0022_xx (target) VALUES (0);

-- Test Case: TC-35-IDX-0023-XX
-- Index integrity: SECONDARY index on target
-- Type: DECIMAL(31,30) -> DECIMAL(33,30), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-06
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=4ab557c81fb7 column_type=decimal(33,30) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0023_xx, t2_tc_35_idx_0023_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0023_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(31,30),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000000);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000001);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000002);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000003);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000004);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000005);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000006);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000007);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000008);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000009);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000010);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000011);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000012);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000013);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000014);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000015);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000016);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000017);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000018);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000019);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000020);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000021);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000022);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000023);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000024);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000025);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000026);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000027);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000028);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000029);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000030);
INSERT INTO t1_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000031);
ANALYZE TABLE t1_tc_35_idx_0023_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0023_xx MODIFY target DECIMAL(33,30), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0023_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(33,30),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000000);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000001);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000002);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000003);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000004);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000005);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000006);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000007);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000008);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000009);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000010);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000011);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000012);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000013);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000014);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000015);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000016);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000017);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000018);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000019);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000020);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000021);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000022);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000023);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000024);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000025);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000026);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000027);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000028);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000029);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000030);
INSERT INTO t2_tc_35_idx_0023_xx (target) VALUES (0.000000000000000000000000000031);
ANALYZE TABLE t2_tc_35_idx_0023_xx;
SELECT 'TC-35-IDX-0023-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0023_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0023_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0023-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0023_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0023_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0023_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0023_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0023-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0023_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0023_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0023-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0023_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0023_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0023_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0023_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0023-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(33,30)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(33,30) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0023_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0024-XX
-- Index integrity: UNIQUE index on target
-- Type: DECIMAL(31,30) -> DECIMAL(33,30), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-06
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=9fdfa02bc667 column_type=decimal(33,30) index_kind=UNIQUE neg_probe=312d76643fd8=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0024_xx, t2_tc_35_idx_0024_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0024_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(31,30),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000000);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000001);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000002);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000003);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000004);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000005);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000006);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000007);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000008);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000009);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000010);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000011);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000012);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000013);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000014);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000015);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000016);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000017);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000018);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000019);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000020);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000021);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000022);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000023);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000024);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000025);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000026);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000027);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000028);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000029);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000030);
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000031);
ANALYZE TABLE t1_tc_35_idx_0024_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0024_xx MODIFY target DECIMAL(33,30), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0024_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(33,30),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000000);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000001);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000002);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000003);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000004);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000005);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000006);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000007);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000008);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000009);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000010);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000011);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000012);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000013);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000014);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000015);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000016);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000017);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000018);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000019);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000020);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000021);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000022);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000023);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000024);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000025);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000026);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000027);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000028);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000029);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000030);
INSERT INTO t2_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000031);
ANALYZE TABLE t2_tc_35_idx_0024_xx;
SELECT 'TC-35-IDX-0024-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0024_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0024_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0024-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0024_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0024_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0024_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0024_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0024-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0024_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0024_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0024-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0024_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0024_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0024_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0024_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0024-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(33,30)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(33,30) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0024_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0024_xx (target) VALUES (0.000000000000000000000000000000);

-- Test Case: TC-35-IDX-0025-XX
-- Index integrity: SECONDARY index on target
-- Type: DECIMAL(64,0) -> DECIMAL(65,0), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-07
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=f6f82ff23d6c column_type=decimal(65,0) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0025_xx, t2_tc_35_idx_0025_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0025_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(64,0),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (0);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (1);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (2);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (3);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (4);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (5);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (6);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (7);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (8);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (9);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (10);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (11);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (12);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (13);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (14);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (15);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (16);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (17);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (18);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (19);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (20);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (21);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (22);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (23);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (24);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (25);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (26);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (27);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (28);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (29);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (30);
INSERT INTO t1_tc_35_idx_0025_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_35_idx_0025_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0025_xx MODIFY target DECIMAL(65,0), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0025_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(65,0),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (0);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (1);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (2);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (3);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (4);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (5);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (6);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (7);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (8);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (9);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (10);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (11);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (12);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (13);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (14);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (15);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (16);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (17);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (18);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (19);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (20);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (21);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (22);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (23);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (24);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (25);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (26);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (27);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (28);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (29);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (30);
INSERT INTO t2_tc_35_idx_0025_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_35_idx_0025_xx;
SELECT 'TC-35-IDX-0025-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0025_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0025_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0025-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0025_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0025_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0025_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0025_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0025-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0025_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0025_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0025-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0025_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0025_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0025_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0025_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0025-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(65,0)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(65,0) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0025_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0026-XX
-- Index integrity: UNIQUE index on target
-- Type: DECIMAL(64,0) -> DECIMAL(65,0), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-07
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=a3230555a659 column_type=decimal(65,0) index_kind=UNIQUE neg_probe=2e193550c680=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0026_xx, t2_tc_35_idx_0026_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0026_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(64,0),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (0);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (1);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (2);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (3);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (4);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (5);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (6);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (7);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (8);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (9);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (10);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (11);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (12);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (13);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (14);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (15);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (16);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (17);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (18);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (19);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (20);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (21);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (22);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (23);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (24);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (25);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (26);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (27);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (28);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (29);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (30);
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_35_idx_0026_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0026_xx MODIFY target DECIMAL(65,0), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0026_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(65,0),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (0);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (1);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (2);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (3);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (4);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (5);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (6);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (7);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (8);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (9);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (10);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (11);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (12);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (13);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (14);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (15);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (16);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (17);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (18);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (19);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (20);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (21);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (22);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (23);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (24);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (25);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (26);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (27);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (28);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (29);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (30);
INSERT INTO t2_tc_35_idx_0026_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_35_idx_0026_xx;
SELECT 'TC-35-IDX-0026-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0026_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0026_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0026-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0026_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0026_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0026_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0026_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0026-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0026_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0026_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0026-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0026_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0026_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0026_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0026_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0026-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(65,0)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(65,0) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0026_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0026_xx (target) VALUES (0);

-- Test Case: TC-35-IDX-0027-XX
-- Index integrity: SECONDARY index on target
-- Type: DECIMAL(8,2) -> DECIMAL(9,2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-08
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=f43c59481ee0 column_type=decimal(9,2) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0027_xx, t2_tc_35_idx_0027_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0027_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(8,2),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.00);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.01);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.02);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.03);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.04);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.05);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.06);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.07);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.08);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.09);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.10);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.11);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.12);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.13);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.14);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.15);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.16);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.17);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.18);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.19);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.20);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.21);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.22);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.23);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.24);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.25);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.26);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.27);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.28);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.29);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.30);
INSERT INTO t1_tc_35_idx_0027_xx (target) VALUES (0.31);
ANALYZE TABLE t1_tc_35_idx_0027_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0027_xx MODIFY target DECIMAL(9,2), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0027_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(9,2),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.00);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.01);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.02);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.03);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.04);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.05);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.06);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.07);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.08);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.09);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.10);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.11);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.12);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.13);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.14);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.15);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.16);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.17);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.18);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.19);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.20);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.21);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.22);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.23);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.24);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.25);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.26);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.27);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.28);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.29);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.30);
INSERT INTO t2_tc_35_idx_0027_xx (target) VALUES (0.31);
ANALYZE TABLE t2_tc_35_idx_0027_xx;
SELECT 'TC-35-IDX-0027-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0027_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0027_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0027-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0027_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0027_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0027_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0027_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0027-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0027_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0027_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0027-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0027_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0027_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0027_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0027_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0027-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(9,2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(9,2) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0027_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0028-XX
-- Index integrity: UNIQUE index on target
-- Type: DECIMAL(8,2) -> DECIMAL(9,2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-08
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=b331f674ddc5 column_type=decimal(9,2) index_kind=UNIQUE neg_probe=688faaa0b790=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0028_xx, t2_tc_35_idx_0028_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0028_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(8,2),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.00);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.01);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.02);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.03);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.04);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.05);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.06);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.07);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.08);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.09);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.10);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.11);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.12);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.13);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.14);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.15);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.16);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.17);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.18);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.19);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.20);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.21);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.22);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.23);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.24);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.25);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.26);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.27);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.28);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.29);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.30);
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.31);
ANALYZE TABLE t1_tc_35_idx_0028_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0028_xx MODIFY target DECIMAL(9,2), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0028_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(9,2),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.00);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.01);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.02);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.03);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.04);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.05);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.06);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.07);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.08);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.09);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.10);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.11);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.12);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.13);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.14);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.15);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.16);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.17);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.18);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.19);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.20);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.21);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.22);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.23);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.24);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.25);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.26);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.27);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.28);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.29);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.30);
INSERT INTO t2_tc_35_idx_0028_xx (target) VALUES (0.31);
ANALYZE TABLE t2_tc_35_idx_0028_xx;
SELECT 'TC-35-IDX-0028-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0028_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0028_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0028-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0028_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0028_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0028_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0028_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0028-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0028_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0028_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0028-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0028_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0028_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0028_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0028_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0028-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(9,2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(9,2) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0028_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0028_xx (target) VALUES (0.00);

-- Test Case: TC-35-IDX-0029-XX
-- Index integrity: SECONDARY index on target
-- Type: DECIMAL(9,2) -> DECIMAL(10,2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-09
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=d8d5223f3d49 column_type=decimal(10,2) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0029_xx, t2_tc_35_idx_0029_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0029_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(9,2),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.00);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.01);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.02);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.03);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.04);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.05);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.06);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.07);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.08);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.09);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.10);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.11);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.12);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.13);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.14);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.15);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.16);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.17);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.18);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.19);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.20);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.21);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.22);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.23);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.24);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.25);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.26);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.27);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.28);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.29);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.30);
INSERT INTO t1_tc_35_idx_0029_xx (target) VALUES (0.31);
ANALYZE TABLE t1_tc_35_idx_0029_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0029_xx MODIFY target DECIMAL(10,2), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0029_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(10,2),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.00);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.01);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.02);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.03);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.04);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.05);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.06);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.07);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.08);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.09);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.10);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.11);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.12);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.13);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.14);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.15);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.16);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.17);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.18);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.19);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.20);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.21);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.22);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.23);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.24);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.25);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.26);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.27);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.28);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.29);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.30);
INSERT INTO t2_tc_35_idx_0029_xx (target) VALUES (0.31);
ANALYZE TABLE t2_tc_35_idx_0029_xx;
SELECT 'TC-35-IDX-0029-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0029_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0029_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0029-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0029_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0029_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0029_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0029_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0029-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0029_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0029_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0029-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0029_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0029_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0029_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0029_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0029-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(10,2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(10,2) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0029_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0030-XX
-- Index integrity: UNIQUE index on target
-- Type: DECIMAL(9,2) -> DECIMAL(10,2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-09
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=cc90d2ad2884 column_type=decimal(10,2) index_kind=UNIQUE neg_probe=e3254556c703=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0030_xx, t2_tc_35_idx_0030_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0030_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(9,2),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.00);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.01);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.02);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.03);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.04);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.05);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.06);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.07);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.08);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.09);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.10);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.11);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.12);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.13);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.14);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.15);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.16);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.17);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.18);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.19);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.20);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.21);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.22);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.23);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.24);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.25);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.26);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.27);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.28);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.29);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.30);
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.31);
ANALYZE TABLE t1_tc_35_idx_0030_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0030_xx MODIFY target DECIMAL(10,2), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0030_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(10,2),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.00);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.01);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.02);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.03);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.04);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.05);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.06);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.07);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.08);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.09);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.10);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.11);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.12);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.13);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.14);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.15);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.16);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.17);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.18);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.19);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.20);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.21);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.22);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.23);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.24);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.25);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.26);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.27);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.28);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.29);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.30);
INSERT INTO t2_tc_35_idx_0030_xx (target) VALUES (0.31);
ANALYZE TABLE t2_tc_35_idx_0030_xx;
SELECT 'TC-35-IDX-0030-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0030_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0030_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0030-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0030_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0030_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0030_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0030_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0030-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0030_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0030_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0030-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0030_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0030_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0030_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0030_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0030-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(10,2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(10,2) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0030_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0030_xx (target) VALUES (0.00);

-- Test Case: TC-35-IDX-0031-XX
-- Index integrity: SECONDARY index on target
-- Type: DECIMAL(17,2) -> DECIMAL(18,2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-10
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=e6109d2ae3a4 column_type=decimal(18,2) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0031_xx, t2_tc_35_idx_0031_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0031_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(17,2),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.00);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.01);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.02);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.03);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.04);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.05);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.06);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.07);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.08);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.09);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.10);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.11);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.12);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.13);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.14);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.15);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.16);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.17);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.18);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.19);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.20);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.21);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.22);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.23);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.24);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.25);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.26);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.27);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.28);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.29);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.30);
INSERT INTO t1_tc_35_idx_0031_xx (target) VALUES (0.31);
ANALYZE TABLE t1_tc_35_idx_0031_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0031_xx MODIFY target DECIMAL(18,2), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0031_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(18,2),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.00);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.01);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.02);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.03);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.04);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.05);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.06);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.07);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.08);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.09);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.10);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.11);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.12);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.13);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.14);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.15);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.16);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.17);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.18);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.19);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.20);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.21);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.22);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.23);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.24);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.25);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.26);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.27);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.28);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.29);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.30);
INSERT INTO t2_tc_35_idx_0031_xx (target) VALUES (0.31);
ANALYZE TABLE t2_tc_35_idx_0031_xx;
SELECT 'TC-35-IDX-0031-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0031_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0031_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0031-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0031_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0031_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0031_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0031_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0031-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0031_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0031_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0031-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0031_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0031_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0031_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0031_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0031-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(18,2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(18,2) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0031_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0032-XX
-- Index integrity: UNIQUE index on target
-- Type: DECIMAL(17,2) -> DECIMAL(18,2), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-10
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=5bab5aeba239 column_type=decimal(18,2) index_kind=UNIQUE neg_probe=79497254290c=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0032_xx, t2_tc_35_idx_0032_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0032_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(17,2),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.00);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.01);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.02);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.03);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.04);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.05);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.06);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.07);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.08);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.09);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.10);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.11);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.12);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.13);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.14);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.15);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.16);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.17);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.18);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.19);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.20);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.21);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.22);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.23);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.24);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.25);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.26);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.27);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.28);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.29);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.30);
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.31);
ANALYZE TABLE t1_tc_35_idx_0032_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0032_xx MODIFY target DECIMAL(18,2), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0032_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(18,2),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.00);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.01);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.02);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.03);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.04);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.05);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.06);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.07);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.08);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.09);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.10);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.11);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.12);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.13);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.14);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.15);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.16);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.17);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.18);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.19);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.20);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.21);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.22);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.23);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.24);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.25);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.26);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.27);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.28);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.29);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.30);
INSERT INTO t2_tc_35_idx_0032_xx (target) VALUES (0.31);
ANALYZE TABLE t2_tc_35_idx_0032_xx;
SELECT 'TC-35-IDX-0032-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0032_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0032_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0032-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0032_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0032_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0032_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0032_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0032-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0032_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0032_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0032-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0032_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0032_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0032_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0032_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0032-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(18,2)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(18,2) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0032_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0032_xx (target) VALUES (0.00);

-- Test Case: TC-35-IDX-0033-XX
-- Index integrity: SECONDARY index on target
-- Type: DECIMAL(62,30) -> DECIMAL(63,30), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-11
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=8c0f5c692f44 column_type=decimal(63,30) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0033_xx, t2_tc_35_idx_0033_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0033_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(62,30),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000000);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000001);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000002);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000003);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000004);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000005);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000006);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000007);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000008);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000009);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000010);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000011);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000012);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000013);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000014);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000015);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000016);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000017);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000018);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000019);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000020);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000021);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000022);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000023);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000024);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000025);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000026);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000027);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000028);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000029);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000030);
INSERT INTO t1_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000031);
ANALYZE TABLE t1_tc_35_idx_0033_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0033_xx MODIFY target DECIMAL(63,30), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0033_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(63,30),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000000);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000001);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000002);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000003);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000004);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000005);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000006);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000007);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000008);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000009);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000010);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000011);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000012);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000013);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000014);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000015);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000016);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000017);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000018);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000019);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000020);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000021);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000022);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000023);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000024);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000025);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000026);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000027);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000028);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000029);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000030);
INSERT INTO t2_tc_35_idx_0033_xx (target) VALUES (0.000000000000000000000000000031);
ANALYZE TABLE t2_tc_35_idx_0033_xx;
SELECT 'TC-35-IDX-0033-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0033_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0033_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0033-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0033_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0033_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0033_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0033_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0033-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0033_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0033_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0033-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0033_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0033_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0033_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0033_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0033-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(63,30)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(63,30) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0033_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0034-XX
-- Index integrity: UNIQUE index on target
-- Type: DECIMAL(62,30) -> DECIMAL(63,30), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: DEC-11
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=cef0deca0c9b column_type=decimal(63,30) index_kind=UNIQUE neg_probe=7ad960ad5e3d=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0034_xx, t2_tc_35_idx_0034_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0034_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(62,30),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000000);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000001);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000002);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000003);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000004);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000005);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000006);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000007);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000008);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000009);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000010);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000011);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000012);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000013);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000014);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000015);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000016);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000017);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000018);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000019);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000020);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000021);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000022);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000023);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000024);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000025);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000026);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000027);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000028);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000029);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000030);
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000031);
ANALYZE TABLE t1_tc_35_idx_0034_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0034_xx MODIFY target DECIMAL(63,30), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0034_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target DECIMAL(63,30),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000000);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000001);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000002);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000003);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000004);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000005);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000006);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000007);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000008);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000009);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000010);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000011);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000012);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000013);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000014);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000015);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000016);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000017);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000018);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000019);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000020);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000021);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000022);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000023);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000024);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000025);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000026);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000027);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000028);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000029);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000030);
INSERT INTO t2_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000031);
ANALYZE TABLE t2_tc_35_idx_0034_xx;
SELECT 'TC-35-IDX-0034-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0034_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0034_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0034-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0034_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0034_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0034_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0034_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0034-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0034_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0034_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0034-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0034_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0034_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0034_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0034_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0034-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='decimal(63,30)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=decimal(63,30) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0034_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0034_xx (target) VALUES (0.000000000000000000000000000000);

-- Test Case: TC-35-IDX-0035-XX
-- Index integrity: SECONDARY index on target
-- Type: TINYTEXT -> TEXT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: TEXT-01
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=d677397563d2 column_type=text index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0035_xx, t2_tc_35_idx_0035_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0035_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TINYTEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_35_idx_0035_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_35_idx_0035_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0035_xx MODIFY target TEXT CHARACTER SET utf8mb4, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0035_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_35_idx_0035_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_35_idx_0035_xx;
SELECT 'TC-35-IDX-0035-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0035_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0035_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0035-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0035_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0035_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0035_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0035_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0035-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0035_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0035_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0035-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0035_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0035_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0035_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0035_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0035-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='text'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=text nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0035_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0036-XX
-- Index integrity: UNIQUE index on target
-- Type: TINYTEXT -> TEXT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: TEXT-01
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=2f10343f27d0 column_type=text index_kind=UNIQUE neg_probe=00c6fce3c60f=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0036_xx, t2_tc_35_idx_0036_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0036_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TINYTEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_35_idx_0036_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0036_xx MODIFY target TEXT CHARACTER SET utf8mb4, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0036_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_35_idx_0036_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_35_idx_0036_xx;
SELECT 'TC-35-IDX-0036-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0036_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0036_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0036-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0036_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0036_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0036_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0036_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0036-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0036_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0036_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0036-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0036_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0036_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0036_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0036_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0036-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='text'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=text nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0036_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0036_xx (target) VALUES ('00000000');

-- Test Case: TC-35-IDX-0037-XX
-- Index integrity: SECONDARY index on target
-- Type: TEXT -> MEDIUMTEXT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: TEXT-02
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=2acf4f1c56d6 column_type=mediumtext index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0037_xx, t2_tc_35_idx_0037_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0037_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_35_idx_0037_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_35_idx_0037_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0037_xx MODIFY target MEDIUMTEXT CHARACTER SET utf8mb4, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0037_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMTEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_35_idx_0037_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_35_idx_0037_xx;
SELECT 'TC-35-IDX-0037-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0037_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0037_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0037-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0037_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0037_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0037_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0037_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0037-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0037_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0037_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0037-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0037_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0037_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0037_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0037_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0037-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='mediumtext'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=mediumtext nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0037_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0038-XX
-- Index integrity: UNIQUE index on target
-- Type: TEXT -> MEDIUMTEXT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: TEXT-02
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=6c5de63498fd column_type=mediumtext index_kind=UNIQUE neg_probe=914f7c325b8f=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0038_xx, t2_tc_35_idx_0038_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0038_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_35_idx_0038_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0038_xx MODIFY target MEDIUMTEXT CHARACTER SET utf8mb4, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0038_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMTEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_35_idx_0038_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_35_idx_0038_xx;
SELECT 'TC-35-IDX-0038-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0038_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0038_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0038-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0038_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0038_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0038_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0038_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0038-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0038_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0038_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0038-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0038_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0038_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0038_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0038_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0038-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='mediumtext'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=mediumtext nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0038_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0038_xx (target) VALUES ('00000000');

-- Test Case: TC-35-IDX-0039-XX
-- Index integrity: SECONDARY index on target
-- Type: MEDIUMTEXT -> LONGTEXT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: TEXT-03
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=ff5952b0a52b column_type=longtext index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0039_xx, t2_tc_35_idx_0039_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0039_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMTEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_35_idx_0039_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_35_idx_0039_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0039_xx MODIFY target LONGTEXT CHARACTER SET utf8mb4, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0039_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target LONGTEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_35_idx_0039_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_35_idx_0039_xx;
SELECT 'TC-35-IDX-0039-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0039_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0039_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0039-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0039_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0039_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0039_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0039_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0039-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0039_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0039_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0039-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0039_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0039_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0039_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0039_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0039-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='longtext'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=longtext nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0039_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0040-XX
-- Index integrity: UNIQUE index on target
-- Type: MEDIUMTEXT -> LONGTEXT, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: TEXT-03
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=900ede1abb58 column_type=longtext index_kind=UNIQUE neg_probe=5b8273b2622b=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0040_xx, t2_tc_35_idx_0040_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0040_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMTEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('00000000');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('00000001');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('00000002');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('00000003');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('00000004');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('00000005');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('00000006');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('00000007');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('00000008');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('00000009');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000a');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000b');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000c');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000d');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000e');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000f');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000g');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000h');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000i');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000j');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000k');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000l');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000m');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000n');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000o');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000p');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000q');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000r');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000s');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000t');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000u');
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('0000000v');
ANALYZE TABLE t1_tc_35_idx_0040_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0040_xx MODIFY target LONGTEXT CHARACTER SET utf8mb4, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0040_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target LONGTEXT CHARACTER SET utf8mb4,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('00000000');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('00000001');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('00000002');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('00000003');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('00000004');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('00000005');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('00000006');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('00000007');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('00000008');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('00000009');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000a');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000b');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000c');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000d');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000e');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000f');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000g');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000h');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000i');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000j');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000k');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000l');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000m');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000n');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000o');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000p');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000q');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000r');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000s');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000t');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000u');
INSERT INTO t2_tc_35_idx_0040_xx (target) VALUES ('0000000v');
ANALYZE TABLE t2_tc_35_idx_0040_xx;
SELECT 'TC-35-IDX-0040-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0040_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0040_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0040-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0040_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0040_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0040_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0040_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0040-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0040_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0040_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0040-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0040_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0040_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0040_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0040_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0040-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='longtext'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> 'utf8mb4')
          AND (MAX(collation_name) <=> 'utf8mb4_0900_ai_ci')
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=longtext nullable=YES has_default=0 charset=utf8mb4 collation=utf8mb4_0900_ai_ci extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0040_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0040_xx (target) VALUES ('00000000');

-- Test Case: TC-35-IDX-0041-XX
-- Index integrity: SECONDARY index on target
-- Type: TINYBLOB -> BLOB, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: BLOB-01
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=e7b8fa9753a4 column_type=blob index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0041_xx, t2_tc_35_idx_0041_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0041_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TINYBLOB,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'00000000');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'00000001');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'00000002');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'00000003');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'00000004');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'00000005');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'00000006');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'00000007');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'00000008');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'00000009');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'0000000A');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'0000000B');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'0000000C');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'0000000D');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'0000000E');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'0000000F');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'00000010');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'00000011');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'00000012');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'00000013');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'00000014');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'00000015');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'00000016');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'00000017');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'00000018');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'00000019');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'0000001A');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'0000001B');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'0000001C');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'0000001D');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'0000001E');
INSERT INTO t1_tc_35_idx_0041_xx (target) VALUES (X'0000001F');
ANALYZE TABLE t1_tc_35_idx_0041_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0041_xx MODIFY target BLOB, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0041_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BLOB,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'00000000');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'00000001');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'00000002');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'00000003');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'00000004');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'00000005');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'00000006');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'00000007');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'00000008');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'00000009');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'0000000A');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'0000000B');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'0000000C');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'0000000D');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'0000000E');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'0000000F');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'00000010');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'00000011');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'00000012');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'00000013');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'00000014');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'00000015');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'00000016');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'00000017');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'00000018');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'00000019');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'0000001A');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'0000001B');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'0000001C');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'0000001D');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'0000001E');
INSERT INTO t2_tc_35_idx_0041_xx (target) VALUES (X'0000001F');
ANALYZE TABLE t2_tc_35_idx_0041_xx;
SELECT 'TC-35-IDX-0041-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0041_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0041_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0041-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0041_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0041_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0041_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0041_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0041-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0041_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0041_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0041-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0041_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0041_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0041_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0041_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0041-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='blob'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=blob nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0041_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0042-XX
-- Index integrity: UNIQUE index on target
-- Type: TINYBLOB -> BLOB, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: BLOB-01
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=ace42cdcc7c5 column_type=blob index_kind=UNIQUE neg_probe=308002d18ee5=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0042_xx, t2_tc_35_idx_0042_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0042_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target TINYBLOB,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000000');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000001');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000002');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000003');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000004');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000005');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000006');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000007');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000008');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000009');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'0000000A');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'0000000B');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'0000000C');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'0000000D');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'0000000E');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'0000000F');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000010');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000011');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000012');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000013');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000014');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000015');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000016');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000017');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000018');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000019');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'0000001A');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'0000001B');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'0000001C');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'0000001D');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'0000001E');
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'0000001F');
ANALYZE TABLE t1_tc_35_idx_0042_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0042_xx MODIFY target BLOB, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0042_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BLOB,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'00000000');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'00000001');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'00000002');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'00000003');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'00000004');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'00000005');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'00000006');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'00000007');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'00000008');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'00000009');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'0000000A');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'0000000B');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'0000000C');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'0000000D');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'0000000E');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'0000000F');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'00000010');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'00000011');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'00000012');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'00000013');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'00000014');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'00000015');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'00000016');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'00000017');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'00000018');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'00000019');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'0000001A');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'0000001B');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'0000001C');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'0000001D');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'0000001E');
INSERT INTO t2_tc_35_idx_0042_xx (target) VALUES (X'0000001F');
ANALYZE TABLE t2_tc_35_idx_0042_xx;
SELECT 'TC-35-IDX-0042-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0042_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0042_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0042-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0042_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0042_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0042_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0042_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0042-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0042_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0042_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0042-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0042_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0042_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0042_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0042_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0042-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='blob'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=blob nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0042_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0042_xx (target) VALUES (X'00000000');

-- Test Case: TC-35-IDX-0043-XX
-- Index integrity: SECONDARY index on target
-- Type: BLOB -> MEDIUMBLOB, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: BLOB-02
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=f684fd0e4bb8 column_type=mediumblob index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0043_xx, t2_tc_35_idx_0043_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0043_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BLOB,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'00000000');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'00000001');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'00000002');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'00000003');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'00000004');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'00000005');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'00000006');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'00000007');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'00000008');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'00000009');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'0000000A');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'0000000B');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'0000000C');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'0000000D');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'0000000E');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'0000000F');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'00000010');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'00000011');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'00000012');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'00000013');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'00000014');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'00000015');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'00000016');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'00000017');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'00000018');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'00000019');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'0000001A');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'0000001B');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'0000001C');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'0000001D');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'0000001E');
INSERT INTO t1_tc_35_idx_0043_xx (target) VALUES (X'0000001F');
ANALYZE TABLE t1_tc_35_idx_0043_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0043_xx MODIFY target MEDIUMBLOB, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0043_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMBLOB,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'00000000');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'00000001');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'00000002');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'00000003');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'00000004');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'00000005');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'00000006');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'00000007');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'00000008');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'00000009');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'0000000A');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'0000000B');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'0000000C');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'0000000D');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'0000000E');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'0000000F');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'00000010');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'00000011');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'00000012');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'00000013');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'00000014');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'00000015');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'00000016');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'00000017');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'00000018');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'00000019');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'0000001A');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'0000001B');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'0000001C');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'0000001D');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'0000001E');
INSERT INTO t2_tc_35_idx_0043_xx (target) VALUES (X'0000001F');
ANALYZE TABLE t2_tc_35_idx_0043_xx;
SELECT 'TC-35-IDX-0043-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0043_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0043_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0043-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0043_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0043_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0043_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0043_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0043-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0043_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0043_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0043-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0043_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0043_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0043_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0043_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0043-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='mediumblob'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=mediumblob nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0043_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0044-XX
-- Index integrity: UNIQUE index on target
-- Type: BLOB -> MEDIUMBLOB, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: BLOB-02
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=882199915591 column_type=mediumblob index_kind=UNIQUE neg_probe=f9da4c6d43e9=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0044_xx, t2_tc_35_idx_0044_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0044_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BLOB,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000000');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000001');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000002');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000003');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000004');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000005');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000006');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000007');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000008');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000009');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'0000000A');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'0000000B');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'0000000C');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'0000000D');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'0000000E');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'0000000F');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000010');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000011');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000012');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000013');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000014');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000015');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000016');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000017');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000018');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000019');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'0000001A');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'0000001B');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'0000001C');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'0000001D');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'0000001E');
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'0000001F');
ANALYZE TABLE t1_tc_35_idx_0044_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0044_xx MODIFY target MEDIUMBLOB, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0044_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMBLOB,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'00000000');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'00000001');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'00000002');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'00000003');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'00000004');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'00000005');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'00000006');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'00000007');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'00000008');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'00000009');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'0000000A');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'0000000B');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'0000000C');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'0000000D');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'0000000E');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'0000000F');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'00000010');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'00000011');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'00000012');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'00000013');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'00000014');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'00000015');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'00000016');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'00000017');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'00000018');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'00000019');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'0000001A');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'0000001B');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'0000001C');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'0000001D');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'0000001E');
INSERT INTO t2_tc_35_idx_0044_xx (target) VALUES (X'0000001F');
ANALYZE TABLE t2_tc_35_idx_0044_xx;
SELECT 'TC-35-IDX-0044-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0044_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0044_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0044-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0044_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0044_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0044_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0044_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0044-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0044_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0044_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0044-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0044_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0044_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0044_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0044_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0044-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='mediumblob'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=mediumblob nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0044_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0044_xx (target) VALUES (X'00000000');

-- Test Case: TC-35-IDX-0045-XX
-- Index integrity: SECONDARY index on target
-- Type: MEDIUMBLOB -> LONGBLOB, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: BLOB-03
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=b34e12aa260e column_type=longblob index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0045_xx, t2_tc_35_idx_0045_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0045_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMBLOB,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'00000000');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'00000001');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'00000002');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'00000003');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'00000004');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'00000005');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'00000006');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'00000007');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'00000008');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'00000009');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'0000000A');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'0000000B');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'0000000C');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'0000000D');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'0000000E');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'0000000F');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'00000010');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'00000011');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'00000012');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'00000013');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'00000014');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'00000015');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'00000016');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'00000017');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'00000018');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'00000019');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'0000001A');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'0000001B');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'0000001C');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'0000001D');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'0000001E');
INSERT INTO t1_tc_35_idx_0045_xx (target) VALUES (X'0000001F');
ANALYZE TABLE t1_tc_35_idx_0045_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0045_xx MODIFY target LONGBLOB, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0045_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target LONGBLOB,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'00000000');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'00000001');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'00000002');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'00000003');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'00000004');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'00000005');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'00000006');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'00000007');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'00000008');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'00000009');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'0000000A');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'0000000B');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'0000000C');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'0000000D');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'0000000E');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'0000000F');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'00000010');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'00000011');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'00000012');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'00000013');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'00000014');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'00000015');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'00000016');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'00000017');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'00000018');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'00000019');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'0000001A');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'0000001B');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'0000001C');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'0000001D');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'0000001E');
INSERT INTO t2_tc_35_idx_0045_xx (target) VALUES (X'0000001F');
ANALYZE TABLE t2_tc_35_idx_0045_xx;
SELECT 'TC-35-IDX-0045-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0045_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0045_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0045-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0045_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0045_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0045_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0045_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0045-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0045_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0045_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0045-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0045_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0045_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0045_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0045_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0045-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='longblob'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=longblob nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0045_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0046-XX
-- Index integrity: UNIQUE index on target
-- Type: MEDIUMBLOB -> LONGBLOB, Algorithm: inplace, Expected: SUCCESS
-- Transition ID: BLOB-03
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=fbe1f083f728 column_type=longblob index_kind=UNIQUE neg_probe=d563e897daf0=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0046_xx, t2_tc_35_idx_0046_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0046_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target MEDIUMBLOB,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000000');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000001');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000002');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000003');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000004');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000005');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000006');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000007');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000008');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000009');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'0000000A');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'0000000B');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'0000000C');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'0000000D');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'0000000E');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'0000000F');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000010');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000011');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000012');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000013');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000014');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000015');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000016');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000017');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000018');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000019');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'0000001A');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'0000001B');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'0000001C');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'0000001D');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'0000001E');
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'0000001F');
ANALYZE TABLE t1_tc_35_idx_0046_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0046_xx MODIFY target LONGBLOB, ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0046_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target LONGBLOB,
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'00000000');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'00000001');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'00000002');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'00000003');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'00000004');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'00000005');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'00000006');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'00000007');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'00000008');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'00000009');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'0000000A');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'0000000B');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'0000000C');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'0000000D');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'0000000E');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'0000000F');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'00000010');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'00000011');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'00000012');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'00000013');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'00000014');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'00000015');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'00000016');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'00000017');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'00000018');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'00000019');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'0000001A');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'0000001B');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'0000001C');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'0000001D');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'0000001E');
INSERT INTO t2_tc_35_idx_0046_xx (target) VALUES (X'0000001F');
ANALYZE TABLE t2_tc_35_idx_0046_xx;
SELECT 'TC-35-IDX-0046-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0046_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0046_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0046-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0046_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0046_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0046_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0046_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0046-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0046_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0046_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0046-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0046_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0046_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0046_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0046_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0046-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='longblob'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=longblob nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0046_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0046_xx (target) VALUES (X'00000000');

-- Test Case: TC-35-IDX-0047-XX
-- Index integrity: SECONDARY index on target
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: BIT-01
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=751961af056d column_type=bit(8) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0047_xx, t2_tc_35_idx_0047_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0047_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIT(1),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0047_xx (target) VALUES (0);
INSERT INTO t1_tc_35_idx_0047_xx (target) VALUES (1);
ANALYZE TABLE t1_tc_35_idx_0047_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0047_xx MODIFY target BIT(8), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0047_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIT(8),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0047_xx (target) VALUES (0);
INSERT INTO t2_tc_35_idx_0047_xx (target) VALUES (1);
ANALYZE TABLE t2_tc_35_idx_0047_xx;
SELECT 'TC-35-IDX-0047-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0047_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0047_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0047-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0047_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0047_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0047_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0047_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0047-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0047_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0047_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0047-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0047_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0047_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0047_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0047_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0047-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0047_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0048-XX
-- Index integrity: UNIQUE index on target
-- Type: BIT(1) -> BIT(8), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: BIT-01
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=d2f9fa579cef column_type=bit(8) index_kind=UNIQUE neg_probe=0c286e2837f5=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0048_xx, t2_tc_35_idx_0048_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0048_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIT(1),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0048_xx (target) VALUES (0);
INSERT INTO t1_tc_35_idx_0048_xx (target) VALUES (1);
ANALYZE TABLE t1_tc_35_idx_0048_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0048_xx MODIFY target BIT(8), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0048_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIT(8),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0048_xx (target) VALUES (0);
INSERT INTO t2_tc_35_idx_0048_xx (target) VALUES (1);
ANALYZE TABLE t2_tc_35_idx_0048_xx;
SELECT 'TC-35-IDX-0048-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0048_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0048_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0048-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0048_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0048_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0048_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0048_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0048-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0048_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0048_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0048-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0048_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0048_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0048_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0048_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0048-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(8)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(8) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0048_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0048_xx (target) VALUES (0);

-- Test Case: TC-35-IDX-0049-XX
-- Index integrity: SECONDARY index on target
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: BIT-02
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=4e5bfbe85457 column_type=bit(16) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0049_xx, t2_tc_35_idx_0049_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0049_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIT(8),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (0);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (1);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (2);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (3);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (4);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (5);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (6);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (7);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (8);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (9);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (10);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (11);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (12);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (13);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (14);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (15);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (16);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (17);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (18);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (19);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (20);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (21);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (22);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (23);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (24);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (25);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (26);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (27);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (28);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (29);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (30);
INSERT INTO t1_tc_35_idx_0049_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_35_idx_0049_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0049_xx MODIFY target BIT(16), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0049_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIT(16),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (0);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (1);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (2);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (3);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (4);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (5);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (6);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (7);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (8);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (9);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (10);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (11);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (12);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (13);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (14);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (15);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (16);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (17);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (18);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (19);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (20);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (21);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (22);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (23);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (24);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (25);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (26);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (27);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (28);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (29);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (30);
INSERT INTO t2_tc_35_idx_0049_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_35_idx_0049_xx;
SELECT 'TC-35-IDX-0049-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0049_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0049_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0049-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0049_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0049_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0049_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0049_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0049-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0049_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0049_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0049-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0049_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0049_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0049_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0049_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0049-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0049_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0050-XX
-- Index integrity: UNIQUE index on target
-- Type: BIT(8) -> BIT(16), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: BIT-02
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=df3e753665e3 column_type=bit(16) index_kind=UNIQUE neg_probe=5c8ca0009e29=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0050_xx, t2_tc_35_idx_0050_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0050_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIT(8),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (0);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (1);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (2);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (3);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (4);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (5);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (6);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (7);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (8);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (9);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (10);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (11);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (12);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (13);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (14);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (15);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (16);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (17);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (18);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (19);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (20);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (21);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (22);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (23);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (24);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (25);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (26);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (27);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (28);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (29);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (30);
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_35_idx_0050_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0050_xx MODIFY target BIT(16), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0050_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIT(16),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (0);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (1);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (2);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (3);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (4);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (5);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (6);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (7);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (8);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (9);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (10);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (11);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (12);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (13);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (14);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (15);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (16);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (17);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (18);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (19);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (20);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (21);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (22);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (23);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (24);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (25);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (26);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (27);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (28);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (29);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (30);
INSERT INTO t2_tc_35_idx_0050_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_35_idx_0050_xx;
SELECT 'TC-35-IDX-0050-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0050_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0050_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0050-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0050_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0050_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0050_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0050_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0050-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0050_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0050_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0050-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0050_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0050_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0050_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0050_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0050-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(16)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(16) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0050_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0050_xx (target) VALUES (0);

-- Test Case: TC-35-IDX-0051-XX
-- Index integrity: SECONDARY index on target
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: BIT-03
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=8e63adc393f6 column_type=bit(32) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0051_xx, t2_tc_35_idx_0051_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0051_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIT(16),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (0);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (1);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (2);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (3);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (4);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (5);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (6);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (7);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (8);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (9);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (10);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (11);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (12);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (13);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (14);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (15);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (16);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (17);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (18);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (19);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (20);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (21);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (22);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (23);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (24);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (25);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (26);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (27);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (28);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (29);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (30);
INSERT INTO t1_tc_35_idx_0051_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_35_idx_0051_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0051_xx MODIFY target BIT(32), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0051_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIT(32),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (0);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (1);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (2);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (3);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (4);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (5);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (6);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (7);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (8);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (9);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (10);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (11);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (12);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (13);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (14);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (15);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (16);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (17);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (18);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (19);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (20);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (21);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (22);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (23);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (24);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (25);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (26);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (27);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (28);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (29);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (30);
INSERT INTO t2_tc_35_idx_0051_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_35_idx_0051_xx;
SELECT 'TC-35-IDX-0051-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0051_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0051_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0051-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0051_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0051_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0051_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0051_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0051-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0051_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0051_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0051-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0051_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0051_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0051_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0051_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0051-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0051_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0052-XX
-- Index integrity: UNIQUE index on target
-- Type: BIT(16) -> BIT(32), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: BIT-03
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=82aa9d758075 column_type=bit(32) index_kind=UNIQUE neg_probe=5ab94b46b245=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0052_xx, t2_tc_35_idx_0052_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0052_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIT(16),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (0);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (1);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (2);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (3);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (4);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (5);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (6);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (7);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (8);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (9);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (10);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (11);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (12);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (13);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (14);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (15);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (16);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (17);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (18);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (19);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (20);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (21);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (22);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (23);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (24);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (25);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (26);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (27);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (28);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (29);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (30);
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_35_idx_0052_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0052_xx MODIFY target BIT(32), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0052_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIT(32),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (0);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (1);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (2);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (3);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (4);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (5);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (6);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (7);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (8);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (9);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (10);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (11);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (12);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (13);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (14);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (15);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (16);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (17);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (18);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (19);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (20);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (21);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (22);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (23);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (24);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (25);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (26);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (27);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (28);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (29);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (30);
INSERT INTO t2_tc_35_idx_0052_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_35_idx_0052_xx;
SELECT 'TC-35-IDX-0052-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0052_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0052_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0052-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0052_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0052_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0052_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0052_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0052-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0052_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0052_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0052-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0052_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0052_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0052_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0052_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0052-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(32)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(32) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0052_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0052_xx (target) VALUES (0);

-- Test Case: TC-35-IDX-0053-XX
-- Index integrity: SECONDARY index on target
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: BIT-04
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=5f0c5a1459fa column_type=bit(64) index_kind=SECONDARY
DROP TABLE IF EXISTS t1_tc_35_idx_0053_xx, t2_tc_35_idx_0053_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0053_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIT(32),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (0);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (1);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (2);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (3);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (4);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (5);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (6);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (7);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (8);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (9);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (10);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (11);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (12);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (13);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (14);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (15);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (16);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (17);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (18);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (19);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (20);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (21);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (22);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (23);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (24);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (25);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (26);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (27);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (28);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (29);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (30);
INSERT INTO t1_tc_35_idx_0053_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_35_idx_0053_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0053_xx MODIFY target BIT(64), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0053_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIT(64),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  INDEX idx_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (0);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (1);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (2);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (3);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (4);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (5);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (6);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (7);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (8);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (9);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (10);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (11);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (12);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (13);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (14);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (15);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (16);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (17);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (18);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (19);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (20);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (21);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (22);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (23);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (24);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (25);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (26);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (27);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (28);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (29);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (30);
INSERT INTO t2_tc_35_idx_0053_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_35_idx_0053_xx;
SELECT 'TC-35-IDX-0053-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index idx_target on ','t1_tc_35_idx_0053_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0053_xx' AND index_name='idx_target' AND column_name='target';
SELECT 'TC-35-IDX-0053-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0053_xx FORCE INDEX(idx_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0053_xx IGNORE INDEX(idx_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0053_xx FORCE INDEX(idx_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0053_xx IGNORE INDEX(idx_target))) AS mismatch;
SELECT 'TC-35-IDX-0053-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0053_xx FORCE INDEX(idx_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0053_xx IGNORE INDEX(idx_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0053-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0053_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0053_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0053_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0053_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0053-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0053_xx' AND column_name='target';

-- Test Case: TC-35-IDX-0054-XX
-- Index integrity: UNIQUE index on target
-- Type: BIT(32) -> BIT(64), Algorithm: inplace, Expected: SUCCESS
-- Transition ID: BIT-04
-- @expect alter=SUCCESS build=SUCCESS assertions=5 alter_sha=7b0f4c991b04 column_type=bit(64) index_kind=UNIQUE neg_probe=9ed52bba3c3d=1062
DROP TABLE IF EXISTS t1_tc_35_idx_0054_xx, t2_tc_35_idx_0054_xx;
SET SESSION sql_mode = 'STRICT_TRANS_TABLES';
CREATE TABLE t1_tc_35_idx_0054_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIT(32),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (0);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (1);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (2);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (3);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (4);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (5);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (6);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (7);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (8);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (9);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (10);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (11);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (12);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (13);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (14);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (15);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (16);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (17);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (18);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (19);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (20);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (21);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (22);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (23);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (24);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (25);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (26);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (27);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (28);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (29);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (30);
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (31);
ANALYZE TABLE t1_tc_35_idx_0054_xx;
-- ALTER expected SUCCESS
ALTER TABLE t1_tc_35_idx_0054_xx MODIFY target BIT(64), ALGORITHM=INPLACE, LOCK=NONE;
CREATE TABLE t2_tc_35_idx_0054_xx (
  id INT NOT NULL AUTO_INCREMENT,
  target BIT(64),
  pad VARCHAR(20) DEFAULT 'pad',
  PRIMARY KEY (id),
  UNIQUE INDEX uq_target (target)
) ENGINE=InnoDB;
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (0);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (1);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (2);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (3);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (4);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (5);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (6);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (7);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (8);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (9);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (10);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (11);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (12);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (13);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (14);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (15);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (16);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (17);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (18);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (19);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (20);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (21);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (22);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (23);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (24);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (25);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (26);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (27);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (28);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (29);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (30);
INSERT INTO t2_tc_35_idx_0054_xx (target) VALUES (31);
ANALYZE TABLE t2_tc_35_idx_0054_xx;
SELECT 'TC-35-IDX-0054-XX#IDX_PRESENT' AS test_id,
       IF(COUNT(*)=1,'PASS','FAIL') AS result,
       CONCAT('index uq_target on ','t1_tc_35_idx_0054_xx',' columns found=',COUNT(*)) AS mismatch
FROM information_schema.statistics
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0054_xx' AND index_name='uq_target' AND column_name='target';
SELECT 'TC-35-IDX-0054-XX#IDX_CONSISTENT' AS test_id,
       IF((SELECT COUNT(*) FROM t1_tc_35_idx_0054_xx FORCE INDEX(uq_target)) = (SELECT COUNT(*) FROM t1_tc_35_idx_0054_xx IGNORE INDEX(uq_target)),'PASS','FAIL') AS result,
       CONCAT('force=',(SELECT COUNT(*) FROM t1_tc_35_idx_0054_xx FORCE INDEX(uq_target)),' ignore=',(SELECT COUNT(*) FROM t1_tc_35_idx_0054_xx IGNORE INDEX(uq_target))) AS mismatch;
SELECT 'TC-35-IDX-0054-XX#IDX_SCAN_HASH' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0054_xx FORCE INDEX(uq_target) ORDER BY id) x)
          = (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED))
             FROM (SELECT id, target FROM t1_tc_35_idx_0054_xx IGNORE INDEX(uq_target) ORDER BY id) y),'PASS','FAIL') AS result,
       'index-scan hash != table-scan hash' AS mismatch;
SELECT 'TC-35-IDX-0054-XX#CRC_ORACLE' AS test_id,
       IF((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0054_xx) <=> (SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0054_xx),'PASS','FAIL') AS result,
       CONCAT('t1=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t1_tc_35_idx_0054_xx),'NULL'),' t2=',IFNULL((SELECT BIT_XOR(CAST(CRC32(CONCAT_WS(0x7C, id, IFNULL(target,'~N~'))) AS UNSIGNED)) FROM t2_tc_35_idx_0054_xx),'NULL')) AS mismatch;
SELECT 'TC-35-IDX-0054-XX#META' AS test_id,
       IF(COUNT(*)=1
          AND MAX(column_type)='bit(64)'
          AND MAX(is_nullable)='YES'
          AND ((MAX(column_default) IS NOT NULL) = 0)
          AND (MAX(character_set_name) <=> NULL)
          AND (MAX(collation_name) <=> NULL)
          AND (MAX(extra) <=> '')
          AND MAX(ordinal_position)=2,'PASS','FAIL') AS result,
       CONCAT('rows=',COUNT(*),
              ' actual[type=',IFNULL(MAX(column_type),'<missing>'),
                     ' nullable=',IFNULL(MAX(is_nullable),'<missing>'),
                     ' has_default=',(MAX(column_default) IS NOT NULL),
                     ' charset=',IFNULL(MAX(character_set_name),'NULL'),
                     ' collation=',IFNULL(MAX(collation_name),'NULL'),
                     ' extra=',IFNULL(MAX(extra),'NULL'),
                     ' pos=',IFNULL(MAX(ordinal_position),-1),']',
              'want[type=bit(64) nullable=YES has_default=0 charset=NULL collation=NULL extra= pos=2]') AS mismatch
FROM information_schema.columns
WHERE table_schema=DATABASE() AND table_name='t1_tc_35_idx_0054_xx' AND column_name='target';
-- 负向探针：唯一约束必须仍然生效（重复值必须被拒 1062）
INSERT INTO t1_tc_35_idx_0054_xx (target) VALUES (0);

